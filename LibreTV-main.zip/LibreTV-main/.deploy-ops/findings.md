## 部署分析发现

### 2026-05-25 P1 快速扫描发现

- 原始 Dockerfile 使用 `node:lts-alpine`，需改为 Debian slim 基础镜像
- 原始 docker-compose.yml 缺少自定义 network、健康检查引用 .env 变量
- 原始 compose 使用 named volume（已注释），需改为 bind mount + .env 管理
- 环境变量 `{{PASSWORD}}` 通过服务器端注入到 HTML，需确保 Dockerfile 不影响此机制
- server.mjs 使用 dotenv 加载 .env，需确保容器内 .env 正确注入
- 项目无数据库/缓存依赖，部署简单
- .dockerignore 已排除 .env* 文件，需注意 compose 方式下 .env 通过环境变量注入而非文件