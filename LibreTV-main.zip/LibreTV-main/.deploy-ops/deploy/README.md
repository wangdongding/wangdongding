# LibreTV Docker 部署指南

## 项目概述

LibreTV 是一个免费在线视频搜索与观看平台，基于 Node.js + Express 后端 + 纯前端 HTML/JS/CSS，无数据库依赖。

## 部署架构

```
┌──────────────────────────────────────────┐
│  Docker Host                             │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │  libretv container                 │  │
│  │  ├─ Express server (PORT)          │  │
│  │  ├─ 静态文件服务                   │  │
│  │  ├─ /proxy 代理接口               │  │
│  │  └─ 密码验证机制                   │  │
│  └────────────────────────────────────┘  │
│       │                                  │
│       │ HOST_PORT:8899 ←→ PORT:8080      │
│       │                                  │
│  ┌────────────────────────────────────┐  │
│  │  bind mount: DATA_DIR/libretv      │  │
│  └────────────────────────────────────┘  │
└──────────────────────────────────────────┘
```

## 端口映射表

| 容器端口 | 主机端口 | 说明 |
|----------|----------|------|
| 8080 | 8899 | Web 服务端口（可通过 .env 中的 HOST_PORT 自定义） |

## 快速部署步骤

### 1. 准备部署文件

将 `.deploy-ops/deploy/` 目录下的所有文件拷贝到目标服务器的工作目录：

```
Dockerfile.libretv
docker-compose.yml
.env.example
```

同时将项目源码（整个 LibreTV-main 目录）也拷贝到同一工作目录。

### 2. 配置环境变量

```bash
cp .env.example .env
```

编辑 `.env` 文件，**必须设置** `PASSWORD`：

```env
PASSWORD=your_secure_password
HOST_PORT=8899
```

### 3. 构建镜像

```bash
docker compose build
```

### 4. 启动服务

```bash
docker compose up -d
```

### 5. 验证部署

```bash
# 检查容器状态
docker compose ps

# 查看日志
docker compose logs -f libretv

# 浏览器访问
http://<服务器IP>:8899
```

## 环境变量说明

| 变量 | 默认值 | 必填 | 说明 |
|------|--------|------|------|
| PASSWORD | 空 | **是** | 访问密码，为空则首次访问需自行设置 |
| PORT | 8080 | 否 | 容器内服务端口 |
| HOST_PORT | 8899 | 否 | 主机映射端口 |
| CONTAINER_NAME | libretv | 否 | 容器名称 |
| CORS_ORIGIN | * | 否 | 跨域来源 |
| DEBUG | false | 否 | 调试模式 |
| REQUEST_TIMEOUT | 5000 | 否 | 请求超时(ms) |
| MAX_RETRIES | 2 | 否 | 重试次数 |
| CACHE_MAX_AGE | 1d | 否 | 缓存时间 |
| DATA_DIR | ./data | 否 | 数据持久化目录 |
| RESTART_POLICY | unless-stopped | 否 | 重启策略 |

## 常见问题

### Q: 访问时提示"请设置密码"
A: 编辑 `.env` 文件，设置 `PASSWORD` 值，然后 `docker compose up -d` 重启。

### Q: 构建时 npm install 失败
A: 检查内网 nexus.yuwei.com npm 镜像源是否可达。若不可达，修改 Dockerfile.libretv 中的 `npm config set registry` 为可用源。

### Q: 端口冲突
A: 修改 `.env` 中的 `HOST_PORT` 为其他可用端口。

### Q: 如何查看调试日志
A: 设置 `.env` 中 `DEBUG=true`，重启容器后查看 `docker compose logs`。

## 维护说明

### 更新镜像

```bash
docker compose build --no-cache
docker compose up -d
```

### 停止服务

```bash
docker compose down
```

### 数据备份

持久化数据在 `.env` 中 `DATA_DIR` 指定的目录下，定期备份该目录即可。