package com.movie.dto;

import lombok.Data;

@Data
public class PageResult<T> {

    private List<T> items;
    private long total;
    private int page;
    private int size;

    public static <T> PageResult<T> of(org.springframework.data.domain.Page<T> page) {
        PageResult<T> result = new PageResult<>();
        result.setItems(page.getContent());
        result.setTotal(page.getTotalElements());
        result.setPage(page.getNumber());
        result.setSize(page.getSize());
        return result;
    }
}