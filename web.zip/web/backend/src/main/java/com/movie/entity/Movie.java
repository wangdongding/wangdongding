package com.movie.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "movie")
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String coverUrl;

    @Column(nullable = false)
    private Integer sourceType; // 1=本地文件, 2=远程链接

    @Column(nullable = false, length = 1000)
    private String sourceUrl;

    @Column(nullable = false, length = 10)
    private String sourceMode; // direct / proxy / iframe

    @Column(length = 20)
    private String format;

    private Integer duration; // 秒

    private Long fileSize; // 字节

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}