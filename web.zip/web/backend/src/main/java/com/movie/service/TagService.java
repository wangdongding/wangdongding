package com.movie.service;

import com.movie.dto.TagDTO;
import com.movie.entity.Tag;
import com.movie.repository.TagRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TagService {

    private final TagRepository tagRepository;

    public List<TagDTO> list() {
        return tagRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public TagDTO create(TagDTO dto) {
        if (tagRepository.existsByName(dto.getName())) {
            throw new RuntimeException("标签已存在");
        }
        Tag tag = new Tag();
        tag.setName(dto.getName());
        tag = tagRepository.save(tag);
        return toDTO(tag);
    }

    public void delete(Long id) {
        tagRepository.deleteById(id);
    }

    private TagDTO toDTO(Tag tag) {
        TagDTO dto = new TagDTO();
        dto.setId(tag.getId());
        dto.setName(tag.getName());
        return dto;
    }
}