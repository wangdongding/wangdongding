package com.movie.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class MovieCreateDTO {

    @NotBlank
    private String title;

    private String description;

    private String coverUrl;

    @NotNull
    private Integer sourceType; // 1=本地, 2=远程

    @NotBlank
    private String sourceUrl;

    @NotBlank
    private String sourceMode; // direct / proxy / iframe

    private String format;

    private Integer duration;

    private Long fileSize;

    private Long categoryId;

    private List<Long> tagIds;
}