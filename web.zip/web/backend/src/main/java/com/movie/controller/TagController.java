package com.movie.controller;

import com.movie.dto.TagDTO;
import com.movie.service.TagService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tags")
@RequiredArgsConstructor
public class TagController {

    private final TagService tagService;

    @GetMapping
    public List<TagDTO> list() {
        return tagService.list();
    }

    @PostMapping
    public TagDTO create(@RequestBody @jakarta.validation.Valid TagDTO dto) {
        return tagService.create(dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        tagService.delete(id);
    }
}