package com.movie.service;

import com.movie.dto.MovieVO;
import com.movie.dto.PageResult;
import com.movie.entity.Favorite;
import com.movie.entity.Movie;
import com.movie.repository.FavoriteRepository;
import com.movie.repository.MovieRepository;
import com.movie.repository.MovieTagRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FavoriteService {

    private final FavoriteRepository favoriteRepository;
    private final MovieRepository movieRepository;
    private final MovieTagRepository movieTagRepository;

    public PageResult<MovieVO> list(int page, int size) {
        Page<Favorite> favoritePage = favoriteRepository.findAllByOrderByCreatedAtDesc(PageRequest.of(page, size));
        Page<MovieVO> voPage = favoritePage.map(f -> toVO(f.getMovie()));
        return PageResult.of(voPage);
    }

    @Transactional
    public void add(Long movieId) {
        if (favoriteRepository.existsByMovieId(movieId)) {
            return; // 已收藏，忽略
        }
        Movie movie = movieRepository.findById(movieId).orElseThrow(() -> new RuntimeException("影片不存在"));
        Favorite favorite = new Favorite();
        favorite.setMovie(movie);
        favoriteRepository.save(favorite);
    }

    @Transactional
    public void remove(Long movieId) {
        favoriteRepository.deleteByMovieId(movieId);
    }

    private MovieVO toVO(Movie movie) {
        MovieVO vo = new MovieVO();
        vo.setId(movie.getId());
        vo.setTitle(movie.getTitle());
        vo.setCoverUrl(movie.getCoverUrl());
        vo.setSourceType(movie.getSourceType());
        vo.setSourceUrl(movie.getSourceUrl());
        vo.setSourceMode(movie.getSourceMode());
        vo.setFormat(movie.getFormat());
        vo.setDuration(movie.getDuration());
        vo.setCategoryName(movie.getCategory() != null ? movie.getCategory().getName() : null);
        vo.setTagNames(movieTagRepository.findByMovieId(movie.getId()).stream()
                .map(mt -> mt.getTag().getName()).collect(Collectors.toList());
        return vo;
    }
}