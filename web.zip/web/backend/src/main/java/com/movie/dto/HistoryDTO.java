package com.movie.dto;

import lombok.Data;

@Data
public class HistoryDTO {

    private Integer progress;
    private Integer duration;
}