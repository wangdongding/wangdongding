package com.movie.repository;

import com.movie.entity.MovieTag;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MovieTagRepository extends JpaRepository<MovieTag, Long> {
    List<MovieTag> findByMovieId(Long movieId);
    void deleteByMovieId(Long movieId);
    List<MovieTag> findByTagId(Long tagId);
}