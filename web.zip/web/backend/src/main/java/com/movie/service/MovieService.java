package com.movie.service;

import com.movie.dto.*;
import com.movie.entity.*;
import com.movie.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MovieService {

    private final MovieRepository movieRepository;
    private final CategoryRepository categoryRepository;
    private final TagRepository tagRepository;
    private final MovieTagRepository movieTagRepository;
    private final HistoryRepository historyRepository;

    public PageResult<MovieVO> list(int page, int size, Long categoryId) {
        PageRequest pageable = PageRequest.of(page, size);
        Page<Movie> moviePage;
        if (categoryId != null) {
            moviePage = movieRepository.findByCategoryId(categoryId, pageable);
        } else {
            moviePage = movieRepository.findAll(pageable);
        }
        Page<MovieVO> voPage = moviePage.map(this::toVO);
        return PageResult.of(voPage);
    }

    public MovieVO getById(Long id) {
        Movie movie = movieRepository.findById(id).orElseThrow(() -> new RuntimeException("影片不存在"));
        MovieVO vo = toVO(movie);
        // 查询播放进度
        Optional<PlayHistory> history = historyRepository.findByMovieId(id);
        history.ifPresent(h -> {
            vo.setProgress(h.getProgress());
            vo.setTotalDuration(h.getDuration());
        });
        return vo;
    }

    public PageResult<MovieVO> search(String keyword, Long categoryId, int page, int size) {
        PageRequest pageable = PageRequest.of(page, size);
        Page<Movie> moviePage;
        if (categoryId != null) {
            moviePage = movieRepository.searchByKeywordAndCategory(keyword, categoryId, pageable);
        } else {
            moviePage = movieRepository.searchByKeyword(keyword, pageable);
        }
        Page<MovieVO> voPage = moviePage.map(this::toVO);
        return PageResult.of(voPage);
    }

    @Transactional
    public MovieVO create(MovieCreateDTO dto) {
        Movie movie = new Movie();
        movie.setTitle(dto.getTitle());
        movie.setDescription(dto.getDescription());
        movie.setCoverUrl(dto.getCoverUrl());
        movie.setSourceType(dto.getSourceType());
        movie.setSourceUrl(dto.getSourceUrl());
        movie.setSourceMode(dto.getSourceMode());
        movie.setFormat(dto.getFormat());
        movie.setDuration(dto.getDuration());
        movie.setFileSize(dto.getFileSize());

        if (dto.getCategoryId() != null) {
            Category category = categoryRepository.findById(dto.getCategoryId())
                    .orElseThrow(() -> new RuntimeException("分类不存在"));
            movie.setCategory(category);
        }

        movie = movieRepository.save(movie);

        if (dto.getTagIds() != null) {
            saveMovieTags(movie, dto.getTagIds());
        }

        return toVO(movie);
    }

    @Transactional
    public MovieVO update(Long id, MovieUpdateDTO dto) {
        Movie movie = movieRepository.findById(id).orElseThrow(() -> new RuntimeException("影片不存在"));

        if (dto.getTitle() != null) movie.setTitle(dto.getTitle());
        if (dto.getDescription() != null) movie.setDescription(dto.getDescription());
        if (dto.getCoverUrl() != null) movie.setCoverUrl(dto.getCoverUrl());
        if (dto.getSourceUrl() != null) movie.setSourceUrl(dto.getSourceUrl());
        if (dto.getSourceMode() != null) movie.setSourceMode(dto.getSourceMode());
        if (dto.getFormat() != null) movie.setFormat(dto.getFormat());
        if (dto.getDuration() != null) movie.setDuration(dto.getDuration());
        if (dto.getFileSize() != null) movie.setFileSize(dto.getFileSize());

        if (dto.getCategoryId() != null) {
            Category category = categoryRepository.findById(dto.getCategoryId())
                    .orElseThrow(() -> new RuntimeException("分类不存在"));
            movie.setCategory(category);
        }

        movie = movieRepository.save(movie);

        if (dto.getTagIds() != null) {
            movieTagRepository.deleteByMovieId(id);
            saveMovieTags(movie, dto.getTagIds());
        }

        return toVO(movie);
    }

    @Transactional
    public void delete(Long id) {
        movieTagRepository.deleteByMovieId(id);
        historyRepository.deleteByMovieId(id);
        favoriteRepository.deleteByMovieId(id);
        movieRepository.deleteById(id);
    }

    // 扫描本地目录（简化版：返回待扫描提示，实际需要调用 FFprobe）
    @Transactional
    public int scanLocalDirectory(String dirPath) {
        // TODO: 实现 FFprobe 扫描逻辑
        return 0;
    }

    private void saveMovieTags(Movie movie, List<Long> tagIds) {
        for (Long tagId : tagIds) {
            Tag tag = tagRepository.findById(tagId).orElseThrow(() -> new RuntimeException("标签不存在"));
            MovieTag movieTag = new MovieTag();
            movieTag.setMovie(movie);
            movieTag.setTag(tag);
            movieTagRepository.save(movieTag);
        }
    }

    private MovieVO toVO(Movie movie) {
        MovieVO vo = new MovieVO();
        vo.setId(movie.getId());
        vo.setTitle(movie.getTitle());
        vo.setDescription(movie.getDescription());
        vo.setCoverUrl(movie.getCoverUrl());
        vo.setSourceType(movie.getSourceType());
        vo.setSourceUrl(movie.getSourceUrl());
        vo.setSourceMode(movie.getSourceMode());
        vo.setFormat(movie.getFormat());
        vo.setDuration(movie.getDuration());
        vo.setFileSize(movie.getFileSize());
        vo.setCategoryName(movie.getCategory() != null ? movie.getCategory().getName() : null);

        List<MovieTag> movieTags = movieTagRepository.findByMovieId(movie.getId());
        vo.setTagNames(movieTags.stream()
                .map(mt -> mt.getTag().getName())
                .collect(Collectors.toList()));

        return vo;
    }

    // 需要注入 FavoriteRepository，在 delete 方法中使用
    private final FavoriteRepository favoriteRepository;
}