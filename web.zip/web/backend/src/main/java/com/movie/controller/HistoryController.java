package com.movie.controller;

import com.movie.dto.HistoryDTO;
import com.movie.dto.MovieVO;
import com.movie.dto.PageResult;
import com.movie.service.HistoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/history")
@RequiredArgsConstructor
public class HistoryController {

    private final HistoryService historyService;

    @GetMapping
    public PageResult<MovieVO> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return historyService.list(page, size);
    }

    @PostMapping("/{movieId}")
    public void updateProgress(@PathVariable Long movieId, @RequestBody HistoryDTO dto) {
        historyService.updateProgress(movieId, dto);
    }

    @DeleteMapping("/{movieId}")
    public void remove(@PathVariable Long movieId) {
        historyService.remove(movieId);
    }

    @DeleteMapping
    public void clearAll() {
        historyService.clearAll();
    }
}