package com.movie.repository;

import com.movie.entity.Favorite;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FavoriteRepository extends JpaRepository<Favorite, Long> {
    Page<Favorite> findAllByOrderByCreatedAtDesc(Pageable pageable);
    boolean existsByMovieId(Long movieId);
    void deleteByMovieId(Long movieId);
}