package com.movie.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Slf4j
@Service
public class CoverService {

    @Value("${app.cover.base-path:/data/covers}")
    private String coverBasePath;

    public String upload(MultipartFile file) {
        String originalFilename = file.getOriginalFilename();
        String ext = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            ext = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
        String filename = UUID.randomUUID().toString() + ext;

        Path dir = Paths.get(coverBasePath);
        try {
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
            }
            Path target = dir.resolve(filename);
            file.transferTo(target.toFile());
            return "/covers/" + filename;
        } catch (IOException e) {
            log.error("封面上传失败", e);
            throw new RuntimeException("封面上传失败: " + e.getMessage());
        }
    }
}