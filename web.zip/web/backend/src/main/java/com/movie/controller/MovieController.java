package com.movie.controller;

import com.movie.dto.*;
import com.movie.service.MovieService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/movies")
@RequiredArgsConstructor
public class MovieController {

    private final MovieService movieService;

    @GetMapping
    public PageResult<MovieVO> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size,
            @RequestParam(required = false) Long categoryId) {
        return movieService.list(page, size, categoryId);
    }

    @GetMapping("/{id}")
    public MovieVO getById(@PathVariable Long id) {
        return movieService.getById(id);
    }

    @GetMapping("/search")
    public PageResult<MovieVO> search(
            @RequestParam String q,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return movieService.search(q, categoryId, page, size);
    }

    @PostMapping
    public MovieVO create(@RequestBody @jakarta.validation.Valid MovieCreateDTO dto) {
        return movieService.create(dto);
    }

    @PutMapping("/{id}")
    public MovieVO update(@PathVariable Long id, @RequestBody MovieUpdateDTO dto) {
        return movieService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        movieService.delete(id);
    }

    @PostMapping("/scan")
    public int scan(@RequestParam String dirPath) {
        return movieService.scanLocalDirectory(dirPath);
    }
}