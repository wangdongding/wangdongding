package com.movie.controller;

import com.movie.service.CoverService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/covers")
@RequiredArgsConstructor
public class CoverController {

    private final CoverService coverService;

    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file) {
        return coverService.upload(file);
    }
}