package com.movie.repository;

import com.movie.entity.PlayHistory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface HistoryRepository extends JpaRepository<PlayHistory, Long> {
    Page<PlayHistory> findAllByOrderByPlayedAtDesc(Pageable pageable);
    Optional<PlayHistory> findByMovieId(Long movieId);
    void deleteByMovieId(Long movieId);
    void deleteAll();
}