package com.movie.repository;

import com.movie.entity.Movie;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MovieRepository extends JpaRepository<Movie, Long> {

    Page<Movie> findByCategoryId(Long categoryId, Pageable pageable);

    @Query(value = "SELECT * FROM movie WHERE MATCH(title, description) AGAINST(:keyword IN NATURAL LANGUAGE MODE)",
            nativeQuery = true)
    Page<Movie> searchByKeyword(@Param("keyword") String keyword, Pageable pageable);

    @Query(value = "SELECT * FROM movie WHERE MATCH(title, description) AGAINST(:keyword IN NATURAL LANGUAGE MODE) AND category_id = :categoryId",
            nativeQuery = true)
    Page<Movie> searchByKeywordAndCategory(@Param("keyword") String keyword, @Param("categoryId") Long categoryId, Pageable pageable);

    List<Movie> findBySourceUrlIn(List<String> sourceUrls);

    boolean existsBySourceUrl(String sourceUrl);
}