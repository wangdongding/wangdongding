package com.movie.dto;

import lombok.Data;

import java.util.List;

@Data
public class MovieUpdateDTO {

    private String title;
    private String description;
    private String coverUrl;
    private String sourceUrl;
    private String sourceMode;
    private String format;
    private Integer duration;
    private Long fileSize;
    private Long categoryId;
    private List<Long> tagIds;
}