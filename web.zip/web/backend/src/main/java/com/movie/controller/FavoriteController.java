package com.movie.controller;

import com.movie.dto.MovieVO;
import com.movie.dto.PageResult;
import com.movie.service.FavoriteService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/favorites")
@RequiredArgsConstructor
public class FavoriteController {

    private final FavoriteService favoriteService;

    @GetMapping
    public PageResult<MovieVO> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return favoriteService.list(page, size);
    }

    @PostMapping("/{movieId}")
    public void add(@PathVariable Long movieId) {
        favoriteService.add(movieId);
    }

    @DeleteMapping("/{movieId}")
    public void remove(@PathVariable Long movieId) {
        favoriteService.remove(movieId);
    }
}