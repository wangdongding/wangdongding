package com.movie.service;

import com.movie.dto.HistoryDTO;
import com.movie.dto.MovieVO;
import com.movie.dto.PageResult;
import com.movie.entity.Movie;
import com.movie.entity.PlayHistory;
import com.movie.repository.HistoryRepository;
import com.movie.repository.MovieRepository;
import com.movie.repository.MovieTagRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HistoryService {

    private final HistoryRepository historyRepository;
    private final MovieRepository movieRepository;
    private final MovieTagRepository movieTagRepository;

    public PageResult<MovieVO> list(int page, int size) {
        Page<PlayHistory> historyPage = historyRepository.findAllByOrderByPlayedAtDesc(PageRequest.of(page, size));
        Page<MovieVO> voPage = historyPage.map(h -> {
            MovieVO vo = toVO(h.getMovie());
            vo.setProgress(h.getProgress());
            vo.setTotalDuration(h.getDuration());
            return vo;
        });
        return PageResult.of(voPage);
    }

    @Transactional
    public void updateProgress(Long movieId, HistoryDTO dto) {
        Movie movie = movieRepository.findById(movieId).orElseThrow(() -> new RuntimeException("影片不存在"));
        PlayHistory history = historyRepository.findByMovieId(movieId)
                .orElseGet(() -> {
                    PlayHistory newHistory = new PlayHistory();
                    newHistory.setMovie(movie);
                    return newHistory;
                });
        history.setProgress(dto.getProgress());
        history.setDuration(dto.getDuration());
        historyRepository.save(history);
    }

    @Transactional
    public void remove(Long movieId) {
        historyRepository.deleteByMovieId(movieId);
    }

    @Transactional
    public void clearAll() {
        historyRepository.deleteAll();
    }

    private MovieVO toVO(Movie movie) {
        MovieVO vo = new MovieVO();
        vo.setId(movie.getId());
        vo.setTitle(movie.getTitle());
        vo.setCoverUrl(movie.getCoverUrl());
        vo.setSourceType(movie.getSourceType());
        vo.setSourceUrl(movie.getSourceUrl());
        vo.setSourceMode(movie.getSourceMode());
        vo.setFormat(movie.getFormat());
        vo.setDuration(movie.getDuration());
        vo.setCategoryName(movie.getCategory() != null ? movie.getCategory().getName() : null);
        vo.setTagNames(movieTagRepository.findByMovieId(movie.getId()).stream()
                .map(mt -> mt.getTag().getName()).collect(Collectors.toList());
        return vo;
    }
}