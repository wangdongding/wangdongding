package com.movie.dto;

import lombok.Data;

import java.util.List;

@Data
public class MovieVO {

    private Long id;
    private String title;
    private String description;
    private String coverUrl;
    private Integer sourceType;
    private String sourceUrl;
    private String sourceMode;
    private String format;
    private Integer duration;
    private Long fileSize;
    private String categoryName;
    private List<String> tagNames;
    private Integer progress; // 播放进度（秒），来自历史记录
    private Integer totalDuration; // 总时长（秒），来自历史记录
}