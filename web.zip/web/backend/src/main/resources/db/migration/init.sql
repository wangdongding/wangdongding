-- 影片搜索与播放网站 数据库初始化

CREATE DATABASE IF NOT EXISTS movie_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE movie_db;

-- 分类表
CREATE TABLE IF NOT EXISTS category (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    sort_order INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 标签表
CREATE TABLE IF NOT EXISTS tag (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 影片表
CREATE TABLE IF NOT EXISTS movie (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    cover_url VARCHAR(500),
    source_type TINYINT NOT NULL COMMENT '1=本地文件, 2=远程链接',
    source_url VARCHAR(1000) NOT NULL,
    source_mode VARCHAR(10) NOT NULL DEFAULT 'direct' COMMENT 'direct/proxy/iframe',
    format VARCHAR(20),
    duration INT COMMENT '时长（秒）',
    file_size BIGINT COMMENT '文件大小（字节）',
    category_id BIGINT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES category(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 全文索引（中文 ngram 解析器）
CREATE FULLTEXT INDEX ft_title_desc ON movie(title, description) WITH PARSER ngram;

-- 影片-标签关联表
CREATE TABLE IF NOT EXISTS movie_tag (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    movie_id BIGINT NOT NULL,
    tag_id BIGINT NOT NULL,
    FOREIGN KEY (movie_id) REFERENCES movie(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tag(id) ON DELETE CASCADE,
    UNIQUE KEY uk_movie_tag (movie_id, tag_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 收藏表
CREATE TABLE IF NOT EXISTS favorite (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    movie_id BIGINT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movie(id) ON DELETE CASCADE,
    UNIQUE KEY uk_favorite_movie (movie_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 播放历史表
CREATE TABLE IF NOT EXISTS play_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    movie_id BIGINT NOT NULL,
    progress INT NOT NULL DEFAULT 0 COMMENT '播放进度（秒）',
    duration INT NOT NULL DEFAULT 0 COMMENT '影片总时长（秒）',
    played_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movie(id) ON DELETE CASCADE,
    UNIQUE KEY uk_history_movie (movie_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 初始分类数据
INSERT INTO category (name, sort_order) VALUES
('电影', 1),
('电视剧', 2),
('动漫', 3),
('纪录片', 4),
('综艺', 5);