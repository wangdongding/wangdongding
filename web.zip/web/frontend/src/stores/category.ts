import { defineStore } from 'pinia'
import { ref } from 'vue'
import { categoryApi, type CategoryDTO } from '../api/category'

export const useCategoryStore = defineStore('category', () => {
  const categories = ref<CategoryDTO[]>([])
  const loading = ref(false)

  async function fetchCategories() {
    loading.value = true
    try {
      categories.value = await categoryApi.list()
    } finally {
      loading.value = false
    }
  }

  return { categories, loading, fetchCategories }
})