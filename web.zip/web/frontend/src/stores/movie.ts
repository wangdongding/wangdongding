import { defineStore } from 'pinia'
import { ref } from 'vue'
import { movieApi, type MovieVO, type PageResult } from '../api/movie'

export const useMovieStore = defineStore('movie', () => {
  const movies = ref<MovieVO[]>([])
  const total = ref(0)
  const currentPage = ref(0)
  const loading = ref(false)

  async function fetchMovies(page: number = 0, size: number = 12, categoryId?: number) {
    loading.value = true
    try {
      const result: PageResult<MovieVO> = await movieApi.list(page, size, categoryId)
      movies.value = result.items
      total.value = result.total
      currentPage.value = result.page
    } finally {
      loading.value = false
    }
  }

  async function searchMovies(q: string, categoryId?: number, page: number = 0, size: number = 12) {
    loading.value = true
    try {
      const result: PageResult<MovieVO> = await movieApi.search(q, categoryId, page, size)
      movies.value = result.items
      total.value = result.total
      currentPage.value = result.page
    } finally {
      loading.value = false
    }
  }

  return { movies, total, currentPage, loading, fetchMovies, searchMovies }
})