import api from './index'

export interface MovieVO {
  id: number
  title: string
  description?: string
  coverUrl?: string
  sourceType: number
  sourceUrl: string
  sourceMode: string
  format?: string
  duration?: number
  fileSize?: number
  categoryName?: string
  tagNames?: string[]
  progress?: number
  totalDuration?: number
}

export interface PageResult<T> {
  items: T[]
  total: number
  page: number
  size: number
}

export interface MovieCreateDTO {
  title: string
  description?: string
  coverUrl?: string
  sourceType: number
  sourceUrl: string
  sourceMode: string
  format?: string
  duration?: number
  fileSize?: number
  categoryId?: number
  tagIds?: number[]
}

export interface MovieUpdateDTO {
  title?: string
  description?: string
  coverUrl?: string
  sourceUrl?: string
  sourceMode?: string
  format?: string
  duration?: number
  fileSize?: number
  categoryId?: number
  tagIds?: number[]
}

export const movieApi = {
  list: (page: number, size: number, categoryId?: number) =>
    api.get<PageResult<MovieVO>>('/api/movies', { params: { page, size, categoryId } }),

  getById: (id: number) =>
    api.get<MovieVO>(`/api/movies/${id}`),

  search: (q: string, categoryId?: number, page?: number, size?: number) =>
    api.get<PageResult<MovieVO>>('/api/movies/search', { params: { q, categoryId, page, size } }),

  create: (data: MovieCreateDTO) =>
    api.post<MovieVO>('/api/movies', data),

  update: (id: number, data: MovieUpdateDTO) =>
    api.put<MovieVO>(`/api/movies/${id}`, data),

  delete: (id: number) =>
    api.delete(`/api/movies/${id}`),

  scan: (dirPath: string) =>
    api.post<number>('/api/movies/scan', null, { params: { dirPath } }),
}