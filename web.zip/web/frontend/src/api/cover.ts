import api from './index'

export const coverApi = {
  upload: (file: File) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post<string>('/api/covers/upload', formData)
  },
}