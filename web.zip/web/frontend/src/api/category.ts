import api from './index'

export interface CategoryDTO {
  id: number
  name: string
  sortOrder?: number
}

export const categoryApi = {
  list: () => api.get<CategoryDTO[]>('/api/categories'),
  create: (data: CategoryDTO) => api.post<CategoryDTO>('/api/categories', data),
  update: (id: number, data: CategoryDTO) => api.put<CategoryDTO>(`/api/categories/${id}`, data),
  delete: (id: number) => api.delete(`/api/categories/${id}`),
}