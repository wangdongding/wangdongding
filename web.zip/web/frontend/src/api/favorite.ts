import api from './index'
import type { MovieVO, PageResult } from './movie'

export const favoriteApi = {
  list: (page: number, size: number) =>
    api.get<PageResult<MovieVO>>('/api/favorites', { params: { page, size } }),
  add: (movieId: number) =>
    api.post(`/api/favorites/${movieId}`),
  remove: (movieId: number) =>
    api.delete(`/api/favorites/${movieId}`),
}