import api from './index'
import type { MovieVO, PageResult } from './movie'

export interface HistoryDTO {
  progress: number
  duration: number
}

export const historyApi = {
  list: (page: number, size: number) =>
    api.get<PageResult<MovieVO>>('/api/history', { params: { page, size } }),
  updateProgress: (movieId: number, data: HistoryDTO) =>
    api.post(`/api/history/${movieId}`, data),
  remove: (movieId: number) =>
    api.delete(`/api/history/${movieId}`),
  clearAll: () =>
    api.delete('/api/history'),
}