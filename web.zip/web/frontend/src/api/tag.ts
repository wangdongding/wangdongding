import api from './index'

export interface TagDTO {
  id: number
  name: string
}

export const tagApi = {
  list: () => api.get<TagDTO[]>('/api/tags'),
  create: (data: TagDTO) => api.post<TagDTO>('/api/tags', data),
  delete: (id: number) => api.delete(`/api/tags/${id}`),
}