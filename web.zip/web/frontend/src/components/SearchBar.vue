<template>
  <div class="search-bar">
    <el-input
      v-model="keyword"
      placeholder="搜索影片..."
      :prefix-icon="SearchIcon"
      clearable
      @keyup.enter="doSearch"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { Search as SearchIcon } from '@element-plus/icons-vue'

const router = useRouter()
const keyword = ref('')

function doSearch() {
  if (keyword.value.trim()) {
    router.push({ path: '/search', query: { q: keyword.value.trim() } })
  }
}
</script>

<style scoped>
.search-bar {
  width: 300px;
}

.search-bar .el-input {
  --el-input-bg-color: #0f3460;
  --el-input-text-color: #eee;
  --el-input-border-color: #0f3460;
  --el-input-placeholder-color: #888;
}
</style>