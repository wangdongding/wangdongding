<template>
  <div ref="playerContainer" class="video-player"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import Artplayer from 'artplayer'

const props = defineProps<{
  url: string
  mode: string // direct / proxy / iframe
  initialProgress?: number
}>()

const emit = defineEmits<{
  progress: [seconds: number]
}>()

const playerContainer = ref<HTMLElement>()
let art: Artplayer | null = null
let progressTimer: number | null = null

onMounted(() => {
  if (props.mode === 'iframe') return // iframe 模式不用 ArtPlayer

  let playUrl = props.url
  if (props.mode === 'proxy') {
    playUrl = `/proxy/?url=${encodeURIComponent(props.url)}`
  }

  art = new Artplayer({
    container: playerContainer.value!,
    url: playUrl,
    autoplay: false,
    pip: true,
    autoSize: true,
    autoMini: true,
    screenshot: true,
    setting: true,
    hotkey: true,
    fullscreen: true,
    fullscreenWeb: true,
  })

  art.on('ready', () => {
    if (props.initialProgress && props.initialProgress > 0) {
      art!.forward = props.initialProgress
    }
  })

  // 每 10 秒上报进度
  art.on('video:timeupdate', () => {
    if (!progressTimer) {
      progressTimer = window.setInterval(() => {
        if (art && art.playing) {
          emit('progress', art.currentTime)
        }
      }, 10000)
    }
  })
})

onBeforeUnmount(() => {
  if (progressTimer) clearInterval(progressTimer)
  if (art) art.destroy(false)
})

watch(() => props.url, (newUrl) => {
  if (art && newUrl) {
    let playUrl = newUrl
    if (props.mode === 'proxy') {
      playUrl = `/proxy/?url=${encodeURIComponent(newUrl)}`
    }
    art.switchUrl(playUrl)
  }
})
</script>

<style scoped>
.video-player {
  width: 100%;
  aspect-ratio: 16/9;
}
</style>