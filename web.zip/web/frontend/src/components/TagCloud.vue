<template>
  <div class="tag-cloud">
    <el-tag
      v-for="tag in tags"
      :key="tag.id"
      :effect="activeTagId === tag.id ? 'dark' : 'plain'"
      :type="activeTagId === tag.id ? 'danger' : 'info'"
      class="tag-item"
      @click="$emit('select', tag)"
    >
      {{ tag.name }}
    </el-tag>
  </div>
</template>

<script setup lang="ts">
import type { TagDTO } from '../api/tag'

defineProps<{ tags: TagDTO[]; activeTagId?: number }>()
defineEmits<{ select: [tag: TagDTO] }>()
</script>

<style scoped>
.tag-cloud {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.tag-item {
  cursor: pointer;
}
</style>