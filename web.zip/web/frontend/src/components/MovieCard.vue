<template>
  <div class="movie-card" @click="$router.push(`/play/${movie.id}`)">
    <div class="cover-wrapper">
      <img v-if="movie.coverUrl" :src="movie.coverUrl" :alt="movie.title" class="cover" />
      <div v-else class="cover-placeholder">
        <el-icon :size="48"><VideoPlay /></el-icon>
      </div>
      <span v-if="movie.format && movie.format !== 'mp4'" class="format-badge">{{ movie.format }}</span>
      <span v-if="movie.sourceType === 2" class="remote-badge">远程</span>
    </div>
    <div class="info">
      <h3 class="title">{{ movie.title }}</h3>
      <div class="meta">
        <span v-if="movie.categoryName">{{ movie.categoryName }}</span>
        <span v-if="movie.duration">{{ formatDuration(movie.duration) }}</span>
      </div>
      <div v-if="movie.tagNames?.length" class="tags">
        <el-tag v-for="tag in movie.tagNames" :key="tag" size="small" type="info">{{ tag }}</el-tag>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { VideoPlay } from '@element-plus/icons-vue'
import type { MovieVO } from '../api/movie'

defineProps<{ movie: MovieVO }>()

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
  return `${m}:${s.toString().padStart(2, '0')}`
}
</script>

<style scoped>
.movie-card {
  cursor: pointer;
  border-radius: 8px;
  overflow: hidden;
  background: #0f3460;
  transition: transform 0.2s, box-shadow 0.2s;
}

.movie-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 20px rgba(0,0,0,0.4);
}

.cover-wrapper {
  position: relative;
  width: 100%;
  aspect-ratio: 16/9;
  overflow: hidden;
}

.cover {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.cover-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #1a1a2e;
  color: #555;
}

.format-badge, .remote-badge {
  position: absolute;
  top: 8px;
  padding: 2px 6px;
  font-size: 12px;
  border-radius: 4px;
  color: #fff;
}

.format-badge {
  right: 8px;
  background: #e94560;
}

.remote-badge {
  left: 8px;
  background: #533483;
}

.info {
  padding: 10px 12px;
}

.title {
  font-size: 14px;
  color: #eee;
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.meta {
  display: flex;
  gap: 8px;
  font-size: 12px;
  color: #888;
  margin-top: 4px;
}

.tags {
  display: flex;
  gap: 4px;
  margin-top: 6px;
  flex-wrap: wrap;
}
</style>