import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      component: () => import('../layouts/MainLayout.vue'),
      children: [
        { path: '', name: 'home', component: () => import('../views/HomeView.vue') },
        { path: 'search', name: 'search', component: () => import('../views/SearchView.vue') },
        { path: 'play/:id', name: 'play', component: () => import('../views/PlayView.vue') },
        { path: 'favorites', name: 'favorites', component: () => import('../views/FavoriteView.vue') },
        { path: 'history', name: 'history', component: () => import('../views/HistoryView.vue') },
        {
          path: 'admin',
          name: 'admin',
          component: () => import('../views/admin/MovieManage.vue'),
        },
      ],
    },
  ],
})

export default router