<template>
  <el-container class="main-layout">
    <el-header class="header">
      <div class="header-left">
        <h1 class="logo" @click="$router.push('/')">影视库</h1>
        <SearchBar />
      </div>
      <el-menu mode="horizontal" :default-active="activeMenu" class="nav-menu" router>
        <el-menu-item index="/">首页</el-menu-item>
        <el-menu-item index="/favorites">收藏</el-menu-item>
        <el-menu-item index="/history">历史</el-menu-item>
        <el-menu-item index="/admin">管理</el-menu-item>
      </el-menu>
    </el-header>
    <el-main class="main-content">
      <router-view />
    </el-main>
  </el-container>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import SearchBar from '../components/SearchBar.vue'

const route = useRoute()
const activeMenu = computed(() => route.path)
</script>

<style scoped>
.main-layout {
  min-height: 100vh;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #1a1a2e;
  color: #fff;
  padding: 0 20px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 20px;
}

.logo {
  font-size: 20px;
  cursor: pointer;
  white-space: nowrap;
  color: #e94560;
}

.nav-menu {
  background: transparent;
  border-bottom: none;
}

.nav-menu .el-menu-item {
  color: #eee;
}

.nav-menu .el-menu-item.is-active {
  color: #e94560;
  border-bottom-color: #e94560;
}

.main-content {
  background: #16213e;
  min-height: calc(100vh - 60px);
}
</style>