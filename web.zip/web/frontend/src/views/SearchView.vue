<template>
  <div class="search-view">
    <h2 class="search-title">搜索结果：{{ keyword }}</h2>

    <div class="filters">
      <el-radio-group v-model="selectedCategory" size="small" @change="doSearch">
        <el-radio-button :value="undefined">全部</el-radio-button>
        <el-radio-button
          v-for="cat in categoryStore.categories"
          :key="cat.id"
          :value="cat.id"
        >
          {{ cat.name }}
        </el-radio-button>
      </el-radio-group>
    </div>

    <div v-loading="movieStore.loading" class="movie-grid">
      <MovieCard v-for="movie in movieStore.movies" :key="movie.id" :movie="movie" />
    </div>

    <el-empty v-if="!movieStore.loading && movieStore.movies.length === 0" description="未找到相关影片" />

    <div class="pagination-wrapper">
      <el-pagination
        v-model:current-page="pageNum"
        :page-size="12"
        :total="movieStore.total"
        layout="prev, pager, next"
        @current-change="onPageChange"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useCategoryStore } from '../stores/category'
import { useMovieStore } from '../stores/movie'
import MovieCard from '../components/MovieCard.vue'

const route = useRoute()
const categoryStore = useCategoryStore()
const movieStore = useMovieStore()

const keyword = ref('')
const selectedCategory = ref<number | undefined>(undefined)
const pageNum = ref(1)

onMounted(() => {
  categoryStore.fetchCategories()
  keyword.value = route.query.q as string || ''
  doSearch()
})

watch(() => route.query.q, (newQ) => {
  if (newQ) {
    keyword.value = newQ as string
    doSearch()
  }
})

function doSearch() {
  pageNum.value = 1
  movieStore.searchMovies(keyword.value, selectedCategory.value, 0, 12)
}

function onPageChange(page: number) {
  movieStore.searchMovies(keyword.value, selectedCategory.value, page - 1, 12)
}
</script>

<style scoped>
.search-view {
  padding: 20px;
}

.search-title {
  color: #eee;
  margin-bottom: 16px;
}

.filters {
  margin-bottom: 16px;
}

.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>