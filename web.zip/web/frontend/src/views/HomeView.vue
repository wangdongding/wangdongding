<template>
  <div class="home-view">
    <!-- 分类导航 -->
    <div class="category-nav">
      <el-radio-group v-model="selectedCategory" @change="onCategoryChange">
        <el-radio-button :value="undefined">全部</el-radio-button>
        <el-radio-button
          v-for="cat in categoryStore.categories"
          :key="cat.id"
          :value="cat.id"
        >
          {{ cat.name }}
        </el-radio-button>
      </el-radio-group>
    </div>

    <!-- 影片网格 -->
    <div v-loading="movieStore.loading" class="movie-grid">
      <MovieCard v-for="movie in movieStore.movies" :key="movie.id" :movie="movie" />
    </div>

    <el-empty v-if="!movieStore.loading && movieStore.movies.length === 0" description="暂无影片" />

    <!-- 分页 -->
    <div class="pagination-wrapper">
      <el-pagination
        v-model:current-page="pageNum"
        :page-size="12"
        :total="movieStore.total"
        layout="prev, pager, next"
        @current-change="onPageChange"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useCategoryStore } from '../stores/category'
import { useMovieStore } from '../stores/movie'
import MovieCard from '../components/MovieCard.vue'

const categoryStore = useCategoryStore()
const movieStore = useMovieStore()

const selectedCategory = ref<number | undefined>(undefined)
const pageNum = ref(1)

onMounted(() => {
  categoryStore.fetchCategories()
  movieStore.fetchMovies(0, 12)
})

function onCategoryChange(categoryId: number | undefined) {
  pageNum.value = 1
  movieStore.fetchMovies(0, 12, categoryId)
}

function onPageChange(page: number) {
  movieStore.fetchMovies(page - 1, 12, selectedCategory.value)
}
</script>

<style scoped>
.home-view {
  padding: 20px;
}

.category-nav {
  margin-bottom: 20px;
}

.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>