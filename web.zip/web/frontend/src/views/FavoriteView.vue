<template>
  <div class="favorite-view">
    <h2 class="page-title">我的收藏</h2>

    <div v-loading="loading" class="movie-grid">
      <MovieCard v-for="movie in favorites" :key="movie.id" :movie="movie" />
    </div>

    <el-empty v-if="!loading && favorites.length === 0" description="暂无收藏" />

    <div class="pagination-wrapper">
      <el-pagination
        v-model:current-page="pageNum"
        :page-size="12"
        :total="total"
        layout="prev, pager, next"
        @current-change="onPageChange"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { favoriteApi, type MovieVO } from '../api/favorite'
import MovieCard from '../components/MovieCard.vue'

const favorites = ref<MovieVO[]>([])
const total = ref(0)
const pageNum = ref(1)
const loading = ref(false)

onMounted(() => fetchFavorites())

async function fetchFavorites(page = 0) {
  loading.value = true
  try {
    const result = await favoriteApi.list(page, 12)
    favorites.value = result.items
    total.value = result.total
  } finally {
    loading.value = false
  }
}

function onPageChange(page: number) {
  fetchFavorites(page - 1)
}
</script>

<style scoped>
.favorite-view {
  padding: 20px;
}

.page-title {
  color: #eee;
  margin-bottom: 16px;
}

.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>