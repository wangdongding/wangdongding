<template>
  <div class="play-view">
    <div v-if="movie" class="player-section">
      <!-- iframe 模式 -->
      <iframe
        v-if="movie.sourceMode === 'iframe'"
        :src="movie.sourceUrl"
        class="iframe-player"
        allowfullscreen
      />

      <!-- 视频播放器 (direct/proxy) -->
      <VideoPlayer
        v-else
        :url="resolvedUrl"
        :mode="movie.sourceMode"
        :initial-progress="movie.progress"
        @progress="onProgress"
      />

      <div class="movie-info">
        <h2>{{ movie.title }}</h2>
        <p v-if="movie.description" class="desc">{{ movie.description }}</p>
        <div class="info-meta">
          <span v-if="movie.categoryName">{{ movie.categoryName }}</span>
          <span v-if="movie.format">{{ movie.format }}</span>
          <span v-if="movie.duration">{{ formatDuration(movie.duration) }}</span>
        </div>
        <div v-if="movie.tagNames?.length" class="info-tags">
          <el-tag v-for="tag in movie.tagNames" :key="tag" size="small" type="info">{{ tag }}</el-tag>
        </div>

        <el-button
          :type="isFavorite ? 'danger' : 'default'"
          :icon="isFavorite ? StarFilled : Star"
          @click="toggleFavorite"
        >
          {{ isFavorite ? '已收藏' : '收藏' }}
        </el-button>
      </div>
    </div>

    <el-empty v-if="!movie && !loading" description="影片不存在" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import { useRoute } from 'vue-router'
import { movieApi, type MovieVO } from '../api/movie'
import { favoriteApi } from '../api/favorite'
import { historyApi } from '../api/history'
import VideoPlayer from '../components/VideoPlayer.vue'
import { Star, StarFilled } from '@element-plus/icons-vue'

const route = useRoute()
const movie = ref<MovieVO | null>(null)
const isFavorite = ref(false)
const loading = ref(true)

const resolvedUrl = computed(() => {
  if (!movie.value) return ''
  // 本地文件：走 /videos/ 路径
  if (movie.value.sourceType === 1) {
    return `/videos/${movie.value.sourceUrl}`
  }
  return movie.value.sourceUrl
})

let progressInterval: number | null = null

onMounted(async () => {
  const id = Number(route.params.id)
  try {
    movie.value = await movieApi.getById(id)
    // 检查收藏状态
    try {
      const favList = await favoriteApi.list(0, 999)
      isFavorite.value = favList.items.some(f => f.id === id)
    } catch {
      // 忽略
    }
  } catch {
    movie.value = null
  } finally {
    loading.value = false
  }
})

onBeforeUnmount(() => {
  if (progressInterval) clearInterval(progressInterval)
})

function onProgress(seconds: number) {
  if (!movie.value) return
  historyApi.updateProgress(movie.value.id, {
    progress: Math.floor(seconds),
    duration: movie.value.duration || 0,
  })
}

async function toggleFavorite() {
  if (!movie.value) return
  if (isFavorite.value) {
    await favoriteApi.remove(movie.value.id)
    isFavorite.value = false
  } else {
    await favoriteApi.add(movie.value.id)
    isFavorite.value = true
  }
}

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
  return `${m}:${s.toString().padStart(2, '0')}`
}
</script>

<style scoped>
.play-view {
  padding: 20px;
  max-width: 960px;
  margin: 0 auto;
}

.iframe-player {
  width: 100%;
  aspect-ratio: 16/9;
  border: none;
}

.movie-info {
  margin-top: 16px;
}

.movie-info h2 {
  color: #eee;
  margin: 0;
}

.desc {
  color: #aaa;
  margin-top: 8px;
}

.info-meta {
  display: flex;
  gap: 8px;
  font-size: 13px;
  color: #888;
  margin-top: 8px;
}

.info-tags {
  display: flex;
  gap: 4px;
  margin-top: 8px;
}
</style>