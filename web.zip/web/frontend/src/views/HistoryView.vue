<template>
  <div class="history-view">
    <h2 class="page-title">播放历史</h2>
    <el-button type="danger" size="small" @click="clearAll">清空历史</el-button>

    <div v-loading="loading" class="movie-grid">
      <MovieCard v-for="movie in historyList" :key="movie.id" :movie="movie" />
    </div>

    <el-empty v-if="!loading && historyList.length === 0" description="暂无历史" />

    <div class="pagination-wrapper">
      <el-pagination
        v-model:current-page="pageNum"
        :page-size="12"
        :total="total"
        layout="prev, pager, next"
        @current-change="onPageChange"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessageBox } from 'element-plus'
import { historyApi, type MovieVO } from '../api/history'
import MovieCard from '../components/MovieCard.vue'

const historyList = ref<MovieVO[]>([])
const total = ref(0)
const pageNum = ref(1)
const loading = ref(false)

onMounted(() => fetchHistory())

async function fetchHistory(page = 0) {
  loading.value = true
  try {
    const result = await historyApi.list(page, 12)
    historyList.value = result.items
    total.value = result.total
  } finally {
    loading.value = false
  }
}

function onPageChange(page: number) {
  fetchHistory(page - 1)
}

async function clearAll() {
  try {
    await ElMessageBox.confirm('确认清空所有播放历史？', '提示', { type: 'warning' })
    await historyApi.clearAll()
    historyList.value = []
    total.value = 0
  } catch {
    // 取消
  }
}
</script>

<style scoped>
.history-view {
  padding: 20px;
}

.page-title {
  color: #eee;
  margin-bottom: 16px;
  display: inline-block;
  margin-right: 12px;
}

.movie-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
  margin-top: 16px;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>