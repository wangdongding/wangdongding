<template>
  <div class="movie-manage">
    <h2 class="page-title">影片管理</h2>

    <!-- 添加影片 -->
    <el-card class="form-card">
      <h3>添加影片</h3>
      <el-form :model="form" label-width="80px">
        <el-form-item label="标题">
          <el-input v-model="form.title" />
        </el-form-item>
        <el-form-item label="来源类型">
          <el-radio-group v-model="form.sourceType">
            <el-radio :value="1">本地文件</el-radio>
            <el-radio :value="2">远程链接</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="文件路径/URL">
          <el-input v-model="form.sourceUrl" />
        </el-form-item>
        <el-form-item v-if="form.sourceType === 2" label="播放模式">
          <el-radio-group v-model="form.sourceMode">
            <el-radio value="direct">直链</el-radio>
            <el-radio value="proxy">代理</el-radio>
            <el-radio value="iframe">嵌入</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="分类">
          <el-select v-model="form.categoryId" clearable placeholder="选择分类">
            <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="简介">
          <el-input v-model="form.description" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="封面">
          <el-upload :show-file-list="false" :before-upload="onCoverUpload" accept="image/*">
            <el-button size="small">上传封面</el-button>
          </el-upload>
          <img v-if="form.coverUrl" :src="form.coverUrl" class="cover-preview" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="addMovie">添加</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 影片列表 -->
    <el-card class="list-card">
      <h3>影片列表</h3>
      <el-table :data="movies" stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="title" label="标题" />
        <el-table-column prop="sourceType" label="来源" width="80">
          <template #default="{ row }">{{ row.sourceType === 1 ? '本地' : '远程' }}</template>
        </el-table-column>
        <el-table-column prop="sourceMode" label="模式" width="80" />
        <el-table-column prop="format" label="格式" width="80" />
        <el-table-column label="操作" width="120">
          <template #default="{ row }">
            <el-button size="small" type="danger" @click="deleteMovie(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { movieApi, type MovieVO, type MovieCreateDTO, type PageResult } from '../../api/movie'
import { categoryApi, type CategoryDTO } from '../../api/category'
import { coverApi } from '../../api/cover'

const categories = ref<CategoryDTO[]>([])
const movies = ref<MovieVO[]>([])

const form = ref<MovieCreateDTO>({
  title: '',
  sourceType: 1,
  sourceUrl: '',
  sourceMode: 'direct',
  categoryId: undefined,
  description: '',
  coverUrl: '',
})

onMounted(async () => {
  categories.value = await categoryApi.list()
  await fetchMovies()
})

async function fetchMovies() {
  const result: PageResult<MovieVO> = await movieApi.list(0, 100)
  movies.value = result.items
}

async function onCoverUpload(file: File) {
  const url = await coverApi.upload(file)
  form.value.coverUrl = url
  return false // 阻止默认上传
}

async function addMovie() {
  if (!form.value.title || !form.value.sourceUrl) return
  await movieApi.create(form.value)
  // 重置表单
  form.value = { title: '', sourceType: 1, sourceUrl: '', sourceMode: 'direct', categoryId: undefined, description: '', coverUrl: '' }
  await fetchMovies()
}

async function deleteMovie(id: number) {
  await movieApi.delete(id)
  await fetchMovies()
}
</script>

<style scoped>
.movie-manage {
  padding: 20px;
}

.page-title {
  color: #eee;
  margin-bottom: 16px;
}

.form-card, .list-card {
  margin-bottom: 20px;
  background: #0f3460;
  color: #eee;
}

.cover-preview {
  max-width: 120px;
  margin-top: 8px;
}
</style>