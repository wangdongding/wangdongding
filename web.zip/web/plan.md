# 影片搜索与播放网站 — 设计文档 (plan.md)

## 一、项目概述

构建一个个人使用的影片搜索与播放网站。支持按关键词搜索影片、浏览封面预览、在线播放，影片资源来自服务器本地文件和远程链接。包含收藏、历史记录、分类标签等功能。

---

## 二、技术栈

| 层级 | 技术选型 | 说明 |
|------|---------|------|
| 前端 | Vue 3 + TypeScript + Vite | 组合式 API、`<script setup>` 语法 |
| UI 框架 | Element Plus | 成熟的 Vue 3 组件库，开箱即用 |
| 视频播放器 | ArtPlayer | 轻量现代、API 优雅，支持 FLV/HLS 等格式扩展 |
| 状态管理 | Pinia | Vue 3 官方推荐 |
| 路由 | Vue Router 4 | - |
| HTTP 客户端 | Axios | - |
| 后端 | Spring Boot 3 (Java 17+) | RESTful API |
| 数据库 | MySQL 8 | 关系型，存储影片元数据、收藏、历史等 |
| 视频转码 | FFmpeg（按需） | MKV/AVI 等 MP4 之外格式实时转码为 HLS/MP4 流 |
| 文件服务 | Nginx | 静态资源代理、视频文件服务、前端部署 |
| 容器化 | Docker + Docker Compose | 统一部署 |

### 中间件说明

本项目仅使用 **MySQL** 一个中间件，尽量保持简洁：

- **不引入 Redis**：个人使用场景，收藏/历史直接存 MySQL 即可
- **不引入 ES**：影片数量有限，MySQL 全文索引足以满足搜索需求
- **不引入 MQ**：无异步任务需求

---

## 三、系统架构

```
┌─────────────┐     ┌──────────────────────────────────┐
│   Browser   │────▶│           Nginx (:80/:443)       │
│  (Vue 3 SPA)│◀────│  /          → 前端静态文件        │
└─────────────┘     │  /api/*    → proxy_pass 后端      │
                    │  /videos/* → alias 本地视频目录     │
                    └──────────┬───────────────────────┘
                               │
                    ┌──────────▼───────────────────────┐
                    │     Spring Boot (:8080)           │
                    │  - REST API                       │
                    │  - 影片元数据 CRUD                 │
                    │  - 搜索（MySQL 全文索引）           │
                    │  - 收藏 / 历史记录                  │
                    │  - FFmpeg 转码服务（非 MP4 时）     │
                    └──────────┬───────────────────────┘
                               │
                    ┌──────────▼───────────────────────┐
                    │     MySQL (:3306)                 │
                    │  - 影片元数据表                     │
                    │  - 分类 / 标签表                    │
                    │  - 收藏表                          │
                    │  - 播放历史表                       │
                    └──────────────────────────────────┘
                               │
                    ┌──────────▼───────────────────────┐
                    │     本地文件系统                     │
                    │  /data/videos/   → 视频文件        │
                    │  /data/covers/   → 封面图片        │
                    └──────────────────────────────────┘
```

### 请求流转

1. **浏览/搜索**：前端 → Nginx `/api/*` → Spring Boot → MySQL
2. **播放本地视频**：前端 → Nginx `/videos/*` → 直接读取本地文件（支持 Range 分段请求）
3. **播放远程链接**：根据 `source_mode` 决定：
   - `direct`：前端直接请求远程 URL 播放
   - `proxy`：前端经 Nginx `/proxy/` 代理转发播放（绕过防盗链/CORS）
   - `iframe`：前端用 iframe 嵌入目标网页
4. **非 MP4 格式播放**：前端请求 `/api/video/stream/{id}` → Spring Boot 调用 FFmpeg 实时转码输出 HLS 流

---

## 四、数据模型

### 4.1 影片表 (movie)

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 自增主键 |
| title | VARCHAR(255) | 影片标题 |
| description | TEXT | 简介 |
| cover_url | VARCHAR(500) | 封面图路径/URL |
| source_type | TINYINT | 1=本地文件, 2=远程链接 |
| source_url | VARCHAR(1000) | 本地路径或远程URL |
| source_mode | VARCHAR(10) | 远程链接播放模式：direct=直链播放, proxy=代理转发, iframe=网页嵌入。本地文件时为 direct |
| format | VARCHAR(20) | 视频格式：mp4/mkv/avi 等 |
| duration | INT | 时长（秒） |
| file_size | BIGINT | 文件大小（字节），远程链接可为空 |
| category_id | BIGINT FK | 所属分类 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

索引：`title` 全文索引(FULLTEXT)、`category_id` 普通索引

### 4.2 分类表 (category)

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 自增主键 |
| name | VARCHAR(50) | 分类名称 |
| sort_order | INT | 排序权重 |

### 4.3 标签表 (tag)

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 自增主键 |
| name | VARCHAR(50) | 标签名称 |

### 4.4 影片-标签关联表 (movie_tag)

| 字段 | 类型 | 说明 |
|------|------|------|
| movie_id | BIGINT FK | 影片ID |
| tag_id | BIGINT FK | 标签ID |

联合主键：(movie_id, tag_id)

### 4.5 收藏表 (favorite)

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 自增主键 |
| movie_id | BIGINT FK | 影片ID |
| created_at | DATETIME | 收藏时间 |

说明：个人使用无需用户关联，直接记录收藏影片

### 4.6 播放历史表 (play_history)

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 自增主键 |
| movie_id | BIGINT FK | 影片ID |
| progress | INT | 播放进度（秒） |
| duration | INT | 影片总时长（秒） |
| played_at | DATETIME | 播放时间 |

---

## 五、核心功能模块

### 5.1 首页
- 分类导航栏
- 最新影片列表（封面卡片网格布局）
- 热门标签云
- 搜索框

### 5.2 搜索
- 关键词搜索（标题、描述）— MySQL FULLTEXT 索引
- 按分类筛选
- 按标签筛选
- 搜索结果：封面 + 标题 + 时长 + 格式标识

### 5.3 影片播放
- ArtPlayer 播放器
- MP4：直接通过 Nginx 静态服务播放（支持拖动进度条）
- MKV/AVI：经 Spring Boot + FFmpeg 转为 HLS 流播放
- 远程链接：根据 source_mode 区分 — direct 直链播放 / proxy 代理转发 / iframe 网页嵌入
- 播放进度自动保存（每 10 秒上报一次）
- 退出后再次进入自动恢复上次进度

### 5.4 收藏
- 影片详情页可点击收藏/取消收藏
- 收藏列表页（按收藏时间倒序）

### 5.5 播放历史
- 自动记录播放历史
- 显示播放进度百分比
- 点击继续播放（跳转到上次进度）
- 历史列表页（按播放时间倒序）

### 5.6 影片管理（后台）
- 扫描本地目录自动入库（读取文件名、提取元数据）
- 手动添加远程链接影片
- 编辑影片信息（标题、描述、封面、分类、标签）
- 删除影片（仅删元数据，可选是否删文件）

---

## 六、API 设计

### 影片相关
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/movies | 影片列表（分页、筛选） |
| GET | /api/movies/{id} | 影片详情 |
| GET | /api/movies/search?q=keyword | 搜索影片 |
| POST | /api/movies | 添加影片 |
| PUT | /api/movies/{id} | 更新影片信息 |
| DELETE | /api/movies/{id} | 删除影片 |
| POST | /api/movies/scan | 扫描本地目录入库 |
| GET | /api/movies/{id}/stream | 获取视频流（非MP4转码） |

### 分类相关
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/categories | 分类列表 |
| POST | /api/categories | 添加分类 |
| PUT | /api/categories/{id} | 更新分类 |
| DELETE | /api/categories/{id} | 删除分类 |

### 标签相关
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/tags | 标签列表 |
| POST | /api/tags | 添加标签 |
| DELETE | /api/tags/{id} | 删除标签 |

### 收藏相关
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/favorites | 收藏列表 |
| POST | /api/favorites/{movieId} | 添加收藏 |
| DELETE | /api/favorites/{movieId} | 取消收藏 |

### 播放历史相关
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/history | 历史列表 |
| POST | /api/history/{movieId} | 记录/更新播放进度 |
| DELETE | /api/history/{movieId} | 删除历史 |
| DELETE | /api/history | 清空所有历史 |

### 封面相关
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/covers/upload | 上传封面图 |
| GET | /api/covers/{filename} | 获取封面图 |

---

## 七、目录结构

### 前端 (frontend/)

```
frontend/
├── public/
├── src/
│   ├── api/                  # Axios 请求封装
│   │   ├── movie.ts
│   │   ├── category.ts
│   │   ├── tag.ts
│   │   ├── favorite.ts
│   │   └── history.ts
│   ├── assets/               # 静态资源
│   ├── components/           # 通用组件
│   │   ├── MovieCard.vue     # 影片封面卡片
│   │   ├── SearchBar.vue     # 搜索栏
│   │   ├── VideoPlayer.vue   # 播放器封装
│   │   └── TagCloud.vue      # 标签云
│   ├── composables/          # 组合式函数
│   │   └── usePagination.ts
│   ├── layouts/              # 布局组件
│   │   └── MainLayout.vue
│   ├── router/               # 路由配置
│   │   └── index.ts
│   ├── stores/               # Pinia 状态
│   │   ├── movie.ts
│   │   ├── category.ts
│   │   └── history.ts
│   ├── views/                # 页面
│   │   ├── HomeView.vue      # 首页
│   │   ├── SearchView.vue    # 搜索结果页
│   │   ├── PlayView.vue      # 播放页
│   │   ├── FavoriteView.vue  # 收藏页
│   │   ├── HistoryView.vue   # 历史页
│   │   └── admin/
│   │       └── MovieManage.vue # 影片管理
│   ├── App.vue
│   └── main.ts
├── index.html
├── vite.config.ts
├── tsconfig.json
└── package.json
```

### 后端 (backend/)

```
backend/
├── src/main/java/com/movie/
│   ├── config/               # 配置类
│   │   ├── WebConfig.java
│   │   └── CorsConfig.java
│   ├── controller/           # 控制器
│   │   ├── MovieController.java
│   │   ├── CategoryController.java
│   │   ├── TagController.java
│   │   ├── FavoriteController.java
│   │   ├── HistoryController.java
│   │   └── CoverController.java
│   ├── entity/               # 实体类
│   │   ├── Movie.java
│   │   ├── Category.java
│   │   ├── Tag.java
│   │   ├── Favorite.java
│   │   └── PlayHistory.java
│   ├── repository/           # JPA Repository
│   │   ├── MovieRepository.java
│   │   ├── CategoryRepository.java
│   │   ├── TagRepository.java
│   │   ├── FavoriteRepository.java
│   │   └── HistoryRepository.java
│   ├── service/              # 业务逻辑
│   │   ├── MovieService.java
│   │   ├── CategoryService.java
│   │   ├── TagService.java
│   │   ├── FavoriteService.java
│   │   ├── HistoryService.java
│   │   └── FFmpegService.java  # 视频转码
│   ├── dto/                  # 数据传输对象
│   │   └── ...
│   └── MovieApplication.java
├── src/main/resources/
│   ├── application.yml
│   └── db/migration/         # 数据库初始化SQL
├── Dockerfile
└── pom.xml
```

### 部署文件

```
项目根目录/
├── frontend/
│   └── Dockerfile
├── backend/
│   └── Dockerfile
├── docker-compose.yml
├── nginx/
│   └── nginx.conf
└── data/
    ├── videos/               # 本地视频文件挂载目录
    └── covers/               # 封面图挂载目录
```

---

## 八、Docker 部署方案

### 8.1 前端 Dockerfile (frontend/Dockerfile)

```dockerfile
# ---- 构建阶段 ----
FROM node:20-alpine AS builder
WORKDIR /app
COPY package.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install --frozen-lockfile
COPY . .
RUN pnpm build

# ---- 运行阶段（产物由 nginx 容器挂载，此处仅用于构建输出）----
# 实际部署中，CI/CD 将 dist/ 产物拷出，供 nginx 容器挂载
# 如果希望单容器运行，可取消下方注释：
# FROM nginx:alpine
# COPY --from=builder /app/dist /usr/share/nginx/html
```

> **说明**：前端采用多阶段构建，最终产物是 `dist/` 目录。在 docker-compose 中由 nginx 容器直接挂载 `dist/`，无需单独跑前端容器。开发时 `pnpm dev` 本地运行，构建时 `pnpm build` 输出静态文件。

### 8.2 后端 Dockerfile (backend/Dockerfile)

```dockerfile
# ---- 构建阶段 ----
FROM maven:3.9-eclipse-temurin-17 AS builder
WORKDIR /app
COPY pom.xml .
RUN mvn dependency:go-offline -B          # 依赖缓存层，pom 不变时复用
COPY src ./src
RUN mvn package -DskipTests -B

# ---- 运行阶段 ----
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app

# 安装 FFmpeg（用于 MKV/AVI 转码）
RUN apk add --no-cache ffmpeg

COPY --from=builder /app/target/*.jar app.jar

ENV JAVA_OPTS="-Xms256m -Xmx512m"
ENV TZ=Asia/Shanghai

EXPOSE 8080
ENTRYPOINT ["sh", "-c", "java $JAVA_OPTS -jar app.jar"]
```

> **说明**：多阶段构建，构建环境含 Maven + JDK17，运行环境仅 JRE17 + FFmpeg，镜像体积小。依赖缓存层加速后续构建。

### 8.3 docker-compose.yml

```yaml
services:
  mysql:
    image: mysql:8
    environment:
      MYSQL_ROOT_PASSWORD: ${DB_PASSWORD}
      MYSQL_DATABASE: movie_db
    volumes:
      - mysql_data:/var/lib/mysql
      - ./backend/src/main/resources/db/migration:/docker-entrypoint-initdb.d
    ports:
      - "3306:3306"

  backend:
    build: ./backend
    environment:
      SPRING_DATASOURCE_URL: jdbc:mysql://mysql:3306/movie_db
      SPRING_DATASOURCE_PASSWORD: ${DB_PASSWORD}
      VIDEO_BASE_PATH: /data/videos
      COVER_BASE_PATH: /data/covers
    volumes:
      - ./data/videos:/data/videos
      - ./data/covers:/data/covers
    depends_on:
      - mysql

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./frontend/dist:/usr/share/nginx/html
      - ./data/videos:/data/videos:ro
      - ./data/covers:/data/covers:ro
    depends_on:
      - backend

volumes:
  mysql_data:
```

> **部署流程**：
> 1. 前端：在 `frontend/` 目录执行 `pnpm build`，产物输出到 `dist/`
> 2. 后端：`docker compose build backend`，多阶段构建打包 JAR
> 3. 启动：`docker compose up -d`，三个容器同时启动
> 4. 视频文件放在宿主机 `data/videos/`，封面放在 `data/covers/`

### 8.4 Nginx 关键配置

```nginx
server {
    listen 80;

    # 前端静态文件
    location / {
        root /usr/share/nginx/html;
        try_files $uri $uri/ /index.html;  # SPA history 模式
    }

    # 后端 API 代理
    location /api/ {
        proxy_pass http://backend:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # 本地视频文件（支持 Range 请求，可拖动进度条）
    location /videos/ {
        alias /data/videos/;
        mp4;
        mp4_buffer_size 1m;
        mp4_max_buffer_size 5m;
    }

    # 封面图片
    location /covers/ {
        alias /data/covers/;
    }

    # 远程链接代理转发（绕过防盗链/CORS）
    location /proxy/ {
        proxy_pass $arg_url;
        proxy_set_header Referer "";
        proxy_set_header User-Agent $http_user_agent;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

## 九、关键技术方案

### 9.1 视频格式兼容

| 格式 | 播放方案 |
|------|---------|
| MP4 | Nginx 直接服务（mp4 模块，支持 Range/seek） |
| MKV/AVI | Spring Boot 调用 FFmpeg 实时转码为 HLS（.m3u8） |
| 远程直链 (direct) | 前端播放器直接请求远程 URL |
| 远程代理 (proxy) | 经 Nginx `/proxy/` 转发，绕过防盗链和 CORS |
| 远程嵌入 (iframe) | 前端用 iframe 加载目标网页 |

> 优化建议：可在影片入库时用 FFmpeg 预转码为 MP4，避免实时转码的性能开销。首次播放时触发转码并缓存。

### 9.2 搜索方案

MySQL FULLTEXT 全文索引，中文需使用 `ngram` 解析器：

```sql
ALTER TABLE movie ADD FULLTEXT INDEX ft_title_desc (title, description) WITH PARSER ngram;
```

查询：
```sql
SELECT * FROM movie WHERE MATCH(title, description) AGAINST('关键词' IN NATURAL LANGUAGE MODE);
```

### 9.3 本地目录扫描入库

1. 后端配置视频根目录路径
2. 递归扫描目录下所有视频文件
3. 提取文件名作为标题（去除扩展名和常见前缀）
4. 调用 FFprobe 提取时长、格式、大小等元数据
5. 自动提取第一帧作为封面（或使用默认封面）
6. 写入数据库

### 9.4 播放进度保存

- 前端播放器每 10 秒通过 `POST /api/history/{movieId}` 上报当前进度
- 播放页加载时请求 `GET /api/movies/{id}` 获取详情，包含上次进度
- 若有历史进度，播放器自动 seek 到对应位置

---

## 十、开发里程碑

### Phase 1: 基础框架搭建
- 前端项目初始化（Vue 3 + TS + Vite + Element Plus + Pinia）
- 后端项目初始化（Spring Boot + JPA + MySQL）
- Docker Compose 基础配置
- Nginx 配置
- 数据库表创建

### Phase 2: 核心功能
- 影片 CRUD API + 前端页面
- 本地目录扫描入库
- 视频播放（MP4 直播 + 非MP4转码）
- 搜索功能

### Phase 3: 辅助功能
- 收藏功能
- 播放历史 + 进度保存/恢复
- 分类标签管理

### Phase 4: 优化与完善
- 封面自动提取
- 非MP4预转码缓存
- 响应式布局适配移动端
- 细节打磨（加载状态、空状态、错误处理）

---

## 十一、风险与注意事项

| 风险 | 应对方案 |
|------|---------|
| MKV/AVI 实时转码性能差 | 入库时预转码，首次播放触发转码并缓存 |
| 大文件上传封面慢 | 封面压缩，前端预览再上传 |
| 视频目录结构变化 | 提供重新扫描功能，基于路径匹配更新 |
| Nginx mp4 模块未安装 | Docker 镜像使用完整版 nginx（非 alpine 精简版）或自行编译 |
| 远程链接失效/防盗链 | source_mode 设为 proxy 走 Nginx 代理，或设为 iframe 嵌入 |
