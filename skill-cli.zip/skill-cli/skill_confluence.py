"""
Confluence Skill — Claude 调用入口
Claude 通过 Skill Tool 调用本文件中的函数

职责:
1. 检查 token 是否已配置 → 未配置则提示用户收集
2. 收集用户输入的业务参数（page_id、CQL、title 等）
3. 调用 cli_confluence.py 完成实际 API 操作
4. 大段内容通过 @filepath 语法传递（CLI 自动读取并清理 skill_temp 临时文件）
"""
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "cli"))
from token_store import has_token, save_token, load_token, get_token_path


# ==================== Token 管理 ====================

def check_and_setup_token() -> str | None:
    """
    检查 Confluence token 是否已配置。
    返回 None 表示已配置，返回提示语表示需要用户配置。
    """
    if has_token("confluence"):
        return None
    token_path = get_token_path()
    return (
        "Confluence token 尚未配置。请提供你的 Confluence API token，我会帮你保存（只需一次）：\n"
        f"你也可以手动编辑 {token_path} 配置文件"
    )


def setup_token(token: str) -> str:
    """用户提供了 token 后，保存到 token_store"""
    save_token("confluence", {"token": token})
    return f"Confluence token 已保存到 {get_token_path()}，后续所有 Confluence 操作将自动使用此 token"


# ==================== CLI 调用封装 ====================

CLI_PATH = str(Path(__file__).parent / "cli" / "cli_confluence.py")


def _call_cli(command: str, *args, timeout: int = 30) -> dict:
    """调用 cli_confluence.py，返回 JSON结果
    - timeout: subprocess 超时秒数，默认 30；upload 等大文件操作建议传 60
    """
    cmd_args = [sys.executable, CLI_PATH, command] + list(args)
    try:
        result = subprocess.run(
            cmd_args,
            capture_output=True,
            encoding='utf-8',
            timeout=timeout
        )
        if result.returncode != 0:
            try:
                return json.loads(result.stdout)
            except json.JSONDecodeError:
                return {"error": result.stderr.strip() or result.stdout.strip()}
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return {"raw": result.stdout.strip()}
    except subprocess.TimeoutExpired:
        return {"error": f"CLI 调用超时 ({timeout}s)"}


# ==================== Skill 函数（Claude 调用这些） ====================

def confluence_view(page_id: str) -> dict:
    """查看 Confluence 页面详情（含正文 HTML 内容）"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("view", page_id)


def confluence_search(cql: str) -> dict:
    """搜索 Confluence 页面（传入 CQL 查询语句）"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("search", cql)


def confluence_create(space: str, title: str, content: str, parent_id: str = "") -> dict:
    """创建 Confluence 页面"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("create", space, title, content, parent_id)


def confluence_update(page_id: str, title: str = "_", body: str = "_") -> dict:
    """更新 Confluence 页面（自动获取版本号+1，与 create 传参风格一致）
    - title: 新标题，默认 "_" 不修改
    - body: 新正文 HTML，默认 "_" 不修改，支持 @filepath 语法
    """
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("update", page_id, title, body)


def confluence_delete(page_id: str) -> dict:
    """删除 Confluence 页面"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("delete", page_id)


def confluence_append(page_id: str, content: str, after: str = "") -> dict:
    """在页面追加内容（内部自动 view→拼接/插入→update，无需重写整页）
    - content: 要追加的 HTML 片段，支持 @filepath 语法
    - after: 可选，定位插入位置，格式 "h2:标题文本" 或 "heading:标题文本"，不传时末尾追加
    """
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("append", page_id, content, after)


def confluence_spaces(limit: str = "50") -> dict:
    """列出所有 Confluence 空间（limit 控制返回数量，默认 50）"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("spaces", limit)


def confluence_children(page_id: str) -> dict:
    """查看页面的子页面列表"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("children", page_id)


# ==================== 新增 Skill 函数 ====================

def confluence_search_page(space_key: str, title: str = "", text: str = "") -> dict:
    """搜索 Confluence 页面（无需手写 CQL，自动 fallback）
    - space_key: 空间 key（必传）
    - title: 标题模糊匹配（可选）
    - text: 正文模糊匹配（可选）
    CQL 无结果时自动 fallback 到 page_by_title 精确匹配
    """
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("search_page", space_key, title, text)


def confluence_upload(page_id: str, filepath: str) -> dict:
    """上传附件到 Confluence 页面（大文件超时 60s）"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("upload", page_id, filepath, timeout=60)


def confluence_get_page_by_title(space: str, title: str) -> dict:
    """按空间+标题精确查找页面"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("page_by_title", space, title)


def confluence_get_comments(page_id: str) -> dict:
    """获取页面评论列表"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("comments", page_id)


def confluence_add_comment(page_id: str, content: str) -> dict:
    """给页面添加评论"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("comment_add", page_id, content)


def confluence_get_attachments(page_id: str) -> dict:
    """获取页面附件列表"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("attachments", page_id)


def confluence_get_versions(page_id: str, limit: str = "10") -> dict:
    """获取页面版本历史（limit 控制返回数量，默认 10）"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("versions", page_id, limit)


def confluence_get_ancestors(page_id: str) -> dict:
    """获取页面祖先列表"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("ancestors", page_id)


def confluence_get_space(key: str) -> dict:
    """获取空间详情"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("space", key)


def confluence_get_current_user() -> dict:
    """获取当前用户信息"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("current_user")


def confluence_test_connection() -> dict:
    """测试 Confluence API 连通性"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("test")


def confluence_get_labels(page_id: str) -> dict:
    """获取页面标签列表"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("labels", page_id)


def confluence_add_labels(page_id: str, labels: str) -> dict:
    """添加页面标签（逗号分隔）"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("label_add", page_id, labels)


def confluence_delete_label(page_id: str, label: str) -> dict:
    """删除页面标签"""
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("label_delete", page_id, label)


def confluence_get_page_by_url(page_url: str) -> dict:
    """根据 Confluence 页面 URL 获取页面详情

    支持以下 URL 格式:
    - http://confluence.yuwei.com:8090/pages/viewpage.action?pageId=187917408
    - http://confluence.yuwei.com:8090/spaces/DEVOPS/pages/187917408
    - http://confluence.yuwei.com:8090/x/YGQzCw (tiny link)
    - http://confluence.yuwei.com:8090/display/DEVOPS/Page+Title
    """
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("get_by_url", page_url)


def confluence_docx_images(filepath: str) -> dict:
    """提取 .docx 文件中的内嵌图片，返回图片文件列表和路径供后续 upload 使用
    注意：extract_docx 已合并文本+图片提取，通常无需单独调用此函数。
    - filepath: .docx 文件的本地路径
    """
    token_msg = check_and_setup_token()
    if token_msg:
        return {"needs_token": True, "message": token_msg}
    return _call_cli("docx_images", filepath)


def confluence_setup_token(token: str) -> str:
    """配置 Confluence token（只需一次，保存后所有操作自动使用）"""
    return setup_token(token)


# ==================== Claude Code Skill 注册 ====================

SKILL_SCHEMA = {
    "name": "confluence",
    "description": "Confluence 平台增删改查 Skill — 通过 CLI 调用 Confluence REST API",
    "functions": [
        {
            "name": "confluence_setup_token",
            "description": "配置 Confluence token（只需一次，保存后所有操作自动使用）",
            "parameters": {
                "token": {"type": "string", "description": "Confluence API token", "required": True}
            }
        },
        {
            "name": "confluence_view",
            "description": "查看 Confluence 页面详情（含正文 HTML 内容）",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID（数字）", "required": True}
            }
        },
        {
            "name": "confluence_search",
            "description": "搜索 Confluence 页面（CQL 语法）",
            "parameters": {
                "cql": {"type": "string", "description": "CQL 查询，如 'space=DEV AND title~\"架构\"'，详见 https://developer.atlassian.com/server/confluence/cql-field-reference/", "required": True}
            }
        },
        {
            "name": "confluence_search_page",
            "description": "搜索 Confluence 页面（无需手写 CQL，CQL 无结果时自动 fallback 到精确匹配）",
            "parameters": {
                "space_key": {"type": "string", "description": "空间 key，如 DEV", "required": True},
                "title": {"type": "string", "description": "标题模糊匹配（可选）", "required": False},
                "text": {"type": "string", "description": "正文模糊匹配（可选）", "required": False}
            }
        },
        {
            "name": "confluence_get_page_by_title",
            "description": "按空间+标题精确查找页面",
            "parameters": {
                "space": {"type": "string", "description": "空间 key，如 DEV", "required": True},
                "title": {"type": "string", "description": "页面标题（精确匹配）", "required": True}
            }
        },
        {
            "name": "confluence_create",
            "description": "创建 Confluence 页面",
            "parameters": {
                "space": {"type": "string", "description": "空间 key，如 DEV", "required": True},
                "title": {"type": "string", "description": "页面标题", "required": True},
                "content": {"type": "string", "description": "页面正文（Confluence Storage Format HTML，如 '<p>内容</p>'）", "required": True},
                "parent_id": {"type": "string", "description": "父页面 ID（可选，不传则创建在空间根目录）", "required": False}
            }
        },
        {
            "name": "confluence_update",
            "description": "更新 Confluence 页面。自动获取版本号+1，与 create 传参风格一致。title 默认 '_' 不改标题，body 传 '_' 不改正文",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True},
                "title": {"type": "string", "description": "新标题，默认 '_' 表示不修改", "required": False},
                "body": {"type": "string", "description": "新正文 HTML（Storage Format），传 '_' 表示不修改，支持 @filepath 语法", "required": True}
            }
        },
        {
            "name": "confluence_delete",
            "description": "删除 Confluence 页面",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True}
            }
        },
        {
            "name": "confluence_append",
            "description": "在页面追加内容（内部自动 view→拼接/插入→update，无需重写整页 body）。支持 after 参数定位插入到指定 heading 后面",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True},
                "content": {"type": "string", "description": "要追加的 HTML 片段（如 '<p>新增段落</p>'），支持 @filepath 语法", "required": True},
                "after": {"type": "string", "description": "定位插入位置，格式 'h2:标题文本' 或 'heading:标题文本'，不传时末尾追加", "required": False}
            }
        },
        {
            "name": "confluence_spaces",
            "description": "列出所有 Confluence 空间（limit 控制返回数量）",
            "parameters": {
                "limit": {"type": "string", "description": "返回数量上限，默认 50", "required": False}
            }
        },
        {
            "name": "confluence_get_space",
            "description": "获取指定空间的详细信息（名称、描述、主页等）",
            "parameters": {
                "key": {"type": "string", "description": "空间 key，如 DEV", "required": True}
            }
        },
        {
            "name": "confluence_children",
            "description": "查看页面的子页面列表",
            "parameters": {
                "page_id": {"type": "string", "description": "父页面 ID", "required": True}
            }
        },
        {
            "name": "confluence_get_comments",
            "description": "获取页面评论列表",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True}
            }
        },
        {
            "name": "confluence_add_comment",
            "description": "给页面添加评论",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True},
                "content": {"type": "string", "description": "评论内容（Storage Format HTML）", "required": True}
            }
        },
        {
            "name": "confluence_get_attachments",
            "description": "获取页面附件列表（含文件大小、媒体类型、下载链接）",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True}
            }
        },
        {
            "name": "confluence_upload",
            "description": "上传附件到 Confluence 页面（大文件超时 60s，上传成功后自动清理 _docx_images_temp 临时图片）",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True},
                "filepath": {"type": "string", "description": "本地文件路径，如 /path/to/file.png", "required": True}
            }
        },
        {
            "name": "confluence_get_versions",
            "description": "获取页面版本历史（limit 控制返回数量，默认最近 10 个）",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True},
                "limit": {"type": "string", "description": "返回版本数量上限，默认 10", "required": False}
            }
        },
        {
            "name": "confluence_get_ancestors",
            "description": "获取页面的祖先页面列表（面包屑路径）",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True}
            }
        },
        {
            "name": "confluence_get_current_user",
            "description": "获取当前认证用户信息（用户名、显示名、邮箱）",
            "parameters": {}
        },
        {
            "name": "confluence_test_connection",
            "description": "测试 Confluence API 连通性（验证 token 和服务器是否可用）",
            "parameters": {}
        },
        {
            "name": "confluence_get_labels",
            "description": "获取页面标签列表",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True}
            }
        },
        {
            "name": "confluence_add_labels",
            "description": "给页面添加标签（多个标签用逗号分隔）",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True},
                "labels": {"type": "string", "description": "标签名，多个用逗号分隔，如 'api,deploy,guide'", "required": True}
            }
        },
        {
            "name": "confluence_delete_label",
            "description": "删除页面上的某个标签",
            "parameters": {
                "page_id": {"type": "string", "description": "页面 ID", "required": True},
                "label": {"type": "string", "description": "要删除的标签名", "required": True}
            }
        },
        {
            "name": "confluence_get_page_by_url",
            "description": "根据 Confluence 页面 URL 直接获取页面详情（支持 viewpage.action?pageId=、/spaces/X/pages/Y、/x/短链接、/display/X/Title 等格式）",
            "parameters": {
                "page_url": {"type": "string", "description": "Confluence 页面完整 URL，如 http://confluence.yuwei.com:8090/pages/viewpage.action?pageId=187917408", "required": True}
            }
        },
        {
            "name": "confluence_docx_images",
            "description": "提取 .docx 文件中的内嵌图片到本地目录，返回图片文件列表供后续 upload 使用。注意：extract_docx 已合并文本+图片提取，通常无需单独调用此函数，直接用 cli_document.py 提取即可获取全部信息",
            "parameters": {
                "filepath": {"type": "string", "description": ".docx 文件本地路径，如 D:/Users/Desktop/report.docx", "required": True}
            }
        }
    ]
}
