"""
Token 存储模块 — CLI 内部统一管理 API 凭据
Token 只需收集一次，后续所有操作复用
存储位置: ~/.skill-cli/tokens.json（用户可自行编辑修改）
"""
import json
import os
from pathlib import Path

TOKEN_DIR = Path.home() / ".skill-cli"
TOKEN_FILE = TOKEN_DIR / "tokens.json"


def _ensure_dir():
    TOKEN_DIR.mkdir(parents=True, exist_ok=True)


def load_token(platform: str) -> dict | None:
    """读取某平台的 token 配置，不存在则返回 None"""
    if not TOKEN_FILE.exists():
        return None
    data = json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
    return data.get(platform)


def save_token(platform: str, token_data: dict):
    """保存某平台的 token 配置"""
    _ensure_dir()
    if TOKEN_FILE.exists():
        data = json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
    else:
        data = {}
    data[platform] = token_data
    TOKEN_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def has_token(platform: str) -> bool:
    """判断某平台是否已配置 token"""
    return load_token(platform) is not None


def get_token_path() -> str:
    """返回 token 文件路径，方便告知用户手动编辑"""
    return str(TOKEN_FILE)


if __name__ == "__main__":
    # 测试: 查看当前存储的 token
    if TOKEN_FILE.exists():
        print(json.dumps(json.loads(TOKEN_FILE.read_text()), indent=2, ensure_ascii=False))
    else:
        print(f"Token 文件不存在，路径: {TOKEN_FILE}")
        print("首次使用时 Skill 会引导你配置 token")