"""
文档文本提取工具 — 处理 .docx / .pdf 文件的结构化文本提取
用法:
  python cli_document.py <file_path>           — 提取结构化文本
  python cli_document.py docx_images <file_path> — 提取 .docx 内嵌图片
输出: {"text": "纯文本", "structured": [{style, text, images}, ...], "paragraphs": 段落数, "method": "..."}
依赖: python-docx, PyPDF2（首次使用自动安装）
"""
import sys
import io
import json
import subprocess
from pathlib import Path

# Windows 上 stdout/stderr 可能用 GBK 编码，导致包含 Unicode 符号（如 ✓ ✗）时崩溃
# 此设置比环境变量 PYTHONIOENCODING 更可靠，因为子进程可能不继承父环境
if sys.stdout.encoding != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

PYPI_MIRROR = "http://nexus.yuwei.com:8081/repository/pypi-proxy/simple"


def _ensure_lib(import_name: str, pip_name: str):
    """检查库是否可用，不可用则自动从内网源安装"""
    try:
        __import__(import_name)
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "-i", PYPI_MIRROR, "--trusted-host", "nexus.yuwei.com",
             pip_name],
            capture_output=True, text=True, timeout=60,
        )
        __import__(import_name)
        return True
    except Exception:
        return False


def _extract_images_from_doc(doc, source_dir: str = None) -> dict:
    """从 docx Document 对象中提取图片到磁盘，并建立段落→文件名映射

    Args:
        doc: python-docx Document 对象
        source_dir: 图片输出目录的父目录（传 None 则不提取到磁盘，仅返回原始文件名）

    Returns:
        {
            "para_images": {段落索引: [文件名, ...]},  # 有 source_dir 时为 hash 文件名，否则为原始名
            "images_dir": str or None,
            "images": [{filename, original_name, filepath, size, media_type}, ...]
        }
    """
    import os
    import hashlib

    # Step 1: 提取图片到磁盘（如果 source_dir 提供），建立 rId → 文件名映射
    rid_to_name = {}
    images = []
    images_dir = None

    if source_dir:
        images_dir = os.path.join(source_dir, "_docx_images_temp")
        os.makedirs(images_dir, exist_ok=True)
        seen_hashes = set()

        for rel in doc.part.rels.values():
            if "image" in rel.reltype:
                image_part = rel.target_part
                content_hash = hashlib.sha256(image_part.blob).hexdigest()[:16]
                orig_name = str(rel.target_ref)
                ext = Path(orig_name).suffix if Path(orig_name).suffix else ".png"
                hash_filename = f"{content_hash}{ext}"

                rid_to_name[rel.rId] = hash_filename

                if content_hash not in seen_hashes:
                    seen_hashes.add(content_hash)
                    out_path = os.path.join(images_dir, hash_filename)
                    with open(out_path, "wb") as f:
                        f.write(image_part.blob)
                    images.append({
                        "filename": hash_filename,
                        "original_name": orig_name,
                        "filepath": out_path,
                        "size": len(image_part.blob),
                        "media_type": image_part.content_type,
                    })
    else:
        # 不提取到磁盘，仅建立 rId → 原始文件名映射
        for rel in doc.part.rels.values():
            if "image" in rel.reltype:
                rid_to_name[rel.rId] = str(rel.target_ref)

    # Step 2: 建立段落→图片文件名映射
    nsmap = {
        'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
        'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
        'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
        'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    }

    para_images = {}
    for idx, para in enumerate(doc.paragraphs):
        image_names = []
        for run in para.runs:
            drawings = run._element.findall('.//wp:inline', nsmap) + run._element.findall('.//wp:anchor', nsmap)
            for drawing in drawings:
                blips = drawing.findall('.//a:blip', nsmap)
                for blip in blips:
                    embed = blip.get(f'{{{nsmap["r"]}}}embed')
                    if embed and embed in rid_to_name:
                        name = rid_to_name[embed]
                        if name not in image_names:
                            image_names.append(name)
        if image_names:
            para_images[idx] = image_names

    return {
        "para_images": para_images,
        "images_dir": images_dir,
        "images": images,
    }


# 样式名 → HTML 标签映射
_STYLE_MAP = {
    "Heading 1": "h1", "Heading 2": "h2", "Heading 3": "h3",
    "Heading 4": "h4", "Heading 5": "h5", "Heading 6": "h6",
    "Heading1": "h1", "Heading2": "h2", "Heading3": "h3",
    "Heading4": "h4", "Heading5": "h5", "Heading6": "h6",
    "TOC Heading": "h1",
    "List Paragraph": "li",
    "ListParagraph": "li",
}


def _style_to_html_tag(style_name: str) -> str:
    """将 docx 样式名映射为 HTML 标签名"""
    return _STYLE_MAP.get(style_name, "p")


def extract_docx(filepath: str) -> dict:
    """提取 .docx 文本+图片（python-docx 优先，zipfile+xml 回退）
    返回结构化 JSON，包含每段的 style、text、images 信息，
    以及兼容旧调用的纯文本 text 字段。
    同时提取内嵌图片到 _docx_images_temp 目录，
    structured[].images 返回与磁盘文件一致的 hash 文件名。
    """
    if _ensure_lib("docx", "python-docx"):
        from docx import Document
        doc = Document(filepath)

        # 合并提取：同时获取段落→图片映射 + 图片文件提取到磁盘
        source_dir = str(Path(filepath).parent)
        img_result = _extract_images_from_doc(doc, source_dir=source_dir)
        para_image_map = img_result["para_images"]

        structured = []
        plain_lines = []

        for idx, para in enumerate(doc.paragraphs):
            style_name = para.style.name if para.style else "Normal"
            text = para.text.strip()
            images = para_image_map.get(idx, [])
            html_tag = _style_to_html_tag(style_name)

            structured.append({
                "style": style_name,
                "html_tag": html_tag,
                "text": text,
                "images": images,
            })
            if text:
                plain_lines.append(text)

        # 表格也以结构化方式输出
        for table in doc.tables:
            for row in table.rows:
                cells = []
                for cell in row.cells:
                    cells.append(cell.text.strip())
                structured.append({
                    "style": "Table",
                    "html_tag": "tr",
                    "text": " | ".join(c for c in cells if c),
                    "images": [],
                })
                plain_lines.append(" | ".join(c for c in cells if c))

        return {
            "text": "\n".join(plain_lines),
            "structured": structured,
            "paragraphs": len(plain_lines),
            "method": "python-docx",
            "images_dir": img_result["images_dir"],
            "images": img_result["images"],
        }

    # 回退：zipfile + xml 手动解析（无结构信息）
    import zipfile
    from xml.etree.ElementTree import iterparse
    text_parts = []
    with zipfile.ZipFile(filepath, 'r') as z:
        if 'word/document.xml' not in z.namelist():
            raise ValueError("不是有效的 .docx 文件（缺少 word/document.xml）")
        with z.open('word/document.xml') as f:
            ns = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
            for event, elem in iterparse(f):
                if elem.tag == f'{ns}p':
                    texts = []
                    for t in elem.iter(f'{ns}t'):
                        if t.text:
                            texts.append(t.text)
                    line = ''.join(texts).strip()
                    if line:
                        text_parts.append({"style": "Unknown", "html_tag": "p", "text": line, "images": []})
                    elem.clear()
    paragraphs = [p for p in "\n".join(p["text"] for p in text_parts).split("\n") if p.strip()]
    return {
        "text": "\n".join(paragraphs),
        "structured": text_parts,
        "paragraphs": len(paragraphs),
        "method": "zipfile+xml",
    }


def extract_docx_images(filepath: str) -> dict:
    """提取 .docx 内嵌图片到临时目录（复用 _extract_images_from_doc）
    返回图片文件列表供后续 upload+append 使用。
    注意：extract_docx 已合并图片提取，通常无需单独调用此函数。
    """
    if not _ensure_lib("docx", "python-docx"):
        return {"error": "无法安装 python-docx，请检查网络或手动安装"}
    from docx import Document

    doc = Document(filepath)
    source_dir = str(Path(filepath).parent)
    img_result = _extract_images_from_doc(doc, source_dir=source_dir)

    return {
        "images_dir": img_result["images_dir"],
        "count": len(img_result["images"]),
        "images": img_result["images"],
        "source_file": str(filepath),
    }


def extract_pdf(filepath: str) -> dict:
    """提取 .pdf 文本（PyPDF2）"""
    if not _ensure_lib("PyPDF2", "PyPDF2"):
        return {"error": "无法安装 PyPDF2，请检查网络或手动安装"}

    from PyPDF2 import PdfReader
    reader = PdfReader(filepath)
    paragraphs = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            for line in text.split("\n"):
                line = line.strip()
                if line:
                    paragraphs.append(line)
    return {"text": "\n".join(paragraphs), "paragraphs": len(paragraphs), "method": "PyPDF2"}


EXTRACTORS = {
    ".docx": extract_docx,
    ".pdf":  extract_pdf,
}


def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "usage": "python cli_document.py <file_path> | python cli_document.py docx_images <file_path>",
            "supported": list(EXTRACTORS.keys()),
            "subcommands": ["docx_images — 提取 .docx 内嵌图片到临时目录"],
        }, ensure_ascii=False, indent=2))
        sys.exit(0)

    # 子命令：docx_images
    if sys.argv[1] == "docx_images":
        if len(sys.argv) < 3:
            print(json.dumps({"error": "用法: python cli_document.py docx_images <file_path>", "supported": [".docx"]}, ensure_ascii=False))
            sys.exit(1)
        filepath = Path(sys.argv[2]).resolve()
        if not filepath.exists():
            print(json.dumps({"error": f"文件不存在: {filepath}"}, ensure_ascii=False))
            sys.exit(1)
        if filepath.suffix.lower() != ".docx":
            print(json.dumps({"error": f"docx_images 仅支持 .docx 格式, 当前: {filepath.suffix}", "supported": [".docx"]}, ensure_ascii=False))
            sys.exit(1)
        try:
            result = extract_docx_images(str(filepath))
        except Exception as e:
            result = {"error": f"图片提取失败: {e}"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)

    filepath = Path(sys.argv[1]).resolve()
    if not filepath.exists():
        print(json.dumps({"error": f"文件不存在: {filepath}"}, ensure_ascii=False))
        sys.exit(1)

    suffix = filepath.suffix.lower()
    if suffix not in EXTRACTORS:
        print(json.dumps({
            "error": f"不支持的文件格式: {suffix}",
            "supported": list(EXTRACTORS.keys()),
        }, ensure_ascii=False))
        sys.exit(1)

    try:
        result = EXTRACTORS[suffix](str(filepath))
    except Exception as e:
        result = {"error": f"提取失败: {e}"}

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
