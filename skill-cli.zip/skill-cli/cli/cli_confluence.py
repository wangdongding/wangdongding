"""
Confluence CLI — 封装 Confluence 平台所有增删改查操作
Skill 通过 Bash Tool 调用本文件: python cli_confluence.py <command> <args>
Token 从 token_store.py 自动读取，无需每次传入
"""
import sys
import io

# Windows 上 stdout/stderr 可能用 GBK 编码，导致中文乱码
# 此设置比环境变量 PYTHONIOENCODING 更可靠，因为子进程可能不继承父环境
if sys.stdout.encoding != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

import json
import os
import re
import subprocess
import functools
import mimetypes
import urllib.request
import urllib.parse
import urllib.error
from pathlib import Path

# 导入 token_store（同目录）
sys.path.insert(0, str(Path(__file__).parent))
from token_store import load_token, get_token_path

# ==================== Confluence 固定配置 ====================
CONFLUENCE_BASE_URL = "http://confluence.yuwei.com:8090"

# 页面 Web UI URL 模板（viewpage.action 格式）
_PAGE_VIEW_URL = f"{CONFLUENCE_BASE_URL}/pages/viewpage.action?pageId={{id}}"
# 短链接 URL 模板（tiny link，基于 pageId 编码）
_HOME_VIEW_URL = f"{CONFLUENCE_BASE_URL}/x/{{tiny_key}}"

CONFLUENCE_API = {
    "get_page":         "/rest/api/content/{id}?expand=body.storage,version,space,ancestors",
    "search":           "/rest/api/content/search",
    "create_page":      "/rest/api/content",
    "update_page":      "/rest/api/content/{id}",
    "delete_page":      "/rest/api/content/{id}",
    "spaces":           "/rest/api/space",
    "children":         "/rest/api/content/{id}/child/page",
    # 新增 API
    "get_by_title":     "/rest/api/content?title={title}&spaceKey={space}&expand=body.storage,version,space",
    "comments":         "/rest/api/content/{id}/child/comment?expand=body.storage,version",
    "attachments":      "/rest/api/content/{id}/child/attachment",
    "versions":         "/rest/api/content/{id}/version?limit={limit}&expand=content",
    "ancestors":        "/rest/api/content/{id}?expand=ancestors",
    "space_detail":     "/rest/api/space/{key}",
    "current_user":     "/rest/api/user/current",
    "labels":           "/rest/api/content/{id}/label",
}


def _get_auth() -> str:
    """从 token_store 获取 Confluence token"""
    cfg = load_token("confluence")
    if not cfg:
        print(json.dumps({
            "error": "Confluence token 未配置，请先运行 Skill 配置 token",
            "token_path": get_token_path()
        }, ensure_ascii=False))
        sys.exit(1)
    return cfg["token"]


def _request(method: str, url: str, token: str, data: dict = None) -> dict:
    """统一 HTTP 请求，使用 urllib 替代 curl（避免 Windows 编码问题）"""
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    body = json.dumps(data, ensure_ascii=False).encode("utf-8") if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        status = resp.status
        if status == 204:
            return {"success": True}
        raw = resp.read().decode("utf-8")
        if not raw:
            return {"success": True}
        return json.loads(raw)
    except urllib.error.HTTPError as e:
        try:
            result = json.loads(e.read().decode("utf-8"))
        except Exception:
            result = {"error": f"HTTP {e.code}: {e.reason}"}
        if e.code == 401:
            result["_hint"] = "Token 可能已过期，请重新配置"
        if e.code == 403:
            result["_hint"] = "权限不足或空间 key 不正确"
        return result
    except urllib.error.URLError as e:
        return {"error": str(e.reason)}
    except Exception as e:
        return {"error": str(e)}


def _page_urls(page_id, data=None):
    """从 API 响应提取 _links，生成格式化的 webui 和 tinyui 链接"""
    webui = _PAGE_VIEW_URL.format(id=page_id)
    tinyui = None
    if data:
        tinyui_path = (data.get("_links") or {}).get("tinyui")
        if tinyui_path:
            tinyui = f"{CONFLUENCE_BASE_URL}{tinyui_path}"
    result = {"webui": webui}
    if tinyui:
        result["tinyui"] = tinyui
    return result


def _sanitize_html(content: str) -> str:
    """转义 HTML 中不属于标签/实体的裸 < 和 &，避免 Confluence XHTML 400。
    - 合法标签（如 <p> <h1> </div> <ac:macro>）保留
    - 裸 < 后跟空格/数字/中文等 → &lt;
    - 裸 & 后不跟完整实体 → &amp;
    """
    # 裸 <：后面紧跟的不是字母、/、!（注释）→ &lt;
    content = re.sub(r'<(?![a-zA-Z/!])', '&lt;', content)
    # 裸 &：后面跟的不是已知实体格式 → &amp;
    content = re.sub(
        r'&(?!(?:amp|lt|gt|quot|apos|nbsp|#\d+|#[xX][0-9a-fA-F]+|[a-zA-Z]+);)',
        '&amp;', content,
    )
    return content


def handle_error(func):
    """统一错误处理装饰器"""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            return {"error": f"{func.__name__} 执行失败: {str(e)}"}
    return wrapper


# ==================== 命令实现 ====================

@handle_error
def cmd_view(page_id: str) -> dict:
    """查看页面详情（含正文内容）"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['get_page'].format(id=page_id)}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    ancestors = [{"id": a.get("id"), "title": a.get("title")} for a in data.get("ancestors", [])]
    result = {
        "id": data.get("id"),
        "title": data.get("title"),
        "type": data.get("type"),
        "space": (data.get("space") or {}).get("key"),
        "version": (data.get("version") or {}).get("number"),
        "body": (data.get("body") or {}).get("storage", {}).get("value"),
        "ancestors": ancestors,
        "links": _page_urls(data.get("id"), data),
    }
    # API 明确返回了 ancestors 字段（expand=ancestors），空数组=根页面
    if "ancestors" in data and len(ancestors) == 0:
        result["is_root"] = True
    return result


@handle_error
def cmd_search(cql: str) -> dict:
    """CQL 搜索页面"""
    token = _get_auth()
    encoded_cql = urllib.parse.quote(cql, safe="")
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['search']}?cql={encoded_cql}&limit=10&expand=space"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "totalSize": data.get("size"),
        "cql": cql,
        "results": [
            {"id": r.get("id"), "title": r.get("title"), "type": r.get("type"), "space": (r.get("space") or {}).get("key"),
             "links": _page_urls(r.get("id"), r)}
            for r in data.get("results", [])
        ],
    }


@handle_error
def cmd_search_page(space_key: str, title: str = "", text: str = "") -> dict:
    """搜索页面（无需手写 CQL），参数: space_key [title] [text]
    - space_key: 空间 key，必传
    - title: 标题模糊匹配（可选），使用 ~ 操作符
    - text: 正文模糊匹配（可选），使用 ~ 操作符
    示例: python cli_confluence.py search_page DEV "~需求分析"
    """
    cql_parts = [f"space = \"{space_key}\""]
    if title:
        # 如果用户没加 ~，自动添加模糊匹配
        title_expr = title.strip()
        if not title_expr.startswith("~"):
            title_expr = f"~\"{title_expr}\""
        elif title_expr.startswith("~") and not title_expr.startswith("~\""):
            title_expr = f"~\"{title_expr[1:]}\""
        cql_parts.append(f"title {title_expr}")
    if text:
        text_expr = text.strip()
        if not text_expr.startswith("~"):
            text_expr = f"~\"{text_expr}\""
        elif text_expr.startswith("~") and not text_expr.startswith("~\""):
            text_expr = f"~\"{text_expr[1:]}\""
        cql_parts.append(f"text {text_expr}")
    cql = " AND ".join(cql_parts)
    result = cmd_search(cql)
    # search_page CQL 对中文标题匹配能力弱——无结果时自动 fallback 到 page_by_title
    if title and not result.get("totalSize") and result.get("results") is not None:
        print(f"[CLI] CQL 搜索无结果，fallback 到 page_by_title", file=sys.stderr)
        return cmd_page_by_title(space_key, title)
    return result


@handle_error
def cmd_create(space: str, title: str, content: str, parent_id: str = "") -> dict:
    """创建页面 — space 不存在时自动返回可用空间列表"""
    token = _get_auth()
    # 惰性校验：先试空间，404 则列出可用空间
    space_url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['space_detail'].format(key=space)}"
    space_data = _request("GET", space_url, token)
    if "error" in space_data:
        # 空间不存在或无权限（403/404），自动列出可用空间帮助用户纠正
        spaces_url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['spaces']}?limit=50"
        spaces_data = _request("GET", spaces_url, token)
        available = [
            {"key": r.get("key"), "name": r.get("name", r.get("key"))}
            for r in (spaces_data.get("results") or [])
        ]
        error_msg = space_data.get("error", "")
        if "403" in error_msg:
            return {
                "error": f"空间 '{space}' 无权限访问",
                "hint": "请确认空间 key 是否正确，或联系管理员开通权限",
                "available_spaces": available,
            }
        return {
            "error": f"空间 '{space}' 不存在",
            "hint": "请从以下可用空间中选择正确的 key",
            "available_spaces": available,
        }
    content = _sanitize_html(content)
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['create_page']}"
    payload = {
        "type": "page",
        "title": title,
        "space": {"key": space},
        "body": {
            "storage": {
                "value": content,
                "representation": "storage"
            }
        }
    }
    if parent_id:
        payload["ancestors"] = [{"id": int(parent_id)}]
    data = _request("POST", url, token, data=payload)
    if "error" in data:
        return data
    page_id = data.get("id")
    result = {
        "id": page_id,
        "title": data.get("title"),
        "type": data.get("type"),
        "space": (data.get("space") or {}).get("key"),
        "version": (data.get("version") or {}).get("number"),
        "_links": data.get("_links"),
        "links": _page_urls(page_id, data),
    }
    if page_id is None:
        result["_diagnose"] = "id is null — Confluence 可能未在 body 中返回 id 字段，请用 page_by_title 确认页面是否创建成功"
        result["_raw_keys"] = list(data.keys())[:20]
        # 打印完整响应到 stderr 方便排查大 payload 问题
        print(f"[CLI] create 返回 id=null, 完整响应: {json.dumps(data, ensure_ascii=False)[:500]}", file=sys.stderr)
    return result


@handle_error
def cmd_update(page_id: str, title: str, body: str) -> dict:
    """更新页面 — 自动获取当前版本号并 +1，与 create 传参风格一致
    - title: 新标题（传 "_" 表示不修改标题）
    - body: 新正文 HTML（传 "_" 表示不修改正文，支持 @filepath 语法）
    """
    token = _get_auth()
    # 先获取当前页面版本号
    view_url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['get_page'].format(id=page_id)}"
    view_data = _request("GET", view_url, token)
    if "error" in view_data:
        return view_data
    current_version = (view_data.get("version") or {}).get("number", 1)
    current_title = view_data.get("title", "")
    # 构造 payload
    resolved_title = current_title if title == "_" else title
    payload = {
        "version": {"number": current_version + 1},
        "title": resolved_title,
        "type": "page",
    }
    if body != "_":
        payload["body"] = {
            "storage": {
                "value": _sanitize_html(body),
                "representation": "storage"
            }
        }
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['update_page'].format(id=page_id)}"
    data = _request("PUT", url, token, data=payload)
    if "error" in data:
        return data
    page_id = data.get("id")
    result = {
        "id": page_id,
        "title": data.get("title"),
        "type": data.get("type"),
        "space": (data.get("space") or {}).get("key"),
        "version": (data.get("version") or {}).get("number"),
        "_links": data.get("_links"),
        "links": _page_urls(page_id, data),
    }
    if page_id is None:
        result["_diagnose"] = "id is null — Confluence 可能未在 body 中返回 id 字段"
        result["_raw_keys"] = list(data.keys())[:20]
        print(f"[CLI] update 返回 id=null, 完整响应: {json.dumps(data, ensure_ascii=False)[:500]}", file=sys.stderr)
    return result


def _insert_after_heading(body: str, after: str, content: str) -> str:
    """在指定 heading 后面插入 content。
    after 格式: "h2:标题文本" 或 "heading:标题文本"
    - h1~h6: 在对应级别的 heading 后插入
    - heading: 在任意级别的 heading 后插入
    匹配失败时 fallback 到末尾追加
    """
    # 解析 after 格式
    m = re.match(r'^(h([1-6])|heading):(.+)$', after, re.IGNORECASE)
    if not m:
        print(f"[CLI] after 参数格式无效: '{after}'，期望 'h2:标题文本' 或 'heading:标题文本'，fallback 到末尾追加", file=sys.stderr)
        return body + content

    level = m.group(2)  # h1~h6 的数字，heading 模式为 None
    heading_text = m.group(3).strip()

    # 两步法：先提取所有同级别 heading，再逐个精确匹配
    if level:
        tag_pattern = re.compile(
            r'<h' + level + r'(?:\s[^>]*)?>(.*?)</h' + level + r'>',
            re.IGNORECASE | re.DOTALL
        )
    else:
        tag_pattern = re.compile(
            r'<h[1-6](?:\s[^>]*)?>(.*?)</h[1-6]>',
            re.IGNORECASE | re.DOTALL
        )

    matches = list(tag_pattern.finditer(body))
    if not matches:
        print(f"[CLI] after 未找到任何 heading，fallback 到末尾追加", file=sys.stderr)
        return body + content

    # 逐个比较：优先精确匹配，其次包含匹配
    exact_match = None
    contains_match = None
    for idx, match in enumerate(matches):
        inner_text = re.sub(r'<[^>]+>', '', match.group(1)).strip()  # 去掉内嵌标签
        if inner_text == heading_text:
            exact_match = (idx, match)
            break
        if heading_text in inner_text:
            if contains_match is None:
                contains_match = (idx, match)

    chosen = exact_match or contains_match
    if not chosen:
        # 打印所有找到的 heading 帮助排查
        found = [re.sub(r'<[^>]+>', '', m.group(1)).strip() for m in matches[:10]]
        print(f"[CLI] after 未找到匹配的 heading: '{heading_text}'，页面中的 heading: {found[:5]}...，fallback 到末尾追加", file=sys.stderr)
        return body + content

    idx, match = chosen
    matched_text = re.sub(r'<[^>]+>', '', match.group(1)).strip()
    insert_pos = match.end()
    print(f"[CLI] after 匹配成功: <h{level or '?'}> #{idx+1} '{matched_text}' (位置 {insert_pos})，在此后插入内容", file=sys.stderr)
    return body[:insert_pos] + content + body[insert_pos:]


@handle_error
def cmd_append(page_id: str, content: str, after: str = "") -> dict:
    """在页面追加内容 — 内部自动 view→拼接/插入→update，对调用者透明
    - content: 要追加的 HTML 片段（如 '<p>新增段落</p>' 或 '<ac:image>...</ac:image>'）
    - after: 可选，定位插入位置，格式 "h2:标题文本" 或 "heading:标题文本"
      不传 after 时在末尾追加
    支持 @filepath 语法从文件读取追加内容
    """
    token = _get_auth()
    content = _sanitize_html(content)
    # 获取当前页面内容
    view_url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['get_page'].format(id=page_id)}"
    view_data = _request("GET", view_url, token)
    if "error" in view_data:
        return view_data
    current_body = (view_data.get("body") or {}).get("storage", {}).get("value", "")
    current_version = (view_data.get("version") or {}).get("number", 1)
    current_title = view_data.get("title", "")
    # 拼接：after 非空时定位插入，否则末尾追加
    if after:
        new_body = _insert_after_heading(current_body, after, content)
    else:
        new_body = current_body + content
    # 全量 update
    payload = {
        "version": {"number": current_version + 1},
        "title": current_title,
        "type": "page",
        "body": {
            "storage": {
                "value": new_body,
                "representation": "storage"
            }
        }
    }
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['update_page'].format(id=page_id)}"
    data = _request("PUT", url, token, data=payload)
    if "error" in data:
        return data
    page_id_resp = data.get("id")
    result = {
        "id": page_id_resp,
        "title": data.get("title"),
        "type": data.get("type"),
        "space": (data.get("space") or {}).get("key"),
        "version": (data.get("version") or {}).get("number"),
        "appended_length": len(content),
        "_links": data.get("_links"),
        "links": _page_urls(page_id_resp, data),
    }
    return result


@handle_error
def cmd_delete(page_id: str) -> dict:
    """删除页面"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['delete_page'].format(id=page_id)}"
    result = _request("DELETE", url, token)
    if "error" not in result:
        return {"success": True, "message": f"页面 {page_id} 已删除"}
    return result


@handle_error
def cmd_spaces(limit: str = "50") -> dict:
    """列出所有空间（支持 limit 参数，默认 50）"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['spaces']}?limit={limit}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "results": [
            {"key": s.get("key"), "name": s.get("name"), "type": s.get("type"), "id": s.get("id")}
            for s in data.get("results", [])
        ]
    }


@handle_error
def cmd_children(page_id: str) -> dict:
    """查看子页面列表"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['children'].format(id=page_id)}?limit=25&expand=space"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "results": [
            {"id": r.get("id"), "title": r.get("title"), "type": r.get("type"), "space": (r.get("space") or {}).get("key"),
             "links": _page_urls(r.get("id"), r)}
            for r in data.get("results", [])
        ]
    }


@handle_error
def cmd_page_by_title(space: str, title: str) -> dict:
    """按空间+标题查找页面"""
    token = _get_auth()
    import urllib.parse
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['get_by_title'].format(space=urllib.parse.quote(space), title=urllib.parse.quote(title))}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "results": [
            {"id": r.get("id"), "title": r.get("title"), "type": r.get("type"), "space": (r.get("space") or {}).get("key"),
             "version": (r.get("version") or {}).get("number")}
            for r in data.get("results", [])
        ]
    }


@handle_error
def cmd_comments(page_id: str) -> dict:
    """获取页面评论列表"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['comments'].format(id=page_id)}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "totalSize": data.get("size"),
        "results": [
            {
                "id": r.get("id"),
                "title": r.get("title"),
                "body": (r.get("body") or {}).get("storage", {}).get("value"),
                "author": (r.get("version") or {}).get("by", {}).get("displayName") if r.get("version") else None,
                "created": (r.get("version") or {}).get("when") if r.get("version") else None,
            }
            for r in data.get("results", [])
        ],
    }


@handle_error
def cmd_comment_add(page_id: str, content: str) -> dict:
    """给页面添加评论"""
    token = _get_auth()
    content = _sanitize_html(content)
    # 评论通过 POST /rest/api/content 创建，指定 container 为页面
    url = f"{CONFLUENCE_BASE_URL}/rest/api/content"
    payload = {
        "type": "comment",
        "container": {"id": int(page_id), "type": "page"},
        "body": {
            "storage": {
                "value": content,
                "representation": "storage"
            }
        }
    }
    data = _request("POST", url, token, data=payload)
    if "error" in data:
        return data
    page_id = data.get("id")
    return {
        "id": page_id,
        "type": data.get("type"),
        "body": (data.get("body") or {}).get("storage", {}).get("value"),
        "links": _page_urls(page_id, data),
    }


@handle_error
def cmd_attachments(page_id: str) -> dict:
    """获取页面附件列表"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['attachments'].format(id=page_id)}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "totalSize": data.get("size"),
        "results": [
            {
                "id": r.get("id"),
                "title": r.get("title"),
                "mediaType": (r.get("metadata") or {}).get("mediaType") or (r.get("extensions") or {}).get("mediaType"),
                "fileSize": (r.get("extensions") or {}).get("fileSize"),
                "downloadUrl": f"{CONFLUENCE_BASE_URL}{(r.get('_links') or {}).get('download')}" if r.get("_links", {}).get("download") else None,
            }
            for r in data.get("results", [])
        ],
    }


# 附件上传命令
@handle_error
def cmd_upload(page_id: str, filepath: str) -> dict:
    """上传附件到页面 — filepath: 本地文件路径"""
    # 路径类型检测
    resolved = _resolve_filepath(filepath)
    if os.path.isdir(resolved):
        # 列出目录内文件，帮助用户选择
        files = [f for f in os.listdir(resolved) if os.path.isfile(os.path.join(resolved, f))]
        return {
            "error": f"路径是目录而非文件: {resolved}",
            "hint": "请指定具体文件路径",
            "files_in_dir": files[:10],
        }
    if not os.path.isfile(resolved):
        return {"error": f"文件不存在: {resolved}"}
    token = _get_auth()
    filename = os.path.basename(resolved)
    mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['attachments'].format(id=page_id)}"
    # 构建 multipart/form-data 请求（MIME 规范要求 CRLF 行尾）
    boundary = "----------WebKitFormBoundary7MA4YWxkQt"
    with open(resolved, "rb") as f:
        file_data = f.read()
    parts = []
    # multipart: metadata 部分
    parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{filename}\"\r\nContent-Type: {mime}\r\n\r\n".encode("utf-8"))
    # multipart: 文件数据部分（二进制）
    parts.append(file_data)
    parts.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))
    body = b"".join(parts)
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "X-Atlassian-Token": "no-check",  # 防 CSRF
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=60)
        raw = resp.read().decode("utf-8")
        data = json.loads(raw)
        # Confluence multipart upload 返回 {"results": [{attachment}]}，从 results[0] 取附件元数据
        att = (data.get("results") or [{}])[0] if isinstance(data.get("results"), list) else data
        result = {
            "id": att.get("id"),
            "title": att.get("title"),
            "mediaType": (att.get("metadata") or {}).get("mediaType"),
            "fileSize": (att.get("extensions") or {}).get("fileSize"),
            "downloadUrl": f"{CONFLUENCE_BASE_URL}{(att.get('_links') or {}).get('download')}" if (att.get("_links") or {}).get("download") else None,
            "pageId": page_id,
            "links": _page_urls(page_id, data),
        }
        # 上传成功后自动清理 _docx_images_temp 中的临时图片文件
        if "_docx_images_temp" in resolved:
            try:
                os.remove(resolved)
                print(f"[CLI] 已清理临时图片: {resolved}", file=sys.stderr)
                parent_dir = os.path.dirname(resolved)
                if os.path.isdir(parent_dir) and not os.listdir(parent_dir):
                    os.rmdir(parent_dir)
                    print(f"[CLI] 已清理空目录: {parent_dir}", file=sys.stderr)
            except Exception:
                pass
        return result
    except urllib.error.HTTPError as e:
        try:
            err_body = e.read().decode("utf-8")
            err_data = json.loads(err_body)
            return err_data
        except Exception as e:
            return {"error": f"上传失败: {str(e)}"}


@handle_error
def cmd_versions(page_id: str, limit: str = "10") -> dict:
    """获取页面版本历史（支持 limit 参数，默认 10）"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['versions'].format(id=page_id, limit=limit)}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    versions = []
    for v in data.get("results", []):
        versions.append({
            "number": v.get("number"),
            "when": v.get("when"),
            "message": v.get("message") if v.get("message") else None,
            "by": (v.get("by") or {}).get("displayName"),
        })
    return {
        "totalSize": data.get("size"),
        "limit": limit,
        "versions": versions,
    }


@handle_error
def cmd_ancestors(page_id: str) -> dict:
    """获取页面祖先列表"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['ancestors'].format(id=page_id)}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "ancestors": [
            {"id": a.get("id"), "title": a.get("title"), "type": a.get("type")}
            for a in data.get("ancestors", [])
        ]
    }


@handle_error
def cmd_space(key: str) -> dict:
    """获取空间详情"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['space_detail'].format(key=key)}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "id": data.get("id"),
        "key": data.get("key"),
        "name": data.get("name"),
        "type": data.get("type"),
        "description": (data.get("description") or {}).get("plain", {}).get("value"),
        "homepage": (data.get("homepage") or {}).get("id") if data.get("homepage") else None,
    }


@handle_error
def cmd_current_user() -> dict:
    """获取当前用户信息"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['current_user']}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "username": data.get("username"),
        "displayName": data.get("displayName"),
        "email": data.get("email"),
        "type": data.get("type"),
    }


@handle_error
def cmd_test_connection() -> dict:
    """测试 Confluence API 连通性"""
    token = _get_auth()
    # 用获取当前用户接口来验证连通性
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['current_user']}"
    data = _request("GET", url, token)
    if "error" in data:
        return {"connected": False, "error": data.get("error")}
    return {
        "connected": True,
        "user": data.get("displayName"),
        "baseUrl": CONFLUENCE_BASE_URL,
    }


@handle_error
def cmd_labels(page_id: str) -> dict:
    """获取页面标签列表"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['labels'].format(id=page_id)}"
    data = _request("GET", url, token)
    if "error" in data:
        return data
    return {
        "results": [
            {"name": r.get("name"), "prefix": r.get("prefix"), "id": r.get("id")}
            for r in data.get("results", [])
        ]
    }


@handle_error
def cmd_label_add(page_id: str, labels: str) -> dict:
    """添加页面标签（逗号分隔）"""
    token = _get_auth()
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['labels'].format(id=page_id)}"
    label_names = [l.strip() for l in labels.split(",") if l.strip()]
    payload = [{"prefix": "global", "name": name} for name in label_names]
    data = _request("POST", url, token, data=payload)
    if "error" in data:
        return data
    return {
        "results": [
            {"name": r.get("name"), "prefix": r.get("prefix"), "id": r.get("id")}
            for r in data.get("results", [])
        ]
    }


@handle_error
def cmd_label_delete(page_id: str, label: str) -> dict:
    """删除页面标签"""
    token = _get_auth()
    import urllib.parse
    label_quoted = urllib.parse.quote(label, safe="")
    url = f"{CONFLUENCE_BASE_URL}{CONFLUENCE_API['labels'].format(id=page_id)}?name={label_quoted}"
    result = _request("DELETE", url, token)
    if "error" not in result:
        return {"success": True, "message": f"标签 '{label}' 已从页面 {page_id} 移除"}
    return result


@handle_error
def cmd_get_page_by_url(page_url: str) -> dict:
    """根据 Confluence URL 获取页面详情（支持 viewpage.action、tiny、display、spaces 格式）"""
    import re

    parsed = urllib.parse.urlparse(page_url)
    page_id = None

    # 1. /pages/viewpage.action?pageId=187917408
    qs = urllib.parse.parse_qs(parsed.query)
    if "pageId" in qs:
        page_id = qs["pageId"][0]

    # 2. /spaces/DEVOPS/pages/187917408
    if not page_id:
        m = re.search(r'/pages/(\d+)', parsed.path)
        if m:
            page_id = m.group(1)

    # 3. /x/YGQzCw (tiny link) — 用 HEAD 请求跟随重定向获取 pageId
    if not page_id:
        token = _get_auth()
        head_url = f"{CONFLUENCE_BASE_URL}{parsed.path}{('?' + parsed.query) if parsed.query else ''}"
        req = urllib.request.Request(head_url, headers={"Authorization": f"Bearer {token}"}, method="HEAD")
        try:
            resp = urllib.request.urlopen(req, timeout=10)
            final_url = resp.geturl()
            final_qs = urllib.parse.parse_qs(urllib.parse.urlparse(final_url).query)
            if "pageId" in final_qs:
                page_id = final_qs["pageId"][0]
        except urllib.error.HTTPError as e:
            # 301/302 redirect — 从 Location header 取
            location = e.headers.get("Location") or e.headers.get("location")
            if location:
                if location.startswith("/"):
                    location = f"{CONFLUENCE_BASE_URL}{location}"
                loc_qs = urllib.parse.parse_qs(urllib.parse.urlparse(location).query)
                if "pageId" in loc_qs:
                    page_id = loc_qs["pageId"][0]
        except Exception:
            pass

    if not page_id:
        return {"error": f"未能从 URL 中提取 pageId: {page_url}"}

    # 调用 cmd_view 获取页面详情
    return cmd_view(page_id)


# ==================== 透传子命令（路由到 cli_document.py） ====================

def _passthrough_doc_command(sub_cmd: str, filepath: str) -> dict:
    """将 docx 相关子命令透传到 cli_document.py 执行，统一入口"""
    doc_cli = str(Path(__file__).parent / "cli_document.py")
    cmd_args = [sys.executable, doc_cli, sub_cmd, filepath]
    try:
        result = subprocess.run(cmd_args, capture_output=True, encoding="utf-8", timeout=30)
        if result.returncode != 0:
            try:
                return json.loads(result.stdout)
            except json.JSONDecodeError:
                return {"error": result.stderr.strip() or result.stdout.strip()}
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return {"raw": result.stdout.strip()}
    except subprocess.TimeoutExpired:
        return {"error": "cli_document.py 调用超时 (30s)"}

@handle_error
def cmd_docx_images(filepath: str) -> dict:
    """提取 .docx 内嵌图片到临时目录 — 透传到 cli_document.py docx_images"""
    return _passthrough_doc_command("docx_images", filepath)

# ==================== CLI 入口 ====================

COMMANDS = {
    "view":           ("page_id",                           cmd_view),
    "search":         ("cql",                               cmd_search),
    "search_page":    ("space_key,title,text",              cmd_search_page),
    "create":         ("space,title,content,parent_id",     cmd_create),
    "update":         ("page_id,title,body",               cmd_update),
    "append":         ("page_id,content,after",             cmd_append),
    "delete":         ("page_id",                           cmd_delete),
    "spaces":         ("limit",                             cmd_spaces),
    "children":       ("page_id",                           cmd_children),
    # 新增命令
    "page_by_title":  ("space,title",                       cmd_page_by_title),
    "comments":       ("page_id",                           cmd_comments),
    "comment_add":    ("page_id,content",                   cmd_comment_add),
    "attachments":    ("page_id",                           cmd_attachments),
    "upload":         ("page_id,filepath",                  cmd_upload),
    "versions":       ("page_id,limit",                     cmd_versions),
    "ancestors":      ("page_id",                           cmd_ancestors),
    "space":          ("key",                               cmd_space),
    "current_user":   ("",                                  cmd_current_user),
    "test":           ("",                                  cmd_test_connection),
    "labels":         ("page_id",                           cmd_labels),
    "label_add":      ("page_id,labels",                    cmd_label_add),
    "label_delete":   ("page_id,label",                     cmd_label_delete),
    # 根据 URL 获取页面
    "get_by_url":     ("page_url",                          cmd_get_page_by_url),
    # docx 图片提取（透传到 cli_document.py）
    "docx_images":    ("filepath",                          cmd_docx_images),
}

def _resolve_filepath(filepath: str) -> str:
    """解析 @file 路径，返回绝对路径。
    如果相对路径解析失败，尝试 $HOME/.skill-cli/tmp/ 下的同名文件。
    因为 MSYS2 bash、Windows Python、Claude Code Write 工具对 /tmp 的映射可能不一致。
    """
    fp = Path(filepath)
    if fp.exists():
        return str(fp)

    # 尝试用 Path.resolve() 获得绝对路径后再判断
    resolved = str(fp.resolve())
    if Path(resolved).exists():
        return resolved

    # 最后 fallback：在 ~/.skill-cli/tmp/ 下找同名文件
    # （SKILL.md 约定临时文件统一写到工程目录，此处做最后兜底）
    home_skill_tmp = Path.home() / ".skill-cli" / "tmp" / fp.name
    if home_skill_tmp.exists():
        return str(home_skill_tmp)

    # 都没找到，返回原路径（让后续 open() 自己报错）
    return filepath


def main():
    """CLI 入口: python cli_confluence.py <command> [args...]"""
    if len(sys.argv) < 2:
        print(json.dumps({
            "usage": "python cli_confluence.py <command> [args...]",
            "commands": {name: params for name, (params, _) in COMMANDS.items()},
            "note": "Token 自动从 ~/.skill-cli/tokens.json 读取"
        }, ensure_ascii=False, indent=2))
        sys.exit(0)

    cmd_name = sys.argv[1]
    if cmd_name not in COMMANDS:
        # 别名表 + 模糊匹配
        _ALIASES = {
            "list-spaces": "spaces", "list_spaces": "spaces", "list-space": "spaces",
            "list-labels": "labels", "list_labels": "labels",
            "list-pages": "search", "list_pages": "search",
            "get-by-url": "get_by_url", "get-by-title": "page_by_title",
            "get_by_title": "page_by_title",
            "page": "page_by_title", "find": "search",
            "post": "create", "put": "update",
            "check-token": "test", "check_token": "test",
            "ping": "test",
        }
        suggestion = _ALIASES.get(cmd_name)
        if not suggestion:
            # 子串匹配：命令名包含输入的词 或 输入的词包含命令名
            for name in COMMANDS:
                if name.replace("_", "") in cmd_name.replace("-", "").replace("_", "") or cmd_name.replace("-", "").replace("_", "") in name.replace("_", ""):
                    suggestion = name
                    break
        if suggestion:
            # 别名命中：自动转向正确命令并继续执行
            print(f"[CLI] 别名 '{cmd_name}' → '{suggestion}'，自动执行 {suggestion}", file=sys.stderr)
            cmd_name = suggestion
        else:
            msg = {"error": f"未知命令: {cmd_name}", "available": list(COMMANDS.keys())}
            print(json.dumps(msg, ensure_ascii=False))
            sys.exit(1)

    param_names, func = COMMANDS[cmd_name]
    if param_names:
        param_list = [p.strip() for p in param_names.split(",")]
    else:
        param_list = []

    args = {}
    # 支持 @filepath 语法从文件读取参数值，绕过 shell 传参长度限制
    for i, pname in enumerate(param_list):
        if i + 2 < len(sys.argv):
            val = sys.argv[i + 2]
            if val.startswith("@"):
                filepath = val[1:]
                resolved = _resolve_filepath(filepath)
                try:
                    with open(resolved, "r", encoding="utf-8") as f:
                        val = f.read()
                    # Debug: 打印读取的文件内容前 200 字符（stderr 输出，不影响 JSON）
                    if len(val) > 200:
                        print(f"[CLI] 读取文件 {resolved}, 内容长度: {len(val)}, 前 200 字符: {val[:200]}...", file=sys.stderr)
                    else:
                        print(f"[CLI] 读取文件 {resolved}, 完整内容: {val}", file=sys.stderr)
                except Exception as e:
                    print(json.dumps({"error": f"读取文件失败: {resolved} — {e}"}, ensure_ascii=False))
                    sys.exit(1)
                # 自动清理 skill_temp 临时文件（SKILL.md 约定：创建完成后清理）
                if resolved and os.path.basename(resolved).startswith("skill_temp"):
                    try:
                        os.remove(resolved)
                        print(f"[CLI] 已清理临时文件: {resolved}", file=sys.stderr)
                    except Exception:
                        pass
            args[pname] = val
        elif pname in ("parent_id", "after"):
            args[pname] = ""
        elif pname == "title" and cmd_name == "update":
            # update 命令 title 缺少时默认 "_"，表示不修改标题
            args[pname] = "_"
        elif pname == "limit":
            # spaces 默认 50，versions 默认 10 — 按 COMMANDS 中的命令名区分
            args[pname] = "10" if cmd_name == "versions" else "50"
        else:
            hint = ""
            if cmd_name == "update" and pname in ("title", "body"):
                hint = f" — {pname} 传 '_' 表示不修改该字段"
            print(json.dumps({
                "error": f"缺少参数: {pname}",
                "usage": f"python cli_confluence.py {cmd_name} {param_names}",
                "hint": hint,
            }, ensure_ascii=False))
            sys.exit(1)

    result = func(**args)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
