# Confluence 查看/搜索页面

## 快速模式

```
confluence_view(page_id="187917408")
confluence_get_page_by_url(page_url="http://confluence.yuwei.com:8090/pages/viewpage.action?pageId=187917408")
confluence_search_page(space_key="DEV", title="架构")    ← 模糊匹配（推荐），CQL 无结果时自动 fallback 到精确匹配
confluence_get_page_by_title(space="DEV", title="部署指南")  ← 精确匹配，标题必须完全一致
confluence_search(cql='space=DEV AND title~"架构"')
confluence_children(page_id="187917408")
confluence_get_ancestors(page_id="187917408")
confluence_spaces()
confluence_spaces(limit="100")
confluence_get_space(key="DEV")
```

**搜索策略**：
- **模糊搜索**用 `search_page`：标题不必完全一致，CQL 的 `~` 操作符做模糊匹配，对中文标题弱但会自动 fallback 到精确匹配
- **精确匹配**用 `page_by_title`：标题必须和 Confluence 中完全一致，适合已知确切标题的场景

## 交互模式

### 第1步：选操作

```
AskUserQuestion:
  questions:
    - question: "你要对 Confluence 执行什么操作？"
      header: "操作"
      options:
        - label: "按 page_id 查看"
        - label: "按 URL 查看"
        - label: "按标题查找"
        - label: "搜索页面"
      multiSelect: false
```

### 按 page_id 查看

```
AskUserQuestion:
  questions:
    - question: "输入页面 ID"
      header: "Page ID"
      options:
        - label: "输入具体数字 ID"
        - label: "我选另一个页面"
      multiSelect: false
```

### 按 URL 查看

```
AskUserQuestion:
  questions:
    - question: "粘贴 Confluence 页面 URL"
      header: "URL"
      options:
        - label: "粘贴完整 URL"
        - label: "我先查一下"
      multiSelect: false
```

### 按标题查找

```
AskUserQuestion:
  questions:
    - question: "选择空间"
      header: "空间"
      options: [从 confluence_spaces() 取最多3个 + Other]
      multiSelect: false
    - question: "输入页面标题（精确匹配）"
      header: "标题"
      options:
        - label: "输入页面标题（支持中文）"
        - label: "我换关键字搜搜看"
      multiSelect: false
```

### 搜索

```
AskUserQuestion:
  questions:
    - question: "输入搜索关键词"
      header: "关键词"
      options:
        - label: "输入 CQL 或关键词"
        - label: "帮我推荐搜索词"
      multiSelect: false
```

### 子页面

```
AskUserQuestion:
  questions:
    - question: "查看哪个页面的子页面？"
      header: "父页面"
      options:
        - label: "输入页面 ID"
        - label: "我先查一下页面"
      multiSelect: false
```

收集 page_id → `confluence_children(page_id)`

### 祖先页面

```
AskUserQuestion:
  questions:
    - question: "查看哪个页面的祖先路径？"
      header: "页面"
      options:
        - label: "输入页面 ID"
        - label: "我先查一下页面"
      multiSelect: false
```

收集 page_id → `confluence_get_ancestors(page_id)`

### 空间列表

直接调用 `confluence_spaces()` 或 `confluence_spaces(limit="100")`，无需参数收集。

若用户要查看具体空间详情：

```
AskUserQuestion:
  questions:
    - question: "查看哪个空间的详情？"
      header: "空间"
      options:
        - label: "输入空间 key（如 DEV）"
        - label: "我先列出所有空间"
      multiSelect: false
```

收集 key → `confluence_get_space(key)`

## 涉及函数

`confluence_view` `confluence_get_page_by_url` `confluence_search_page` `confluence_get_page_by_title` `confluence_search` `confluence_children` `confluence_get_ancestors` `confluence_spaces` `confluence_get_space`
