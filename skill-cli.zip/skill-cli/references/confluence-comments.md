# Confluence 评论管理

## 快速模式

```
confluence_get_comments(page_id="187917408")
confluence_add_comment(page_id="187917408", content="<p>评论内容</p>")
```

## 交互模式

### 查看评论

```
AskUserQuestion:
  questions:
    - question: "查看哪个页面的评论？"
      header: "页面"
      options:
        - label: "输入页面 ID"
        - label: "我先查一下页面"
      multiSelect: false
```

### 添加评论

```
AskUserQuestion:
  questions:
    - question: "给哪个页面添加评论？"
      header: "页面"
      options:
        - label: "输入页面 ID"
        - label: "我查一下再确认"
      multiSelect: false
    - question: "评论内容"
      header: "评论"
      options:
        - label: "补充说明"
        - label: "问题反馈"
        - label: "确认/同意"
      multiSelect: false
```

评论内容通过 Other 自由输入。

**预设选项→HTML 格式映射**：
- "补充说明" → `<p>补充说明：{用户输入的实际内容}</p>`
- "问题反馈" → `<p>问题反馈：{用户输入的实际内容}</p>`
- "确认/同意" → `<p>确认/同意：{用户输入的实际内容}</p>`

用户选择预设选项只是快捷标签，实际内容仍需在 Other 中输入。Claude 将预设标签作为前缀拼接进 `<p>` 标签，传入 `content` 参数。

## 涉及函数

`confluence_get_comments` `confluence_add_comment`
