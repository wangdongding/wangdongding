# Confluence 创建页面

## 快速模式

```
confluence_create(space="DEV", title="新页面标题", content="<p>页面内容</p>")
confluence_create(space="DEV", title="新页面标题", content="@./skill_temp.html", parent_id="187917408")
```

**参数说明**：

| 参数 | 必填 | 说明 |
|------|------|------|
| space | 必填 | 空间标识，如 DEV、DEVOPS |
| title | 必填 | 页面标题（支持中文） |
| content | 必填 | Confluence Storage Format HTML，或用 `@` 语法从文件读取 |
| parent_id | **可选** | `""` 或不传 → 创建在空间根目录；传入数字 ID → 作为该页面的子页面 |

- 小段 HTML 内容（短段落、简单格式）可以直接作为命令行参数传入
- 大段 HTML 内容（带多表格、多宏的复杂文档）使用 `@` 前缀让 CLI 从文件读取，绕开 shell 传参长度限制：

```bash
# 不传父页面（创建在根目录）
confluence_create(space="DEV", title="新页面标题", content="@./skill_temp.html")

# 传入父页面 ID（作为子页面创建）
confluence_create(space="DEV", title="新页面标题", content="@./skill_temp.html", parent_id="187917408")
```

## Storage Format HTML 模板

### 普通文档

```html
<h1>一级标题</h1>
<p>正文段落，支持 <strong>加粗</strong>、<em>斜体</em>、<code>代码</code>。</p>
<h2>二级标题</h2>
<ul>
  <li>列表项 1</li>
  <li>列表项 2</li>
</ul>
<ol>
  <li>步骤一：先做这个</li>
  <li>步骤二：再做这个</li>
</ol>
<p>更多内容...</p>
```

### 带表格

```html
<p>以下是一个汇总表格：</p>
<table>
  <tr><th>名称</th><th>类型</th><th>说明</th></tr>
  <tr><td>key1</td><td>string</td><td>参数说明</td></tr>
  <tr><td>key2</td><td>int</td><td>参数说明</td></tr>
</table>
```

### 带链接

```html
<p>相关文档：<a href="http://confluence.yuwei.com:8090/pages/viewpage.action?pageId=187917408">参考页面</a></p>
```

### 目录宏

```html
<p><ac:structured-macro ac:name="toc"/></p>
<h2>章节一</h2>
<p>内容...</p>
<h2>章节二</h2>
<p>内容...</p>
```

### 信息面板宏

```html
<p><ac:structured-macro ac:name="info">
  <ac:rich-text-body>这是一条重要提示信息。</ac:rich-text-body>
</ac:structured-macro></p>
```

### 提示/警告/备注宏

```html
<p><ac:structured-macro ac:name="tip">
  <ac:rich-text-body>小技巧：使用快捷键 Ctrl+S 保存。</ac:rich-text-body>
</ac:structured-macro></p>

<p><ac:structured-macro ac:name="warning">
  <ac:rich-text-body>注意：此操作不可逆。</ac:rich-text-body>
</ac:structured-macro></p>

<p><ac:structured-macro ac:name="note">
  <ac:rich-text-body>备注：此配置在 2.0 版本中已弃用。</ac:rich-text-body>
</ac:structured-macro></p>
```

### 面板宏（可自定义标题）

```html
<p><ac:structured-macro ac:name="panel">
  <ac:parameter ac:name="title">自定义标题</ac:parameter>
  <ac:rich-text-body>面板内的内容，可以包含任意格式。</ac:rich-text-body>
</ac:structured-macro></p>
```

### 状态标签宏

```html
<p><ac:structured-macro ac:name="status">
  <ac:parameter ac:name="title">已完成</ac:parameter>
  <ac:parameter ac:name="colour">Green</ac:parameter>
</ac:structured-macro></p>
<p>可用颜色：Green、Red、Yellow、Blue、Grey</p>
```

### 代码块宏

```html
<ac:structured-macro ac:name="code">
  <ac:parameter ac:name="language">python</ac:parameter>
  <ac:parameter ac:name="title">hello.py</ac:parameter>
  <ac:parameter ac:name="linenumbers">true</ac:parameter>
  <ac:parameter ac:name="collapse">false</ac:parameter>
  <ac:plain-text-body><![CDATA[def hello():
    print("Hello, World!")

if __name__ == "__main__":
    hello()]]></ac:plain-text-body>
</ac:structured-macro>
```

**注意**：代码块宏**不能**包裹在 `<p>` 标签内，否则内容会被当作段落渲染。`<ac:plain-text-body>` 内的代码用 `<![CDATA[...]]>` 包裹，避免 XML 转义。

### 图片引用

```html
<p><ac:image ac:alt="图片描述">
  <ri:attachment ri:filename="example.png">
    <ri:page ri:content-title="页面标题" ri:space-key="DEV"/>
  </ri:attachment>
</ac:image></p>
```

引用同空间其他页面附件：
```html
<p><ac:image ac:alt="架构图">
  <ri:attachment ri:filename="architecture.png">
    <ri:page ri:content-title="系统架构文档"/>
  </ri:attachment>
</ac:image></p>
```

引用外部 URL 图片：
```html
<p><ac:image ac:alt="外部图片">
  <ri:url ri:value="http://confluence.yuwei.com:8090/download/attachments/123/example.png"/>
</ac:image></p>
```

### 子页面列表宏

```html
<p><ac:structured-macro ac:name="children">
  <ac:parameter ac:name="depth">1</ac:parameter>
</ac:structured-macro></p>
```

### 摘录宏（配合摘录引用使用）

```html
<p><ac:structured-macro ac:name="excerpt">
  <ac:rich-text-body>这段内容可以被其他页面的摘录引用宏抓取。</ac:rich-text-body>
</ac:structured-macro></p>
```

---

### 行内元素

| 标签 | 效果 | 示例 |
|------|------|------|
| `<strong>` | **加粗** | `<strong>重要</strong>` |
| `<em>` | *斜体* | `<em>强调</em>` |
| `<code>` | `代码` | `<code>print()</code>` |
| `<u>` | <u>下划线</u> | `<u>下划线文本</u>` |
| `<s>` | ~~删除线~~ | `<s>已废弃</s>` |
| `<sub>` | 下标 | `H<sub>2</sub>O` |
| `<sup>` | 上标 | `x<sup>2</sup>` |
| `<br />` | 换行 | `第一行<br />第二行` |
| `<blockquote>` | 块引用 | `<blockquote><p>引用内容</p></blockquote>` |
| `<hr />` | 水平线 | `<hr />` |

---

### 表格高级用法

合并单元格：
```html
<table>
  <tr><th>名称</th><th>类型</th><th>说明</th></tr>
  <tr><td>key1</td><td>string</td><td rowspan="2">合并两行</td></tr>
  <tr><td>key2</td><td>int</td></tr>
  <tr><td colspan="3">合并三列</td></tr>
</table>
```

---

**注意**：toc 宏会自动根据页面中的 h1~h6 生成目录，无需手动写目录。info/tip/warning/note/panel/children/excerpt 等宏必须包裹在 `<p>` 标签内，否则 Confluence 服务端可能不渲染。**例外：代码块宏（code）不能放在 `<p>` 内。**`<ac:structured-macro>` 标签内容可能被 Confluence 存储层过滤或压缩，这取决于 Confluence 版本和配置。如果页面创建后发现宏或格式缺失，先检查临时 .html 文件内容是否完整，再用 `confluence_view` 检查页面实际渲染结果。

## HTML 内容格式

Confluence Storage Format HTML，支持 `<h1>`~`<h6>`、`<p>`、`<ul>/<ol>`、`<table>`、`<a>` 等标准 HTML 标签。

## 交互模式

### 第1步：选空间

先调 `confluence_spaces()` 获取空间列表，用结果填充选项：

```
AskUserQuestion:
  questions:
    - question: "选择目标空间"
      header: "空间"
      options: [从 spaces 结果取最多3个 + Other]
      multiSelect: false
```

### 第2步：输入标题和内容

```
AskUserQuestion:
  questions:
    - question: "输入页面标题"
      header: "标题"
      options:
        - label: "输入页面标题"
        - label: "我先查一下空间"
      multiSelect: false
    - question: "输入页面内容（支持 HTML）"
      header: "内容"
      options:
        - label: "纯文本（自动包裹 <p> 标签）"
        - label: "HTML 内容（在 Other 中输入）"
      multiSelect: false
```

**纯文本→HTML 转化规则**：
- 用户选择"纯文本"或在 Other 中输入纯文本时，Claude 自动做以下转化再传入 `content` 参数：
  1. 整段文本包裹 `<p>...</p>`
  2. 换行符替换为 `</p><p>`（分段）
  3. 用户明确提及的标题（如"一级标题：xxx"）转为 `<h1>`~`<h6>`
  4. 列表项（以 `- ` 或 `1. ` 开头）转为 `<ul>/<ol><li>`
- 用户选择"HTML 内容"或输入含 HTML 标签的文本时，原样传入，不做额外包裹

### 第3步：父页面（仅特定场景触发）

**默认行为**：用户只说"在 X 空间创建文档"时，**不询问父页面**，直接传 `""` 创建在空间根目录。

**触发条件**：仅当用户明确说了以下类似描述时才询问：
- "作为 XXX 的子页面"
- "放在 XXX 下面"
- "隶属于 XXX"
- "在当前页面下创建"

满足触发条件时才弹出：

```
AskUserQuestion:
  questions:
    - question: "请输入父页面 ID，或跳过（根目录）"
      header: "父页面"
      options: [不需要（根目录） / 在 Other 中输入父页面 ID]
      multiSelect: false
```

## 从 .docx 文件创建页面（端到端）

当用户要求"根据 .docx 文件创建 Confluence 页面"时，`extract_docx` 已合并文本+图片提取，一次调用即可获取全部信息。

### 快速模式（自动执行）

```
# Step 1: 提取 .docx 结构化文本 + 内嵌图片（一次调用完成）
#         用 cli_document.py 提取，返回 structured 字段 + images_dir + images 列表
python cli/cli_document.py "D:/Users/Desktop/report.docx"
# 返回:
# {
#   "text": "纯文本备用",
#   "structured": [
#     {"style": "Heading1", "html_tag": "h1", "text": "AI知识库导入SOP", "images": []},
#     {"style": "Normal",   "html_tag": "p",  "text": "操作步骤如下：",     "images": []},
#     {"style": "ListParagraph", "html_tag": "li", "text": "步骤一：打开脚本", "images": []},
#     {"style": "Normal",   "html_tag": "p",  "text": "界面如下：",         "images": ["767a6b319a59d023.png"]},
#     {"style": "Normal",   "html_tag": "p",  "text": "",                  "images": ["a1b2c3d4e5f67890.png"]},
#     ...
#   ],
#   "paragraphs": 12,
#   "method": "python-docx",
#   "images_dir": "D:/Users/Desktop/_docx_images_temp",
#   "images": [
#     {"filename": "767a6b319a59d023.png", "original_name": "image1.png", "filepath": "D:/Users/Desktop/_docx_images_temp/767a6b319a59d023.png", ...},
#     {"filename": "a1b2c3d4e5f67890.png", "original_name": "image2.png", "filepath": "D:/Users/Desktop/_docx_images_temp/a1b2c3d4e5f67890.png", ...}
#   ]
# }

# Claude 根据 structured 自动转为 Storage Format HTML:
# - html_tag="h1" → <h1>...</h1>
# - html_tag="p" + images=["767a6b319a59d023.png"] → <p>界面如下：</p><p><ac:image><ri:attachment ri:filename="767a6b319a59d023.png"/></ac:image></p>
# - html_tag="p" + text="" + images=["a1b2c3d4e5f67890.png"] → <p><ac:image><ri:attachment ri:filename="a1b2c3d4e5f67890.png"/></ac:image></p>
# - html_tag="li" → <li>步骤一：打开脚本</li>（包裹在 <ul> 或 <ol> 中）
# 然后创建页面:
confluence_create(space="DEV", title="从 docx 导入", content="@./skill_temp.html")

# Step 2: 逐张上传图片为页面附件（filepath 从 images[].filepath 取）
confluence_upload(page_id="新页面ID", filepath="D:/Users/Desktop/_docx_images_temp/767a6b319a59d023.png")
confluence_upload(page_id="新页面ID", filepath="D:/Users/Desktop/_docx_images_temp/a1b2c3d4e5f67890.png")

# Step 3: 不需要额外 append — 图片引用已在 Step 1 的 HTML 中内嵌
# （仅当 Step 1 遗漏了某些图片位置时才需追加）
# 临时图片文件在上传成功后由 CLI 自动清理
```

**关键点**：
- `extract_docx` 已合并图片提取，一次调用返回 `structured`（文本+图片文件名）+ `images_dir`（图片目录）+ `images`（图片文件列表），**无需再单独调用 `confluence_docx_images`**
- `structured[].images` 中的文件名是 **hash 文件名**（如 `767a6b319a59d023.png`），与磁盘上的实际文件名一致，直接用于 `<ri:attachment ri:filename="...">`
- `ri:filename` 必须与 `structured[].images` 中的文件名完全一致（hash 文件名）
- 上传成功后，CLI 自动删除 `_docx_images_temp` 中的临时图片文件；目录为空时自动删除目录

### 交互模式

当用户说"把某个 docx 文件放到 Confluence 上"时：

```
AskUserQuestion:
  questions:
    - question: "选择目标空间"
      header: "空间"
      options: [从 spaces 结果取最多3个 + Other]
      multiSelect: false
```

收集空间和标题后，**自动执行三步流程**（无需逐步确认）：
1. `cli_document.py` 提取结构化文本+图片 → Claude 按 html_tag 映射转为 HTML（含图片引用） → `confluence_create` 创建页面
2. 逐张 `confluence_upload` 上传图片（filepath 从 `images[].filepath` 取）
3. 图片引用已在 Step 1 的 HTML 中内嵌，通常不需要额外 append

每步完成后向用户报告进度（如"文本已创建，正在上传 2 张图片..."），最后输出页面链接摘要。

## 涉及函数

`confluence_create` `confluence_upload`
