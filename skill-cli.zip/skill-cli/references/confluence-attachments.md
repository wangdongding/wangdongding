# Confluence 附件/版本/标签/空间/连接测试

## 快速模式

```
# 附件
confluence_get_attachments(page_id="187917408")
confluence_upload(page_id="187917408", filepath="/path/to/file.png")

# 版本历史
confluence_get_versions(page_id="187917408")
confluence_get_versions(page_id="187917408", limit="20")

# 标签
confluence_get_labels(page_id="187917408")
confluence_add_labels(page_id="187917408", labels="api,deploy,guide")
confluence_delete_label(page_id="187917408", label="guide")

# 空间详情
confluence_get_space(key="DEV")
confluence_spaces(limit="100")

# 连通测试
confluence_test_connection()
confluence_get_current_user()
```

## 交互模式

### 第1步：选操作

```
AskUserQuestion:
  questions:
    - question: "要对页面执行什么操作？"
      header: "操作"
      options:
        - label: "查看附件"
        - label: "上传附件"
        - label: "查看版本历史"
        - label: "管理标签"
        - label: "测试连接/用户"
      multiSelect: false
```

### 附件/版本

收集 page_id → 直接调用函数。

### 上传附件

收集 page_id 和本地文件路径 → `confluence_upload(page_id, filepath)`

```
AskUserQuestion:
  questions:
    - question: "输入目标页面 ID"
      header: "页面 ID"
      options:
        - label: "输入页面 ID"
        - label: "我先查一下页面"
      multiSelect: false
    - question: "输入本地文件路径（如 /path/to/file.png）"
      header: "文件路径"
      options:
        - label: "输入文件路径"
        - label: "我换一个文件"
      multiSelect: false
```

CLI 调用示例：
```bash
python cli/cli_confluence.py upload 187917408 /path/to/file.png
```

## 插入附件到已有页面（端到端）

上传附件只是第一步，附件不会自动出现在页面正文中。需要 **upload → append** 两步完成：

```
# Step 1: 上传文件为附件
confluence_upload(page_id="187917408", filepath="/path/to/diagram.png")
# 返回中 title 字段即附件文件名（如 "diagram.png"）

# Step 2: 追加附件引用到页面正文（根据文件类型选择对应格式，见下方）
confluence_append(page_id="187917408", content='...')
```

**Storage Format 按文件类型选择**：

| 场景 | append 的 content |
|------|-------------------|
| 图片内嵌显示 | `<ac:image><ri:attachment ri:filename="diagram.png"/></ac:image>` |
| 文件下载链接 | `<p><ac:link><ri:attachment ri:filename="report.pdf"/><ac:plain-text-link-body>下载报告</ac:plain-text-link-body></ac:link></p>` |
| PDF/Office 在线预览 | `<ac:structured-macro ac:name="view-file"><ac:parameter ac:name="name"><ri:attachment ri:filename="report.pdf"/></ac:parameter></ac:structured-macro>` |

**注意事项**：
- `ri:filename` 的值必须与 Step 1 上传的文件名完全一致（即 upload 返回的 `title` 字段）
- 多个附件依次 append 即可
- 如果需要在页面特定位置插入（而非末尾），需用 `confluence_update` 重写整页 body

### 标签管理

先调 `confluence_get_labels(page_id)` 查看现有标签，再选操作：

```
AskUserQuestion:
  questions:
    - question: "操作哪个页面？"
      header: "页面"
      options:
        - label: "输入页面 ID"
        - label: "我先查一下页面"
      multiSelect: false
```

```
AskUserQuestion:
  questions:
    - question: "标签操作"
      header: "标签"
      options: [查看标签 / 添加标签 / 删除标签]
      multiSelect: false
```

- 添加：收集标签名（逗号分隔）→ `confluence_add_labels(page_id, labels)`
- 删除：从现有标签中选或输入 → `confluence_delete_label(page_id, label)`

### 空间详情

```
AskUserQuestion:
  questions:
    - question: "查看哪个空间？"
      header: "空间"
      options: [从 confluence_spaces() 取最多3个 + Other]
      multiSelect: false
```

### 连通测试/用户

直接调用 `confluence_test_connection()` 或 `confluence_get_current_user()`，无需参数。

## 涉及函数

`confluence_get_attachments` `confluence_upload` `confluence_get_versions` `confluence_get_labels` `confluence_add_labels` `confluence_delete_label` `confluence_get_space` `confluence_spaces` `confluence_test_connection` `confluence_get_current_user` `confluence_append`
