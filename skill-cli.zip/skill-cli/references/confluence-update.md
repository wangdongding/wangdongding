# Confluence 更新/删除页面

## 快速模式

```
# 更新页面（自动获取版本号 +1，与 create 传参风格一致）
confluence_update(page_id="187917408", title="新标题", body="<p>新内容</p>")

# 只改正文，标题不变（title 传 "_"）
confluence_update(page_id="187917408", title="_", body="@./skill_temp.html")

# 只改标题，正文不变（body 传 "_"）
confluence_update(page_id="187917408", title="新标题", body="_")

# 删除页面
confluence_delete(page_id="187917408")
```

**参数说明**：

| 参数 | 说明 |
|------|------|
| page_id | 页面 ID |
| title | 新标题，传 `"_"` 表示不修改 |
| body | 新正文 HTML，传 `"_"` 表示不修改，支持 `@filepath` 语法 |

CLI 内部自动：先 `view` 获取当前 `version.number` → +1 → 拼装完整 JSON → PUT 发送

## 追加内容（推荐）

往已有页面末尾追加内容时，**优先使用 `confluence_append`**，无需重写整页 body：

```
# 追加短文本（直接传参）
confluence_append(page_id="187917408", content="<p>新增段落</p>")

# 追加大段 HTML（@文件模式）
confluence_append(page_id="187917408", content="@./skill_temp.html")
```

| 参数 | 说明 |
|------|------|
| page_id | 页面 ID |
| content | 要追加的 HTML 片段，支持 `@filepath` 语法 |

CLI 内部自动：`view` 获取当前 body → 拼接新内容 → `update` 提交，对调用者完全透明。

**何时用 `update` vs `append`**：
- **追加内容**（在末尾添加段落、表格、代码块等）→ 用 `confluence_append`
- **替换全文**（重写整页内容、修改页面中间内容）→ 用 `confluence_update`

## 交互模式

### 更新页面

```
AskUserQuestion:
  questions:
    - question: "更新哪个页面？"
      header: "页面"
      options:
        - label: "输入页面 ID"
        - label: "我先查看一下"
      multiSelect: false
    - question: "要更新什么？"
      header: "字段"
      options: [标题 / 正文 / 标题+正文]
      multiSelect: false
```

收集新内容 → 调用 `confluence_update(page_id, title, body)`，无需手动拼 JSON 或查版本号

### 删除页面

**重要**：删除前必须先 `confluence_view(page_id)` 展示页面标题和摘要，让用户确认后再执行删除，防止误删。

```
AskUserQuestion:
  questions:
    - question: "确认删除哪个页面？此操作不可恢复！"
      header: "删除"
      options:
        - label: "输入页面 ID"
        - label: "我先查看一下页面内容"
      multiSelect: false
```

收到 page_id 后，**先调 `confluence_view(page_id)`** 展示：

```
即将删除：
  标题：{title}
  空间：{space_key}
  页面 ID：{id}
  Web UI：{webui}
```

然后二次确认：

```
AskUserQuestion:
  questions:
    - question: "确认要删除「{title}」吗？此操作不可恢复！"
      header: "确认"
      options:
        - label: "确认删除"
        - label: "算了不删了"
      multiSelect: false
```

用户确认后才调用 `confluence_delete(page_id)`。

## 涉及函数

`confluence_update` `confluence_delete` `confluence_append`
