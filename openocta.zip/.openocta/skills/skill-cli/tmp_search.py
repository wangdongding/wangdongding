import requests, json

with open('/root/.skill-cli/tokens.json') as f:
    cfg = json.load(f)['confluence']

base = cfg['base_url']
token = cfg['token']
headers = {'Authorization': f'Bearer {token}'}

# The token is a PAT (Personal Access Token), 44 chars
# PAT auth requires the user to have proper permissions
# Let's check who we are
r = requests.get(f'{base}/rest/api/user/current', headers=headers)
print(f"Current user status: {r.status_code}")
print(json.dumps(r.json(), indent=2, ensure_ascii=False)[:1000])

print("\n---\n")

# Check if anonymous access works for spaces
r2 = requests.get(f'{base}/rest/api/space', params={'limit': 50})
print(f"Anonymous spaces status: {r2.status_code}")
print(json.dumps(r2.json(), indent=2, ensure_ascii=False)[:2000])
