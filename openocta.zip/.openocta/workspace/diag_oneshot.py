#!/usr/bin/env python3
"""One-shot WinRM diagnosis on 172.17.3.193"""

import requests
from requests.auth import HTTPBasicAuth
import base64
import uuid
import time
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def uid(): return f"uuid:{str(uuid.uuid4()).upper()}"
def encode_ps(cmd): return base64.b64encode(cmd.encode('utf-16-le')).decode('ascii')

def soap_post(action, body_extra, shell_id=None, selectors=None):
    header_extras = ""
    if shell_id:
        header_extras += f'<w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>'
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>{action}</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    {header_extras}
  </s:Header>
  <s:Body>
    {body_extra}
  </s:Body>
</s:Envelope>'''

def find_tag(xml_text, tag_name):
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name and elem.text:
            return elem.text
    return None

def extract_streams(xml_text):
    stdout_parts, stderr_parts = [], []
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == 'Stream' and elem.text:
            name = elem.attrib.get('Name', '')
            decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
            if 'stdout' in name: stdout_parts.append(decoded)
            elif 'stderr' in name: stderr_parts.append(decoded)
    return ''.join(stdout_parts), ''.join(stderr_parts)

auth = HTTPBasicAuth(USER, PASS)
hdrs = {'Content-Type': 'application/soap+xml; charset=UTF-8'}

# Single PowerShell command that gathers all info
ps = r"""
whoami
$auth = Get-ChildItem WSMan:\localhost\Service\Auth
foreach ($a in $auth) { Write-Output ("AUTH:{0}={1}" -f $a.Name,$a.Value) }
$uac = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
Write-Output ("UAC:EnableLUA={0}" -f $uac.EnableLUA)
Write-Output ("UAC:FilterAdministratorToken={0}" -f $uac.FilterAdministratorToken)
Write-Output ("UAC:LocalAccountTokenFilterPolicy={0}" -f $uac.LocalAccountTokenFilterPolicy)
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$adminSid = [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
Write-Output ("TOKEN:IsAdmin={0}" -f ($id.Groups -contains $adminSid))
Write-Output ("OS:{0}" -f [System.Environment]::OSVersion.VersionString)
Write-Output ("WINRM:AllowUnencrypted={0}" -f (Get-Item WSMan:\localhost\Service\AllowUnencrypted).Value)
"""

try:
    # Create shell
    body = '''<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>'''
    r = requests.post(URL, data=soap_post("http://schemas.xmlsoap.org/ws/2004/09/transfer/Create", body), auth=auth, headers=hdrs, timeout=15)
    print(f"Create Shell: HTTP {r.status_code}")
    if r.status_code != 200:
        print(f"Error: {r.text[:300]}")
        exit(1)
    
    shell_id = find_tag(r.text, 'ShellId')
    print(f"ShellId: {shell_id}")
    
    # Execute command
    encoded = encode_ps(ps)
    cmd_body = f'''<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>powershell.exe</rsp:Command>
      <rsp:Arguments>-NoProfile -NonInteractive -EncodedCommand {encoded}</rsp:Arguments>
    </rsp:CommandLine>'''
    r2 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command", cmd_body, shell_id=shell_id), auth=auth, headers=hdrs, timeout=30)
    print(f"Command: HTTP {r2.status_code}")
    
    command_id = find_tag(r2.text, 'CommandId')
    print(f"CommandId: {command_id}")
    
    # Receive output
    all_stdout, all_stderr = "", ""
    for i in range(30):
        time.sleep(1)
        rcv_body = f'''<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
      <rsp:CommandId>{command_id}</rsp:CommandId>
    </rsp:Receive>'''
        r3 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive", rcv_body, shell_id=shell_id), auth=auth, headers=hdrs, timeout=15)
        if r3.status_code == 200:
            out, err = extract_streams(r3.text)
            if out: all_stdout += out
            if err: all_stderr += err
            if 'Done' in r3.text:
                print(f"Completed after {i+1}s")
                break
    
    print(f"\n{'='*60}")
    print("WINRM SERVER DIAGNOSTICS")
    print('='*60)
    print(all_stdout)
    if all_stderr: print(f"STDERR: {all_stderr}")
    
    # Delete shell
    del_body = ""
    r4 = requests.post(URL, data=soap_post("http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete", del_body, shell_id=shell_id), auth=auth, headers=hdrs, timeout=10)
    print(f"\nShell deleted: HTTP {r4.status_code}")

except Exception as e:
    print(f"ERROR: {e}")
    import traceback; traceback.print_exc()
