#!/usr/bin/env python3
import requests, base64, struct

URL = "http://172.17.3.88:5985/wsman"

type1_msg = b'NTLMSSP\x00' + struct.pack('<I', 1) + struct.pack('<I', 0x00088215) + struct.pack('<HHI', 0, 0, 32) + struct.pack('<HHI', 0, 0, 32)
type1 = base64.b64encode(type1_msg).decode('ascii')

print(f"Type1: {type1[:80]}...")
r = requests.post(URL, headers={
    'Content-Type': 'application/soap+xml; charset=UTF-8',
    'Authorization': f'Negotiate {type1}'
}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)

print(f"Status: {r.status_code}")
auth_header = r.headers.get('WWW-Authenticate', '')
print(f"WWW-Authenticate: {auth_header[:300]}")

challenge = None
for part in auth_header.split(','):
    part = part.strip()
    if part.startswith('Negotiate ') and len(part) > 10:
        challenge = part[10:]
        break

if challenge:
    print(f"Challenge length: {len(challenge)}")
    decoded = base64.b64decode(challenge)
    print(f"Signature: {decoded[:8]}")
    print(f"Type: {struct.unpack('<I', decoded[8:12])[0]}")
    server_challenge = decoded[24:32]
    print(f"Server challenge: {server_challenge.hex()}")
    target_info_len = struct.unpack('<H', decoded[40:42])[0]
    target_info_offset = struct.unpack('<I', decoded[44:48])[0]
    target_info = decoded[target_info_offset:target_info_offset + target_info_len]
    print(f"TargetInfo hex: {target_info.hex()}")
    # Parse target_info sub-blocks
    i = 0
    while i < len(target_info):
        if i + 4 > len(target_info): break
        av_id = struct.unpack('<H', target_info[i:i+2])[0]
        av_len = struct.unpack('<H', target_info[i+2:i+4])[0]
        av_data = target_info[i+4:i+4+av_len]
        if av_id == 0: break
        names = {1:'Computer',2:'Domain',3:'DNS Computer',4:'DNS Domain',5:'DNS Tree',6:'Flags',7:'Timestamp',8:'Single Host',9:'Target Name'}
        name = names.get(av_id, f'AV_{av_id}')
        if av_id in (1,2,3,4,5,9):
            print(f"  {name}: {av_data.decode('utf-16-le', errors='replace')}")
        elif av_id == 6:
            print(f"  {name}: {struct.unpack('<I', av_data)[0]:#x}")
        else:
            print(f"  {name}: {av_data.hex()}")
        i += 4 + av_len
else:
    print("No Negotiate challenge found")
