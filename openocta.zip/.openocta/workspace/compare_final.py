#!/usr/bin/env python3
"""Full WinRM comparison - 172.17.3.193 vs 172.17.3.88"""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET
import base64, uuid, time, sys

CONTENT_TYPE = 'application/soap+xml; charset=UTF-8'
SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'

def soap(to_url, action, body, resource_uri=None, selectors=None):
    msg_id = str(uuid.uuid4())
    sid = str(uuid.uuid4())
    res = f'<w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>' if resource_uri else ''
    sel = ''
    if selectors:
        sel = '<w:SelectorSet>' + ''.join(f'<w:Selector Name="{k}">{v}</w:Selector>' for k,v in selectors.items()) + '</w:SelectorSet>'
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
<s:Header>
<a:Action>{action}</a:Action>
<a:To>{to_url}</a:To>
<w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
<a:MessageID>uuid:{msg_id}</a:MessageID>
<a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
{res}{sel}
<w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
<p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
<p:SessionId mustUnderstand="false">uuid:{sid}</p:SessionId>
</s:Header>
<s:Body>{body}</s:Body>
</s:Envelope>'''

def winrm_post(url, auth, action, body, resource_uri=None, selectors=None, timeout=20):
    env = soap(url, action, body, resource_uri, selectors)
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE}, data=env, verify=False, timeout=timeout)
    return r

def run_ps(url, auth, ps_cmd):
    encoded = base64.b64encode(ps_cmd.encode('utf-16-le')).decode('ascii')
    cmd = f'powershell -NoProfile -NonInteractive -EncodedCommand {encoded}'
    
    # Create shell
    r = winrm_post(url, auth, 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Create',
        '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>',
        resource_uri=SHELL_URI)
    if r.status_code != 200:
        return f"[CreateShell HTTP {r.status_code}]"
    root = ET.fromstring(r.content)
    shell_id = None
    for e in root.iter():
        if e.get('Name') == 'ShellId' and e.text:
            shell_id = e.text; break
    if not shell_id:
        return "[No ShellId]"
    
    # Execute command
    r = winrm_post(url, auth, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command',
        f'<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>{cmd}</rsp:Command></rsp:CommandLine>',
        resource_uri=SHELL_URI, selectors={'ShellId': shell_id})
    if r.status_code != 200:
        return f"[Exec HTTP {r.status_code}]"
    root = ET.fromstring(r.content)
    cmd_id = None
    for e in root.iter():
        t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
        if t == 'CommandId' and e.text:
            cmd_id = e.text; break
    if not cmd_id:
        return "[No CommandId]"
    
    # Receive output
    time.sleep(1)
    r = winrm_post(url, auth, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive',
        '<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream>stdout stderr</rsp:DesiredStream></rsp:Receive>',
        resource_uri=SHELL_URI, selectors={'ShellId': shell_id}, timeout=25)
    output = ""
    if r.status_code == 200:
        root = ET.fromstring(r.content)
        for e in root.iter():
            t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
            if t == 'Stream' and e.text:
                try: output += base64.b64decode(e.text).decode('utf-8', errors='replace')
                except: pass
    
    # Signal & Delete
    winrm_post(url, auth, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal',
        '<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code></rsp:Signal>',
        resource_uri=SHELL_URI, selectors={'ShellId': shell_id})
    winrm_post(url, auth, 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', '',
        resource_uri=SHELL_URI, selectors={'ShellId': shell_id})
    
    return output.strip() if output.strip() else "[No output]"

# ====== MAIN ======
servers = [
    ("172.17.3.193", HTTPBasicAuth("administrator", "admin!123"), "PROBLEMATIC"),
    ("172.17.3.88", HTTPBasicAuth("Compiler", "Yuwei@2505"), "WORKING"),
]

diagnostics = [
    ("1. WinRM Auth", "winrm get winrm/config/service/auth"),
    ("2. WinRM Service", "winrm get winrm/config/service"),
    ("3. WinRM Client TrustedHosts", "winrm get winrm/config/client | Select-String TrustedHosts"),
    ("4. UAC-LocalAccountTokenFilterPolicy", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name LocalAccountTokenFilterPolicy -EA 0 | Select -Exp LocalAccountTokenFilterPolicy}catch{'NOT SET'}"),
    ("5. UAC-FilterAdministratorToken", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name FilterAdministratorToken -EA 0 | Select -Exp FilterAdministratorToken}catch{'NOT SET'}"),
    ("6. UAC-EnableLUA", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name EnableLUA -EA 0 | Select -Exp EnableLUA}catch{'NOT SET'}"),
    ("7. CredSSP", "Get-WSManCredSSP 2>&1 | Out-String"),
    ("8. OS Version", "(Get-WmiObject Win32_OperatingSystem).Caption + ' ' + [System.Environment]::OSVersion.Version.ToString()"),
    ("9. Current User", "whoami"),
    ("10. PS Remoting", "Get-PSSessionConfiguration | Format-Table Name, Permission -Auto"),
]

for ip, auth, label in servers:
    url = f"http://{ip}:5985/wsman"
    print("=" * 70)
    print(f"  {ip} ({label})")
    print("=" * 70)
    for name, cmd in diagnostics:
        print(f"\n--- {name} ---")
        try:
            result = run_ps(url, auth, cmd)
            print(result[:1200])
        except Exception as e:
            print(f"ERROR: {e}")
        sys.stdout.flush()
