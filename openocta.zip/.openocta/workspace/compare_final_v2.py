#!/usr/bin/env python3
"""Compare WinRM config on 172.17.3.88 vs 172.17.3.193 via NTLM auth."""

import requests, struct, hashlib, hmac, base64, uuid, xml.etree.ElementTree as ET

# ---- Pure Python MD4 ----
def md4(data: bytes) -> bytes:
    def f(x,y,z): return (x&y)|(~x&z)
    def g(x,y,z): return (x&y)|(x&z)|(y&z)
    def h(x,y,z): return x^y^z
    def rr(n,b): return ((n<<b)|(n>>(32-b)))&0xFFFFFFFF
    A,B,C,D = 0x67452301,0xefcdab89,0x98badcfe,0x10325476
    msg = bytearray(data)
    orig = len(data)*8
    msg.append(0x80)
    while len(msg)%64!=56: msg.append(0)
    msg += struct.pack('<Q',orig)
    for i in range(0,len(msg),64):
        X=list(struct.unpack('<16I',msg[i:i+64]))
        AA,BB,CC,DD = A,B,C,D
        for j in range(48):
            if j<16:   fn,s,ki = f,0,j
            elif j<32: fn,s,ki = g,0x5A827999,j//5
            else:      fn,s,ki = h,0x6ED9EBA1,j//3
            t = (rr(A,[3,7,11,19][j//16]) + fn(B,C,D) + X[ki] + s) & 0xFFFFFFFF
            A,D,C,B = D,C,B,t
        A=(A+AA)&0xFFFFFFFF; B=(B+BB)&0xFFFFFFFF
        C=(C+CC)&0xFFFFFFFF; D=(D+DD)&0xFFFFFFFF
    return struct.pack('<4I',A,B,C,D)

# ---- NTLMv2 Auth ----
def ntlm_hash(password):
    return md4(password.encode('utf-16-le'))

def ntlmv2_response(ntpw, username, domain, server_challenge, target_info):
    ntowfv2 = hmac.new(ntpw, (username.upper().encode('utf-16-le')+domain.encode('utf-16-le')), hashlib.md5).digest()
    # temp = target_info + 4 zero bytes (mic placeholder - we skip MIC)
    temp = target_info + b'\x00\x00\x00\x00'
    nt_proof = hmac.new(ntowfv2, server_challenge + temp, hashlib.md5).digest()
    return nt_proof + temp, ntowfv2

def build_type1():
    flags = 0x00088215
    msg = b'NTLMSSP\x00' + struct.pack('<I',1) + struct.pack('<I',flags)
    msg += struct.pack('<HHI',0,0,0)  # Domain
    msg += struct.pack('<HHI',0,0,0)  # Workstation
    return base64.b64encode(msg).decode()

def parse_type2(raw):
    msg = base64.b64decode(raw)
    server_challenge = msg[24:32]
    neg_flags = struct.unpack('<I', msg[20:24])[0]
    target_info = b''
    if len(msg) > 48:
        ti_len = struct.unpack('<H', msg[40:42])[0]
        ti_off = struct.unpack('<I', msg[44:48])[0]
        target_info = msg[ti_off:ti_off+ti_len]
    return server_challenge, target_info, neg_flags

def build_type3(username, password, domain, server_challenge, target_info, neg_flags):
    ntpw = ntlm_hash(password)
    nt_resp, ntowfv2 = ntlmv2_response(ntpw, username, domain, server_challenge, target_info)
    lm_resp = hmac.new(ntowfv2, server_challenge + b'\x00'*8, hashlib.md5).digest()
    domain_up = domain.upper() if domain else ''
    workstation = 'ANSIBLE'
    dom_enc = domain_up.encode('utf-16-le')
    usr_enc = username.encode('utf-16-le')
    ws_enc = workstation.encode('utf-16-le')
    # NTLM Type3 header: sig(8) + type(4) + 6 fields * (len(2)+maxlen(2)+offset(4)) + flags(4) = 8+4+48+4 = 64
    base = 64
    lm_off = base
    nt_off = lm_off + len(lm_resp)
    dom_off = nt_off + len(nt_resp)
    usr_off = dom_off + len(dom_enc)
    ws_off = usr_off + len(usr_enc)
    sk_off = ws_off + len(ws_enc)  # session key (empty)
    msg = b'NTLMSSP\x00'
    msg += struct.pack('<I', 3)  # Type3
    msg += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
    msg += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
    msg += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
    msg += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
    msg += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off)
    msg += struct.pack('<HHI', 0, 0, sk_off)  # Session key
    msg += struct.pack('<I', 0x00088215)  # Flags
    msg += lm_resp + nt_resp + dom_enc + usr_enc + ws_enc
    return base64.b64encode(msg).decode()

# ---- WinRM SOAP ----
SOAP_TPL = '''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>{action}</wsa:Action>
    <wsa:To>{to}</wsa:To>
    <wsman:ResourceURI wsmv:OptimizeEnumeration="true">{uri}</wsman:ResourceURI>
    <wsa:MessageID>uuid:{msgid}</wsa:MessageID>
    <wsa:ReplyTo><wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo>
    {extra_header}
  </s:Header>
  <s:Body>{body}</s:Body>
</s:Envelope>'''

SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'
CMD_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command'

def winrm_run(host, user, passwd, command, domain=''):
    url = f'http://{host}:5985/wsman'
    session = requests.Session()
    session.headers.update({'Content-Type': 'application/soap+xml; charset=UTF-8'})

    # NTLM Type1
    type1 = build_type1()
    resp1 = session.post(url, headers={'Authorization': f'Negotiate {type1}'}, timeout=8)
    if resp1.status_code not in (401, 407):
        return f"Unexpected after Type1: HTTP {resp1.status_code}"

    # Extract Type2 from response
    auth_h = resp1.headers.get('WWW-Authenticate', '')
    t2 = ''
    for part in auth_h.replace('Negotiate', '\nNegotiate').split('\n'):
        part = part.strip()
        if part.startswith('Negotiate ') and len(part) > 11:
            t2 = part[11:]
            break
    if not t2:
        return f"No Type2 token in: {auth_h}"

    server_challenge, target_info, neg_flags = parse_type2(t2)
    type3 = build_type3(user, passwd, domain, server_challenge, target_info, neg_flags)

    def soap(action, uri, body='', extra_header=''):
        msgid = str(uuid.uuid4())
        return SOAP_TPL.format(action=action, to=url, uri=uri, msgid=msgid, body=body, extra_header=extra_header)

    def selector_header(shell_id):
        return f'<wsman:SelectorSet><wsman:Selector Name="ShellId">{shell_id}</wsman:Selector></wsman:SelectorSet>'

    # Create Shell
    create_body = '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>'
    create_soap = soap('http://schemas.xmlsoap.org/ws/2004/09/transfer/Create', SHELL_URI, create_body)
    r = session.post(url, data=create_soap.encode(), headers={'Authorization': f'Negotiate {type3}'}, timeout=8)
    if r.status_code != 200:
        return f"CreateShell HTTP {r.status_code}: {r.text[:300]}"

    root = ET.fromstring(r.text)
    shell_id = None
    for elem in root.iter():
        if 'ShellId' in elem.tag: shell_id = elem.text; break
    if not shell_id: return "No ShellId"

    # Execute
    b64_cmd = base64.b64encode(command.encode('utf-16-le')).decode()
    exec_body = f'<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>powershell.exe</rsp:Command><rsp:Arguments>-NoProfile -NonInteractive -EncodedCommand {b64_cmd}</rsp:Arguments></rsp:CommandLine>'
    exec_soap = soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command', CMD_URI, exec_body, selector_header(shell_id))
    r = session.post(url, data=exec_soap.encode(), headers={'Authorization': f'Negotiate {type3}'}, timeout=8)
    if r.status_code != 200:
        return f"Execute HTTP {r.status_code}: {r.text[:300]}"

    root = ET.fromstring(r.text)
    command_id = None
    for elem in root.iter():
        if 'CommandId' in elem.tag: command_id = elem.text; break
    if not command_id: return "No CommandId"

    # Receive
    recv_body = f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream CommandId="{command_id}">stdout stderr</rsp:DesiredStream></rsp:Receive>'
    recv_soap = soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive', SHELL_URI, recv_body,
        selector_header(shell_id) + '<wsmv:OperationTimeout>PT60.000S</wsmv:OperationTimeout>')
    r = session.post(url, data=recv_soap.encode(), headers={'Authorization': f'Negotiate {type3}'}, timeout=15)
    if r.status_code != 200:
        return f"Receive HTTP {r.status_code}: {r.text[:300]}"

    root = ET.fromstring(r.text)
    stdout_b64, stderr_b64 = '', ''
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if tag == 'Stream':
            name = elem.attrib.get('Name','')
            content = elem.text or ''
            if 'stdout' in name: stdout_b64 += content
            elif 'stderr' in name: stderr_b64 += content

    stdout = base64.b64decode(stdout_b64).decode('utf-8', errors='replace') if stdout_b64 else ''
    stderr = base64.b64decode(stderr_b64).decode('utf-8', errors='replace') if stderr_b64 else ''

    # Signal + Delete
    sig_body = f'<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Code CommandId="{command_id}">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code></rsp:Signal>'
    sig_soap = soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal', SHELL_URI, sig_body, selector_header(shell_id))
    try: session.post(url, data=sig_soap.encode(), headers={'Authorization': f'Negotiate {type3}'}, timeout=5)
    except: pass

    del_soap = soap('http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', SHELL_URI, '', selector_header(shell_id))
    try: session.post(url, data=del_soap.encode(), headers={'Authorization': f'Negotiate {type3}'}, timeout=5)
    except: pass

    return stdout.strip() or stderr.strip() or '(no output)'

# ---- Main ----
cmds = [
    ('WinRM_Service', 'winrm get winrm/config/Service'),
    ('WinRM_Client', 'winrm get winrm/config/Client'),
    ('WinRM_WinRS', 'winrm get winrm/config/Winrs'),
    ('UAC_LocalAccountTokenFilterPolicy', 'Get-ItemProperty -Path HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System -Name LocalAccountTokenFilterPolicy -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalAccountTokenFilterPolicy'),
    ('UAC_FilterAdministratorToken', 'Get-ItemProperty -Path HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System -Name FilterAdministratorToken -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FilterAdministratorToken'),
    ('CredSSP', 'winrm get winrm/config/Service/Auth'),
    ('OS_Version', '[System.Environment]::OSVersion.VersionString'),
    ('User_RID', '(Get-WmiObject Win32_UserAccount | Where-Object {$_.Name -eq "Administrator"}).SID'),
]

servers = [
    ('172.17.3.88', 'Compiler', 'Yuwei@2025', ''),
    ('172.17.3.193', 'administrator', 'admin!123', ''),
]

for srv, user, passwd, domain in servers:
    print(f"\n{'='*60}")
    print(f"  SERVER: {srv}  USER: {user}")
    print(f"{'='*60}")
    for cmd_name, ps_cmd in cmds:
        try:
            result = winrm_run(srv, user, passwd, ps_cmd, domain)
            print(f"\n--- {cmd_name} ---")
            print(result[:1000])
        except Exception as e:
            print(f"\n--- {cmd_name} --- ERROR: {type(e).__name__}: {e}")
