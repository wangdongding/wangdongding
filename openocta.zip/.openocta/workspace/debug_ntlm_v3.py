#!/usr/bin/env python3
"""Debug NTLM Type3 - try different flags and domain combos"""
import requests, base64, struct, hashlib, hmac, os, time

def md4(data):
    msg = bytearray(data)
    msg_len = len(data)
    msg.append(0x80)
    while len(msg) % 64 != 56: msg.append(0)
    msg += struct.pack('<Q', msg_len * 8)
    a0, b0, c0, d0 = 0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
    def lr(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    for i in range(0, len(msg), 64):
        M = [struct.unpack('<I', msg[i+j:i+j+4])[0] for j in range(0, 64, 4)]
        a, b, c, d = a0, b0, c0, d0
        for k in range(16):
            a = lr((a + ((b&c)|(~b&d)) + M[k]) & 0xFFFFFFFF, [3,7,11,19][k%4]); a,b,c,d = d,a,b,c
        for k in [0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]:
            a = lr((a + ((b&c)|(b&d)|(c&d)) + M[k] + 0x5A827999) & 0xFFFFFFFF, [3,5,9,13][([0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15].index(k))%4]); a,b,c,d = d,a,b,c
        for k in [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]:
            a = lr((a + (b^c^d) + M[k] + 0x6ED9EBA1) & 0xFFFFFFFF, [3,9,11,15][([0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15].index(k))%4]); a,b,c,d = d,a,b,c
        a0=(a0+a)&0xFFFFFFFF; b0=(b0+b)&0xFFFFFFFF; c0=(c0+c)&0xFFFFFFFF; d0=(d0+d)&0xFFFFFFFF
    return struct.pack('<4I', a0, b0, c0, d0)

URL = "http://172.17.3.88:5985/wsman"
USER = "Compiler"
PASS = "Yuwei@2505"
DOMAIN = "WIN-3Q977300URH"

# Step 1: Type 1 - include domain and workstation
dom_enc_t1 = DOMAIN.upper().encode('utf-16-le')
ws_enc_t1 = DOMAIN.upper().encode('utf-16-le')
t1_body = bytearray()
t1_body += b'NTLMSSP\x00' + struct.pack('<I',1)
flags = 0x00088215  # Standard flags
t1_body += struct.pack('<I', flags)
t1_body += struct.pack('<HHI', len(dom_enc_t1), len(dom_enc_t1), 32 + len(ws_enc_t1))  # domain after workstation
t1_body += struct.pack('<HHI', len(ws_enc_t1), len(ws_enc_t1), 32)  # workstation at offset 32
t1_body += ws_enc_t1 + dom_enc_t1
t1 = base64.b64encode(bytes(t1_body)).decode()

r1 = requests.post(URL, headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': f'Negotiate {t1}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
print(f"Type1 -> Status: {r1.status_code}")

auth = r1.headers.get('WWW-Authenticate','')
challenge = None
for p in auth.split(','):
    p = p.strip()
    if p.startswith('Negotiate ') and len(p) > 10: challenge = p[10:]; break
if not challenge:
    print("No challenge!")
    exit(1)

d = base64.b64decode(challenge)
server_chal = d[24:32]
ti_len = struct.unpack('<H', d[40:42])[0]
ti_off = struct.unpack('<I', d[44:48])[0]
target_info = d[ti_off:ti_off+ti_len]
print(f"Server challenge: {server_chal.hex()}")

# Build Type3 with domain
nt_h = md4(PASS.encode('utf-16-le'))
client_chal = os.urandom(8)
temp = hmac.new(nt_h, (USER.upper() + DOMAIN).encode('utf-16-le'), hashlib.md5).digest()
blob = bytearray()
blob += b'\x01\x01\x00\x00\x00\x00\x00\x00'
blob += struct.pack('<Q', int(time.time()) + 11644473600)
blob += client_chal + b'\x00\x00\x00\x00' + target_info
ntproof = hmac.new(temp, server_chal + bytes(blob), hashlib.md5).digest()
nt_resp = ntproof + bytes(blob)
lm_resp = hmac.new(temp, server_chal + client_chal, hashlib.md5).digest() + client_chal

dom_enc = DOMAIN.upper().encode('utf-16-le')
usr_enc = USER.encode('utf-16-le')
ws_enc = DOMAIN.upper().encode('utf-16-le')

base_off = 88
lm_off = base_off
nt_off = lm_off + len(lm_resp)
dom_off = nt_off + len(nt_resp)
usr_off = dom_off + len(dom_enc)
ws_off = usr_off + len(usr_enc)
sess_off = ws_off + len(ws_enc)

t3 = bytearray()
t3 += b'NTLMSSP\x00' + struct.pack('<I',3)
t3 += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
t3 += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
t3 += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
t3 += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
t3 += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off)
t3 += struct.pack('<HHI', 0, 0, sess_off)
t3 += struct.pack('<I', flags)
t3 += struct.pack('<Q', 0x0000000F00000001)  # Version: Windows 10/Server 2016+
t3 += lm_resp + nt_resp + dom_enc + usr_enc + ws_enc

t3_b64 = base64.b64encode(bytes(t3)).decode()
r3 = requests.post(URL, headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': f'Negotiate {t3_b64}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
print(f"Type3 -> Status: {r3.status_code}")

# If still 401, try with the NTLM flag instead of Negotiate header
if r3.status_code == 401:
    print("\n--- Trying NTLM header instead of Negotiate ---")
    t3_b64_2 = base64.b64encode(bytes(t3)).decode()
    r4 = requests.post(URL, headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': f'NTLM {t3_b64_2}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
    print(f"NTLM header -> Status: {r4.status_code}")
    
    # Try Type1 with NTLM header
    t1_simple = base64.b64encode(b'NTLMSSP\x00' + struct.pack('<I',1) + struct.pack('<I',0x00088215) + struct.pack('<HHI',0,0,32) + struct.pack('<HHI',0,0,32)).decode()
    r5 = requests.post(URL, headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': f'NTLM {t1_simple}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
    print(f"NTLM Type1 -> Status: {r5.status_code}")
    auth2 = r5.headers.get('WWW-Authenticate','')
    print(f"NTLM Type1 -> Auth: {auth2[:200]}")
