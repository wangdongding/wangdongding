#!/usr/bin/env python3
"""Get WinRM config from 172.17.3.193 using Basic auth + proper SOAP"""
import requests, uuid, xml.etree.ElementTree as ET, base64, time

def winrm_exec(host, user, password, ps_command, timeout=25):
    url = f"http://{host}:5985/wsman"
    NS_SOAP = "http://www.w3.org/2003/05/soap-envelope"
    NS_WSMAN = "http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
    NS_ADDR = "http://schemas.xmlsoap.org/ws/2004/08/addressing"
    NS_MSFT = "http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd"
    NS_SHELL = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell"
    
    resource_uri = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"
    
    session = requests.Session()
    session.auth = requests.auth.HTTPBasicAuth(user, password)
    
    def make_headers(action):
        return {
            'Content-Type': 'application/soap+xml; charset=UTF-8',
        }
    
    def soap_envelope(header_elements, body_element):
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="{NS_SOAP}" xmlns:a="{NS_ADDR}" xmlns:w="{NS_WSMAN}" xmlns:p="{NS_MSFT}">
  <s:Header>
{header_elements}
  </s:Header>
  <s:Body>
{body_element}
  </s:Body>
</s:Envelope>"""

    # Step 1: Create Shell
    msg_id = str(uuid.uuid4())
    header = f"""    <a:Action mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <p:OptionSet>
      <p:Option Name="WINRS_NOPROFILE" Value="FALSE"/>
    </p:OptionSet>"""
    body = f"""    <rsp:Shell xmlns:rsp="{NS_SHELL}">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>"""
    
    create_envelope = soap_envelope(header, body)
    
    r = session.post(url, data=create_envelope.encode('utf-8'), headers=make_headers("Create"), timeout=timeout)
    
    if r.status_code != 200:
        return f"[Create Shell HTTP {r.status_code}] {r.text[:500]}"
    
    # Extract ShellId
    root = ET.fromstring(r.content)
    shell_id = None
    for elem in root.iter():
        if 'ShellId' in elem.tag:
            shell_id = elem.text
            break
    if not shell_id:
        return f"[No ShellId] {r.text[:500]}"
    
    # Step 2: Execute Command
    encoded_cmd = base64.b64encode(ps_command.encode('utf-16-le')).decode('ascii')
    msg_id = str(uuid.uuid4())
    header = f"""    <a:Action mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>"""
    body = f"""    <rsp:CommandLine xmlns:rsp="{NS_SHELL}">
      <rsp:Command>powershell.exe</rsp:Command>
      <rsp:Arguments>-NoProfile -NonInteractive -EncodedCommand {encoded_cmd}</rsp:Arguments>
    </rsp:CommandLine>"""
    
    exec_envelope = soap_envelope(header, body)
    r = session.post(url, data=exec_envelope.encode('utf-8'), headers=make_headers("Command"), timeout=timeout)
    
    if r.status_code != 200:
        return f"[Execute HTTP {r.status_code}] {r.text[:500]}"
    
    # Extract CommandId
    root = ET.fromstring(r.content)
    command_id = None
    for elem in root.iter():
        if 'CommandId' in elem.tag:
            command_id = elem.text
            break
    if not command_id:
        return f"[No CommandId] {r.text[:500]}"
    
    # Step 3: Receive Output (poll)
    time.sleep(3)
    all_output = ""
    for _ in range(8):
        msg_id = str(uuid.uuid4())
        header = f"""    <a:Action mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>"""
        body = f"""    <rsp:Receive xmlns:rsp="{NS_SHELL}">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
    </rsp:Receive>"""
        
        recv_envelope = soap_envelope(header, body)
        r = session.post(url, data=recv_envelope.encode('utf-8'), headers=make_headers("Receive"), timeout=timeout)
        
        if r.status_code != 200:
            all_output += f"\n[Receive HTTP {r.status_code}]"
            break
        
        root = ET.fromstring(r.content)
        done = False
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if tag == 'Stream' and elem.text:
                try:
                    decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                    all_output += decoded
                except:
                    pass
            if tag == 'CommandState':
                state = elem.attrib.get('State', '')
                if 'Done' in state:
                    done = True
        
        if done:
            break
        time.sleep(2)
    
    # Step 4: Delete Shell (cleanup)
    try:
        msg_id = str(uuid.uuid4())
        header = f"""    <a:Action mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI>{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>"""
        session.post(url, data=soap_envelope(header, "").encode('utf-8'), headers=make_headers("Delete"), timeout=5)
    except:
        pass
    
    return all_output if all_output.strip() else "[No output]"


# ============ MAIN ============
host = "172.17.3.193"
user = "administrator"
password = "admin!123"

commands = [
    ("1. WinRM Service Auth", "winrm get winrm/config/service/auth"),
    ("2. WinRM Service Config (AllowUnencrypted)", "winrm get winrm/config/service | findstr /i 'AllowUnencrypted CredSSP'"),
    ("3. WinRS Config (MaxShells)", "winrm get winrm/config/winrs"),
    ("4. UAC - LocalAccountTokenFilterPolicy", r"reg query 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v LocalAccountTokenFilterPolicy 2>&1"),
    ("5. UAC - FilterAdministratorToken", r"reg query 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v FilterAdministratorToken 2>&1"),
    ("6. UAC - EnableLUA", r"reg query 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v EnableLUA 2>&1"),
    ("7. WhoAmI", "whoami"),
    ("8. WhoAmI Groups", "whoami /groups"),
    ("9. Administrators Group", "net localgroup Administrators"),
    ("10. OS Version", "systeminfo | findstr /B /C:'OS Name' /C:'OS Version'"),
    ("11. WinRM Listener", "winrm enumerate winrm/config/listener"),
    ("12. CredSSP Service", "winrm get winrm/config/service/auth | findstr CredSSP"),
    ("13. CredSSP Client Delegate", "wsman get wsman/config/client/auth | findstr CredSSP 2>&1 || echo [not found]"),
]

for name, cmd in commands:
    print(f"\n{'='*60}")
    print(f"[{name}] on {host}")
    print(f"{'='*60}")
    result = winrm_exec(host, user, password, cmd)
    print(result)

print("\n\nDONE - All checks are READ-ONLY")
