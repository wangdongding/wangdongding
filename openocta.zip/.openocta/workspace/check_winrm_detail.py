#!/usr/bin/env python3
"""Execute remote PowerShell via WinRM to check auth/CredSSP/UAC config on 172.17.3.193"""

import requests
from requests.auth import HTTPBasicAuth
import uuid
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
WINRM_URL = f"http://{TARGET}:5985/wsman"

NS = {
    's': 'http://www.w3.org/2003/05/soap-envelope',
    'wsa': 'http://schemas.xmlsoap.org/ws/2004/08/addressing',
    'wsman': 'http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd',
    'wsmv': 'http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd',
}

def build_shell_envelope(url):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
            xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsmv:OptionSet>
      <wsman:Option Name="WINRS_CODEPAGE">65001</wsman:Option>
    </wsmv:OptionSet>
  </s:Header>
  <s:Body>
    <wsmv:Shell>
      <wsmv:InputStreams>stdin</wsmv:InputStreams>
      <wsmv:OutputStreams>stdout stderr</wsmv:OutputStreams>
    </wsmv:Shell>
  </s:Body>
</s:Envelope>"""

def build_command_envelope(shell_id, command):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
            xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</wsa:Action>
    <wsa:To>{WINRM_URL}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsmv:ShellId>{shell_id}</wsmv:ShellId>
  </s:Header>
  <s:Body>
    <wsmv:CommandLine>
      <wsmv:Command>powershell.exe</wsmv:Command>
      <wsmv:Arguments>-NoProfile -NonInteractive -EncodedCommand {command}</wsmv:Arguments>
    </wsmv:CommandLine>
  </s:Body>
</s:Envelope>"""

def build_getoutput_envelope(shell_id, command_id):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
            xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</wsa:Action>
    <wsa:To>{WINRM_URL}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsmv:ShellId>{shell_id}</wsmv:ShellId>
  </s:Header>
  <s:Body>
    <wsmv:Receive>
      <wsmv:DesiredStream>stdout stderr</wsmv:DesiredStream>
      <wsmv:CommandId>{command_id}</wsmv:CommandId>
    </wsmv:Receive>
  </s:Body>
</s:Envelope>"""

def build_delete_envelope(shell_id):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</wsa:Action>
    <wsa:To>{WINRM_URL}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>"""

import base64

def encode_ps(cmd):
    """Encode PowerShell command as Base64 for -EncodedCommand"""
    # Must be UTF-16LE encoded
    return base64.b64encode(cmd.encode('utf-16-le')).decode('ascii')

def extract_shell_id(xml_text):
    root = ET.fromstring(xml_text)
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if tag == 'ShellId':
            return elem.text
    # Try Selector
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if tag == 'Selector' and elem.text and len(elem.text) > 20:
            return elem.text
    return None

def extract_command_id(xml_text):
    root = ET.fromstring(xml_text)
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if tag == 'CommandId':
            return elem.text
    return None

def extract_output(xml_text):
    """Extract base64-encoded stdout/stderr from Receive response"""
    stdout_chunks = []
    stderr_chunks = []
    root = ET.fromstring(xml_text)
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if tag == 'Stream':
            stream_name = elem.attrib.get('Name', '')
            if elem.text:
                decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                if 'stdout' in stream_name:
                    stdout_chunks.append(decoded)
                elif 'stderr' in stream_name:
                    stderr_chunks.append(decoded)
    return ''.join(stdout_chunks), ''.join(stderr_chunks)

headers = {'Content-Type': 'application/soap+xml; charset=UTF-8'}
auth = HTTPBasicAuth(USER, PASS)

# PowerShell command to check WinRM auth config + CredSSP + UAC
ps_cmd = r"""
$sep = '---SEPARATOR---'
# 1. WinRM Service Auth config
Write-Output "=== WinRM Service Auth ==="
Get-Item WSMan:\localhost\Service\Auth | Format-List * | Out-String
Write-Output $sep
# 2. CredSSP status
Write-Output "=== CredSSP Service Status ==="
try { Get-Item WSMan:\localhost\Service\Auth\CredSSP | Select-Object Value | Out-String } catch { Write-Output "CredSSP key not found" }
Write-Output $sep
# 3. UAC
Write-Output "=== UAC Settings ==="
Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System | Select-Object EnableLUA, FilterAdministratorToken, LocalAccountTokenFilterPolicy | Out-String
Write-Output $sep
# 4. Current user
Write-Output "=== Current User ==="
whoami
Write-Output $sep
# 5. Admin group membership
Write-Output "=== Admin Membership ==="
whoami /groups | Out-String
"""

try:
    # Step 1: Create shell
    resp = requests.post(WINRM_URL, data=build_shell_envelope(WINRM_URL),
                         auth=auth, headers=headers, timeout=15)
    print(f"Create Shell: HTTP {resp.status_code}")
    
    if resp.status_code != 200:
        print(f"Error: {resp.text[:500]}")
        exit(1)
    
    shell_id = extract_shell_id(resp.text)
    print(f"ShellId: {shell_id}")
    
    # Step 2: Execute command
    encoded = encode_ps(ps_cmd)
    resp2 = requests.post(WINRM_URL, data=build_command_envelope(shell_id, encoded),
                          auth=auth, headers=headers, timeout=30)
    print(f"Command: HTTP {resp2.status_code}")
    
    command_id = extract_command_id(resp2.text)
    print(f"CommandId: {command_id}")
    
    # Step 3: Get output (may need multiple receives)
    import time
    all_stdout = ""
    all_stderr = ""
    for attempt in range(10):
        time.sleep(1)
        resp3 = requests.post(WINRM_URL, data=build_getoutput_envelope(shell_id, command_id),
                              auth=auth, headers=headers, timeout=15)
        if resp3.status_code == 200:
            out, err = extract_output(resp3.text)
            all_stdout += out
            all_stderr += err
            # Check if command is done (State=Done)
            if 'Done' in resp3.text:
                break
    
    print(f"\n{'='*60}")
    print("STDOUT:")
    print(all_stdout)
    if all_stderr:
        print(f"\nSTDERR:\n{all_stderr}")
    
    # Step 4: Delete shell
    requests.post(WINRM_URL, data=build_delete_envelope(shell_id),
                  auth=auth, headers=headers, timeout=10)

except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
