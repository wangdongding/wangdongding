#!/usr/bin/env python3
"""Try to get .88 info via SMB RPC - since port 445 is open"""

import socket, struct

# Try a simple SMB connection to check if we can enumerate
# Actually, let's try a different approach entirely:
# Use the WinRM Identify endpoint which doesn't require auth

import requests

# The Identify endpoint doesn't require authentication
URL_88 = "http://172.17.3.88:5985/wsman"
URL_193 = "http://172.17.3.193:5985/wsman"

IDENTIFY_SOAP = '''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:wsmid="http://schemas.dmtf.org/wbem/wsman/identity/1/wsmanidentity.xsd">
<s:Header/>
<s:Body><wsmid:Identify/></s:Body>
</s:Envelope>'''

print("=== 172.17.3.88 Identify ===")
try:
    r = requests.post(URL_88, headers={'Content-Type':'application/soap+xml; charset=UTF-8'}, data=IDENTIFY_SOAP, verify=False, timeout=10)
    print(f"Status: {r.status_code}")
    if r.status_code == 200:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(r.content)
        for e in root.iter():
            if e.text and e.text.strip():
                tag = e.tag.split('}')[-1] if '}' in e.tag else e.tag
                print(f"  {tag}: {e.text.strip()}")
except Exception as e:
    print(f"Error: {e}")

print("\n=== 172.17.3.193 Identify ===")
try:
    r = requests.post(URL_193, headers={'Content-Type':'application/soap+xml; charset=UTF-8'}, data=IDENTIFY_SOAP, verify=False, timeout=10)
    print(f"Status: {r.status_code}")
    if r.status_code == 200:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(r.content)
        for e in root.iter():
            if e.text and e.text.strip():
                tag = e.tag.split('}')[-1] if '}' in e.tag else e.tag
                print(f"  {tag}: {e.text.strip()}")
except Exception as e:
    print(f"Error: {e}")

# Also check the auth methods offered by each server
print("\n=== Auth Headers Comparison ===")
for ip in ["172.17.3.88", "172.17.3.88"]:
    url = f"http://{ip}:5985/wsman"
    try:
        r = requests.post(url, headers={'Content-Type':'application/soap+xml; charset=UTF-8'}, data=IDENTIFY_SOAP, verify=False, timeout=10)
        print(f"{ip}: Status={r.status_code}, WWW-Authenticate={r.headers.get('WWW-Authenticate','NONE')}")
    except Exception as e:
        print(f"{ip}: Error: {e}")

for ip in ["172.17.3.193"]:
    url = f"http://{ip}:5985/wsman"
    try:
        r = requests.post(url, headers={'Content-Type':'application/soap+xml; charset=UTF-8'}, data=IDENTIFY_SOAP, verify=False, timeout=10)
        print(f"{ip}: Status={r.status_code}, WWW-Authenticate={r.headers.get('WWW-Authenticate','NONE')}")
    except Exception as e:
        print(f"{ip}: Error: {e}")
