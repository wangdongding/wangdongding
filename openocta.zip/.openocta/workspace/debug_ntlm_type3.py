#!/usr/bin/env python3
"""Debug NTLM Type3 - step by step"""
import requests, base64, struct, hashlib, hmac, os, time

def md4(data):
    msg = bytearray(data)
    msg_len = len(data)
    msg.append(0x80)
    while len(msg) % 64 != 56: msg.append(0)
    msg += struct.pack('<Q', msg_len * 8)
    a0, b0, c0, d0 = 0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
    def lr(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    for i in range(0, len(msg), 64):
        M = [struct.unpack('<I', msg[i+j:i+j+4])[0] for j in range(0, 64, 4)]
        a, b, c, d = a0, b0, c0, d0
        for k in range(16):
            a = lr((a + ((b&c)|(~b&d)) + M[k]) & 0xFFFFFFFF, [3,7,11,19][k%4]); a,b,c,d = d,a,b,c
        for k in [0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]:
            a = lr((a + ((b&c)|(b&d)|(c&d)) + M[k] + 0x5A827999) & 0xFFFFFFFF, [3,5,9,13][([0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15].index(k))%4]); a,b,c,d = d,a,b,c
        for k in [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]:
            a = lr((a + (b^c^d) + M[k] + 0x6ED9EBA1) & 0xFFFFFFFF, [3,9,11,15][([0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15].index(k))%4]); a,b,c,d = d,a,b,c
        a0=(a0+a)&0xFFFFFFFF; b0=(b0+b)&0xFFFFFFFF; c0=(c0+c)&0xFFFFFFFF; d0=(d0+d)&0xFFFFFFFF
    return struct.pack('<4I', a0, b0, c0, d0)

URL = "http://172.17.3.88:5985/wsman"
USER = "Compiler"
PASS = "Yuwei@2505"
DOMAIN = "WIN-3Q977300URH"  # From Type2 target_info

# Step 1: Type 1
t1 = base64.b64encode(b'NTLMSSP\x00' + struct.pack('<I',1) + struct.pack('<I',0x00088215) + struct.pack('<HHI',0,0,32) + struct.pack('<HHI',0,0,32)).decode()
r1 = requests.post(URL, headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': f'Negotiate {t1}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
print(f"Type1 -> Status: {r1.status_code}")

# Get Type2 challenge
auth = r1.headers.get('WWW-Authenticate','')
challenge = None
for p in auth.split(','):
    p = p.strip()
    if p.startswith('Negotiate ') and len(p) > 10: challenge = p[10:]; break
if not challenge:
    print("No challenge!")
    exit(1)

d = base64.b64decode(challenge)
server_chal = d[24:32]
ti_len = struct.unpack('<H', d[40:42])[0]
ti_off = struct.unpack('<I', d[44:48])[0]
target_info = d[ti_off:ti_off+ti_len]
print(f"Server challenge: {server_chal.hex()}")
print(f"Target info length: {ti_len}")

# Step 3: Build Type3
nt_h = md4(PASS.encode('utf-16-le'))
print(f"NTLM hash: {nt_h.hex()}")

# Try with domain from Type2
client_chal = os.urandom(8)
temp = hmac.new(nt_h, (USER.upper() + DOMAIN).encode('utf-16-le'), hashlib.md5).digest()
blob = bytearray()
blob += b'\x01\x01\x00\x00\x00\x00\x00\x00'
blob += struct.pack('<Q', int(time.time()) + 11644473600)
blob += client_chal + b'\x00\x00\x00\x00' + target_info
ntproof = hmac.new(temp, server_chal + bytes(blob), hashlib.md5).digest()
nt_resp = ntproof + bytes(blob)

lm_resp = hmac.new(hmac.new(nt_h, (USER.upper() + DOMAIN).encode('utf-16-le'), hashlib.md5).digest(), server_chal + client_chal, hashlib.md5).digest() + client_chal

dom_enc = DOMAIN.upper().encode('utf-16-le')
usr_enc = USER.encode('utf-16-le')
base_off = 88
lm_off = base_off
nt_off = lm_off + len(lm_resp)
dom_off = nt_off + len(nt_resp)
usr_off = dom_off + len(dom_enc)
ws_off = usr_off + len(usr_enc)

t3 = bytearray()
t3 += b'NTLMSSP\x00' + struct.pack('<I',3)
t3 += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
t3 += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
t3 += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
t3 += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
t3 += struct.pack('<HHI', 0, 0, ws_off)
t3 += struct.pack('<I', 0x00088215)
t3 += struct.pack('<Q', 0)
t3 += lm_resp + nt_resp + dom_enc + usr_enc

t3_b64 = base64.b64encode(bytes(t3)).decode()
print(f"Type3 length: {len(t3)} bytes")

# Step 4: Send Type3
r3 = requests.post(URL, headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': f'Negotiate {t3_b64}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
print(f"Type3 -> Status: {r3.status_code}")
print(f"Type3 -> Headers: {dict(r3.headers)}")

if r3.status_code == 401:
    # Try with empty domain
    print("\n--- Retrying with empty domain ---")
    temp2 = hmac.new(nt_h, (USER.upper() + '').encode('utf-16-le'), hashlib.md5).digest()
    blob2 = bytearray()
    blob2 += b'\x01\x01\x00\x00\x00\x00\x00\x00'
    blob2 += struct.pack('<Q', int(time.time()) + 11644473600)
    blob2 += client_chal + b'\x00\x00\x00\x00' + target_info
    ntproof2 = hmac.new(temp2, server_chal + bytes(blob2), hashlib.md5).digest()
    nt_resp2 = ntproof2 + bytes(blob2)
    lm_resp2 = hmac.new(hmac.new(nt_h, (USER.upper() + '').encode('utf-16-le'), hashlib.md5).digest(), server_chal + client_chal, hashlib.md5).digest() + client_chal
    
    dom_enc2 = b''.encode('utf-16-le')  # empty domain
    usr_enc2 = USER.encode('utf-16-le')
    base_off2 = 88
    lm_off2 = base_off2
    nt_off2 = lm_off2 + len(lm_resp2)
    dom_off2 = nt_off2 + len(nt_resp2)
    usr_off2 = dom_off2 + len(dom_enc2)
    ws_off2 = usr_off2 + len(usr_enc2)
    
    t3b = bytearray()
    t3b += b'NTLMSSP\x00' + struct.pack('<I',3)
    t3b += struct.pack('<HHI', len(lm_resp2), len(lm_resp2), lm_off2)
    t3b += struct.pack('<HHI', len(nt_resp2), len(nt_resp2), nt_off2)
    t3b += struct.pack('<HHI', len(dom_enc2), len(dom_enc2), dom_off2)
    t3b += struct.pack('<HHI', len(usr_enc2), len(usr_enc2), usr_off2)
    t3b += struct.pack('<HHI', 0, 0, ws_off2)
    t3b += struct.pack('<I', 0x00088215)
    t3b += struct.pack('<Q', 0)
    t3b += lm_resp2 + nt_resp2 + dom_enc2 + usr_enc2
    
    r3b = requests.post(URL, headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': f'Negotiate {base64.b64encode(bytes(t3b)).decode()}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
    print(f"Type3 (empty domain) -> Status: {r3b.status_code}")
