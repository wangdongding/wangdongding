# 服务部署方式注册表

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-10-10 | 类型: 只读参考
> doc_id: ref-service-deploy-registry v1 | tags: deploy,registry,service | depends: ref-k8s-cluster
> 用途: 每个可独立更新镜像的服务在此注册，明确其部署方式，供 SOP-002 通用部署更新使用

## 一句话结论

**服务更新前先查此表，确认部署方式和更新命令，再执行对应 SOP。**

---

## 部署方式说明

| 方式代码 | 含义 | 更新镜像方法 | 回滚方法 |
|---------|------|-------------|---------|
| **helm** | Helm Release 管理（含子服务） | 修改 values.yaml 中 tag → helm upgrade | helm rollback + cp .bak 恢复 values |
| **yaml** | kubectl apply 直部署 | 修改 yaml 中 image tag → kubectl apply | kubectl rollout undo + cp .bak 恢复 yaml |

---

## 服务清单

### innies 命名空间

| # | 服务名 | 部署方式 | Helm Release / yaml路径 | 节点 | 镜像当前tag | 更新操作 |
|---|--------|---------|------------------------|------|------------|---------|
| 1 | crab-gateway | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 4.0.18 | 改 values 中 crab-gateway tag → helm upgrade innies-stack |

> ⚠️ **crab-gateway tag 备注**：`customer-*` tag 是 CUSTOMER 模式，需 license 文件或 `LICENSE_CONTENT_BASE64` 环境变量，未配置会 CrashLoopBackOff。标准 tag（如 3.0.3）无需 license。
| 2 | file-parser-api | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 3.0.22 | 改 values 中 file-parser-api tag → helm upgrade innies-stack |
| 3 | innies-biz | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 4.0.12 | 改 values 中 innies-biz tag → helm upgrade innies-stack |
| 4 | innies-fe | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 2.0.80 | 改 values 中 innies-fe tag → helm upgrade innies-stack |
| 5 | innies-loom | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 3.0.18 | 改 values 中 innies-loom tag → helm upgrade innies-stack |
| 6 | innies-users | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 1.3.2 | 改 values 中 innies-users tag → helm upgrade innies-stack |
| 7 | prism | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 3.0.10 | 改 values 中 prism tag → helm upgrade innies-stack |
| 8 | synapse | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 3.0.23 | 改 values 中 synapse tag → helm upgrade innies-stack |
| 9 | z8m | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 3.0.1 | 改 values 中 z8m tag → helm upgrade innies-stack |
| 10 | redis | helm | innies-stack → /data/zhiman/innies/values.yaml | 180 | 7.2 | 改 values 中 redis tag → helm upgrade innies-stack |
| 11 | deer-flow | helm | deer-flow → /data/zhiman/innies/deer-flow.values.yaml | 180 | 1.0.3 | 改 deer-flow.values.yaml tag → helm upgrade deer-flow |
| 12 | **pdf2zh** | **yaml** | **/data/zhiman/innies/pdf2zh/deployment.yaml** | **180** | **1.9.11-offline-0.1.0** | **改 deployment.yaml image tag → kubectl apply** |

### llm 命名空间

| # | 服务名 | 部署方式 | Helm Release / yaml路径 | 节点 | 镜像当前tag | 更新操作 |
|---|--------|---------|------------------------|------|------------|---------|
| 13 | xinference | helm | xinference → /data/zhiman/xinference/values.yaml | 180 | v1.5.0 | 改 values tag → helm upgrade xinference |
| 14 | vllm-reranker | helm | vllm → /data/zhiman/vllm/values.yaml | 180 | v0.9.1 | 改 values tag → helm upgrade vllm |
| 15 | infinity-vl-embedding | helm | infinity → /data/zhiman/infinity/values.yaml | 180 | latest | 改 values tag → helm upgrade infinity |
| 16 | zhiman-pdfminer | helm | zhiman-pdfminer → /data/zhiman/vllm/pdfminer/values.yaml | 180 | 3.2.3 | 改 values tag → helm upgrade zhiman-pdfminer |
| 17 | deployment-reloader | yaml | /data/zhiman/reloader/deployment-reloader.yaml | 180 | main-c16c462 | 改 yaml image tag → kubectl apply |

### milvus 命名空间

| # | 服务名 | 部署方式 | Helm Release / yaml路径 | 节点 | 镜像当前tag | 更新操作 |
|---|--------|---------|------------------------|------|------------|---------|
| 18 | milvus | helm | milvus → /data/zhiman/milvus/values.yaml | 180 | v2.6.15 | 改 values tag → helm upgrade milvus |
| 19 | attu | helm | milvus → /data/zhiman/milvus/values.yaml | 180 | v2.5.3 | 改 values 中 attu tag → helm upgrade milvus |

---

## innies-stack 子服务 → values.yaml tag 路径映射

> ⚠️ innies-stack 是大 Chart（包含多个子服务），更新子服务只需改 values.yaml 中对应 tag，一次 helm upgrade 生效。务必只改目标服务的 tag，避免误改其他子服务。

| 子服务 | values.yaml 中 tag 路径（近似） | 镜像 registry |
|--------|-------------------------------|--------------|
| crab-gateway | crab-gateway.image.tag | zhiman/yuwei/crab-gateway |
| file-parser-api | file-parser-api.image.tag | zhiman/file-parser-api |
| innies-biz | innies-biz.image.tag | zhiman/innies-biz |
| innies-fe | innies-fe.image.tag | zhiman/innies-fe |
| innies-loom | innies-loom.image.tag | zhiman/innies-loom |
| innies-users | innies-users.image.tag | zhiman/innies-users |
| prism | prism.image.tag | zhiman/yuwei/prism |
| synapse | synapse.image.tag | zhiman/synapse |
| z8m | z8m.image.tag | zhiman/z8m |
| redis | redis.image.tag | zhiman/redis |

---

## 快速查询

> 更新服务时，先从此表确认部署方式，再按对应 SOP 执行：
> - **helm** → SOP-002 Step A（修改 values → helm upgrade）
> - **yaml** → SOP-002 Step B（修改 yaml → kubectl apply）

## 相关文档

- [[sop-001-harbor-image-sync]] - 镜像同步 SOP
- [[sop-002-k8s-rollout]] - K8s 部署更新 SOP
- [[sop-helm-ops]] - Helm 升级命令速查
- [[ref-k8s-cluster]] - 集群环境信息

> 返回导航: [[INDEX]]
