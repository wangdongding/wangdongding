# K8S 集群环境信息

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-08-04 | 类型: 只读参考
> doc_id: ref-k8s-cluster v2 | tags: k8s,cluster,environment | depends: 无

## 集群概况

| 项目 | 值 |
|------|-----|
| K8S版本 | v1.29.9 |
| CNI | Cilium |
| CSI | Rook-Ceph(rbd+cephfs) |
| Ingress | nginx(ingress-nginx) |
| 容器运行时 | containerd 1.7.23 |
| GPU调度 | HAMI v2.6.1 |
| 镜像仓库 | 172.17.3.179 |
| Helm | innies-stack-0.1.27 |

## 节点信息

> 详见 [[ref-resource]] §服务器硬件与已分配资源 — 含 CPU/内存/GPU 分配明细

简要: 3节点（master01 + node01/02），node01/02 有 GPU（HAMI 调度），master 无 GPU

## Namespace(12个)

| ns | 用途 |
|----|------|
| cert-manager | TLS证书 |
| cnpg | CloudNative-PG |
| hami | GPU插件+调度 |
| ingress-nginx | Ingress |
| innies | 核心业务-AI知识库 |
| kube-system | 系统组件 |
| llm | 大模型推理 |
| milvus | Milvus向量库 |
| rabbitmq | RMQ集群 |
| rook-ceph | Ceph存储operator+集群 |
| default | 默认命名空间(空) |
| rook-ceph-external-system | Ceph外部工具(如tools Pod) |


## Pod清单

### innies(9 Deploy+1 STS)

> 各服务当前镜像 tag 详见 [[ref-service-deploy-registry]]（tag 权威源）

| Pod | 端口 | 类型 |
|-----|------|------|
| crab-gateway | 3000 | Deploy |
| file-parser-api | 5002 | Deploy |
| innies-biz | 9004 | Deploy |
| innies-fe | 80 | Deploy |
| innies-loom | 9005 | Deploy |
| innies-users | 9002 | Deploy |
| prism | 9003 | Deploy |
| redis | 6379 | STS |
| synapse | 9001/60001 | Deploy |
| z8m(N8N) | 5678 | Deploy |
| pdf2zh | 11008 | Deploy(yaml) |
| deer-flow-backend | 8000 | Deploy |
| deer-flow-frontend | 3000 | Deploy |

### llm(8 Pod)

> 各服务当前镜像 tag 详见 [[ref-service-deploy-registry]]（tag 权威源）

| Pod | 端口 |
|-----|------|
| xinference | 9997 |
| vllm-reranker | 8000 |
| infinity-vl-embedding | 8000 |
| zhiman-pdfminer | 8000 |
| deployment-reloader | 8000 |
| 3*NFS-server | 2049 |

### milvus(19 Pod,v2.6.15)

核心: mixcoord/proxy/datanode/querynode/streamingnode(各1)
消息: pulsarv3(broker1+proxy2+bookie3+zk3+recovery1)
存储: etcd(STS 3实例), attu(NodePort:30800)

### cnpg(5 Pod,PG 17.4)

postgres-cluster-prod(主备2���例) + pooler-rw(2 PgBouncer) + operator

### rabbitmq(4 Pod,2节点集群)

server-0/1 + cluster-operator + topology-operator

### rook-ceph(v19.2.2 Squid)

mon(3)+mgr(2)+osd(5)+rgw(1)+CSI plugins
> 状态: HEALTH_WARN(MON_DISK_LOW+PG_DEGRADED+RECENT_CRASH)


## Service清单

> 详见 [[ref-service-call-chain]] §Service ClusterIP 清单 — 与流量路由统一管理


## Ingress清单

> 详见 [[ref-service-call-chain]] §Ingress 资源清单 — 与流量路由统一管理


## PVC清单与StorageClass

> 详见 [[ref-storage]] - PVC/PV完整映射表、容量、SC、扩容策略

## Rook-Ceph 存储概览

> 详见 [[ref-ceph-storage]] - OSD/Pool/PG/告警详情

## ConfigMap(innies)

| CM | 内容 |
|----|------|
| innies-bucket | S3连接(host/bucket/port) |
| file-parser-api-config | ENV,MINERU_SERVICE_URL |
| prism-config | env.yaml |
| synapse-config | env.yaml |
| z8m-config | DB_TYPE,LOG_LEVEL |

## CoreDNS 自定义配置 (kube-system/coredns)

> 2026-08-04 新增：因 Cilium 异常后外部 DNS 转发不稳定，在 Corefile 中增加 hosts 插件

| 域名 | 映射 IP | 用途 |
|------|--------|------|
| dc.yuwei.com | 172.17.2.201 | innies-users LDAP 认证服务器 |

> ⚠️ 如果 LDAP 服务器 IP 变更，需同步更新此 hosts 条目（kubectl edit cm coredns -n kube-system）

## Secret与证书

> 详见 [[ref-secret-cert]] - 全量Secret/证书清单、到期日、轮换方式

简要: innies业务Secret(S3/DB连接/API Key)、cnpg TLS+basic-auth、hami/rabbitmq/kube-system TLS，详见上方链接

> 返回导航: [[INDEX]]
