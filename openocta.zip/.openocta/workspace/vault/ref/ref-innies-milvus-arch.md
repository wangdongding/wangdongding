# Innies 知识库向量架构现状

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-07-08(v2) | 类型: 运维参考(含变更记录)
> doc_id: ref-innies-milvus-arch v2 | tags: milvus,innies,collection,schema,knowledge_base | depends: ref-service-deploy-registry,ref-database
>
> 📎 导航: [[INDEX]]

## 一句话结论

**当前innies知识库存在两种Milvus collection schema并存状态：旧共享collection(InniesEmb schema) + 新独立collection(Legacy schema)，新建知识库默认走旧共享collection。InniesEmb schema已包含embeddedText+segment_index+BM25 function（与81生产环境一致），chunk expansion在InniesEmb上已修复，BM25仍受partitionKey限制部分失效。Legacy schema的chunk expansion仍失败（缺segment_index字段）。**

---

## 当前架构状态 (2026-07-08)

### Milvus innies 数据库中的collection分布

| 类型 | 数量 | schema | 数据量 | 引用知识库数 |
|------|------|--------|--------|-------------|
| `innies_emb_459c6be7e638481aa05804d97f9b0070` | 1 | InniesEmb | 95条(持续增长) | 新建知识库默认复用此collection |
| `innies_emb_781d2496ea164de0bcc8ad64be27d537` | 1 | InniesEmb | 0条(空壳) | 0(无PG引用) |
| `kb_XXX` | 156 | Legacy | 数万条 | 155个KB(37有文档+118空库) |

### innies-biz创建知识库的决策逻辑

```
knowledge_base_management_service.rs:373
V2 Milvus collection already exists, reusing
  knowledge_base_id=XXX collection_name=innies_emb_459c6be7... model_id=459c6be7
```

流程：
1. 新知识库使用默认 embedding_model_id = `459c6be7-e638-481a-a058-04d97f9b0070`
2. innies-biz查找Milvus中是否已有该model对应的collection
3. 发现 `innies_emb_459c6be7` 存在 → **复用**（"already exists, reusing"）
4. 若不存在 → 创建新的 `kb_XXX` 格式独立collection

**结论：只要旧 `innies_emb_459c6be7` collection存在，新建知识库就会走旧共享collection。**

### kb_embedding_migration表状态

| collection_active格式 | 记录数 | 有文档的知识库数 | 空库数 |
|-----------------------|--------|----------------|--------|
| `innies_emb_459c6be7...` | 75 | 2(测试库) | 73 |
| `kb_XXX` | 155 | 37 | 118 |

所有migration记录的 `active_model_id` 统一为 `459c6be7-e638-481a-a058-04d97f9b0070`。
kb_格式记录的 `created_at` 均为 2026-03-30（批量迁移操作产生）。
旧innies_emb格式记录的 `created_at` 为各知识库实际创建时间。

---

## 两种Schema字段对比

### InniesEmb schema（共享collection，实际已包含BM25全量字段）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | VarChar(36) | 主键 |
| tenant_id | VarChar(36) | **partitionKey** |
| kb_id | VarChar(36) | 知识库ID |
| user_id | VarChar(36) | 用户ID |
| document_id | VarChar(36) | 文档ID |
| segment_type | VarChar(64) | 段类型 |
| embedding | FloatVector(1024) | 向量 |
| sparse | SparseFloatVector | BM25稀疏向量(**function输出**,由text_bm25_emb生成) |
| document | JSON | 文档元数据 |
| embeddedText | VarChar(65535) | BM25原文(enable_analyzer=true) |
| segment_index | Int64(nullable) | 段索引（2026-07-08新增+INVERTED索引） |

### Legacy schema（新独立collection）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | VarChar(36) | 主键 |
| document_id | VarChar(36) | 文档ID |
| embedding | FloatVector(1024) | 向量 |
| sparse | SparseFloatVector | BM25稀疏向量(function输出) |
| document | JSON | 文档元数据 |
| embeddedText | VarChar(65535) | BM25原文(enable_analyzer=true) |

**关键差异**：
- InniesEmb有 `tenant_id`(partitionKey)、`kb_id`、`user_id`、`segment_type`、`embeddedText`、`segment_index`，BM25 function为`text_bm25_emb`
- Legacy有 `embeddedText`，**没有** `tenant_id`、`kb_id`、`user_id`、`segment_type`、`segment_index`
- 两者的BM25都通过function(`text_bm25_emb`)从embeddedText自动生成sparse字段
- **核心区别**：InniesEmb用partitionKey(tenant_id)做多租户隔离，Legacy用独立collection做隔离

---

## 已知问题（暂不处理）

### 问题1：InniesEmb schema下BM25混合检索部分失效

**现象**：搜索innies_emb collection时BM25结果不稳定
- 第一次搜索(query=`jumpserver怎么部署`)：BM25 found 0 results
- 第二次搜索(query=`jumpserver 怎么部署`，加空格重写)：BM25 found 2 results, raw_distance>0

**原因**：InniesEmb schema使用tenant_id做partitionKey过滤，BM25的sparse字段检索被partitionKey限制了搜索范围。部分query重写后能命中，原始query往往返回0结果。

**影响**：走旧共享collection的知识库，混合检索(hybrid)部分退化，关键字精确匹配不稳定。与81生产环境表现一致（81上BM25同样raw=0.0000）。

### 问题2：Legacy schema下chunk expansion失败（InniesEmb已修复）

**现象**：synapse搜索kb_格式collection时，chunk expansion查询失败
```
KB display chunk expansion query failed: field segment_index not exist
```

**原因**：synapse的chunk expansion使用 `segment_index >= X && segment_index <= Y` 过滤条件，但Legacy schema没有segment_index字段。

**修复状态**：
- ✅ **InniesEmb schema已修复**：2026-07-08新增segment_index字段(Int64,nullable=true)+INVERTED索引，chunk expansion不再报错，日志显示`segment_index=Some(0)` + `segment_index_missing=false` + `chunk expansion complete`（expanded_results=0是因为文档只有1个chunk，无相邻chunk可扩展）
- ❌ **Legacy schema仍失败**：kb_格式collection缺segment_index字段，chunk expansion查询仍报错



**影响**：搜索能返回基本结果(1条命中)，但无法扩展显示关联chunk的上下文段落。

### 问题3：Query Rewrite LLM超时

**现象**：所有搜索请求的query rewrite均超时10s
```
Failed to rewrite query: Query rewrite LLM request timeout after 10s. Using original query.
```

**原因**：prism LLM推理模型响应慢，10s超时不够。

**影响**：自动fallback到原始query，搜索精度降低但基本可用。

---

## synapse collection路由逻辑

synapse根据 `kb_embedding_migration` 表中的 `collection_active` 字段决定路由：

| collection_active开头 | schema_type | 写入/搜索schema |
|-----------------------|-------------|----------------|
| `innies_emb_` | InniesEmb | InniesEmb(有tenant_id/kb_id/segment_type) |
| `kb_` | Legacy | Legacy(有embeddedText，无segment_type) |

日志确认：
```
Resolved KB 3fd8779d to collection innies_emb_459c6be7 (schema: InniesEmb)
Resolved KB 7f6920db to collection kb_7f6920db (schema: Legacy)
```

---

## 服务连接配置

| 服务 | Milvus连接 | 数据库 |
|------|-----------|--------|
| innies-biz | `http://milvus.milvus.svc.cluster.local.:19530` | innies |
| synapse | `http://milvus.milvus.svc.cluster.local.:19530` | innies |
| innies-biz RAG调用 | synapse gRPC: `http://innies-stack-synapse.innies:9001` | - |
| synapse embedding调用 | `http://infinity-service-zhiman-vl-embedding.llm:8000` | - |
| synapse LLM/query rewrite | `http://innies-stack-prism.innies:9003` | - |

---

## 未来修复方向（待开发配合）

1. **innies-biz修复**：创建知识库时强制分配 `kb_XXX` 格式独立collection，不再查找旧collection复用（**最重要，止血动作**）
2. **synapse修复**：chunk expansion对Legacy schema不使用segment_index字段过滤（用document_id替代）
3. **存量迁移**：旧migration记录更新collection_active为kb_格式，空库可直接改，有文档的库需清空PG数据后重新上传
4. **旧collection清理**：迁移完成后删除Milvus中的 `innies_emb_459c6be7` 和 `innies_emb_781d2496` 两个collection
5. **prism性能**：调整query rewrite超时(15-20s)或优化LLM推理速度

---

## 变更记录

- 2026-07-08: 清除 `innies_emb_459c6be7` collection中原200万+向量数据，同步清除PG中相关知识库的document和chunk_meta数据
- 2026-07-08: 新增segment_index字段(Int64,nullable=true)到innies_emb_459c6be7 collection，创建INVERTED索引(segment_index_index)
- 2026-07-08: 经验证InniesEmb schema实际已包含embeddedText+segment_index+text_bm25_emb function（与81生产环境一致），文档v1描述过时已更正
- 2026-07-08: chunk expansion在InniesEmb上已修复（不再报segment_index not exist），BM25仍受partitionKey限制部分失效

---

## 180与81环境对比（2026-07-08只读探测）

| 指标 | 180(测试) | 81(生产) | 差异评估 |
|------|-----------|----------|----------|
| innies_emb_459c6be7行数 | 95条 | 2,611,127条 | 81数据量巨大 |
| innies_emb关联文档数 | 少量(测试库) | 40,979个文档 | 81是生产环境影响面大 |
| InniesEmb schema | embeddedText+segment_index+BM25 function | 同180 | **已一致** |
| BM25状态 | 部分失效(partitionKey限制) | 同180，raw=0.0000 | 两边一样 |
| chunk expansion(InniesEmb) | ✅ 已修复 | ✅ 正常 | 一致 |
| chunk expansion(Legacy kb_) | ❌ 失败 | ❌ 失败 | 一致 |
| Query Rewrite超时 | ❌ 10s超时 | ❌ 10s超时 | 一致 |
| Milvus namespace | milvus | milvus-prod | 命名空间不同 |
| innies namespace | innies | innies-prod | 命名空间不同 |

---

## 数据清除历史

- 2026-07-08: 清除 `innies_emb_459c6be7` collection中原200万+向量数据，同步清除PG中相关知识库的document和chunk_meta数据
- 清除后旧collection仅剩28条残留数据，后因新建测试知识库增长至37条(持续增长)

## 相关文档

- [[ref-service-deploy-registry]] - 服务部署方式注册表
- [[ref-database]] - 数据库详情
