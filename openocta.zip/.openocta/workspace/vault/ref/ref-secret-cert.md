# Secret与证书详情

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-06-30 | 类型: 只读参考
> doc_id: ref-secret-cert v1 | tags: secret,tls,certificate | depends: ref-k8s-cluster

## 1. TLS证书清单

| Namespace | Secret名 | 类型 | Subject | 到期日 | 管理方式 |
|-----------|----------|------|---------|--------|----------|
| cnpg | cnpg-webhook-cert | kubernetes.io/tls | CNPG webhook | 自动轮换 | CNPG operator自动管理 |
| cnpg | postgres-cluster-prod-server | kubernetes.io/tls | postgres-cluster-prod-rw | 2026-09-22 | CNPG operator自动管理 |
| cnpg | postgres-cluster-prod-pooler | kubernetes.io/tls | cnpg_pooler_pgbouncer | 2026-09-22 | CNPG operator自动管理 |
| cnpg | postgres-cluster-prod-replication | kubernetes.io/tls | streaming_replica | 2026-09-22 | CNPG operator自动管理 |
| hami | hami-scheduler-tls | Opaque(tls内嵌) | O=nil2 | 2126-05-30 | HAMi webhook-certgen |
| kube-system | hubble-server-certs | kubernetes.io/tls | *.kubernetes.hubble-grpc.cilium.io | 2029-06-22 | Cilium自动管理 |
| rabbitmq | webhook-server-cert | kubernetes.io/tls | (rabbitmq operator) | 2026-09-22 | RabbitMQ operator |

> ✅ 所有TLS证书均由对应operator自动管理，无需手动轮换
> ⚠️ CNPG/RabbitMQ证书到期日在2026-09-22，约3个月后到期，但operator会在到期前自动续签

## 2. 业务Secret清单

### 2.1 innies namespace

| Secret名 | 类型 | 内容 | 关联服务 |
|----------|------|------|----------|
| innies-bucket | Opaque | S3 AK/SK (AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY) | synapse/biz/prism/crab-gateway |
| innies-stack-innies-biz-db | Opaque | DATABASE_URL → pooler…innies_biz | innies-biz |
| innies-stack-innies-loom-db | Opaque | DATABASE_URL → pooler…innies_loom | innies-loom |
| innies-stack-innies-users-db | Opaque | DATABASE_URL + ADMIN → pooler…innies_users | innies-users |
| innies-stack-prism-db | Opaque | DATABASE_URL → pooler…prism | prism |
| innies-stack-synapse-secrets | Opaque | RABBITMQ_URL + S3 + MILVUS | synapse |
| innies-stack-z8m-secret | Opaque | PG连接 → z8m DB | z8m(N8N) |
| innies-stack-z8m-admin-key | Opaque | Z8M API Key | z8m管理接口 |
| innies-stack-z8m-z8m-admin | Opaque | Z8M Admin凭据 | z8m |

### 2.2 cnpg namespace

| Secret名 | 类型 | 内容 |
|----------|------|------|
| cnpg-ca-secret | Opaque | CNPG CA证书 |
| postgres-cluster-prod-app | basic-auth | PG app用户密码 |
| postgres-cluster-prod-ca | Opaque | PG CA证书 |
| postgres-cluster-prod-superuser | basic-auth | PG superuser密码 |

### 2.3 其他namespace

| Namespace | Secret名 | 类型 | 内容 |
|-----------|----------|------|------|
| milvus | milvus-bucket | Opaque | S3 AK/SK(Milvus专用) |
| milvus | milvus-minio | Opaque | Minio凭证 |
| rabbitmq | rabbitmq-cluster-prod-default-user | Opaque | RMQ用户密码 |
| rabbitmq | rabbitmq-cluster-prod-erlang-cookie | Opaque | RMQ集群cookie |

## 3. 连接信息格式

### PostgreSQL (通过CNPG Secret)
```
DATABASE_URL格式: postgresql://app:<密码>@pooler-postgres-cluster-prod-rw.cnpg.svc.cluster.local.:5432/<db名>
```

### S3 (通过innies-bucket Secret + innies-bucket CM)
```
S3_ENDPOINT = CM:innies-bucket → host/bucket/port
AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY = Secret:innies-bucket
```

### RabbitMQ (通过synapse-secrets)
```
RABBITMQ_URL = amqp://<user>:<pass>@rabbitmq-cluster-prod.rabbitmq.svc.cluster.local.:5672/
```

## 4. Secret管理注意事项

- CNPG Secret由operator自动管理，修改后下次operator reconcile会重置
- 业务Secret(innies-biz-db等)由Helm values注入，修改需helm upgrade更新
- S3 AK/SK通过OBC(innies-bucket)自动生成，不要手动修改
- 所有Secret的ReclaimPolicy跟随Helm release，helm uninstall会删除

## 5. 全量Secret统计

| 类型 | 数量 |
|------|------|
| kubernetes.io/tls | 7 |
| kubernetes.io/basic-auth | 2 |
| Opaque(业务) | ~30 |
| Opaque(基础设施) | ~39 |
| **合计** | ~78 |

## 相关文档

- [[ref-k8s-cluster]] - 集群环境信息

> 返回导航: [[INDEX]]
