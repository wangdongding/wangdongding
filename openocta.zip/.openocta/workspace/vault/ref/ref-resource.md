# 资源分配详情

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-09-14 | 类型: 静态快照
> doc_id: ref-resource v2 | tags: resource,cpu,memory,gpu | depends: ref-k8s-cluster
> ⚠️ 2026-09-14 勘误：GPU物理数量以 HAMI 注册(hami.io/node-nvidia-register)为准，**每节点实际仅1张RTX3080(10GB)**；capacity 中 nvidia.com/gpu=5 为 HAMI 上报虚值，无任何Pod使用该资源（全部走 gpucores/gpumem-percentage 切片调度）

## 服务器硬件与已分配资源

| 节点 | 角色 | CPU可分配 | 内存可分配 | GPU | CPU已Request | CPU已Limit | 内存已Request | 内存已Limit | GPU已分配 |
|------|------|----------|----------|-----|-------------|-----------|-------------|------------|----------|
| ai-q-master01 | master | 8核 | 15.5Gi | 0 | 3.6核(45%) | 0 | 3.5Gi(22%) | 8.1Gi(52%) | 0 |
| ai-q-node01 | worker | 32核 | 125Gi | 1(RTX3080) | 12.35核(38.6%) | 16.7核(52%) | 36.6Gi(29.2%) | 96.3Gi(76.8%) | 2切片(50%+50%) |
| ai-q-node02 | worker | 32核 | 125Gi | 1(RTX3080) | 29.6核(92.5%) | 53.9核(168%) | 100.9Gi(80.5%) | 231.1Gi(184%) | 2切片(50%+50%) |

> metrics-server未安装,无实时用量数据,以上为资源分配比(Request/Limit占可分配百分比)

## GPU资源分配详情

| 节点 | GPU总数(物理) | GPU已分配(虚拟切片) | 分配给 |
|------|--------------|--------------------|-------|
| ai-q-master01 | 0 | 0 | - |
| ai-q-node01 | 1 (RTX3080 10GB, UUID d682bf5d) | 2切片 (50%+50%=100%) | infinity-vl-embedding(50%) + vllm-reranker(50%) |
| ai-q-node02 | 1 (RTX3080 10GB, UUID 7637341e) | 2切片 (50%+50%=100%) | zhiman-pdfminer(50%) + xinference(50%) |

> ⚠️ 2026-09-14 勘误：两节点均为1张RTX3080且已 50%+50% 占满，**当前无GPU余量**。HAMI 以 gpucores/gpumem-percentage(0~100) 做切片，每张物理卡=100cores/100mem；capacity 中 nvidia.com/gpu=5 为 HAMI 上报虚值，无任何 Pod 使用该资源

## 各Pod资源分配明细

### innies ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim |
|-----|------|---------|---------|---------|--------|
| crab-gateway | node01 | 1 | 1 | 2Gi | 2Gi |
| file-parser-api | node01 | 500m | 1 | 1Gi | 2Gi |
| innies-biz | node01 | 2 | 2 | 4Gi | 4Gi |
| innies-fe | node01 | 1 | 1 | 2Gi | 2Gi |
| innies-loom | node01 | 1 | 1 | 2Gi | 2Gi |
| innies-users | node01 | 1 | 1 | 2Gi | 2Gi |
| prism | node02 | 1 | 4 | 2Gi | 8Gi |
| redis | node01 | 100m | 500m | 128Mi | 512Mi |
| synapse | node02 | 1 | 4 | 2Gi | 8Gi |
| z8m | node01 | - | - | - | - |

> innies-biz是innies ns中资源消耗最大的服务(CPU 2核/Mem 4Gi),prism和synapseLimit弹性到4核/8Gi

### llm ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim | GPU | 备注 |
|-----|------|---------|---------|---------|---------|-----|------|
| xinference | node02 | 2 | 8 | 8Gi | 16Gi | 50%切片 | 2026-09-14 CPU req 4→2修复调度 |
| vllm-reranker | node01 | - | - | - | - | 50%切片 | |
| infinity-vl-embedding | node01 | - | - | - | - | 50%切片 | |
| zhiman-pdfminer | node02 | 4 | 16 | 8Gi | 32Gi | 50%切片 | 2026-09-14修复(加schedulerName) |
| 3*NFS-server | node01 | - | - | - | - | 0 | |

> xinference为llm ns资源消耗较大的服务(CPU Req 2核/Lim 8核/Mem 8~16Gi/GPU 50%切片)；GPU列按HAMI切片标注，node01/node02各1张RTX3080均已占满

### milvus ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim | 备注 |
|-----|------|---------|---------|---------|---------|------|
| attu | node02 | 100m | 500m | 128Mi | 512Mi | 管理UI |
| mixcoord | node02 | 500m | 2 | 1Gi | 4Gi | 2026-07-08加limit |
| proxy | node02 | 500m | 2 | 1Gi | 4Gi | 2026-07-08加limit |
| datanode | node02 | 500m | 2 | 1Gi | 4Gi | 2026-07-08加limit |
| querynode | node01 | 1 | 4 | 2Gi | 8Gi | 2026-07-08加limit |
| streamingnode | node02 | 500m | 2 | 1Gi | 4Gi | 2026-07-08加limit |
| pulsarv3-bookie(3) | node01/02 | 500m | 2 | 4Gi | 16Gi | 2026-07-08加limit |
| pulsarv3-broker | node02 | 500m | 2 | 4Gi | 16Gi | 2026-07-08加limit |
| pulsarv3-proxy(2) | node01/02 | 500m | 1 | 1Gi | 4Gi | 2026-07-08加limit |
| pulsarv3-zk(3) | node01/02 | 200m | 500m | 256Mi | 1Gi | 2026-07-08加limit |
| etcd(3) | node01/02 | 200m | 1 | 512Mi | 2Gi | 2026-07-08加limit |

> 2026-07-08: 全组件添加resources.limits/requests(override文件: /data/zhiman/milvus/resources-override.yaml)，修复GC tuner memoryThreshold过高导致OOM循环重启

### cnpg ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim |
|-----|------|---------|---------|---------|--------|
| postgres-cluster-prod-1 | node01 | - | - | - | - |
| postgres-cluster-prod-2 | node02 | - | - | - | - |
| pooler-rw(2) | node01/02 | 100m | 500m | 100Mi | 500Mi |
| cnpg-operator | node01 | - | - | - | - |

> PG实例资源由CNPG Operator自动管理,无手动配置

### rabbitmq ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim |
|-----|------|---------|---------|---------|--------|
| server-0 | node01 | 1 | 2 | 2Gi | 2Gi |
| server-1 | node02 | 1 | 2 | 2Gi | 2Gi |
| cluster-operator | node01 | 200m | 200m | 500Mi | 500Mi |
| topology-operator | node01 | 100m | 300m | 100Mi | 500Mi |

### rook-ceph ns(核心组件)

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim |
|-----|------|---------|---------|---------|--------|
| mon-a | node01 | 1 | - | 1Gi | 2Gi |
| mon-b | node02 | 1 | - | 1Gi | 2Gi |
| mon-c | master | 1 | - | 1Gi | 2Gi |
| mgr-a | master | 500m | - | 512Mi | 1Gi |
| mgr-b | node01 | 500m | - | 512Mi | 1Gi |
| osd-0 | node02 | 1 | - | 4Gi | 4Gi |
| osd-1 | node02 | 1 | - | 4Gi | 4Gi |
| osd-2 | node02 | 1 | - | 4Gi | 4Gi |
| osd-3 | node02 | 1 | - | 4Gi | 4Gi |
| osd-4 | node01 | 1 | - | 4Gi | 4Gi |
| rgw | node02 | 1 | - | 1Gi | 2Gi |

> OSD是Ceph最重的组件(node02上4个OSD,共16Gi mem request)


## Ceph存储用量与OSD分布

> 详见 [[ref-ceph-storage]] - 集群总览、OSD分布、Pool用量、PG状态、告警跟踪

一句话: 100TiB总容量/252GiB已用(0.25%)/HEALTH_WARN/5 OSD/3副本(osd.2空→PG不均衡)

## 相关文档

- [[ref-k8s-cluster]] - 集群环境信息

> 返回导航: [[INDEX]]
