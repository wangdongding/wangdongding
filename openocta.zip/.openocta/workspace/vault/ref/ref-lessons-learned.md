# 经验教训

> 🏷️ 环境归属: 179本机 + 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-09-21 | 类型: 经验记录

## 2026-09-21 | Cilium VXLAN MTU 未显式配置导致大包丢弃，前端大文件传输超时

- **教训**：集群物理网络 MTU=1420（非标准 1500，可能因 VPN/隧道/云网络），Cilium ConfigMap 未显式设置 `mtu`，默认 1500。VXLAN 封装后包大小 1550 > 物理 MTU 1420，大包被丢弃。表现为：小请求（<1400B）正常，大文件（>1400B）传输超时，ingress-nginx 报 `upstream timed out (110: Operation timed out) while reading response header from upstream`。Pod 内 curl 正常（不走 VXLAN 隧道），跨节点通过 ingress-nginx 代理时超时。
- **排查方法**：①确认 Pod 本身正常（exec 内 curl 秒回）②确认 ingress-nginx 到 Pod 的直连 curl 也超时 ③用 `ping -M do -s <size>` 逐步测试物理 MTU ④计算有效 MTU = 物理 MTU - VXLAN 开销(50B) ⑤检查 Cilium ConfigMap 是否有 `mtu` 字段
- **措施**：Cilium ConfigMap 添加 `mtu: "1370"`（1420-50），`kubectl rollout restart ds cilium -n kube-system` 滚动重启生效。
- **预防**：Cilium VXLAN 部署必须显式设置 MTU = 物理 MTU - 50。部署后用 `ping -M do -s <mtu-28>` 验证跨节点物理 MTU，确保 Cilium MTU 配置正确。非标准 MTU 环境尤其注意。
- **关联**：[[ref-change-log]] 2026-09-21 Cilium MTU 修复

## 2026-09-14 | HAMI GPU Pod 必须指定 schedulerName: hami-scheduler，否则 default-scheduler 无法调度

- **教训**：zhiman-pdfminer 和 xinference 的 Pod 长期 Pending，事件显示 "Insufficient nvidia.com/gpucores / nvidia.com/gpumem-percentage"。根因是 Deployment 未指定 `schedulerName: hami-scheduler`，default-scheduler 不识别 HAMI 管理的 GPU 共享资源（gpucores/gpumem-percentage），直接按节点 capacity 检查失败。而同集群的 vllm-reranker、infinity-vl-embedding 因指定了 hami-scheduler 正常运行。
- **措施**：①values.yaml 添加 `schedulerName: hami-scheduler` ②Chart 模板 deployment.yaml 添加 `{{- with .Values.schedulerName }}schedulerName: {{ . }}{{- end }}` 渲染逻辑 ③helm package + helm upgrade 生效。
- **预防**：所有使用 HAMI GPU 资源（nvidia.com/gpucores、nvidia.com/gpumem-percentage）的 Deployment 必须指定 `schedulerName: hami-scheduler`。新建 GPU 服务时，Chart 模板应默认包含 schedulerName 字段。
- **关联**：[[ref-change-log]] 2026-09-14 zhiman-pdfminer 修复调度失败

## 2026-09-07 | mc mirror不适合跨集群S3大文件迁移 + SSH隧道multipart upload数据截断 + IPVS NodePort延迟生效

- **教训1**：mc mirror采用流式传输（边读边写），源端读取因网络问题中断时目标端PUT body不完整，RGW返回ContentLength mismatch（声明16MB但实际只发送2~8MB）。此问题在SSH隧道和IPVS环境下均会触发，4次尝试均失败。rclone先读取数据到内存缓冲再写入，源端读取失败会重试，不会产生ContentLength mismatch。
- **措施1**：跨集群S3大文件迁移优先使用rclone copy而非mc mirror。rclone默认chunk size 5MB（mc默认16MB），更小粒度更可靠；--retries自动重试失败对象。
- **教训2**：SSH隧道在传输大文件multipart upload时存在数据截断问题，无论读写哪端走隧道都会触发。622GB数据量级应避免使用SSH隧道。
- **措施2**：大文件迁移使用NodePort/直连网络，避免SSH隧道。跨集群K8s网络隔离时，在目标集群创建NodePort暴露RGW，源端通过物理网络直连。
- **教训3**：kube-proxy IPVS模式下新建NodePort Service后，IPVS规则可能存在但未立即生效（ipvsadm显示规则但计数器为0，curl Connection refused）。需等待kube-proxy re-sync（1~5分钟）。
- **措施3**：创建NodePort后先验证curl连通性再使用，不要立即开始迁移。如急需可用，可重启kube-proxy强制同步。
- **教训4**：SSH端口转发 `-L port:svc-name:80` 中的K8s Service DNS名在目标主机上无法解析，需改用ClusterIP。
- **措施4**：SSH端口转发始终使用ClusterIP（如10.96.1.58）而非K8s DNS名（如rook-ceph-rgw-ceph-objectstore.rook-ceph.svc）。
- **关联**：[[plan-s3-migrate-81-to-180]] v5、[[ref-change-log]] 2026-09-07 S3数据迁移

## 2026-08-21 | 新版本镜像可能引入新环境变量要求 + 数据库表 owner 不匹配导致迁移失败 + advisory lock 僵尸会话

- **教训1**：synapse 3.0.15 新增 DATABASE_URL 环境变量要求，但 chart 模板和 values.yaml 均未配置，导致 Pod CrashLoopBackOff。升级前应确认新版本是否有新增配置要求（查看 changelog 或镜像启动日志）。
- **措施1**：通过 values.yaml extraEnv 添加 DATABASE_URL，重新 helm upgrade 生效。后续升级前应先检查新版本 release notes 或用 `kubectl logs` 查看启动报错。
- **教训2**：innies-biz 4.0.8 数据库迁移 `ALTER TABLE knowledge_base ADD COLUMN` 失败，因为表 owner 是 postgres 而非 app 用户。innies_biz 数据库 60 张表全部由 postgres 创建，app 用户无 ALTER 权限。
- **措施2**：通过 `ALTER TABLE ... OWNER TO app` 批量修改全部 60 张表的 owner。根因可能是早期迁移由 postgres 超级用户执行，后续版本改用 app 用户后 owner 不一致。
- **教训3**：innies-biz 重启后 migration advisory lock 被 zombie session (PID 1956449) 占用，持续等待无法获取锁。该 PID 对应的数据库连接已不存在但 lock 未释放。
- **措施3**：删除 Pod 触发重建后，advisory lock 自动释放（旧连接随 Pod 销毁断开）。如遇类似情况，可先 `pg_stat_activity` 确认 PID 是否存活，不存活则 `pg_terminate_backend` 或直接删 Pod。
- **关联**：[[ref-change-log]] 2026-08-21 批量部署 7 服务

## 2026-08-18 | OpenOcta API 不支持流式调用 + 长推理导致连接断开

- **教训**：ai-alert-bridge 调用 OpenOcta 数字员工 API (`/openocta/open/v1/completion`) 时，非流式调用(stream=False)在模型长推理时出现 "Server disconnected without sending a response"；尝试改为流式(stream=True)后返回 501 Not Implemented，说明该端点不支持 SSE 流式响应。
- **措施**：恢复非流式调用，增加重试机制(MAX_RETRIES=2)和详细日志（请求参数/响应状态/耗时/错误分类），对连接断开和超时自动重试，4xx 错误不重试。同时精简 prompt 限制输出300字以内，避免表格和代码块，适配钉钉 Markdown 渲染。
- **注意**：OpenOcta `/openocta/open/v1/completion` 端点仅支持非流式调用。如果后续模型推理时间持续增长，可能需要考虑换用支持流式的端点或增加中间层保活。
- **关联**：[[ref-change-log]] 2026-08-18 ai-alert-bridge 修复

## 2026-08-04 | Cilium 异常后 CoreDNS 外部域名转发不稳定导致 LDAP 登录间歇性失败

- **教训**：180集群 Cilium 曾经异常（挂掉/重启），之后 CoreDNS 的 `forward . /etc/resolv.conf` 链路对外部域名解析变得不稳定，表现为间歇性 "failed to lookup address information: Name or service not known"。innies-users(ferriskey) 的 LDAP 认证连接 dc.yuwei.com:389 因此间歇性失败——首次 bind 可能成功，但二次连接（用户密码验证）时 DNS 解析失败，导致登录报 "Authentication failed: internal server error"。
- **措施**：在 CoreDNS Corefile 中增加 hosts 插件，将关键外部域名（如 dc.yuwei.com）静态映射为 IP，绕过不稳定的 forward 链路。比修改业务 Deployment hostAliases 更持久——Helm 部署的服务迭代时 hostAliases 会丢失，而 CoreDNS ConfigMap 一般不随业务变更。
- **注意**：此为 workaround 而非根因修复。如果 LDAP 服务器 IP 变更，需同步更新 CoreDNS hosts 条目。根因可能是 Cilium 对 NodePort/ClusterIP 转发链路的 bug，需关注 Cilium 后续版本更新。
- **关联**：[[ref-change-log]] 2026-08-04 CoreDNS hosts 修改

## 2026-07-13 | containerd 迁移后 overlayfs snapshot 残留导致 nerdctl pull 失败

- **教训**：containerd 数据目录迁移（rsync+软链接）后，overlayfs snapshot 可能出现空目录残留（目录存在但缺少 fs 子目录），导致后续 nerdctl pull 报 "failed to stat parent: stat .../snapshots/XXX/fs: no such file or directory"。重启 containerd 不会自动修复此类残留。
- **措施**：迁移后首次拉取新镜像前，应检查是否存在空 snapshot 目录（`ls /data/containerd/io.containerd.snapshotter.v1.overlayfs/snapshots/` 中目录仅有 `.` 和 `..`）。如发现空目录，可用 `mkdir` 补齐缺失的 fs 子目录后重试拉取。此类空 snapshot 目录可能是迁移时 rsync 遗漏或 containerd 内部写入未完成的中间产物。
- **关联**：[[ref-change-log]] 2026-07-13 zhiman-pdfminer 镜像同步

## 2026-07-08 | Milvus InniesEmb schema文档过时问题

- **教训**：知识库文档(ref-innies-milvus-arch)描述180上InniesEmb schema没有embeddedText和segment_index字段，但实际探测发现这两个字段早已存在（embeddedText+segment_index+BM25 function text_bm25_emb）。schema变更可能由之前某次操作完成但文档未同步更新。
- **措施**：每次Milvus collection schema变更后，必须用describe API验证实际schema并更新文档。不能仅凭代码逻辑或历史记录假设schema状态。

## 2026-07-08 | Milvus AlterCollection添加字段前需确认字段是否已存在

- **教训**：尝试添加segment_index字段时返回duplicate field name错误，说明字段已经存在。应在变更前先describe collection确认当前schema，避免重复操作。
- **措施**：执行schema变更前，先用/v2/vectordb/collections/describe确认当前字段列表。

## 2026-07-08 | BM25在InniesEmb schema上的表现与预期不同

- **教训**：之前认为InniesEmb schema缺embeddedText导致BM25完全失效，但实际发现InniesEmb已有embeddedText字段，BM25不是完全失效而是部分失效（partitionKey限制）。query重写后（加空格）BM25能返回结果(raw_distance>0)，原始query可能返回0结果。
- **措施**：分析BM25问题时不能仅凭"有/没有embeddedText"判断，需要看实际搜索日志中的BM25 raw_distance和返回数量。

## 相关文档

- [[ref-change-log]] - 变更日志
