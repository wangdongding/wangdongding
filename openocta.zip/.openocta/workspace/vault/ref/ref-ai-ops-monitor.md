# AI-Ops 监控告警体系

> 🏷️ 环境归属: 179本机(172.17.3.179) | 最后更新: 2026-07-16 | 类型: 只读参考
> doc_id: ref-ai-ops-monitor v1 | tags: monitoring,alerting,prometheus,grafana,loki | depends: ref-env-context

## 1. 部署概况

| 项目 | 值 |
|------|-----|
| 部署目录 | /data/ai-ops-monitor/ |
| 部署方式 | Docker Compose (docker compose) |
| 网络名 | ai-ops-monitor-net (bridge) |
| 镜像仓库 | 172.17.3.179/yuwei/ |
| 容器前缀 | ai-ops- |
| 环境变量 | .env (从 .env.example 复制) |
| 部署脚本 | deploy.sh |

## 2. 组件清单 (10个容器)

| 容器名 | 镜像 | 宿主端口 | 作用 |
|--------|------|---------|------|
| ai-ops-node-exporter | 172.17.3.179/yuwei/prom/node-exporter:latest | 9100 | 主机指标采集 (CPU/内存/磁盘/网络) |
| ai-ops-blackbox-exporter | 172.17.3.179/yuwei/prom/blackbox-exporter:latest | 9115 | HTTP/TCP/ICMP 黑盒探测 |
| ai-ops-cadvisor | 172.17.3.179/yuwei/cadvisor/cadvisor:v0.51.0 | 8082→8080 | 容器指标采集 (CPU/内存/网络/IO) |
| ai-ops-postgres-exporter | 172.17.3.179/yuwei/prometheuscommunity/postgres-exporter:latest | 9187 | PostgreSQL 指标采集 |
| ai-ops-pushgateway | 172.17.3.179/yuwei/prom/pushgateway:latest | 9091 | 临时任务/Cron 推送指标 |
| ai-ops-prometheus | 172.17.3.179/yuwei/prom/prometheus:latest | 9090 | 指标中心 + 告警评估 |
| ai-ops-alertmanager | 172.17.3.179/yuwei/prom/alertmanager:latest | 9093 | 告警路由/分发 |
| ai-ops-loki | 172.17.3.179/yuwei/grafana/loki:latest | 3100 | 日志中心 |
| ai-ops-promtail | 172.17.3.179/yuwei/grafana/promtail:latest | 9080 | 日志采集 (宿主机+容器) |
| ai-ops-grafana | 172.17.3.179/yuwei/grafana/grafana:latest | 3000 | 可视化看板 |

## 3. 监控节点

### 3.1 Docker 节点 (node-exporter + cAdvisor 容器)

| 节点 IP | node-exporter | cAdvisor | 说明 |
|---------|--------------|----------|------|
| 172.17.3.179 | 容器内 :9100 | 容器内 :8080 | ai-master01, 本机 |
| 172.17.47.137 | :9101 | :8080 | node02 |

### 3.2 K8s 节点 (node-exporter 进程 + kubelet cAdvisor)

| 节点 IP | node-exporter | kubelet cAdvisor | 说明 |
|---------|--------------|-----------------|------|
| 172.17.3.180 | :9100 | :10250/metrics/cadvisor | ai-q-master01 |
| 172.25.20.27 | :9100 | :10250/metrics/cadvisor | ai-q-node01 |
| 172.25.20.28 | :9100 | :10250/metrics/cadvisor | ai-q-node02 |

> K8s cAdvisor 通过 bearer_token + CA 证书认证，配置文件: prometheus/k8s-bearer-token, prometheus/k8s-ca.crt
> metric_relabel_configs: 丢弃 POD/空容器行，用 container 标签覆盖 name 标签，统一 Docker/K8s 两种节点的容器名

## 4. Prometheus 配置要点

| 配置项 | 值 |
|--------|-----|
| 抓取间隔 | 15s |
| 评估间隔 | 15s |
| 数据保留 | 90d / 50GB |
| admin API | 开启 (--web.enable-admin-api) |
| lifecycle | 开启 (--web.enable-lifecycle) |
| external_labels | cluster=ai-ops-prod, environment=production |

### 4.1 抓取 Job 清单

| Job 名 | 类型 | 目标 |
|--------|------|------|
| prometheus | 自身 | localhost:9090 |
| alertmanager | 服务 | alertmanager:9093 |
| node-exporter | 主机指标 | 5个节点 (见上) |
| cadvisor | 容器指标 | 2个Docker节点 |
| k8s-cadvisor | K8s容器指标 | 3个K8s节点 (HTTPS+bearer) |
| blackbox-http | HTTP探测 | 12个URL (监控组件+业务服务) |
| blackbox-tcp | TCP探测 | 5个端口 (PG/Redis/SSH/Harbor/JMS) |
| postgres-exporter | 数据库 | postgres-exporter:9187 |
| pushgateway | 临时指标 | pushgateway:9091 |
| grafana | 服务 | grafana:3000 |

### 4.2 Blackbox HTTP 探测目标

| 目标 | 说明 |
|------|------|
| http://prometheus:9090 | Prometheus |
| http://grafana:3000 | Grafana |
| http://alertmanager:9093 | Alertmanager |
| http://loki:3100/ready | Loki |
| http://cadvisor:8080/healthz | cAdvisor |
| http://promtail:9080/ready | Promtail |
| http://blackbox-exporter:9115/-/healthy | Blackbox |
| http://172.17.3.179:8080/health | open-webui |
| http://172.17.3.179:8000/health | open-terminal |
| http://172.17.3.179:8888 | openwebui-jupyter |
| http://172.17.3.179:8081 | jms_web |
| http://172.17.3.179:80 | harbor (nginx) |

### 4.3 Blackbox TCP 探测目标

| 目标 | 说明 |
|------|------|
| 172.17.3.179:5432 | openwebui-postgres |
| 172.17.3.179:6379 | openwebui-redis |
| 172.17.3.179:2222 | jms_koko (SSH) |
| 172.17.3.179:80 | harbor (nginx) |
| 172.17.3.179:8081 | jms_web (nginx) |

## 5. 告警规则 (5组)

### 5.1 主机资源 (host-resources.yml)

| 规则名 | 条件 | 级别 | for |
|--------|------|------|-----|
| HostHighCpuLoad | CPU>80% | warning | 5m |
| HostCriticalCpuLoad | CPU>95% | critical | 2m |
| HostLowMemory | 内存>85% | warning | 2m |
| HostCriticalMemory | 内存>95% | critical | 2m |
| HostDiskSpaceWarning | 磁盘>80% | warning | 1m |
| HostDiskSpaceCritical | 磁盘>90% | critical | 1m |
| HostDiskIoHigh | IO利用率>80% | warning | 10m |
| HostHighLoadAvg | 负载/CPU核>1.0 | warning | 10m |

### 5.2 容器 (containers.yml)

| 规则名 | 条件 | 级别 | for |
|--------|------|------|-----|
| ContainerOomKilled | OOM事件 | critical | 1m |
| ContainerRestartLoop | 5m重启>2次 | warning | 1m |
| ContainerHighCpu | CPU>80% | warning | 5m |
| ContainerHighMemory | 内存>85% (有limit) | warning | 5m |

### 5.3 服务健康 (services.yml)

| 规则名 | 条件 | 级别 |
|--------|------|------|
| NodeExporterDown | up==0 | critical |
| PrometheusDown | up==0 | critical |
| AlertmanagerDown | up==0 | critical |
| GrafanaDown | up==0 | critical |
| LokiDown | up==0 | critical |
| PushgatewayDown | up==0 | warning |
| CadvisorDown | up==0 | critical |
| PostgresExporterDown | up==0 | warning |
| PrometheusRuleEvaluationFailures | 规则评估失败 | warning |

### 5.4 网络连通性 (network.yml)

| 规则名 | 条件 | 级别 |
|--------|------|------|
| ServiceHttpProbeFailed | HTTP探测失败 | critical |
| ServiceHttpProbeSlow | 响应>3s | warning |
| SslCertExpiringSoon | 证书<30天 | warning |
| SslCertExpiringCritical | 证书<7天 | critical |
| TcpPortUnreachable | TCP不通 | critical |
| NetworkNicErrors | 网卡错误包 | warning |
| NetworkNicDrops | 网卡丢包 | warning |

### 5.5 PostgreSQL (postgres.yml)

| 规则名 | 条件 | 级别 |
|--------|------|------|
| PostgresDown | pg_up==0 | critical |
| PostgresTooManyConnections | 连接>100 | warning |
| PostgresSlowQueries | 块读时间>0.5 | warning |
| PostgresDeadlocks | 死锁 | critical |
| PostgresHighRollbackRate | 回滚>10% | warning |
| PostgresReplicationLag | 延迟>60s | critical |

## 6. Alertmanager 告警路由

| 配置项 | 值 |
|--------|-----|
| 分组键 | alertname, cluster, severity |
| group_wait | 30s (critical: 10s) |
| group_interval | 5m |
| repeat_interval | 4h (critical: 1h) |
| 抑制规则 | critical 抑制同 instance+alertname 的 warning |

### 6.1 接收器

| 接收器 | 通道 | 地址 |
|--------|------|------|
| default | 钉钉Webhook | http://172.17.47.137:8060/dingtalk/monitor/send |
| critical-channels | 钉钉Webhook | 同上 (预留邮件通道) |

### 6.2 钉钉桥接

| 项目 | 值 |
|------|-----|
| 部署位置 | 172.17.47.137:8060 |
| 配置文件 | dingtalk/config.yml |
| 模板文件 | dingtalk/template.tmpl |
| 机器人token | 0efe518c... (见配置文件) |
| 签名密钥 | SEC5ee5f... (见配置文件) |

## 7. Loki 日志配置

| 配置项 | 值 |
|--------|-----|
| 模式 | 单节点 (filesystem存储) |
| Schema | v13 (TSDB索引) |
| 日志保留 | 30d |
| 采集速率限制 | 10MB/s (burst 20MB) |
| Compactor | 启用, 10m压缩间隔, 启用保留删除 |
| Ruler | 启用, 对接 alertmanager:9093 |
| 数据目录 | /loki (Volume: loki-data) |

### 7.1 Promtail 采集

| 配置项 | 值 |
|--------|-----|
| 采集源 | /var/log (宿主机) + /var/lib/docker/containers (容器) |
| Docker SD | 通过 docker.sock 自动发现容器 |
| machine-id | /etc/machine-id |

## 8. Grafana 配置

| 配置项 | 值 |
|--------|-----|
| 数据源 - Prometheus | http://prometheus:9090 (默认) |
| 数据源 - Loki | http://loki:3100 (含错误日志→Prometheus跳转) |
| 数据源 - Alertmanager | http://alertmanager:9093 |
| Dashboard自动加载 | /var/lib/grafana/dashboards (AI-Ops文件夹) |
| 自动刷新间隔 | 30s |

## 9. 常用查询速查

> 以下为数字员工排查问题时常用的 PromQL 和命令

### 9.1 主机 CPU 分析

```
# 某节点 CPU 使用率 (5m平均)
100 - (avg by(instance) (rate(node_cpu_seconds_total{mode="idle", instance="172.17.3.179"}[5m])) * 100)

# 按模式分解 CPU
avg by(mode, instance) (rate(node_cpu_seconds_total{instance="172.17.3.179"}[5m])) * 100

# Top5 高 CPU 节点
topk(5, 100 - (avg by(instance) (rate(node_cpu_seconds_total{mode="idle"}[5m])) * 100))
```

### 9.2 主机内存分析

```
# 内存使用率
(1 - node_memory_MemAvailable_bytes{instance="172.17.3.179"} / node_memory_MemTotal_bytes{instance="172.17.3.179"}) * 100

# Top5 高内存节点
topk(5, (1 - node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes) * 100)
```

### 9.3 磁盘分析

```
# 磁盘使用率 (排除 /boot)
(1 - node_filesystem_avail_bytes{mountpoint!~"/boot(/efi)?"} / node_filesystem_size_bytes{mountpoint!~"/boot(/efi)?"}) * 100

# 磁盘 IO
rate(node_disk_io_time_seconds_total[5m]) * 100
```

### 9.4 容器分析

```
# 某节点容器 CPU Top5
topk(5, rate(container_cpu_usage_seconds_total{instance="172.17.3.179", name!=""}[5m]) * 100)

# 某节点容器内存 Top5
topk(5, container_memory_working_set_bytes{instance="172.17.3.179", name!=""})

# 容器重启事件
increase(container_restart_count[5m]) > 0

# OOM 事件
increase(container_oom_events_total[5m]) > 0
```

### 9.5 服务可用性

```
# 所有 up 目标状态
up

# HTTP 探测结果
probe_success{job="blackbox-http"}

# TCP 探测结果
probe_success{job="blackbox-tcp"}

# HTTP 响应时间
probe_duration_seconds{job="blackbox-http"}
```

### 9.6 PostgreSQL

```
# PG 连接数
sum by(instance) (pg_stat_activity_count)

# PG 死锁
rate(pg_stat_database_deadlocks_total[5m])

# PG 复制延迟
pg_replication_lag
```

## 10. 常用运维命令

```bash
# 查看所有容器状态
cd /data/ai-ops-monitor && docker compose --env-file .env ps

# 查看告警 (通过 Prometheus API)
curl -s 'http://172.17.3.179:9090/api/v1/alerts' | python3 -m json.tool

# 查看当前 firing 的告警
curl -s 'http://172.17.3.179:9090/api/v1/alerts?filter=alertstate="firing"' | python3 -m json.tool

# 查看 Alertmanager 中的告警
curl -s 'http://172.17.3.179:9093/api/v2/alerts' | python3 -m json.tool

# 热重载 Prometheus 配置
curl -X POST http://172.17.3.179:9090/-/reload

# 热重载 Alertmanager 配置
curl -X POST http://172.17.3.179:9093/-/reload

# 查询 PromQL (URL编码)
curl -s 'http://172.17.3.179:9090/api/v1/query?query=up' | python3 -m json.tool

# Grafana 数据源健康
curl -s http://172.17.3.179:3000/api/health

# Loki 日志查询 (LogQL)
curl -s 'http://172.17.3.179:3100/loki/api/v1/query_range' --data-urlencode 'query={job="varlogs"}' --data-urlencode 'start=...' --data-urlencode 'end=...' --data-urlencode 'limit=100' -G
```

## 11. 配置文件清单

| 文件路径 | 作用 |
|---------|------|
| docker-compose.yml | 编排定义 |
| .env | 环境变量 (密码/连接信息) |
| prometheus/prometheus.yml | Prometheus 抓取配置 |
| prometheus/alerts/host-resources.yml | 主机资源告警规则 |
| prometheus/alerts/containers.yml | 容器告警规则 |
| prometheus/alerts/services.yml | 服务健康告警规则 |
| prometheus/alerts/network.yml | 网络连通性告警规则 |
| prometheus/alerts/postgres.yml | PostgreSQL告警规则 |
| prometheus/k8s-bearer-token | K8s API 认证 token |
| prometheus/k8s-ca.crt | K8s API CA 证书 |
| alertmanager/alertmanager.yml | Alertmanager 路由/接收器 |
| alertmanager/templates/default.tmpl | 告警通知模板 |
| loki/loki.yml | Loki 存储保留/压缩配置 |
| grafana/provisioning/datasources/datasources.yml | Grafana 数据源自动配置 |
| grafana/provisioning/dashboards/dashboards.yml | Grafana Dashboard 自动加载 |
| blackbox/blackbox.yml | 黑盒探测模块配置 |
| postgres-exporter/queries.yml | PG 自定义查询 |
| dingtalk/config.yml | 钉钉机器人配置 |
| dingtalk/template.tmpl | 钉钉消息模板 |

## 12. 已知问题

| 问题 | 容器 | 状态 | 说明 |
|------|------|------|------|
| AI分析调用失败 | ai-ops-ai-alert-bridge | ✅ 已修复 | OpenOcta API 不支持流式(501)，非流式长推理断连；已加重试+日志+精简prompt |
| Loki unhealthy | ai-ops-loki | 待修复 | 启动后 empty ring 错误，需等待 ring 初始化 |
| Promtail unhealthy | ai-ops-promtail | 待修复 | 依赖 loki 就绪 |
| Node-exporter partial | ai-ops-node-exporter | 可忽略 | systemd collector 报错 (容器内无 dbus socket)，不影响核心指标 |

## 相关文档

- [[ref-env-context]] - 运维环境上下文、连接方式
- [[ref-k8s-cluster]] - K8s 集群信息 (被监控的 K8s 节点)
- [[ref-database]] - 数据库详情 (PG exporter 监控目标)
- [[ref-service-call-chain]] - 服务调用关系 (被监控的业务服务)

> 返回导航: [[INDEX]]
