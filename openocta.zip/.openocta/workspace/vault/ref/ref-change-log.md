# 变更日志

> 🏷️ 环境归属: 179本机 + 180测试集群(ai-q, 172.17.3.180) + 81生产集群 | 最后更新: 2026-10-23 | 类型: 变更记录

## 2026-10-23 | 179本机 | 磁盘清理：containerd default命名空间82个镜像全清（回收97G）

- **变更内容**: `nerdctl rmi -f` 清空 containerd default 命名空间全部82个镜像（vllm 10.47G+8.67G、zhiman-pdfminer 12.89G、file-parser-api×6、synapse×8、prism×3等，合计57.5G未压缩+content blob），/data 398G(80%) → 301G(61%)，回收97G
- **清理前验证（Harbor副本核对）**: 通过 Registry v2 API（/v2/<repo>/tags/list + per-repo pull token，凭据取自/root/.docker/config.json）逐一核对82个镜像tag，Harbor 166仓库/7261个tag中全部82个tag均存在，**0个缺失**；default命名空间0容器，无任何本地引用（180/81集群直接从Harbor拉取，不经过本机default ns）
- **影响范围**: 无运行中容器受影响（moby命名空间32个Docker容器不受default ns清理影响）
- **验证结果**: ✅ default命名空间0镜像；containerd/docker服务active；Harbor全家桶/pdf2zh/open-webui/JumpServer等32个容器全部正常；/data 398G(80%)→301G(61%)
- **回滚方案**: 无需回滚（需要时 `nerdctl pull` 从本机Harbor重拉，秒级）
- **操作人**: 运维数字员工（用户确认"全清"）

## 2026-10-23 | 179本机 | 磁盘清理：Docker悬空镜像 + containerd k8s.io残留镜像（回收约19G）

- **变更内容**: /data 磁盘清理（417G/84% → 398G/80%）：① `docker image prune -f` 清除25个悬空镜像（回收6.46G，含pdf2zh重复构建残留1.57G×6）；② 删除9个两个月前退出的构建废容器（apt-get装gcc/nodejs失败残留，exit 100，随机命名）；③ `nerdctl -n k8s.io rmi` 清除14个K8s残留镜像（回收约13G）
- **确认依据（k8s.io镜像无引用）**: 179本机kubelet为not-found（无systemd单元、无日志），不在任何集群节点列表（kubectl指向180 ai-q集群，节点仅ai-q-master01/node01/node02）；k8s.io命名空间0容器；14个镜像均为旧tag（innies-biz 4.0.5/4.0.3、synapse 3.0.12/3.0.8、prism 3.0.6等，180集群现跑4.0.12/3.0.23/3.0.10等新tag），全部来自本机Harbor(172.17.3.179)可随时重拉
- **影响范围**: 无运行中容器受影响
- **验证结果**: ✅ docker悬空镜像0个；k8s.io命名空间0镜像；/data 417G(84%)→398G(80%)；Harbor全家桶/pdf2zh/open-webui等25个容器healthy（注：ai-ops-promtail/loki/node-exporter的unhealthy为清理前已存在的健康检查问题，与本次无关）
- **回滚方案**: 无需回滚（若179未来重新加入集群，kubelet会自动从本机Harbor重拉镜像）
- **后续机会**: containerd default命名空间（nerdctl）仍有82个镜像约90G、/data/harbor registry 109G可做GC、docker_images_export 7.5G待确认删除
- **操作人**: 运维数字员工（用户确认）

## 2026-10-10 | 镜像同步+部署 | synapse:3.0.23

- **变更内容**:按 PL-001 全流程同步镜像并部署升级 innies-stack (revision 57→58)
- **镜像变更**:synapse 3.0.20→3.0.23
- **配置变更**:无（仅镜像tag更新）
- **备份文件**:values.yaml.bak.202610101459（SOP-002 时间格式）
- **影响范围**:synapse Pod 滚动重启 1 个，其余子服务未受影响
- **验证结果**:✅ 1 Pod Running 1/1, 0 Restarts, 镜像 172.17.3.179/zhiman/yuwei/synapse:3.0.23 确认, 日志显示 SYNAPSE RAG SYSTEM READY
- **回滚方案**:helm rollback innies-stack 57 -n innies + cp /data/zhiman/innies/values.yaml.bak.202610101459 /data/zhiman/innies/values.yaml
- **操作人**:运维数字员工（用户确认）

## 2026-09-21 | 180测试集群 | Cilium MTU 修复（前端大文件传输超时）

- **变更内容**: Cilium ConfigMap 添加 `mtu: "1370"`，滚动重启 Cilium DaemonSet 3 个 Pod
- **根因**: 物理网络 MTU=1420（非标准 1500），Cilium VXLAN 隧道默认 MTU=1500 未显式配置，VXLAN 封装后包大小 1550 > 物理 MTU 1420，大包被丢弃。小请求（<1400B）正常，大文件（>1400B）传输超时
- **影响范围**: 全集群网络，Cilium Pod 逐个滚动重启（每个节点约 10-20s 短暂中断）
- **验证结果**: ✅ cilium_host/cilium_vxlan MTU=1370 生效；innies-fe 1.7MB JS 文件从超时(30s,0B) → 0.26s 返回完整 1718022B；前端页面正常加载
- **备份文件**: /tmp/cilium-config-backup.yaml
- **回滚方案**: kubectl patch cm cilium-config -n kube-system --type merge -p '{"data":{"mtu":null}}' && kubectl rollout restart ds cilium -n kube-system
- **操作人**: 运维数字员工（用户确认）

## 2026-09-20 | 180测试集群 | innies-fe 全流程更新（镜像同步+部署）

- **变更内容**: 按 PL-001 全流程同步镜像并部署升级 innies-stack (revision 56→57)
- **镜像变更**: innies-fe 2.0.79→2.0.80
- **配置变更**: 无（仅镜像tag更新）
- **备份文件**: values.yaml.bak.202609201807
- **影响范围**: innies-fe Pod 滚动重启 1 个，其余子服务未受影响
- **验证结果**: ✅ 1 Pod Running 1/1, 0 Restarts, 镜像 172.17.3.179/zhiman/yuwei/innies-fe:2.0.80 确认
- **回滚方案**: helm rollback innies-stack 56 -n innies + cp /data/zhiman/innies/values.yaml.bak.202609201807 /data/zhiman/innies/values.yaml
- **操作人**: 运维数字员工（用户确认）

## 2026-09-20 | 180测试集群 | file-parser-api 全流程更新（镜像同步+部署）

- **变更内容**: 按 PL-001 全流程同步镜像并部署升级 innies-stack (revision 55→56)
- **镜像变更**: file-parser-api 3.0.19→3.0.22
- **配置变更**: 无（仅镜像tag更新）
- **备份文件**: values.yaml.bak.202609201750
- **影响范围**: file-parser-api Pod 滚动重启 1 个，其余子服务未受影响
- **验证结果**: ✅ 1 Pod Running 1/1, 0 Restarts, 镜像 172.17.3.179/zhiman/yuwei/file-parser-api:3.0.22 确认
- **回滚方案**: helm rollback innies-stack 55 -n innies + cp /data/zhiman/innies/values.yaml.bak.202609201750 /data/zhiman/innies/values.yaml
- **操作人**: 运维数字员工（用户确认）

## 2026-09-20 | 180测试集群 | file-parser-api MinerU 批处理参数调整

- **变更内容**: 调整 file-parser-api 的 MinerU 批处理参数，解决大 PDF(381MB/32页)解析失败问题
- **配置变更**: PDF_ENGINES_MINERU_BATCH_THRESHOLD_MB 30.0→300.0（批次文件大小阈值，原值30MB过小导致176.7MB批次在客户端被拒绝未发送给MinerU）; PDF_ENGINES_MINERU_BATCH_SIZE 20→15（每批次页数）
- **根因**: 每批次20页=176.7MB，远超原阈值30.0MB，批次在file-parser-api客户端被拒绝，从未发送给MinerU（MinerU日志无POST请求记录）
- **备份文件**: values.yaml.bak.202609181700
- **影响范围**: file-parser-api Pod 重启（滚动更新），其他子服务不受影响
- **验证结果**: ✅ Pod Running 1/1，0 Restarts，BATCH_THRESHOLD_MB=300.0 BATCH_SIZE=15 确认生效
- **回滚方案**: helm rollback innies-stack 53 -n innies + cp values.yaml.bak.202609181700 values.yaml
- **操作人**: 运维数字员工

## 2026-09-18 | 180测试集群 | innies-stack file-parser-api/synapse 全流程更新（镜像同步+部署+配置变更）

- **变更内容**: 按 SOP-001 同步 2 个镜像到生产仓库，按 SOP-002 部署升级 innies-stack (revision 52→53)。同时调整 file-parser-api 内存限制和环境变量
- **镜像变更**: file-parser-api 3.0.17→3.0.19, synapse 3.0.18→3.0.20
- **配置变更**: file-parser-api 内存限制 2Gi→8Gi；环境变量 MAX_UPLOAD_SIZE_MB 500→1024, WORD_PARSER_MAX_DOCX_FILE_SIZE_MB 300→1024, WORD_PARSER_MAX_DOC_FILE_SIZE_MB 300→1024, EXCEL_PARSER_MAX_XLS_SIZE_MB 300→1024, PPT_PARSER_MAX_PPTX_FILE_SIZE_MB 300→1024, PPT_PARSER_MAX_PPT_FILE_SIZE_MB 300→1024, PDF_ENGINES_PDF_MAX_PDF_FILE_SIZE_MB 500→1024
- **备份文件**: values.yaml.bak.202609181451（内存+环境变量变更）, values.yaml.bak.202609181523（镜像tag变更）
- **影响范围**: file-parser-api 和 synapse 各滚动重启 1 个 Pod，其余子服务未受影响
- **验证结果**: ✅ 两个 Pod 均 1/1 Running, 0 Restarts，镜像版本 172.17.3.179/zhiman/yuwei/file-parser-api:3.0.19 和 172.17.3.179/zhiman/yuwei/synapse:3.0.20 确认正确，日志无 error/fatal
- **回滚方案**: helm rollback innies-stack 52 -n innies + cp /data/zhiman/innies/values.yaml.bak.202609181451 /data/zhiman/innies/values.yaml
- **操作人**: 运维数字员工

## 2026-09-16 | 180测试集群 | innies-stack 7服务全流程更新（镜像同步+部署）

- **变更内容**:按 SOP-001 批量同步 7 个镜像到生产仓库,按 SOP-002 部署升级 innies-stack (revision 50→51)
- **镜像变更**:innies-loom 3.0.15-fix-chat-concurrency→3.0.18, prism 3.0.8→3.0.10, synapse 3.0.15→3.0.18, innies-biz 4.0.8→4.0.12, crab-gateway 4.0.14→4.0.18, innies-fe 2.0.76→2.0.79, file-parser-api 3.0.15→3.0.17
- **配置变更**:无（仅镜像tag更新，无配置变更）
- **备份文件**:values.yaml.bak.202609161619（SOP-002 时间格式）
- **验证结果**:✅ 7 个 Pod 均 Running 1/1,零重启,镜像版本确认正确
- **异常处理**:innies-fe 拉取时遇 snapshot 300/fs 空目录问题，mkdir 补齐后成功；prism/file-parser-api 拉取卡住（layer waiting 8分钟无进展），kill+retry 后利用已缓存 layer 秒完成
- **回滚方案**:helm rollback innies-stack 50 -n innies + cp values.yaml.bak.202609161619 values.yaml
- **操作人**:运维数字员工（用户确认）

## 2026-09-16 | 81生产环境 | innies-stack values 预备变更（补齐synapse环境变量 + 7服务tag对齐180测试，⚠️ 未执行helm upgrade）

- **变更内容**：修改81生产 values 文件（/root/yuwei/charts/innies/innies.values.yaml），为后续生产升级做准备。①synapse extraEnv 补齐3个缺失变量：DATABASE_URL（3.0.15硬性要求，缺失会CrashLoopBackOff）、HYBRID_VECTOR_WEIGHT=0.5、HYBRID_BM25_WEIGHT=0.5；②7个服务镜像tag对齐180测试环境当前版本
- **镜像变更（仅values文件，未部署）**：prism 3.0.6→3.0.8, synapse 3.0.12→3.0.15, innies-fe 2.0.73→2.0.76, crab-gateway 4.0.8→4.0.14, innies-biz 4.0.2→4.0.8, innies-loom 3.0.13→3.0.15-fix-chat-concurrency, file-parser-api 3.0.13→3.0.15（innies-users 1.3.2、z8m 3.0.1 两边一致不变）
- **DATABASE_URL值**：postgresql://innies_user:***@pooler-postgres-cluster-prod-rw.data-layer-prod.svc.cluster.local.:5432/innies_biz（81用innies_user连接，与180的app用户不同；密码在values global.dataLayer.postgresql）
- **操作步骤**：①备份 cp innies.values.yaml → innies.values.202609161525.yaml ②sed按行号精确替换7个tag ③printf生成插入块+sed '249r'插入3个env到synapse extraEnv末尾 ④helm template验证渲染
- **验证结果**：✅ helm template渲染成功（45个K8s资源）；synapse Deployment确认包含HYBRID_VECTOR_WEIGHT/HYBRID_BM25_WEIGHT/DATABASE_URL；9个镜像tag渲染正确（172.17.3.81:5050/zhiman/yuwei/*）
- **前置对比结论**：file-parser-api 92个env两边完全对齐（含TEXT_PARSER_MD_DECODE_TIMEOUT_S=30、PDF_ENGINES_MINERU_OFFLINE_TIMEOUT_READ=1500.0等）；innies-biz env两边对齐（仅Z8M_WEBSITE/PDF2ZH_BASE_URL环境差异）；81的innies_biz表owner=innies_user且连接用户也是innies_user，180的表owner问题在81不存在
- **追加变更（同日）**：innies-biz replicaCount 3→1（DB迁移期间单副本避免冲突）、livenessProbe.initialDelaySeconds 2400→3600（40分钟→1小时，给34GB innies_biz迁移留余量）；periodSeconds 120、timeoutSeconds 20 不变
- **⚠️ 待办（部署前必做）**：①确认7个新tag镜像已同步到81本地registry(172.17.3.81:5050) ②执行helm upgrade innies-stack -n innies-prod ③部署后验证 ④部署后将innies-biz replicaCount改回3、initialDelaySeconds改回2400 ⑤更新本注册表tag
- **回滚方案**：cp /root/yuwei/charts/innies/innies.values.202609161525.yaml /root/yuwei/charts/innies/innies.values.yaml（未部署，恢复文件即可）
- **操作人**：运维数字员工（用户确认）

## 2026-09-14 | 180测试集群 | xinference 调度失败修复（CPU request 4→2）+ GPU资源信息勘误

- **变更内容**：xinference Deployment CPU request 4→2（limit 8 不变），解决 node02 CPU 超卖（requests 92.5%，29600m/32000m）导致 Insufficient cpu 无法调度的问题；GPU 请求不变（nvidia.com/gpucores=50, nvidia.com/gpumem-percentage=50）
- **背景**：xinference 长期 Pending，根因为 NodeSelector 锁定 ai-q-node02 + node02 CPU requests 仅剩 2.4 核 < 4 核需求；node01 CPU 富余但 GPU 被 embedding+reranker 各 50% 占满，无法接收
- **操作步骤**：kubectl patch deploy xinference -n llm --type=json -p='[{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/cpu","value":"2"}]'
- **影响范围**：仅 xinference 单 Pod（llm ns）滚动重建；node02 CPU request 净 +2 核
- **验证结果**：✅ Pod 调度至 ai-q-node02，hami bind-phase=success（GPU-7637341e，50% 切片），模型 bge-m3 加载完成，Ready 1/1
- **知识库勘误**：ref-resource.md v2 — 节点 GPU 物理数量以 HAMI 注册(hami.io/node-nvidia-register)为准，node01/node02 各 1 张 RTX3080(10GB)；capacity 中 nvidia.com/gpu=5 为 HAMI 上报虚值，无 Pod 使用；node02 GPU = zhiman-pdfminer(50%) + xinference(50%)，node01 GPU = infinity-vl-embedding(50%) + vllm-reranker(50%)，两节点均无 GPU 余量
- **回滚方案**：patch 将 CPU request 改回 4
- **操作人**：运维数字员工（用户确认）

## 2026-09-14 | 180测试集群 | zhiman-pdfminer 修复调度失败（添加 schedulerName: hami-scheduler）

- **变更内容**：zhiman-pdfminer Pod 长期 Pending 无法调度，根因为 Deployment 未指定 schedulerName: hami-scheduler，导致 default-scheduler 无法识别 HAMI GPU 资源（nvidia.com/gpucores、nvidia.com/gpumem-percentage）
- **操作步骤**：①values.yaml 添加 schedulerName: hami-scheduler ②Chart 模板 deployment.yaml 添加 schedulerName 渲染逻辑 ③重新 helm package + helm upgrade zhiman-pdfminer (rev 4→5)
- **影响范围**：仅 zhiman-pdfminer 1个 Pod（llm 命名空间），Pod 重建
- **验证结果**：✅ Pod Running 1/1，调度到 ai-q-node02，API 返回 HTTP 200
- **回滚方案**：values.yaml 删除 schedulerName 行 + helm rollback zhiman-pdfminer 4 -n llm
- **操作人**：运维数字员工

## 2026-09-08 | 180测试集群 | innies-stack prism/synapse ConfigMap 挂载补齐（对齐生产环境）

- **变更内容**：180测试环境 prism 和 synapse 缺少 ConfigMap 挂载（81生产环境有 innies-stack-prism-config 和 innies-stack-synapse-config），补齐后与生产对齐
- **操作步骤**：①从81生产导出 prism/synapse ConfigMap yaml ②在180创建同名 ConfigMap ③打 Helm 管理注解 ④values.yaml 中 prism.configMap.enabled 和 synapse.configMap.enabled 改为 true ⑤helm upgrade innies-stack (rev 50)
- **影响范围**：prism 和 synapse 各重启1个 Pod，ConfigMap 内容为空 `{}`
- **验证结果**：✅ 两个 Pod 均 Running，volume mount 已包含 config ConfigMap
- **回滚方案**：values.yaml 中两个 configMap.enabled 改回 false + helm rollback innies-stack 49
- **操作人**：运维数字员工

## 2026-09-08 | 180测试集群 | file-parser-api/innies-biz 移除多余 ConfigMap 挂载（对齐生产环境）

- **变更内容**：180测试环境 file-parser-api 和 innies-biz 多了 ConfigMap 挂载（81生产环境没有），移除后与生产对齐。file-parser-api 的 ConfigMap 导致 xlsx 解析失败（Excel size guard 报 NoneType.get 错误）
- **操作步骤**：①values.yaml 中 file-parser-api.configMap.enabled 和 innies-biz.configMap.enabled 改为 false ②helm upgrade innies-stack
- **影响范围**：file-parser-api 和 innies-biz 各重启1个 Pod
- **验证结果**：✅ xlsx 文件上传解析恢复正常
- **回滚方案**：values.yaml 中两个 configMap.enabled 改回 true + helm rollback
- **操作人**：运维数字员工

## 2026-09-07 | S3数据迁移 | 81生产S3物理文件迁移至180测试集群（622GB）

- **变更内容**：将81生产集群S3 bucket(innies-bucket-af7a9428)的244,840个对象(622GB)全量同步至180测试集群S3 bucket(innies-bucket-7ddde5a3)，并更新PG file表s3_bucket字段
- **执行方案**：方案C - rclone copy + NodePort（mc mirror SSH隧道方案因ContentLength mismatch失败，详见plan-s3-migrate-81-to-180 v5）
- **关键步骤**：①180创建NodePort(31900)暴露RGW ②81安装rclone配置两端remote ③rclone copy全量同步(10h29m, 613.530GiB, 223,999对象) ④验证对象数245,500 ⑤PG UPDATE 235,452条s3_bucket记录 ⑥前端预览验证通过
- **踩坑记录**：mc mirror SSH隧道multipart upload ContentLength mismatch(4次尝试均失败)；NodePort IPVS规则延迟生效(Connection refused约5分钟后恢复)；SSH隧道需用ClusterIP而非K8s DNS名
- **影响范围**：180 S3 bucket数据(新增244K对象)、PG innies_biz.file表(235,452条s3_bucket更新)
- **验证结果**：✅ 180 bucket对象数245,500(期望≈245,441)；PG file表全部235,456条指向180 bucket；前端历史文档PDF预览正常
- **回滚方案**：PG回滚 `UPDATE file SET s3_bucket = b.s3_bucket FROM file_s3_bucket_backup_20260904 b WHERE file.id = b.id;`
- **操作人**：运维数字员工（用户确认）
- **待清理**：180 NodePort svc rook-ceph-rgw-nodeport

## 2026-09-04 | 数据库维护 | 生产81 chunk_meta TOAST膨胀清理（Step1+Step2）+ autovacuum表级参数修正

- **变更内容**：生产81(innies_biz.public.chunk_meta) 处理TOAST膨胀（total 30GB/toast 27GB，对比180干净基线 toast 仅11GB）。执行两步：① ALTER TABLE 设置表级 autovacuum 参数（threshold=1000/scale=0.01，触发阈值从~54.9万降至~2.84万，治本）；② VACUUM (VERBOSE, ANALYZE)（移除主表4,148 + TOAST 2,496 个死元组，刷新统计）
- **背景**：chunk_meta 为 insert+delete 高发表（累计 delete 261万），autovacuum 默认 scale_factor=0.2 导致大表（274万行）永不触发，last_autovacuum 停留 2026-04-15（约5个月未自动清理）；6/29 曾膨胀 17.5GB 用 VACUUM FULL 处理（SOP 记录），本次为复发
- **影响范围**：仅 chunk_meta 表级参数（不影响其他表/服务）；VACUUM 在线操作不锁表
- **验证结果**：last_vacuum/last_analyze=2026-09-04 10:51 已更新；reloptions 6项参数生效；WAL增量~90MB；业务无感知
- **待办**：Step3 VACUUM (FULL, VERBOSE, ANALYZE) 由用户手动执行（预计1.5~2.5h、ACCESS EXCLUSIVE锁表、预计 toast 27GB→~11-13GB）
- **回滚方案**：ALTER TABLE chunk_meta RESET (autovacuum_vacuum_threshold, autovacuum_vacuum_scale_factor, autovacuum_analyze_threshold, autovacuum_analyze_scale_factor, autovacuum_vacuum_insert_threshold, autovacuum_vacuum_insert_scale_factor)
- **操作人**：运维数字员工（用户确认）

## 2026-08-21 | 镜像同步+部署 | innies-loom:3.0.15-fix-chat-concurrency, prism:3.0.8, synapse:3.0.15, innies-biz:4.0.8, crab-gateway:4.0.14, innies-fe:2.0.76, file-parser-api:3.0.15

- **变更内容**：按 PL-001 全流程执行，SOP-001 批量同步 7 个镜像到生产仓库，SOP-002 部署升级 innies-stack (revision 40→43)
- **镜像变更**：innies-loom 3.0.13→3.0.15-fix-chat-concurrency, prism 3.0.6→3.0.8, synapse 3.0.12→3.0.15, innies-biz 4.0.6-yw-fix→4.0.8, crab-gateway 4.0.8→4.0.14, innies-fe 2.0.73→2.0.76, file-parser-api 3.0.12→3.0.15
- **配置变更**：synapse 新增 DATABASE_URL 环境变量（3.0.15 版本新要求）；innies_biz 数据库 60 张表 owner 从 postgres 改为 app（修复迁移权限问题）
- **异常处理**：1) synapse 3.0.15 启动报错 "DATABASE_URL not set"，通过 values.yaml extraEnv 添加 DATABASE_URL 修复；2) innies-biz 4.0.8 迁移失败 "must be owner of table knowledge_base"，通过 ALTER TABLE ... OWNER TO app 修复全部 60 张表；3) innies-biz 迁移 advisory lock 被 zombie session(PID 1956449) 占用，kill pod 后 lock 释放，重启成功
- **备份文件**：values.yaml.bak.202608211106
- **验证结果**：✅ 7 个 Pod 均 Running 1/1，零重启，镜像版本确认正确
- **回滚方案**：helm rollback innies-stack 40 -n innies + cp /data/zhiman/innies/values.yaml.bak.202608211106 /data/zhiman/innies/values.yaml

## 2026-08-18 | ai-alert-bridge 修复 | AI 告警分析功能修复 + 输出格式优化

- **变更内容**：修复 ai-alert-bridge 调用 OpenOcta API 失败问题，优化 AI 分析输出格式适配钉钉
- **问题1**：非流式调用(stream=False)时 OpenOcta API 长推理导致 "Server disconnected without sending a response"
- **问题2**：尝试流式调用(stream=True)时 OpenOcta API 返回 501 Not Implemented（该端点不支持 SSE）
- **修复方案**：恢复非流式调用 + 增加重试机制(MAX_RETRIES=2) + 增加详细日志(请求/响应/耗时/状态码) + 增加连接断开/超时/HTTP错误的分类处理(4xx不重试)
- **格式优化**：精简 prompt，限制输出300字以内，禁止表格和代码块，改用 emoji+列表格式适配钉钉 Markdown
- **验证结果**：钉钉告警消息中 AI 分析正常输出，格式简洁可读
- **回滚方案**：回退 app.py 到修改前版本，docker compose up -d 重建容器

## 2026-08-17 | 镜像同步+部署 | innies-biz:4.0.6-yw-fix

- **变更内容**：按 PL-001 全流程执行，SOP-001 同步镜像到生产仓库，SOP-002 部署升级 innies-stack (revision→40)
- **镜像变更**：innies-biz 4.0.6→4.0.6-yw-fix
- **备份文件**：values.yaml.bak.202608171130
- **验证结果**：Pod Running 1/1，0 Restarts，镜像版本 172.17.3.179/zhiman/yuwei/innies-biz:4.0.6-yw-fix 确认正确，日志无 error/fatal，其他子服务未受影响
- **回滚方案**：helm rollback innies-stack 39 -n innies + cp /data/zhiman/innies/values.yaml.bak.202608171130 /data/zhiman/innies/values.yaml

## 2026-08-13 | 镜像同步+部署 | innies-biz:4.0.6

- **变更内容**：按 SOP-001 同步镜像到生产仓库，按 SOP-002 部署升级 innies-stack (revision→39)
- **镜像变更**：innies-biz 4.0.5→4.0.6
- **备份文件**：values.yaml.bak.202608131352
- **验证结果**：Pod Running 1/1，0 Restarts，镜像版本 172.17.3.179/zhiman/yuwei/innies-biz:4.0.6 确认正确
- **回滚方案**：helm rollback innies-stack 38 -n innies + cp /data/zhiman/innies/values.yaml.bak.202608131352 /data/zhiman/innies/values.yaml

## 2026-08-11 | 镜像同步+部署 | innies-loom:3.0.12, prism:3.0.6, synapse:3.0.12, innies-biz:4.0.5, crab-gateway:4.0.8, innies-fe:2.0.73, file-parser-api:3.0.12

- **变更内容**：按 SOP-001 批量同步 7 个镜像到生产仓库，按 SOP-002 部署升级 innies-stack (revision→33)
- **镜像变更**：innies-loom 3.0.7→3.0.12, prism 3.0.1→3.0.6, synapse 3.0.7→3.0.12, innies-biz 4.0.2→4.0.5, crab-gateway 4.0.3→4.0.8, innies-fe 2.0.69→2.0.73, file-parser-api 4.0.2→3.0.12
- **配置变更**：用户提前调整了环境变量；prism registry 路径从 zhiman/prism 修正为 zhiman/yuwei/prism（与 Harbor 实际镜像路径对齐，修复 ImagePullBackOff）
- **备份文件**：values.yaml.bak.202608111148（SOP-002 时间格式）
- **验证结果**：7 个 Pod 均 Running 1/1，镜像版本确认正确
- **回滚方案**：helm rollback innies-stack 31 -n innies + cp values.yaml.bak.202608111148 values.yaml

## 2026-08-06 | 监控体系增强 | ai-alert-bridge 上线 + K8s node-exporter 采集修复

- **ai-alert-bridge 上线**: 新增 AI 告警分析桥接服务(172.17.3.179:8070)，Alertmanager webhook 改指向该服务，调用 OpenOcta 数字员工 API 分析告警原因，合并原始告警+AI分析为一条钉钉消息（不再重复发原始告警）
- **Alertmanager 配置变更**: 两个 receiver(default/critical-channels)的 webhook URL 从 `http://172.17.47.137:8060/dingtalk/monitor/send` 改为 `http://172.17.3.179:8070/alert`
- **K8s node-exporter 采集修复**: 新增 k8s-node-exporter-180/27/28 三个 job，通过 K8s API Server Pod Proxy(https://172.17.3.180:6443/api/v1/namespaces/monitoring/pods/<pod>:9100/proxy/metrics)访问 DaemonSet Pod，解决 172.25.20.27/28 和 180 节点 Pod IP 网段不通的问题
- **Prometheus 配置变更**: 从 node-exporter job 中移除 K8s 节点的直连 target，改为独立 job 通过 API Server 代理

## 2026-08-05 | 镜像同步+部署 | innies-loom:3.0.7, synapse:3.0.7, innies-biz:4.0.2, crab-gateway:4.0.3, file-parser-api:4.0.2

- **变更内容**：按 SOP-001 批量同步 5 个镜像到生产仓库，按 SOP-002 部署升级 innies-stack
- **镜像变更**：innies-loom 3.0.8→3.0.7, synapse 3.0.8→3.0.7, innies-biz 4.0.3→4.0.2, crab-gateway 4.0.5→4.0.3, file-parser-api 4.0.3→4.0.2
- **验证结果**：5 个 Pod 均 Running，镜像版本确认正确
- **回滚方案**：helm rollback innies-stack {prev_revision} -n innies + cp values.yaml.bak 恢复 values

## 2026-08-04 | 180测试集群 | CoreDNS 增加 hosts 条目修复 LDAP 登录 DNS 解析失败

- **变更内容**：修改 kube-system/coredns ConfigMap，在 Corefile 中增加 hosts 插件，将 `dc.yuwei.com` 静态映射为 `172.17.2.201`，绕过集群内 DNS 对外部域名解析不稳定的问题
- **影响范围**：全部集群 Pod 的 DNS 解析（新增一条 hosts 规则，不影响其他域名解析，fallthrough 保证未匹配域名仍走 forward 链路）
- **原因**：innies-users(ferriskey) 使用 LDAP 认证连接 dc.yuwei.com:389，集群内 Pod 通过 CoreDNS forward /etc/resolv.conf 解析外部域名不稳定（间歇性 "failed to lookup address information: Name or service not known"），怀疑与之前 Cilium 异常后 DNS 转发链路不稳定有关
- **验证结果**：✅ 修改后 LDAP 登录(wangdd 账号)恢复正常，innies-users 日志不再报 DNS 解析失败
- **操作人**：运维数字员工 + 用户确认
- **回滚方案**：kubectl edit cm coredns -n kube-system，删除 hosts { ... } 块即可恢复原状

## 2026-07-21 | 镜像同步+部署 | innies-loom:3.0.8, synapse:3.0.8, innies-biz:4.0.3, crab-gateway:4.0.5, file-parser-api:4.0.3

- **变更内容**：按 SOP-001 批量同步 5 个镜像到生产仓库，按 SOP-002 部署升级 innies-stack (revision→30)
- **镜像变更**：innies-loom 2.x→3.0.8, synapse 3.0.2→3.0.8, innies-biz 3.x→4.0.3, crab-gateway 4.0.3→4.0.5, file-parser-api 3.x→4.0.3
- **配置变更**：file-parser-api extraEnv 全面更新（MINERU_SERVICE_URL 保持本地地址 http://zhiman-pdfminer.llm.svc.cluster.local:8000/file_parse，新增 PDF_ENGINES_MINERU_*、PPT/EXCEL/WORD_PARSER_*、MINERU_ENABLED 等环境变量）
- **备份文件**：values.yaml.bak.202607211316（SOP-002 时间格式）
- **验证结果**：5 个 Pod 均 Running 1/1，零重启，镜像版本确认正确
- **回滚方案**：helm rollback innies-stack 13 -n innies + cp values.yaml.bak.202607211316 values.yaml

## 2026-07-13 | 镜像同步 | zhiman-pdfminer:3.2.3 同步到生产仓库

- **变更内容**：按 SOP-001 同步 `harbor.pvg2.zhiman.tech/yuwei/zhiman-pdfminer:3.2.3` 到生产仓库
- **过程**：zm代理拉取 → tag → push zhiman项目 → 触发复制规则(execution_id=166) → Succeed → 清理zm代理镜像
- **异常处理**：首次 nerdctl pull 因 snapshot 416 空目录报 overlayfs "no such file or directory" 失败；重启 containerd 未修复，最终用 mkdir 补齐 fs 子目录后拉取成功
- **影响范围**：仅镜像同步，未涉及服务部署更新；containerd 重启导致 Docker 17容器短暂中断约2分钟
- **仅同步镜像**：不涉及服务部署，不更新 ref-service-deploy-registry 的 tag 列

## 2026-07-13 | 知识库 | P2 优化：文档新鲜度提醒 + k8s-cluster瘦身 + 故障排查拆分

- **变更内容**：知识库 workflow P2 优化（3项）
- **P2-5**：ref-env-context 增加「文档新鲜度检查」章节，列出6篇需定期检查的文档+一键扫描命令
- **P2-6**：ref-k8s-cluster 瘦身（219→132行，-40%），Service ClusterIP表+Ingress清单下沉到 ref-service-call-chain（111→189行），节点信息引用 ref-resource，ref-k8s-cluster 转为集群元数据+引用入口
- **P2-7**：sop-troubleshooting-runbook 拆分（373→202行，-46%），5类高频故障保留主runbook，7类低频运维场景拆至新建 sop-troubleshooting-extended(190行)，quickref 链接同步更新
- **INDEX更新**：新增 sop-troubleshooting-extended 条目，更新 ref-k8s-cluster/ref-service-call-chain 描述，依赖链补充 ref-k8s-cluster→5个REF + runbook→extended
- **影响范围**：6个文件修改+1个新文件，仅文档结构优化
- **验证结果**：✅ 全库40个wikilink，38个有效（2个BROKEN为既有脚本引用+模板占位符），INDEX文档完整性100%，零断链
- **回滚方案**：原文件均已备份为 .bak.20260713
- **操作人**：运维数字员工

## 2026-07-13 | 知识库 | P1 优化：Pipeline 补全闭环 + "必做"文案单点维护

- **变更内容**：知识库 workflow P1 优化（2项）
- **P1-1**：PL-001 编排表增加 Step 4（更新文档），失败策略=warn（非阻塞）；执行模式描述同步更新 step4；参数传递补充 step2→step4
- **P1-2**：以 sop-002「部署后必做」为权威版本，sop-001 和 PL-001 的重复全文替换为引用链接，消除三处措辞漂移风险
- **影响范围**：PL-001(v2.0→v2.1)、sop-001，仅文档结构优化，不涉及运行时环境
- **验证结果**：✅ PL-001 wikilink 全部有效零断链，"不可跳过"标记仅 sop-002 权威版保留
- **回滚方案**：原文件均已备份为 .bak.20260713
- **操作人**：运维数字员工

## 2026-07-13 | 知识库 | P0 优化：SOP-002 合并 + sop-helm-ops 去重

- **变更内容**：知识库 workflow 全局只读分析后执行 P0 优化（2项）
- **P0-1**：sop-002-k8s-rollout-quickref.md(85行) + sop-002-k8s-rollout.md(63行) 合并为单文件 sop-002-k8s-rollout.md(145行)，quickref 改为重定向桩
- **P0-2**：sop-helm-ops.md 中"部署后必做"段落（与 sop-002 重复）替换为引用链接，消除单点维护风险
- **引用更新**：INDEX.md(4处)、ref-env-context.md(1处)、sop-helm-ops.md(3处) 共 8 处链接从 quickref 改为 rollout
- **影响范围**：仅知识库文档结构，不涉及运行时环境
- **验证结果**：✅ 合并后文件 17 个 wikilink 全部有效，sop-helm-ops 13 个 wikilink 全部有效，零断链
- **回滚方案**：原文件均已备份为 .bak.20260713（sop-002-k8s-rollout.md.bak / sop-002-k8s-rollout-quickref.md.bak / sop-helm-ops.md.bak）
- **操作人**：运维数字员工

## 2026-07-13 | 180测试集群 | 知识库文档对齐修复（3项）

- **变更内容**：只读分析后发现3处文档与实际环境不一致，统一修复
- **修改1**：sop-helm-ops.md 第78行 pdfminer helm upgrade 命令路径修正（/data/zhiman/pdfminer/ → /data/zhiman/vllm/pdfminer/）
- **修改2**：ref-database.md 补充 file.s3_bucket 字段说明（innies-biz 不读取此字段，env S3_BUCKET 为权威源）
- **修改3**：sop-002-k8s-rollout-quickref.md + sop-002-k8s-rollout.md 备份模板统一为 `$(date +%Y%m%d%H%M%S)` 时间戳格式
- **影响范围**：仅知识库文档，不涉及运行时环境
- **回滚方案**：4个原文件均已备份为 .bak.20260713120000
- **操作人**：运维数字员工

## 2026-07-10 | 180测试集群 | innies-fe 升级 2.0.66→2.0.69

- **变更内容**：innies-fe 前端服务镜像升级，2.0.66 → 2.0.69
- **镜像同步**：通过 zm 代理拉取 harbor.pvg2.zhiman.tech/yuwei/innies-fe:2.0.69 → 本地 Harbor zhiman 项目 → 触发 zhiman-prod 复制规则同步到生产仓库
- **影响范围**：仅 innies-stack-innies-fe 1个Pod（前端静态服务），不影响其他子服务
- **操作步骤**：SOP-001镜像同步(8步) + SOP-002部署升级(备份values→改tag→helm upgrade→验证)
- **验证结果**：✅ Pod Running，镜像 172.17.3.179/zhiman/yuwei/innies-fe:2.0.69
- **Helm Revision**：27
- **回滚方案**：①恢复 values.yaml.bak + helm upgrade；②helm rollback innies-stack 26
- **操作人**：运维数字员工

## 2026-07-08 | 180测试集群 | Milvus InniesEmb schema变更

- **变更内容**：向innies_emb_459c6be7e638481aa05804d97f9b0070 collection添加segment_index字段(Int64,nullable=true)，创建INVERTED索引segment_index_index
- **影响范围**：仅innies_emb_459c6be7 collection（当前95条数据），不影响kb_格式collection
- **原因**：修复InniesEmb schema下chunk expansion查询报错(segment_index not exist)，使180与81生产环境schema一致
- **验证结果**：✅ chunk expansion不再报错，日志显示segment_index=Some(0) + segment_index_missing=false；BM25仍受partitionKey限制部分失效（与81一致）
- **操作人**：运维+用户确认
- **回滚方案**：Milvus DropField API删除segment_index字段和索引


---

## 变更日志条目模板

> 新增变更记录时，复制对应场景模板，替换 `<>` 占位符，插入到元数据头之后、首条记录之前。
> 变量值从 SOP 的变量采集表中获取。

### 场景一：部署更新（SOP-002 / PL-001 全流程或仅部署）

```markdown
## {DATE} | 镜像同步+部署 | {SVC_LIST}:{TAG_CHANGE}

- **变更内容**:按 SOP-001 批量同步 {POD_COUNT} 个镜像到生产仓库,按 SOP-002 部署升级 {HELM_RELEASE} (revision→{NEW_REV})
- **镜像变更**:{TAG_CHANGE}
- **配置变更**:{CONFIG_CHANGE}
- **备份文件**:{BACKUP_FILE}(SOP-002 时间格式)
- **验证结果**:✅ {POD_COUNT} 个 Pod 均 Running 1/1,零重启,镜像版本确认正确
- **回滚方案**:helm rollback {HELM_RELEASE} {PREV_REV} -n {NS} + cp {BACKUP_FILE} values.yaml
```

### 场景二：仅镜像同步（SOP-001 / PL-001 仅同步）

```markdown
## {DATE} | 镜像同步 | {IMAGE_NAME}:{TAG} 同步到生产仓库

- **变更内容**:按 SOP-001 同步 {IMAGE} 到生产仓库
- **过程**:zm代理拉取 → tag → push zhiman项目 → 触发复制规则(execution_id={EXECUTION_ID}) → Succeed → 清理zm代理镜像
- **异常处理**:{EXCEPTION}
- **影响范围**:仅镜像同步,未涉及服务部署更新
- **仅同步镜像**:不涉及服务部署,不更新 ref-service-deploy-registry 的 tag 列
```

### 场景三：知识库文档优化

```markdown
## {DATE} | 知识库 | {OPT_SUMMARY}

- **变更内容**:知识库 {OPT_LEVEL} 优化({ITEM_COUNT}项)
- **{OPT_ID}-1**:{DETAIL_1}
- **{OPT_ID}-2**:{DETAIL_2}
- **影响范围**:{AFFECTED_FILES}个文件修改{NEW_FILE_NOTE},仅文档结构优化
- **验证结果**:✅ {WIKILINK_TOTAL}个wikilink,{WIKILINK_VALID}个有效,{BROKEN_NOTE},INDEX文档完整性100%,零断链
- **回滚方案**:原文件均已备份为 .bak.{DATE}
- **操作人**:运维数字员工
```

### 场景四：基础设施/数据库变更

```markdown
## {DATE} | {ENV} | {CHANGE_SUMMARY}

- **变更内容**:{DETAIL}
- **影响范围**:{SCOPE}
- **原因**:{REASON}
- **验证结果**:✅ {VERIFY_DETAIL}
- **操作人**:{OPERATOR}
- **回滚方案**:{ROLLBACK}
```

> 提示：日期相同的多个变更可合并为一条记录，用子条目区分。
