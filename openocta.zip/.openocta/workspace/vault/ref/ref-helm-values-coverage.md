# Helm Values 覆盖度与配置管理盲区

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-06-30 | 类型: 只读参考
> doc_id: ref-helm-values-coverage v1 | tags: helm,values,config | depends: ref-k8s-cluster,ref-service-deploy-registry

## 一句话结论

**常规 helm upgrade 完全正常，现有 values 文件覆盖日常变更需求。**
盲区仅在灾难恢复/集群重建场景才会暴露：Operator 自动生成的 Secret 密码会随机重生成，OBC 动态 bucket 名后缀会变化。

---

## 正常 helm upgrade 可覆盖的配置

| 服务 | 配置项 | 来源文件 |
|------|--------|----------|
| innies-stack | S3 AK/SK/bucket/endpointUrl | values.yaml global.dataLayer.s3 |
| innies-stack | RMQ 用户名/密码/host/vhost | values.yaml global.dataLayer.rabbitmq |
| innies-stack | z8m PG密码/admin密码/secretKey | values.yaml z8m段 |
| innies-stack | innies-users admin密码 | values.yaml users段 |
| innies-stack | storageClassName | values.yaml 各组件 storage段 |
| innies-stack | 镜像版本/资源配额/副本数/环境变量 | values.yaml |
| milvus | S3 AK/SK/bucket | values.yaml externalS3 |
| milvus | storageClassName | values.yaml |
| milvus | 镜像版本/资源配额 | values.yaml |
| rabbitmq | storageClassName/容量/副本数/插件 | rabbitmq-cluster.yaml |
| cnpg | storageClassName/容量/实例数/镜像 | pg-cluster.yaml |
| vllm/infinity | storageClassName/镜像/资源 | values.yaml + pvc.yaml |
| rook-ceph | OSD设备映射/Ceph配置 | cluster-values.yaml |

---

## 无法通过 values 管理的盲区

### 盲区1: CNPG Operator 自动生成的认证 Secret

| Secret | 内容 | pg-cluster.yaml有? | 灾难恢复风险 |
|-------|------|-------------------|-------------|
| postgres-cluster-prod-app | app用户密码(rAPZVoE2...) | 无 | 重建->密码随机重生成->innies/z8m全挂 |
| postgres-cluster-prod-superuser | superuser密码(lnvgkzuX...) | 无 | 重建->密码变->运维无法登录 |
| postgres-cluster-prod-server | TLS证书 | 无 | CNPG自动轮换不影响 |
| postgres-cluster-prod-replication | 复制TLS | 无 | CNPG自动轮换不影响 |
| postgres-cluster-prod-ca | CA证书 | 无 | CNPG自动轮换不影响 |
| cnpg-webhook-cert | webhook TLS | 无 | CNPG operator自动 |

**关键影响链**：
innies的z8m/prism/biz/loom全部引用 app Secret 密码 ->
该密码硬编码到 innies values.yaml ->
CNPG重建后密码变 -> values中硬编码值失效 -> 服务全挂

### 盲区2: RabbitMQ Operator 自动生成的认证 Secret

| Secret | 内容 | yaml有? | 灾难恢复风险 |
|-------|------|--------|-------------|
| rabbitmq-cluster-prod-default-user | 随机用户名+密码 | 无 | 重建->用户名密码变 |
| rabbitmq-cluster-prod-erlang-cookie | erlang cookie | 无 | 重建->cookie变->节点无法加入 |
| webhook-server-cert | webhook TLS | 无 | RMQ operator自动 |

**补充**：innies实际用手动创建的 innies/innies123 用户和 synapse vhost，
不依赖 default-user Secret。但 vhost/user 权限绑定也不在任何 values 中。

### 盲区3: OBC 动态 bucket 名绑定

| OBC | 动态后缀 | 灾难恢复风险 |
|-----|---------|-------------|
| innies-bucket | -7ddde5a3-b4f3-4213-ae57-0ce457461be4 | OBC重建->后缀变->values硬编码bucket名失效 |
| milvus-bucket | -7476e10d-75ce-4fcf-9eaf-3efec58bbe68 | 同上 |

OBC创建后生成的AK/SK/bucket名被硬编码到innies/milvus values.yaml。
OBC重建后必须同步更新这些值。

### 盲区4: Rook-Ceph 存储资源定义(不在/data/zhiman下)

| 资源 | 说明 |
|------|------|
| CephObjectStore | RGW定义(metadataPool replicated=3 dataPool EC gateway) |
| CephBlockPool | failureDomain=host replicated size=2 |
| CephFilesystem | MDS配置 |
| StorageClass ceph-block/ceph-filesystem/ceph-bucket | CSI provisioner + Secret引用 |
| RGW CSI Secret | rook-csi-rbd-provisioner等CSI驱动认证 |

### 盲区5: TLS证书(全部Operator自动管理)

CNPG/RMQ/Cilium/HAMI/cert-manager的TLS证书全部由各Operator自动管理，
不需要values配置，也不需要手动干预。到期日监控见 [[ref-secret-cert]]。

### 盲区6: 独立PVC文件

vllm/infinity的PVC不在Helm values中，是独立kubectl apply：
| 文件 | PVC |
|------|-----|
| vllm/pvc.yaml | vllm-model-data(200Gi) + vllm-adapter-data(50Gi) |
| infinity/pvc.yaml | infinity-model-data(10Gi) |

PVC扩容需单独操作，不在helm upgrade管理范围。

---

## 覆盖度汇总

| 类别 | 数量 | values覆盖? | 日常升级风险 | 灾难恢复风险 |
|------|------|------------|-------------|-------------|
| 业务AK/SK/密码 | ~15 | 是(硬编码到values) | 无 | 中(OBC重建需同步) |
| Operator自动Secret | ~20 | 否 | 无 | 高(密码随机重生成) |
| OBC动态绑定 | 2 | 部分(硬编码但bucket名动态) | 无 | 高(后缀变化) |
| StorageClass/PVC | 25 | 部分(部分values部分独立yaml) | 无 | 低 |
| TLS证书 | ~8 | 否(Operator自动) | 无 | 无(自动轮换) |

---

## 建议改进方向

1. CNPG -> pg-cluster.yaml显式指定superuserSecretName+appSecretName，引用自定义Secret
2. RabbitMQ -> rabbitmq-cluster.yaml显式指定.spec.secret引用自定义Secret
3. Rook-Ceph -> 把CephObjectStore/CephBlockPool/StorageClass定义extract到独立yaml
4. OBC -> innies/milvus values中考虑用模板变量引用OBC Secret/CM，而非硬编码bucket名
5. PVC -> 将vllm/infinity PVC纳入Helm chart管理或至少在文档中标注为独立资源

---

## 相关文档

- [[sop-helm-ops]] - Helm升级操作命令
- [[ref-secret-cert]] - Secret/证书完整清单
- [[ref-storage]] - PVC/PV映射
- [[ref-ceph-storage]] - Ceph存储配置
- [[ref-change-log]] - 变更日志
- [[ref-k8s-cluster]] - 集群环境信息
- [[ref-service-deploy-registry]] - 服务部署方式注册表

> 返回导航: [[INDEX]]
