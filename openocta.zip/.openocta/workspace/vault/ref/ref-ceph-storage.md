# Ceph 存储状态监控

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-06-30 | 类型: 只读检查
> doc_id: ref-ceph-storage v1 | tags: ceph,storage,monitoring | depends: ref-k8s-cluster

## 1. 集群概况

| 项目 | 值 |
|------|-----|
| Ceph版本 | 19.2.2 |
| 总容量 | 100 TiB (5×HDD) |
| 已用/可用 | 252 GiB / 99 TiB (0.25%) |
| 存储副本 | 3 (size=3, min_size=1) |
| 集群健康 | HEALTH_WARN ⚠️ |
| Mon节点 | 3 (a,b,c quorum) |
| Mgr节点 | b(active), a(standby) |
| OSD | 5 up/5 in |
| RGW | 1 active (ceph-objectstore) |
| MDS | 1 active + 1 standby (cephfs) |

## 2. OSD 分布

| OSD | 所在节点 | 容量 | 已用 | 可用 | %USE | PGS |
|-----|---------|------|------|------|------|-----|
| osd.0 | ai-q-node02 | 15 TiB | 78 GiB | 14 TiB | 0.53% | 48 |
| osd.1 | ai-q-node02 | 15 TiB | 79 GiB | 14 TiB | 0.53% | 225 |
| osd.2 | ai-q-node02 | 15 TiB | 67 MiB | 15 TiB | 0.00% | 78 |
| osd.3 | ai-q-node02 | 15 TiB | 8.6 GiB | 15 TiB | 0.06% | 53 |
| osd.4 | ai-q-node01 | 41 TiB | 86 GiB | 41 TiB | 0.20% | 361 |

> ⚠️ osd.2 几乎没有数据(67MiB)，osd.1承载225个PG远超其他，PG分布不均衡

## 3. 当前告警 (HEALTH_WARN)

### 3.1 MON_DISK_LOW
- mon.a 所在节点磁盘剩余15%
- mon.a Pod运行在 ai-q-master01 (172.17.3.180)
- 节点根分区 98G已用78G (84%)
- mon数据目录 /var/lib/ceph/mon/ceph-a 仅66M（不是mon本身问题，是节点磁盘）
- **风险**: 根分区写满导致mon.a宕机，丢失quorum
- **建议**: 清理master01根分区(日志/缓存)或扩容根分区

### 3.2 PG_DEGRADED (3.5%数据降级)
- 2481/70656 对象降级 (3.511%)
- 105 PG active+undersized+degraded
- 221 PG undersized
- 原因: osd.2几乎空，无法承载足够副本，导致部分PG只有1-2个副本
- 数据暂无丢失风险(min_size=1)，但容灾能力下降

### 3.3 对象错位 (29.8% misplaced)
- 21063/70656 对象不在CRUSH算法期望的位置
- 43 PG active+clean+remapped
- 持续6天未完成恢复
- **原因**: osd.2加入后数据应该开始rebalance但似乎卡住

### 3.4 MGR Crash (1 daemon)
- ceph-mgr.b 在 2026-06-26 断言失败 (RefCountedObject nref!=0)
- 已有standby mgr.a 接管，不影响服务
- 可清理: ceph crash rm <id>

## 4. Pool 详情

| Pool | ID | PGs | 副本数 | 存储量 | 用途 |
|------|----|-----|--------|--------|------|
| ceph-blockpool | 1 | 32 | 3 | 77 GiB | RBD块存储(K8s PVC) |
| ceph-filesystem-data0 | 5 | - | 3 | - | CephFS数据 |
| ceph-filesystem-metadata | 3 | - | 3 | - | CephFS元数据 |
| ceph-objectstore.rgw.* | 2,4,6,7,8,9,10,11 | - | 3 | - | RGW对象存储 |

## 5. PG 状态分布

| PG状态 | 数量 | 说明 |
|--------|------|------|
| active+undersized | 116 | 副本不足但可读写 |
| active+clean | 97 | 正常 |
| active+undersized+degraded | 105 | 副本不足且有降级 |
| active+clean+remapped | 43 | 数据在迁移中 |
| **合计** | 361 | |

## 6. PVC 使用概况 (K8s侧)

| Namespace | PVC数量 | 总容量 | 主要用途 |
|-----------|---------|--------|----------|
| cnpg | 2 | 200Gi | PostgreSQL数据 |
| milvus | 13 | 1090Gi | etcd+Pulsar+Minio+logs |
| llm | 4 | 270Gi | 模型数据 |
| innies | 4 | 32Gi | 业务+Redis |
| rabbitmq | 2 | 40Gi | 消息队列 |
| **合计** | 25 | 1542Gi | |

## 7. 日常检查命令

```bash
# 集群健康
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph status

# OSD状态
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph osd df

# PG恢复进度
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph pg stat

# 详细告警
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph health detail

# crash列表
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph crash ls

# Pool容量
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph df detail

# mon磁盘空间(检查MON_DISK_LOW)
kubectl -n rook-ceph exec rook-ceph-mon-a-<pod> -c mon -- df -h
```

## 8. 修复操作日志

| 日期 | 操作 | 结果 |
|------|------|------|
| 2026-06-30 | 首次记录 | 发现3个WARN，osd.2空+PG不均衡，持续观察中 |

> K8s 层 PVC/PV/StorageClass 映射见 [[ref-storage]]

## 相关文档

- [[ref-k8s-cluster]] - 集群环境信息

> 返回导航: [[INDEX]]
