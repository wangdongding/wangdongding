# 运维环境上下文卡片

> 🏷️ 环境归属: 179本机 + 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-09-24 | 类型: 会话初始化必读
> doc_id: ref-env-context v2 | tags: environment,context,init,teleport | depends: 无

## 一句话结论

**会话开始时直接读取此文件，无需探测环境，0步即可定位。**

---

## 本机信息 (179)

| 项目 | 值 |
|------|----- |
| IP | 172.17.3.179 |
| 角色 | Harbor 镜像仓库 + JumpServer + LLM Dashboard + Teleport Auth/Proxy |
| kubectl | ✅ v1.29.9 (直连180集群) |
| Helm | ✅ v3.17.4 (直连180集群) |
| Harbor | 运行中 (9容器, healthy) |

> 详细集群信息见 [[ref-k8s-cluster]]

## 连接方式

| 方式 | 详情 | 优先使用 |
|------|------|---------|
| **kubectl 直连** | kubeconfig → /root/.kube/config, server: https://172.17.3.180:6443 | ⭐ **首选** |
| **Teleport SSH** | `tssh ai-q-180 "command"` (底层: ssh -F /var/lib/teleport/bot/openocta/ssh_config root@ai-q-180.innies) | ⭐ **SSH首选** |
| **直连 SSH (fallback)** | `ssh 172.17.3.180` | 仅 Teleport 故障时使用，需说明原因 |

> ⚠️ 查询类命令(kubectl get/helm status)在179直连执行。部署类命令(kubectl apply/helm upgrade)和文件操作需SSH到180，因yaml/values/tgz文件在180节点。
> ⚠️ **SSH连接优先使用Teleport**（提供凭据轮换、审计日志、加密存储）。直连SSH仅作为Teleport故障时的fallback。Teleport服务: `systemctl status teleport`(179/180), `systemctl status tbot`(179)
> ⚠️ **重要：tssh 不需要 tsh login！tbot systemd 服务自动管理机器身份证书，直接执行 `tssh ai-q-180 "command"` 即可。禁止执行 tsh login 或 tsh status 检查登录状态——tsh status 显示 Not logged in 是正常的，因为 tssh 走的是 tbot 机器身份，不是用户登录。**

## 常用路径 (180节点)

| 路径 | 用途 |
|------|------ |
| /data/zhiman/innies/ | innies 业务配置根目录 |
| /data/zhiman/innies/values.yaml | innies-stack Helm values |
| /data/zhiman/innies/pdf2zh/deployment.yaml | pdf2zh yaml 直部署 |
| /data/zhiman/vllm/values.yaml | vllm Helm values |
| /data/zhiman/xinference/values.yaml | xinference Helm values |
| /data/zhiman/milvus/values.yaml | milvus Helm values |
| /data/zhiman/infinity/values.yaml | infinity Helm values |

> 完整目录结构见 [[sop-helm-ops]] §2

## Harbor 仓库

| 项目 | 值 |
|------|----- |
| 地址 | 172.17.3.179 (不加 :80) |
| 镜像格式 | 172.17.3.179/kubernetes/<服务名>/<镜像名>:<tag> |

> 详细 Harbor 信息见 [[ref-harbor-infra]]

## 平台约束

| 约束 | 说明 |
|------|------ |
| **网络环境** | **⚠️ 所有环境均为纯内网环境，严禁执行任何涉及外网的操作（包括但不限于：apt/yum/pip install 联网下载、curl 外部URL、helm repo add 联网仓库、docker pull 外部镜像、git clone 外部仓库等）。所有镜像、依赖、包必须通过内网 Harbor(172.17.3.179) 或本地文件获取。内网地址（172.17.x.x）的操作是允许的，只有涉及外网/公网的才禁止。** |
| Bash 硬超时 | 10 秒，超时截断无返回 |
| 命令禁止换行 | Bash 命令不能包含换行符 |
| 等待类命令 | ❌ 禁止 rollout status --timeout>10s 等；改用轮询模式 |
| 读取vault文件 | ❌ read 工具会折叠长文件中间部分；✅ 优先用 `cli_vault.py slice` 精准提取行范围，或 `bash sed -n` 分段读取 |

## 知识库关键词映射

| 搜索关键词 | 实际文档 |
|-----------|--------- |
| 180集群 / 180 / ai-q | ref-k8s-cluster |
| 部署方式 / 服务注册 | ref-service-deploy-registry |
| 环境上下文 / 连接方式 | ref-env-context |
| 镜像同步 / Harbor同步 | sop-001-harbor-image-sync |
| 部署更新 / rollout | sop-002-k8s-rollout |
| 健康检查 / pod状态 | sop-003-service-check |
| 经验教训 / 常见问题 | ref-lessons-learned |
| vault读取 / vault搜索 | ref-vault-cli (⭐ 优先用 cli_vault.py slice/search 代替 read 工具) |
| Helm升级 / helm命令 | sop-helm-ops |

## 数据权威源映射

> 同一信息可能出现在多个文档中，以下标注**权威源**。变更时只需更新权威源，其他文档引用不复制。

| 信息类型 | 权威源文档 | 说明 |
|---------|-----------|------|
| PG 连接入口/ClusterIP | [[ref-database]] | ref-k8s-cluster 引用，不重复列 IP |
| Secret / 证书清单 | [[ref-secret-cert]] | ref-database 引用，不重复列 Secret |
| Harbor 配置 / 镜像格式 | [[ref-harbor-infra]] | ref-env-context / sop-helm-ops 引用 |
| Service ClusterIP / Port | [[ref-k8s-cluster]] | 集群网络信息权威源 |
| PVC / PV / StorageClass | [[ref-storage]] | ref-ceph-storage 引用 K8s 侧 PVC |
| Ceph 集群状态 / OSD / PG | [[ref-ceph-storage]] | ref-storage 引用 Ceph 侧状态 |
| 服务调用关系 / 流量路由 | [[ref-service-call-chain]] | 唯一记录流量拓扑的文档 |
| 服务部署方式 / tag | [[ref-service-deploy-registry]] | 部署前必查 |
| Helm Release / 升级命令 | [[sop-helm-ops]] | Helm 操作权威参考 |

## 文档新鲜度检查

> 会话初始化时快速扫描，超过 14 天未更新的文档需评估是否与实际环境对齐。

| 文档 | 最后更新 | 检查方法 |
|------|---------|---------|
| [[ref-k8s-cluster]] | 元数据头「最后更新」日期 | `grep '最后更新' vault/ref/ref-k8s-cluster.md` |
| [[ref-resource]] | 元数据头日期（静态快照） | 重大扩缩容后必须更新 |
| [[ref-secret-cert]] | 元数据头日期 | 证书到期日前需检查 |
| [[ref-ceph-storage]] | 元数据头日期 | Ceph 告警变化时更新 |
| [[ref-storage]] | 元数据头日期 | PVC/PV 变更时更新 |
| [[sop-troubleshooting-runbook]] | 元数据头日期 | 新增排查场景时更新 |

> 提示：用 `grep -rn '最后更新' vault/ --include='*.md'` 一键扫描全部文档日期。

> 返回导航: [[INDEX]]
