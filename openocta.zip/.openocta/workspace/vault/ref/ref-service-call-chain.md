# 服务调用关系链-流量路由

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-07-09 | 类型: 只读参考
> doc_id: ref-service-call-chain v2 | tags: service,routing,traffic,clusterip,ingress | depends: ref-k8s-cluster,ref-service-deploy-registry

## 外部流量入口

> 2026-06-30 重构后：所有域名 Ingress 已关闭，前端通过 IP:NodePort 访问

| 入口地址 | 路径 | 后端Service |
|---------|------|------------|
| http://172.17.3.180:31819/ | / | innies-fe [前端页面] |
| http://172.17.3.180:31819/api/v1 | /api/v1 | crab-gateway [API网关] |
| http://172.17.3.180:31819/aiagent | /aiagent | z8m(N8N) [工作流] |

> ~~aikb.yuwei.com~~ / ~~aiagent.yuwei.com~~ / ~~xinference.yuwei.com~~ / ~~vllm.yuwei.com~~ / ~~infinity.yuwei.com~~ — 域名 Ingress 已全部关闭
> LLM 模型服务(xinference/vllm/infinity)通过 Service 短名直连，不走 Ingress

### Ingress 资源清单

> 2026-06-30 重构后：所有域名Ingress已关闭，仅保留 direct Ingress（无host），前端通过 IP:NodePort 访问

| Ingress | 域名 | 后端Service | 路径 | TLS | 状态 |
|---------|------|------------|------|------|------|
| innies-stack-direct | *(无域名) | crab-gateway | /api/v1 | No | ✅ 活跃 |
| innies-stack-direct | *(无域名) | z8m | /aiagent | No | ✅ 活跃 |
| innies-stack-direct | *(无域名) | innies-fe | / | No | ✅ 活跃 |
| ~~innies-stack-ingress~~ | ~~aikb.yuwei.com~~ | ~~innies-fe + crab-gateway~~ | - | - | ❌ 已关闭 |
| ~~innies-stack-z8m~~ | ~~aiagent.yuwei.com~~ | ~~z8m~~ | - | - | ❌ 已关闭 |
| ~~xinference~~ | ~~xinference.yuwei.com~~ | ~~xinference~~ | - | - | ❌ 已关闭 |
| ~~vllm-ingress~~ | ~~vllm.yuwei.com~~ | ~~vllm-reranker~~ | - | - | ❌ 已关闭 |
| ~~infinity-ingress~~ | ~~infinity.yuwei.com~~ | ~~infinity-vl-embedding~~ | - | - | ❌ 已关闭 |

**前端访问方式**: `http://172.17.3.180:31819/`（IP + NodePort）
**内部服务调用**: Service 短名直连（不走 Ingress）
**跨集群连81模型**: Pod 通过81 Ingress 域名直达（DNS搜索域已去掉 yuwei.com，不再劫持）

## 内部调用关系链

### crab-gateway-3000 API入口

- innies-users-9002 [认证鉴权]
- synapse-9001 [RAG检索]
- prism-9003 [LLM调用]
- innies-biz-9004 [业务逻辑]
- innies-loom-9005 [Agent推理]
- S3-rgw [文件上传]

### innies-biz-9004 核心业务

- deployment-reloader-llm-80 [MinerU Pod重启管理]

- synapse-9001 [RAG检索]
- prism-9003 [LLM调用]
- innies-users-9002 [用户服务]
- z8m-5678 [工作流]
- deer-flow-backend-8000 [深度搜索]
- milvus-19530 [向量检索]
- redis-6379 [缓存]
- PG-pooler-rw [数据持久化-innies_biz]
- S3-rgw [文件读写]

### innies-loom-9005 Agent推理

- synapse-9001 [检索]
- prism-9003 [LLM]
- innies-biz-9004 [业务]
- z8m-5678 [工作流]
- deer-flow-backend-8000 [深度搜索]

### prism-9003 LLM调度

- innies-biz-9004 [模型管理+配额+文件服务]
- file-parser-api-5002 [文件解析]
- redis-6379 [缓存]
- PG-pooler-rw [数据持久化-prism]
- S3-rgw [文件处理]

### synapse-9001 RAG知识库

- rabbitmq-5672 [消息消费 queue-synapse_ingestion_queue]
- S3-rgw [文件入库]
- milvus-19530 [向量读写 DB-innies]

### file-parser-api-5002 文件解析

- zhiman-pdfminer-llm-8000 [MinerU/PDF解析]
- deployment-reloader-llm-80 [Pod重启管理]

### innies-users-9002 用户服务

- innies-biz-9004 [业务]
- redis-6379 [缓存]
- PG-pooler-rw [数据持久化-innies_users]

### z8m-N8N-5678 工作流引擎

- PG-pooler-rw [数据持久化-z8m]

## 消息队列流

- exchange: synapse_exchange
- routing_key: document.update
- queue: synapse_ingestion_queue
- 消费者: synapse
- 处理: 文件入库+向量化+存入milvus

## 数据存储关系

- PG-innies_biz <--- innies-biz, innies-users
- PG-innies_loom <--- innies-loom
- PG-innies_users <--- innies-users
- PG-prism <--- prism
- PG-z8m <--- z8m
- Redis <--- innies-biz, innies-users, prism
- Milvus-innies <--- synapse, innies-biz
- S3 Bucket <--- synapse, innies-biz, prism, crab-gateway
- RabbitMQ <--- synapse

## LLM调用链

> 2026-06-30 重构后：域名 Ingress 已关闭，LLM 服务通过 Service 短名直连

- prism --> xinference [模型管理+调度 via Service: xinference.llm:9997]
- prism --> vllm-reranker [重排模型 via Service: vllm-reranker.llm:8000]
- prism --> infinity-vl-embedding [向量模型 via Service: infinity-vl-embedding.llm:8000]
- 注: 6/29修复: llm表base_url已改为集群内Service地址
- 注: 跨集群连81模型仍通过81 Ingress域名直达（DNS搜索域已去掉yuwei.com）

## Service ClusterIP 清单

> 从 ref-k8s-cluster 下沉至此，与流量路由统一管理

### innies

| Service | ClusterIP | Port |
|---------|-----------|------|
| crab-gateway | 10.96.3.97 | 3000 |
| file-parser-api | 10.96.3.135 | 5002 |
| innies-biz | 10.96.0.243 | 9004 |
| innies-fe | 10.96.3.96 | 80 |
| innies-loom | 10.96.3.51 | 9005 |
| innies-users | 10.96.2.95 | 9002 |
| prism | 10.96.0.240 | 9003 |
| redis | Headless | 6379 |
| synapse | 10.96.3.98 | 9001/60001 |
| z8m | 10.96.1.48 | 5678 |
| deer-flow-backend | 10.96.2.214 | 8000 |
| deer-flow-frontend | 10.96.2.134 | 3000 |
| pdf2zh | 10.96.2.95 | 11008 |

### llm

| Service | ClusterIP | Port |
|---------|-----------|------|
| xinference | 10.96.3.56 | 9997 |
| vllm-reranker | 10.96.2.237 | 8000 |
| infinity-vl-embedding | 10.96.0.127 | 8000 |
| zhiman-pdfminer | 10.96.2.148 | 8000 |
| deployment-reloader | 10.96.3.232 | 80 |

### milvus

| Service | ClusterIP | Port |
|---------|-----------|------|
| milvus(主入口) | 10.96.0.186 | 19530/9091 |
| attu(NodePort:30800) | 10.96.3.201 | 3000 |
| milvus-minio | 10.96.2.191 | 9000 |
| milvus-etcd | 10.96.3.24 | 2379/2380 |

### cnpg(PG访问入口)

> 详见 [[ref-database]] §访问入口 — PG 连接信息的权威源

### rabbitmq

| Service | ClusterIP | Port |
|---------|-----------|------|
| rabbitmq-cluster-prod | 10.96.2.147 | 5672/15672 |
| rabbitmq-cluster-prod-nodes | Headless | 4369/25672 |

### rook-ceph(关键)

| Service | ClusterIP | Port |
|---------|-----------|------|
| rook-ceph-mgr-dashboard | 10.96.2.26 | 8443 |
| rook-ceph-rgw-ceph-objectstore | 10.96.1.58 | 80 |

## 相关文档

- [[ref-k8s-cluster]] - 集群环境信息
- [[ref-service-deploy-registry]] - 服务部署方式注册表

> 返回导航: [[INDEX]]
