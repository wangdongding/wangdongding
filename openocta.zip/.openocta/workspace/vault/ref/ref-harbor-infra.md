# 参考信息: Harbor 基础设施

> 🏷️ 环境归属: 179本机 | 最后更新: 2026-07-03 | 类型: 只读参考
> doc_id: ref-harbor-infra v1 | tags: harbor,infrastructure | depends: 无

## 环境变量

| 变量 | 值 | 说明 |
|------|-----|------|
| HARBOR | 172.17.3.179 | 本地 Harbor 地址（HTTP 默认80，不加 :80） |
| HARBOR_API | http://172.17.3.179/api/v2.0 | Harbor API 地址 |
| HARBOR_USER | admin | Harbor 管理员用户 |
| HARBOR_PASS | admin | Harbor 管理员密码 |
| PROXY_PROJECT | zm | 代理项目（拉取外部镜像入口） |
| TARGET_PROJECT | zhiman | 推送目标项目 |
| REPLICATION_POLICY_ID | 1 | 复制规则 ID（zhiman-prod） |

## 架构说明

- **本地 Harbor**: `172.17.3.179`，HTTP 协议默认80端口，地址中不写 :80
- **代理项目 zm**: 走代理拉取外部镜像，地址格式 `172.17.3.179/zm/<路径>`
- **目标项目 zhiman**: 推送目标，地址格式 `172.17.3.179/zhiman/<路径>`
- **复制规则 zhiman-prod**: policy_id=1，manual 触发，filter 匹配 `zhiman/*`，全量同步到生产仓库
- **远端接收格式**: `<远端项目>/<原始路径>`，如 `yuwei/zilliz/attu:v2.5.3`

## 依赖状态

- containerd certs.d: 已统一为 `172.17.3.179`（不带 :80）
- hosts.toml 和 config.toml 中 :80 已去掉
- nerdctl 可用，认证通过 certs.d 配置

## 镜像地址格式

- 代理拉取: `172.17.3.179/zm/<namespace>/<image>:<tag>`
- 推送目标: `172.17.3.179/zhiman/<namespace>/<image>:<tag>`
- 原始外部: `harbor.pvg2.zhiman.tech/<namespace>/<image>:<tag>`

## 注意事项

- 拉取外部镜像必须走 zm 代理，不能直接从原始地址拉取
- 复制规则是全量扫描，远端已有 artifact 自动跳过不重复传输
- 复制规则可能产生多个 execution ID（重复触发不影响结果）
> 返回导航: [[INDEX]]
