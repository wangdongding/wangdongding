# S3 物理文件迁移方案：81生产 → 180测试

> 🏷️ 环境归属: 180测试集群 + 81生产集群 | 日期: 2026-08-21 | 类型: 迁移方案
> doc_id: plan-s3-migrate-81-to-180 v5 | tags: migration,s3,ceph,rgw | depends: plan-migrate-81-to-180, ref-database, ref-ceph-storage
> v5变更: ✅ 迁移已完成。新增方案C(rclone+NodePort)为实际执行方案，记录mc mirror SSH隧道方案失败原因(ContentLength mismatch)、NodePort IPVS排坑过程、rclone成功执行结果、PG UPDATE完成、前端预览恢复
> v4变更: 实时数据验证(2026-09-04)、Ceph空间+PG降级确认、网络连通性实测(跨集群K8s网络隔离确认)、方案A/B对比+推荐方案B、PG UPDATE前备份表步骤、回滚方案更新
> v3变更: 补充PG UPDATE前备份表步骤、补充网络连通性分析(SSH跳板直连方案vs隧道方案)、更新实时数据(81对象数244840)、Ceph空间实时验证(2026-09-04)
> v2变更: 补充Ceph空间评估(实时数据验证)、修正mc mirror去掉--watch、补充RGW pool容量计算、补充81 S3凭据来源验证

---

## 一、问题背景

180集群已导入81生产的PG数据和Milvus数据（详见 [[plan-migrate-81-to-180]]），但**S3物理文件未同步**，导致：

- 前端点击历史文档（从81导入的）预览PDF失败 → 文件在180的S3 bucket中不存在
- 新上传的文档可以正常预览 → 新文件直接写入180的S3 bucket

### 根因分析

| 层面 | 现状 | 影响 |
|------|------|------|
| S3物理文件 | 81的bucket有244,840个对象(622GB)，180的bucket仅601个对象(714MB) | 历史文档的PDF/图片等文件在180上不存在 |
| PG file表s3_bucket字段 | 235,452条记录指向81的bucket名，仅4条指向180的bucket名 | 当前服务不读此字段，但数据不一致 |
| innies-biz环境变量 | S3_BUCKET=180的bucket名，S3_ENDPOINT_URL=180的RGW | 服务签名URL指向180的S3，但文件不在那里 |
| 其他服务(synapse/prism/crab-gateway) | 同上，均指向180的S3 | 同上 |

> **核心矛盾**：服务生成的签名URL指向180的S3 bucket，但历史文档的物理文件仍在81的S3 bucket中。
> **好消息**：所有服务的S3环境变量已正确指向180的bucket，**无需修改任何服务配置**，只需把物理文件搬过来即可。

---

## 二、环境信息确认（已从服务器采集）

### 81生产 S3 配置

| 项目 | 值 |
|------|-----|
| RGW Service | rook-ceph-rgw-ceph-objectstore.rook-ceph.svc (81集群内) |
| Bucket名 | innies-bucket-af7a9428-e13f-460b-9cf6-f89edaf9c6f3 |
| AccessKey | A9QW0BPS21TQELMW659R |
| SecretKey | W2hps4sBKBahKbKcMXnAzSMXPMXR4189b2Y0AgHl |
| 对象数量 | 244,840 |
| 数据大小 | 622 GB (668,505,595,904 bytes) |
| 来源 | values.yaml: /root/yuwei/charts/innies/innies.values.yaml → global.dataLayer.s3 |
| 来源 | CM: innies-bucket (ns: innies-prod) ✅ 已验证 |
| 来源 | Secret: innies-bucket (ns: innies-prod) ✅ 已验证 |

### 180测试 S3 配置

| 项目 | 值 |
|------|-----|
| RGW Service | rook-ceph-rgw-ceph-objectstore.rook-ceph.svc (180集群内) |
| Bucket名 | innies-bucket-7ddde5a3-b4f3-4213-ae57-0ce457461be4 |
| AccessKey | 3PTXJE31JDTYVI2DAS7N |
| SecretKey | KA5fpLKONvYwToLbibciJrzCcexHK8V1SdbzfCyC |
| 对象数量 | 601 |
| 数据大小 | 714 MB (748,544,000 bytes) |
| 来源 | CM: innies-bucket (ns: innies) ✅ 已验证 |
| 来源 | Secret: innies-bucket (ns: innies) ✅ 已验证 |
| innies-biz环境变量 | S3_BUCKET=innies-bucket-7ddde5a3-b4f3-4213-ae57-0ce457461be4 |
| innies-biz环境变量 | S3_ENDPOINT_URL=http://rook-ceph-rgw-ceph-objectstore.rook-ceph.svc.cluster.local. |
| innies-biz环境变量 | S3_ACCESS_KEY_ID=3PTXJE31JDTYVI2DAS7N |
| innies-biz环境变量 | S3_SECRET_ACCESS_KEY=KA5fpLKONvYwToLbibciJrzCcexHK8V1SdbzfCyC |

### 数据量对比

| 指标 | 81(生产) | 180(测试) | 差异 |
|------|----------|-----------|------|
| 对象数 | 244,840 | 601 | 244,239个对象缺失 |
| 数据量 | 622 GB | 714 MB | ~621 GB需迁移 |
| PG file表记录 | 235,452条指向81 bucket | 4条指向180 bucket | 235,448条s3_bucket不一致 |

---

## 三、迁移方案

### 方案选择：rclone copy + NodePort（✅ 实际执行方案）

> **为什么最终用rclone而不是mc mirror？**
> - mc mirror通过SSH隧道传输时，multipart upload出现ContentLength mismatch（声明16MB但实际只发送了2~8MB），无论读写哪端走隧道都会触发
> - mc mirror通过NodePort直连时，81端IPVS偶发"operation not permitted"导致源端读取中断，同样触发ContentLength mismatch
> - **rclone的优势**：rclone先读取数据到内存缓冲再写入，源端读取失败会重试而非发送不完整PUT；默认chunk size 5MB（mc默认16MB），更小粒度更可靠
> - rclone copy --progress提供实时进度，--retries自动重试失败对象

### ❌ mc mirror SSH隧道方案失败记录（2026-09-07）

| 尝试 | 方案 | 传输量 | 耗时 | 错误 |
|------|------|--------|------|------|
| 第1次 | 方案B: mc在81, 写走SSH隧道 | 3.23 GiB | 3m07s | ContentLength=16777216 Body=8536846 |
| 第2次 | 方案B: mc在81, --part-size 5M | 退出码1 | - | --part-size不是mc mirror有效参数 |
| 第3次 | 方案A: mc在180, 读走SSH隧道 | 8.10 GiB | 7m43s | ContentLength=16777216 Body=2663228 |
| 第4次 | mc在81, 写走NodePort | 3.02 GiB | 27s | dial tcp EPERM + ContentLength mismatch |

> **根因**：mc mirror采用流式传输（边读边写），源端读取中断时目标端PUT body不完整，RGW返回ContentLength mismatch。SSH隧道和IPVS偶发中断都会触发此问题。

### NodePort排坑记录（2026-09-07）

在180上创建NodePort暴露RGW时遇到IPVS规则不生效问题：

| 排查步骤 | 结果 |
|----------|------|
| 创建svc rook-ceph-rgw-nodeport (80:31900/TCP) | ✅ Endpoints: 10.0.2.130:80 |
| curl 172.17.3.180:31900 | ❌ Connection refused |
| iptables -t nat -L -n \| grep 31900 | 无规则（IPVS模式预期如此） |
| kube-proxy mode | ipvs |
| ipvsadm -Ln \| grep 31900 | ✅ 规则存在: TCP 172.17.3.180:31900 rr → 10.0.2.130:80 Masq |
| ipvsadm -Ln --stats -t 172.17.3.180:31900 | ❌ 所有计数器为0，IPVS未拦截数据包 |
| KUBE-FIREWALL / KUBE-PROXY-FIREWALL | 无阻断规则 |
| 其他NodePort (31819 ingress) | ✅ 正常工作 |

> **结论**：IPVS规则存在但未生效，原因未完全定位（可能与kube-proxy watch机制故障有关）。**后续NodePort自动恢复可用**（约30分钟后curl测试成功返回XML），推测kube-proxy完成了一次re-sync。

### ✅ 最终成功方案：rclone copy + NodePort（方案C）

| 对比项 | 方案A: SSH隧道 | 方案B: SSH跳板直连 | **方案C: rclone + NodePort** |
|--------|---------------|-------------------|---------------------------|
| 原理 | mc在180, 读写都走SSH隧道 | mc在81, 读直连写走SSH隧道 | **rclone在81, 读直连81 RGW, 写走NodePort直连180 RGW** |
| 数据流 | 81 RGW → SSH隧道 → 180 mc → 180 RGW | 81 RGW → 81 mc → SSH隧道 → 180 RGW | **81 RGW → 81 rclone → 物理网络 → 180 NodePort → 180 RGW** |
| 工具 | mc mirror | mc mirror | **rclone copy** |
| SSH隧道 | 需要 | 需要 | **不需要** |
| 传输可靠性 | ❌ ContentLength mismatch | ❌ ContentLength mismatch | **✅ 缓冲写入+自动重试** |
| 实测速度 | 17~24 MiB/s | 17~24 MiB/s | **~10 MiB/s（更稳定）** |
| 推荐度 | ⭐⭐ | ⭐⭐ | **⭐⭐⭐⭐⭐** |

### 迁移流程（方案C - 实际执行）

```
81 S3 bucket (innies-bucket-af7a9428...)
    ↓ [Step 1: 在180创建NodePort暴露RGW]
    ↓ [Step 2: 在81安装rclone并配置两端remote]
    ↓ [Step 3: 在81执行rclone copy全量同步]
180 S3 bucket (innies-bucket-7ddde5a3...)
    ↓ [Step 4: 验证对象数量]
    ↓ [Step 5: 清理NodePort + 备份PG file表 + 更新s3_bucket]
    ↓ [Step 6: 验证前端预览]
```

### 网络连通性分析（2026-09-04 实测）

> **关键发现**：81的RGW Service是ClusterIP(10.96.1.86)，仅81集群内可达，180无法直连。

| 连通路径 | 可达性 | 说明 |
|----------|--------|------|
| 180 → 81 节点IP(172.17.3.81/84) | ✅ 可达 | ping 0.3ms，SSH可登录 |
| 180 → 81 RGW ClusterIP(10.96.1.86) | ❌ 不可达 | 跨集群K8s网络不通，路由走网关 |
| 180 → 81 RGW PodIP(10.0.4.116:8080) | ❌ 不可达 | 跨集群Pod网络不通 |
| 81 集群内 → 81 RGW ClusterIP | ✅ 可达 | curl返回200 |
| 81 集群内 → 180 RGW ClusterIP | ❌ 不可达 | 同理，跨集群K8s网络不通 |
| **81 → 180 NodePort(172.17.3.180:31900)** | **✅ 可达** | **物理网络直连，无需SSH隧道** |

---

## 四、执行步骤

### Step 1: 在180创建NodePort暴露RGW（变更操作）

```bash
# SSH到180
ssh 172.17.3.180

# 创建NodePort Service（使用与原RGW Service相同的selector）
kubectl apply -f - <<EOF
apiVersion: v1
kind: Service
metadata:
  name: rook-ceph-rgw-nodeport
  namespace: rook-ceph
spec:
  type: NodePort
  selector:
    app: rook-ceph-rgw
    ceph_daemon_id: ceph-objectstore
    rgw: ceph-objectstore
    rook_cluster: rook-ceph
    rook_object_store: ceph-objectstore
  ports:
    - port: 80
      targetPort: 80
      nodePort: 31900
EOF

# 验证Service和Endpoints
kubectl get svc rook-ceph-rgw-nodeport -n rook-ceph
kubectl describe svc rook-ceph-rgw-nodeport -n rook-ceph | grep Endpoints

# ⚠️ IPVS模式NodePort可能延迟生效，从81验证连通性
# 在81上执行:
curl -s http://172.17.3.180:31900/ | head -5
# 期望返回XML格式的RGW响应，如果Connection refused则等待1~2分钟重试
```

> **IPVS排坑提示**：kube-proxy IPVS模式下新建NodePort可能不会立即生效（IPVS规则存在但计数器为0）。如果curl返回Connection refused，等待kube-proxy re-sync（约1~5分钟），或重启kube-proxy强制同步。

### Step 2: 在81安装rclone并配置两端remote

```bash
# SSH到81
ssh 172.17.3.81

# 安装rclone（内网有apt代理）
apt install -y rclone

# 配置81源端remote（集群内直连RGW ClusterIP）
rclone config create prod81-s3 s3 \
  provider=Other \
  endpoint=http://10.96.1.86:80 \
  access_key_id=A9QW0BPS21TQELMW659R \
  secret_access_key=W2hps4sBKBahKbKcMXnAzSMXPMXR4189b2Y0AgHl \
  no_check_bucket=true

# 配置180目标端remote（通过NodePort直连，无需SSH隧道）
rclone config create local180-s3 s3 \
  provider=Other \
  endpoint=http://172.17.3.180:31900 \
  access_key_id=3PTXJE31JDTYVI2DAS7N \
  secret_access_key=KA5fpLKONvYwToLbibciJrzCcexHK8V1SdbzfCyC \
  no_check_bucket=true

# 验证连通性
rclone lsl prod81-s3:innies-bucket-af7a9428-e13f-460b-9cf6-f89edaf9c6f3/ --max-depth 2 | head -5
echo test | rclone rcat local180-s3:innies-bucket-7ddde5a3-b4f3-4213-ae57-0ce457461be4/rclone-test.txt
rclone delete local180-s3:innies-bucket-7ddde5a3-b4f3-4213-ae57-0ce457461be4/rclone-test.txt
```

### Step 3: 执行rclone copy全量同步

```bash
# 在81上执行（后台运行，日志输出到文件）
nohup rclone copy \
  prod81-s3:innies-bucket-af7a9428-e13f-460b-9cf6-f89edaf9c6f3/ \
  local180-s3:innies-bucket-7ddde5a3-b4f3-4213-ae57-0ce457461be4/ \
  --progress \
  --transfers 4 \
  --retries 5 \
  --contimeout 60s \
  --timeout 300s \
  > /tmp/rclone-copy-$(date +%Y%m%d%H%M).log 2>&1 &

# 监控进度（实时查看日志）
tail -f /tmp/rclone-copy-*.log

# 或在180上定期检查对象数量
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- \
  radosgw-admin --rgw-zone=ceph-objectstore bucket stats \
  --bucket=innies-bucket-7ddde5a3-b4f3-4213-ae57-0ce457461be4 2>&1 | grep num_objects
```

> **rclone vs mc mirror关键区别**：
> - rclone copy：先读取数据到内存缓冲再写入，源端读取失败会重试，不会产生ContentLength mismatch
> - mc mirror：流式传输（边读边写），源端中断时目标端PUT body不完整
> - rclone默认chunk size 5MB（mc默认16MB），更小粒度更可靠
> - rclone --retries自动重试失败对象，mc mirror遇到错误直接跳过

> **实际执行结果（2026-09-07）**：
> - 传输量：613.530 GiB / 613.530 GiB, 100%
> - 传输对象：223,999（另有20,937个已存在对象被跳过）
> - 耗时：10h29m7.5s
> - 平均速度：~10 MiB/s

### Step 4: 验证S3对象同步完成

```bash
# 在180上通过radosgw-admin验证对象数量
kubectl -n rook-ceph exec deploy/rook-ceph-tools -- \
  radosgw-admin --rgw-zone=ceph-objectstore bucket stats \
  --bucket=innies-bucket-7ddde5a3-b4f3-4213-ae57-0ce457461be4 2>&1 | grep num_objects

# 期望：num_objects ≈ 244,840 + 601(原有) ≈ 245,441
# 实际结果：num_objects = 245,500 ✅
```

### Step 5: 清理NodePort + 备份PG file表 + 更新s3_bucket（变更操作）

```bash
# ① 清理临时NodePort（迁移完成后不再需要）
# 在180上执行:
kubectl delete svc rook-ceph-rgw-nodeport -n rook-ceph

# ② 连接PG
ssh 172.17.3.180
PRIMARY_POD=$(kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')

# ③ 先查看当前分布（确认）
kubectl exec -n cnpg $PRIMARY_POD -- psql -U postgres -d innies_biz -c \
  "SELECT s3_bucket, count(*) FROM file GROUP BY s3_bucket;"

# ④ ⚠️ 备份原值（UPDATE前必须执行！确保可精确回滚）
kubectl exec -n cnpg $PRIMARY_POD -- psql -U postgres -d innies_biz -c \
  "CREATE TABLE file_s3_bucket_backup_20260904 AS SELECT id, s3_bucket FROM file WHERE s3_bucket = 'innies-bucket-af7a9428-e13f-460b-9cf6-f89edaf9c6f3';"

# 确认备份行数（应≈235,452）
kubectl exec -n cnpg $PRIMARY_POD -- psql -U postgres -d innies_biz -c \
  "SELECT count(*) FROM file_s3_bucket_backup_20260904;"

# ⑤ 执行更新（将81的bucket名替换为180的bucket名）
# ⚠️ 235K行UPDATE约需5分钟，期间命令会卡在终端，属正常现象
kubectl exec -n cnpg $PRIMARY_POD -- psql -U postgres -d innies_biz -c \
  "UPDATE file SET s3_bucket = 'innies-bucket-7ddde5a3-b4f3-4213-ae57-0ce457461be4' WHERE s3_bucket = 'innies-bucket-af7a9428-e13f-460b-9cf6-f89edaf9c6f3';"

# ⑥ 验证更新结果
kubectl exec -n cnpg $PRIMARY_POD -- psql -U postgres -d innies_biz -c \
  "SELECT s3_bucket, count(*) FROM file GROUP BY s3_bucket;"
# 期望：所有记录的s3_bucket都指向180的bucket名
# 实际结果：235,456条全部指向180 bucket ✅
```

> **回滚命令**（仅在UPDATE出错时执行）：
> ```sql
> UPDATE file SET s3_bucket = b.s3_bucket
> FROM file_s3_bucket_backup_20260904 b
> WHERE file.id = b.id;
> ```

### Step 6: 验证前端预览功能

```bash
# 1. 检查innies-biz服务状态
kubectl get pods -n innies -l app.kubernetes.io/name=innies-biz
kubectl logs deploy/innies-stack-innies-biz -n innies --tail=20

# 2. 前端访问测试
curl -s -o /dev/null -w "%{http_code}" http://172.17.3.180:31819/

# 3. ⚠️ 关键验证：在前端点击一个历史文档（从81导入的），确认PDF预览正常
```

> **实际验证结果（2026-09-07）**：✅ 前端历史文档PDF预览恢复正常

---

## 五、回滚方案

| 场景 | 回滚方式 |
|------|----------|
| rclone copy中断 | 重新执行 `rclone copy`，已传输对象自动跳过（rclone检查size/modtime） |
| S3数据异常 | 180 bucket中通过rclone delete删除同步的对象（保留原有601个） |
| PG s3_bucket更新错误 | 从备份表精确恢复：`UPDATE file SET s3_bucket = b.s3_bucket FROM file_s3_bucket_backup_20260904 b WHERE file.id = b.id;` |
| NodePort异常 | 删除重建Service，或等待kube-proxy re-sync（IPVS模式可能延迟1~5分钟） |

---

## 六、风险与注意事项

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| 622GB数据传输耗时过长 | 高 | 迁移窗口长 | rclone copy支持断点续传；方案C无SSH隧道瓶颈 |
| 180 Ceph存储空间不足 | ~~中~~ **极低** | 同步失败 | ✅ 已验证：RGW pool可用93TiB，迁移仅需1.87TiB(含3副本)，占2% |
| NodePort IPVS延迟生效 | 中 | 迁移启动延迟 | 等待1~5分钟kube-proxy re-sync，或重启kube-proxy |
| 81端IPVS偶发EPERM | 低 | 个别对象读取失败 | rclone --retries自动重试，不影响整体迁移 |
| 同步期间81有新文件写入 | 低 | 180缺少最新文件 | 迁移窗口暂停81业务写入，或迁移后再做一次增量同步 |
| file表s3_bucket更新影响其他逻辑 | 低 | 未知功能异常 | 当前服务不读此字段，风险极低；已建备份表可精确回滚 |
| 180 Ceph HEALTH_WARN(PG降级14.9%) | 中 | 写入性能略降 | 当前osd.2几乎空导致PG不均衡，但不影响数据安全；迁移后观察Ceph恢复情况 |

### 前置检查：180 Ceph存储空间（✅ 已验证，空间充足）

> **2026-08-21 实时数据验证结果：**

| 指标 | 180(测试) | 81(生产) |
|------|-----------|----------|
| Ceph总容量 | 100 TiB (5×HDD) | 36 TiB |
| Ceph已用 | 563 GiB (0.55%) | 4.8 TiB (13.06%) |
| Ceph可用 | **99 TiB** | 32 TiB |
| RGW pool (ceph-objectstore.rgw.buckets.data) | 已用82GiB, **MAX AVAIL=93 TiB** | 已用1.2TiB, MAX AVAIL=19 TiB |

**空间评估：**

| 项目 | 值 |
|------|-----|
| 需迁移数据量 | 622 GB (innies-bucket) |
| Ceph副本数 | 3 |
| 实际Ceph存储占用 | 622 GB × 3 = **1.87 TiB** (含3副本) |
| RGW pool当前可用 | 93 TiB |
| 迁移后RGW pool使用率 | (82GiB+1.87TiB)/93TiB ≈ **2.1%** |
| 结论 | **✅ 空间完全充足，1.87TiB仅占93TiB的2%** |

> ⚠️ 注意：Ceph对象存储使用3副本，622GB数据实际占用1.87TiB原始空间。但RGW pool MAX AVAIL=93TiB，完全够用。

---

## 七、与现有迁移方案的关系

本方案是 [[plan-migrate-81-to-180]] 的**补充**，补齐了S3物理文件迁移这一缺失环节：

| 迁移项 | 方案 | 状态 |
|--------|------|------|
| PG数据 | pg_dump → scp → pg_restore | ✅ 已完成 |
| Milvus向量数据 | milvus-backup | ✅ 已完成 |
| **S3物理文件** | **rclone copy + NodePort** | **✅ 已完成（2026-09-07）** |
| PG file表s3_bucket修正 | SQL UPDATE | ✅ 已完成（2026-09-07） |

---

## 八、预估耗时

| 步骤 | 耗时 |
|------|------|
| Step 1: 创建NodePort | 2分钟（IPVS可能延迟1~5分钟生效） |
| Step 2: 安装rclone+配置remote | 5分钟 |
| Step 3: rclone copy全量同步 | **~10.5小时**（613GB，实测~10 MiB/s） |
| Step 4: 验证对象数 | 5分钟 |
| Step 5: 清理NodePort + PG UPDATE | 10分钟（UPDATE约5分钟） |
| Step 6: 验证前端预览 | 10分钟 |
| **合计** | **~11小时** |

> ⚠️ 实测耗时远超原预估（原预估2.5~7小时基于mc mirror+SSH隧道），主要因为rclone单线程传输速度较慢（~10 MiB/s vs mc mirror的17~24 MiB/s），但rclone传输更稳定可靠，无需反复重试。
> 建议在业务低峰期执行，rclone copy期间不影响180现有服务

---

## 九、方案完整性检查清单

> 以下所有项均已验证，方案可确保数据完整迁移、预览功能恢复。

| 检查项 | 状态 | 说明 |
|--------|------|------|
| 81 S3凭据正确性 | ✅ 已验证 | CM+Secret与plan记载一致，rclone可连通 |
| 180 S3凭据正确性 | ✅ 已验证 | CM+Secret与plan记载一致，rclone可连通 |
| 180 Ceph空间充足 | ✅ 已验证 | RGW pool可用93TiB，迁移仅需1.87TiB(含3副本) |
| 180所有服务S3环境变量指向正确 | ✅ 已验证 | innies-biz/synapse/prism/crab-gateway均指向180 bucket |
| S3物理文件迁移 | ✅ rclone copy完成 | 223,999对象+20,937跳过=244,936，613.530 GiB |
| 180 bucket对象数 | ✅ 245,500 | 期望≈245,441，实际略多（新上传文件） |
| PG file表s3_bucket修正 | ✅ SQL UPDATE完成 | 235,452条记录从81 bucket名→180 bucket名 |
| 前端预览恢复 | ✅ 已验证 | 历史文档PDF预览正常 |
| 无需修改服务配置 | ✅ 已确认 | 所有服务环境变量已正确，无需helm upgrade |
| 回滚方案 | ✅ 已覆盖 | rclone中断可重试、PG可反向UPDATE |
| NodePort已清理 | ⬜ 待清理 | 迁移完成后删除rook-ceph-rgw-nodeport |

### 预览恢复逻辑链

```
用户点击预览 → innies-biz生成签名URL(指向180 S3 bucket + 文件key)
  → 180 RGW查找文件 → [迁移前]文件不存在→404→预览失败
                      → [迁移后]文件存在→200→预览成功 ✅
```

---

## 十、经验教训

### 1. mc mirror不适合跨集群大文件迁移

mc mirror采用流式传输（边读边写），当源端读取因网络问题中断时，目标端PUT body不完整，RGW返回ContentLength mismatch。此问题在SSH隧道和IPVS环境下均会触发，且mc无有效重试机制。

**结论**：跨集群S3大文件迁移优先使用rclone，其缓冲写入+自动重试机制更可靠。

### 2. SSH隧道不适合大文件multipart upload

SSH隧道在传输大文件multipart upload时存在数据截断问题（Content-Length声明16MB但实际只传输2~8MB），无论读写哪端走隧道都会触发。622GB数据量级应避免使用SSH隧道。

**结论**：大文件迁移应使用NodePort/直连网络，避免SSH隧道。

### 3. IPVS模式NodePort可能延迟生效

kube-proxy IPVS模式下新建NodePort Service后，IPVS规则可能存在但未立即生效（计数器为0，Connection refused）。需等待kube-proxy re-sync（1~5分钟），或重启kube-proxy强制同步。

**结论**：创建NodePort后不要立即使用，先验证curl连通性。

### 4. SSH隧道DNS解析问题

SSH隧道 `-L port:svc-name:80` 中的K8s Service DNS名（如rook-ceph-rgw-ceph-objectstore.rook-ceph.svc）在目标主机上无法解析，需改用ClusterIP。

**结论**：SSH端口转发始终使用ClusterIP而非DNS名。

> **结论**：只要 Step 2 (mc mirror) 把 81 的 244,501 个对象同步到 180 的 bucket，预览即可恢复。Step 5 (s3_bucket UPDATE) 是数据一致性修正，当前服务不读此字段，但为防未来代码重构触发 404，建议一并执行。

---

> 📎 导航: [[INDEX]] | [[plan-migrate-81-to-180]] | [[ref-database]] | [[ref-ceph-storage]]
