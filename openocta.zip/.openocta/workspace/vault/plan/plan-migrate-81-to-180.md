# 生产环境(81) → 测试环境(180) 数据迁移方案

> 🏷️ 环境归属: 179本机 + 180测试集群 + 81生产集群 | 日期: 2026-08-19 | 类型: 迁移方案
> doc_id: plan-migrate-81-to-180 v3 | tags: migration,pg,milvus,backup | depends: ref-database,ref-resource,ref-innies-milvus-arch
> v3变更: 修正PG Pod名硬编码(改用动态primary定位)、补充180 PG备份步骤、补充file表s3_bucket字段风险、补充CNPG managedDB冲突风险、修正Milvus API localhost→Service地址、补充kb_ collection迁移说明

---

## 一、环境信息摘要

### PostgreSQL (CNPG)

| 指标 | 180(测试) | 81(生产) | 差异 |
|------|-----------|----------|------|
| 实例数 | 2(主备) | 3(一主二备) | - |
| PG版本 | 17.4 | 17.4 | 一致 |
| Pooler ClusterIP | 10.96.0.149:5432 | 10.96.0.150:5432 | - |
| 直连RW ClusterIP | 10.96.2.247:5432 | 10.96.0.205:5432 | - |
| App用户密码 | rAPZVoE2... | 519F5vNa... | 不同 |
| Superuser密码 | lnvgkzuX... | 无superuser secret | - |
| 存储 | 100Gi/实例 | 100Gi/实例 | 一致 |
| PG内存限制 | 无显式限制 | 无显式限制 | 一致 |

#### PG数据库大小对比

| 数据库名 | 180(测试) | 81(生产) | 差异 |
|----------|-----------|----------|------|
| innies_biz | 1,857 MB | 34,000 MB | **+32.1 GB (18.3x)** |
| proxymeter | 不存在 | 746 MB | 81独有 |
| innies_users | 348 MB | 399 MB | +51 MB |
| innies_loom | 333 MB | 393 MB | +60 MB |
| superset | 不存在 | 61 MB | 81独有 |
| z8m | 11 MB | 12 MB | +1 MB |
| innies | 不存在 | 7,547 bytes | 81独有 |
| prism | 7,547 bytes | 7,547 bytes | 一致 |
| synapse | 7,393 bytes | 不存在 | 180独有 |
| app | 7,491 bytes | 7,491 bytes | 一致 |
| postgres | 7,491 bytes | 7,491 bytes | 一致 |
| **合计** | **~2.55 GB** | **~35.6 GB** | **+33 GB (14x)** |

### Milvus

| 指标 | 180(测试) | 81(生产) | 差异 |
|------|-----------|----------|------|
| 版本 | v2.6.15 | v2.6.15 | 一致 |
| Collection数 | 158 | 158 | 一致 |
| innies_emb_459c6be7 | 898 entities | 2,607,989 entities | **2,904x** |
| innies_emb_781d2496 | 0 entities | 0 entities | 一致 |
| kb_ collections | 175,127(33个非空) | 未全量统计 | 用户将删除180的kb_ |
| S3 Bucket大小 | 35 GiB / 11,348 objects | 52 GiB / 12,977 objects | +17 GiB |
| QueryNode资源 | 1C/2Gi Req, 4C/16Gi Lim | 4C/64Gi Req, 8C/128Gi Lim | **差距巨大** |
| QueryNode所在节点 | node01 | node02 | - |

#### S3/MinIO 配置

| 指标 | 180(测试) | 81(生产) |
|------|-----------|----------|
| RGW地址 | 10.96.1.58:80 | 10.96.1.86:80 |
| AccessKey | 995CBSBEFDCJLFFKW35S | XVKLJ0B08JVT90ZTGYQM |
| SecretKey | 6B7Igjj2m9Qqme275VA7S2HwRbXYHnABsQEfNakH | kbMCEUt0Be8D1RoAjNiXvHxaJkxYCD4LIcQh0jY8 |
| Bucket | milvus-bucket-7476e10d-75ce-4fcf-9eaf-3efec58bbe68 | milvus-bucket-aec4dbd6-4d5e-4aa7-b88a-442b3e3cd901 |
| mc alias | dstrgw | milvusminio |

#### milvus-backup 工具

| 指标 | 180 | 81 |
|------|------|-----|
| 版本 | v0.5.16 | v0.5.16 |
| 路径 | /usr/local/milvus-backup/ | /usr/local/milvus-backup/ |
| 配置文件 | ceshi-backup.yaml(备份用), restore.yaml(恢复用) | milvus-backup20260630.yaml |
| 已有备份 | milvus_prod_2510_upgrade_20260629, milvus_prod_260630_upgrade_20260630 | milvus_prod_260630_upgrade_20260630 |
| 上次恢复耗时 | ~50分钟(2990秒) | - |

---

## 二、资源评估 — 内存够不够用？

### 180集群节点内存现状

| 节点 | 总内存 | 已Request | 已Limit | 可用(Request维度) |
|------|--------|-----------|---------|-------------------|
| ai-q-master01 | 15.5 Gi | 2,310 Mi (14%) | 5,706 Mi (35%) | ~13.2 Gi |
| ai-q-node01 | 125 Gi | 43,488 Mi (33%) | 128,742 Mi (100%) | ~84 Gi |
| ai-q-node02 | 125 Gi | 64,606 Mi (50%) | 141,168 Mi (110%) | ~63 Gi |
| **合计** | **265 Gi** | **~108 Gi (40%)** | **~269 Gi (101%)** | **~160 Gi** |

### 迁移后内存需求预估

| 组件 | 当前180 Req | 迁移后需要 Req | 增量 | 说明 |
|------|-------------|---------------|------|------|
| Milvus QueryNode | 2 Gi | 32~64 Gi | +30~62 Gi | 2.6M条向量+HNSW索引，预估实际占用20~25Gi |
| Milvus DataNode | 1 Gi | 4 Gi | +3 Gi | 对齐81配置 |
| Milvus StreamingNode | 1 Gi | 8 Gi | +7 Gi | 对齐81配置 |
| PG实例(无显式限制) | 0 | 0 | ~8~16 Gi(动态) | shared_buffers+work_mem随数据量增长 |
| **合计增量** | - | - | **+48~88 Gi** | - |

### 结论

| 场景 | 迁移后总Request | 剩余可用 | 评估 |
|------|----------------|----------|------|
| 保守(QueryNode=64Gi) | ~170 Gi | ~95 Gi | ✅ 够用，但偏紧 |
| 推荐(QueryNode=32Gi) | ~138 Gi | ~127 Gi | ✅ 够用，有缓冲 |

> **结论：180集群内存足够承载81生产数据迁移。** 建议QueryNode设为32Gi Req/64Gi Lim（实际数据约20~25Gi，32Gi Request留有余量）。如需完全对齐81配置(64Gi/128Gi)也可行，但节点会偏紧。

---

## 三、前置准备

### 3.1 工具确认

| 工具 | 位置 | 状态 |
|------|------|------|
| milvus-backup v0.5.16 | 180: /usr/local/milvus-backup/ | ✅ |
| milvus-backup v0.5.16 | 81: /usr/local/milvus-backup/ | ✅ |
| mc (MinIO Client) | 180 & 81 均有 | ✅ |
| kubectl | 179(直连180), 81(直连81集群) | ✅ |
| pg_dump/restore | PG Pod内自带(PG 17.4) | ✅ |

### 3.2 凭据清单

| 凭据 | 180 | 81 |
|------|------|-----|
| PG app用户密码 | rAPZVoE2IlfyT08dbqJ4hnIyEc96hJAX3zHmmOi7do7MKqWQwQUWvlsQyKJjTRT0 | 519F5vNaSG4Td3glFULQdpoORsWoHpEGFNh8zGnTWqlJ5A3lGhmvDcglxY2fZXQp |
| PG superuser密码 | lnvgkzuX1Xx8OmHEVODz9mVZs3CIZTMGEmEiyxavgn0cl8QexGUFEbYs52Odv5m0 | 无superuser secret |
| S3 AccessKey | 995CBSBEFDCJLFFKW35S | XVKLJ0B08JVT90ZTGYQM |
| S3 SecretKey | 6B7Igjj2m9Qqme275VA7S2HwRbXYHnABsQEfNakH | kbMCEUt0Be8D1RoAjNiXvHxaJkxYCD4LIcQh0jY8 |

### 3.3 前置操作（变更类，需确认后执行）

1. **扩大180 PG存储**（可选）：当前100Gi/实例，迁移后数据约35GB，空间足够，无需扩容
2. **准备备份目录**：确保180和81的 /tmp 或 /data 有足够空间存放PG dump文件（至少40GB）
3. **通知业务侧暂停写入**（迁移窗口期间）

---

## 四、PG迁移方案

### 方案选择：pg_dump → scp → pg_restore

> 81 PG总量~35.6GB，pg_dump预计耗时30~60分钟，scp传输10~20分钟，pg_restore 30~60分钟。
> 总预估耗时：1.5~2.5小时

### Step 1: 在81上导出数据库（只读操作）

```bash
# SSH到81，在PG primary Pod中执行pg_dump
ssh 172.17.3.81

# 确认primary节点（role=primary的pod）
kubectl get pods -n data-layer-prod -l cnpg.io/cluster=postgres-cluster-prod -L role

# 设置primary Pod名变量（动态获取，避免硬编码）
PRIMARY_POD=$(kubectl get pods -n data-layer-prod -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')
echo "Primary Pod: $PRIMARY_POD"

# 导出所有业务数据库（在primary pod中执行）
# innies_biz (34GB - 最大的库)
kubectl exec -n data-layer-prod $PRIMARY_POD -- pg_dump \
  -U app -d innies_biz -F c -f /tmp/innies_biz.dump

# 其他库
kubectl exec -n data-layer-prod $PRIMARY_POD -- pg_dump \
  -U app -d innies_users -F c -f /tmp/innies_users.dump

kubectl exec -n data-layer-prod $PRIMARY_POD -- pg_dump \
  -U app -d innies_loom -F c -f /tmp/innies_loom.dump

kubectl exec -n data-layer-prod $PRIMARY_POD -- pg_dump \
  -U app -d z8m -F c -f /tmp/z8m.dump

kubectl exec -n data-layer-prod $PRIMARY_POD -- pg_dump \
  -U app -d prism -F c -f /tmp/prism.dump

# 81独有数据库
kubectl exec -n data-layer-prod $PRIMARY_POD -- pg_dump \
  -U app -d proxymeter -F c -f /tmp/proxymeter.dump

kubectl exec -n data-layer-prod $PRIMARY_POD -- pg_dump \
  -U app -d superset -F c -f /tmp/superset.dump

kubectl exec -n data-layer-prod $PRIMARY_POD -- pg_dump \
  -U app -d innies -F c -f /tmp/innies.dump
```

### Step 2: 将dump文件从Pod拷到81主机

```bash
# 在81上执行
PRIMARY_POD=$(kubectl get pods -n data-layer-prod -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')
for db in innies_biz innies_users innies_loom z8m prism proxymeter superset innies; do
  kubectl cp data-layer-prod/${PRIMARY_POD}:/tmp/${db}.dump /tmp/${db}.dump
done
```

### Step 3: 传输dump文件从81到180

```bash
# 在179或180上执行，从81拉取
scp 172.17.3.81:/tmp/*.dump /tmp/

# 再推到180（如果从179执行）
scp /tmp/*.dump 172.17.3.180:/tmp/
```

### Step 4: 在180上导入数据库（变更操作，需确认）

> ⚠️ **前置：先备份180现有PG数据**（回滚保险，数据量小~2.5GB，耗时短）
> ```bash
> # 在180上备份现有数据（在pg_restore之前执行）
> PRIMARY_POD=$(kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')
> for db in innies_biz innies_users innies_loom z8m prism; do
>   kubectl exec -n cnpg $PRIMARY_POD -- pg_dump -U app -d ${db} -F c -f /tmp/${db}_pre_migrate.dump
> done
> # 拷贝到主机保存
> for db in innies_biz innies_users innies_loom z8m prism; do
>   kubectl cp cnpg/${PRIMARY_POD}:/tmp/${db}_pre_migrate.dump /data/backup_pg_pre_migrate/${db}.dump
> done
> ```

```bash
# SSH到180
ssh 172.17.3.180

# 动态获取primary Pod名
PRIMARY_POD=$(kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')
echo "Primary Pod: $PRIMARY_POD"

# 将dump文件拷入PG Pod
for db in innies_biz innies_users innies_loom z8m prism proxymeter superset innies; do
  kubectl cp /tmp/${db}.dump cnpg/${PRIMARY_POD}:/tmp/${db}.dump
done

# 创建81独有的数据库（180不存在的库）
# ⚠️ 注意：如果180的CNPG cluster spec中managedDatabase列表包含这些库名，
# operator可能自动管理这些库，需先检查: kubectl get cluster -n cnpg postgres-cluster-prod -o yaml | grep -A20 managedDatabases
kubectl exec -n cnpg $PRIMARY_POD -- psql -U app -c "CREATE DATABASE proxymeter;"
kubectl exec -n cnpg $PRIMARY_POD -- psql -U app -c "CREATE DATABASE superset;"
kubectl exec -n cnpg $PRIMARY_POD -- psql -U app -c "CREATE DATABASE innies;"

# 恢复数据（先删后导，确保干净）
# ⚠️ 以下操作会覆盖180现有数据，确认后执行

# innies_biz（最大，34GB，预计30~60分钟）
kubectl exec -n cnpg $PRIMARY_POD -- pg_restore \
  -U app -d innies_biz --clean --if-exists /tmp/innies_biz.dump

# 其他库
for db in innies_users innies_loom z8m prism proxymeter superset innies; do
  kubectl exec -n cnpg $PRIMARY_POD -- pg_restore \
    -U app -d ${db} --clean --if-exists /tmp/${db}.dump
done
```

### Step 5: 验证PG数据

```bash
# 在180上验证各库大小
PRIMARY_POD=$(kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')
kubectl exec -n cnpg $PRIMARY_POD -- psql -U app -c "SELECT datname, pg_size_pretty(pg_database_size(datname)) as size FROM pg_database WHERE datistemplate = false ORDER BY pg_database_size(datname) DESC;"
```

> ⚠️ **file表s3_bucket字段风险**：81数据导入后，innies_biz.file表的s3_bucket字段将指向81集群的bucket名。当前innies-biz服务通过环境变量S3_BUCKET生成签名URL，不读取此字段，**运行不受影响**。但若后续代码重构改为读取DB字段，历史记录将指向81 bucket导致404。迁移后建议评估是否执行：
> ```sql
> UPDATE file SET s3_bucket = 'milvus-bucket-7476e10d-75ce-4fcf-9eaf-3efec58bbe68' WHERE s3_bucket = 'milvus-bucket-aec4dbd6-4d5e-4aa7-b88a-442b3e3cd901';
> ```
> 详见 [[ref-database]] §file.s3_bucket字段说明

### Step 6: 清理临时文件

```bash
# 81上清理
PRIMARY_POD_81=$(kubectl get pods -n data-layer-prod -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')
kubectl exec -n data-layer-prod $PRIMARY_POD_81 -- rm -f /tmp/*.dump
rm -f /tmp/*.dump

# 180上清理
PRIMARY_POD_180=$(kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')
kubectl exec -n cnpg $PRIMARY_POD_180 -- rm -f /tmp/*.dump
rm -f /tmp/*.dump
```

---

## 五、Milvus迁移方案

### 方案选择：milvus-backup（backup → mc mirror跨集群 → restore）

> **迁移范围**：本次仅迁移 `innies_emb_459c6be7e638481aa05804d97f9b0070`（2.6M条向量，81生产核心数据）。180现有kb_ collection(175,127条/33个非空)不受影响，迁移后用户可单独清理。
>
> milvus-backup是应用级工具，理解Milvus collection schema/索引/segment元数据，通过Milvus API操作，安全可靠。
> mc是存储级工具，只拷贝S3对象，不处理etcd元数据，直接用mc拷贝会导致数据不一致。
>
> 上次用milvus-backup恢复innies_emb_459c6be7耗时约50分钟（2990秒）。

### 迁移流程图

```
81 Milvus → [Step1: milvus-backup backup] → 81 S3 bucket/backup/
                                          ↓ [Step2: SSH隧道+mc mirror]
180 S3 bucket/backup/ ← ← ← ← ← ← ← ← ←
                                          ↓ [Step3: 调整QueryNode资源]
                                          ↓ [Step4: 清空180现有数据]
180 Milvus ← [Step5: milvus-backup restore] ← 180 S3 bucket/backup/
```

### Step 1: 在81上创建新备份（只读操作，不影响生产）

```bash
# SSH到81
ssh 172.17.3.81

# 创建新的备份配置文件（指定只备份innies_emb_459c6be7）
cat > /usr/local/milvus-backup/migrate_260819.yaml << 'EOF'
log:
  level: info
  console: true
  file:
    rootPath: "./backup_logs"

milvus:
  address: "127.0.0.1"
  port: 19530
  user: ""
  password: ""
  tlsMode: 0

minio:
  storageType: "s3"
  address: "10.96.1.86"
  port: 80
  accessKeyID: "XVKLJ0B08JVT90ZTGYQM"
  secretAccessKey: "kbMCEUt0Be8D1RoAjNiXvHxaJkxYCD4LIcQh0jY8"
  useSSL: false
  bucketName: "milvus-bucket-aec4dbd6-4d5e-4aa7-b88a-442b3e3cd901"
  rootPath: ""
  useIAM: false

backupStorageType: "s3"
backupAddress: "10.96.1.86"
backupPort: 80
backupAccessKeyID: "XVKLJ0B08JVT90ZTGYQM"
backupSecretAccessKey: "kbMCEUt0Be8D1RoAjNiXvHxaJkxYCD4LIcQh0jY8"
backupUseSSL: false
backupBucketName: "milvus-bucket-aec4dbd6-4d5e-4aa7-b88a-442b3e3cd901"
backupRootPath: "backup/migrate_260819"
EOF

# 执行备份（只备份innies_emb_459c6be7 collection）
cd /usr/local/milvus-backup
./milvus-backup backup \
  --config migrate_260819.yaml \
  --collection_names "innies_emb_459c6be7e638481aa05804d97f9b0070" \
  --dbname "innies" \
  --name "migrate_260819"

# 验证备份
./milvus-backup list --config migrate_260819.yaml

# 查看备份详情
./milvus-backup describe migrate_260819 --config migrate_260819.yaml
```

> 预计耗时：10~20分钟（2.6M条向量，S3 bucket 52GiB中的innies_emb部分）

### Step 2: 跨集群传输备份数据（SSH隧道 + mc mirror）

> **SSH隧道说明**：隧道是**临时性的**，仅在数据传输期间存在。
> - `ssh -fN` 的 `-f` 将SSH进程放后台，`-N` 表示只做端口转发不执行命令
> - 隧道存活期间不影响两端任何运行中的服务
> - `mc mirror` 完成后即可关闭隧道，关闭命令：`kill $(lsof -ti:9001)`
> - 如隧道中断，`mc mirror --overwrite` 支持断点续传，重连后重跑即可
> - 180上已有 `prod81-rgw` alias（指向 localhost:9001），但凭据是旧的（A9QW0BPS...），需用 `mc alias set` 覆盖为正确凭据

```bash
# 在180上建立到81的SSH隧道（将180的localhost:9001转发到81的RGW 10.96.1.86:80）
ssh -fN -L 9001:10.96.1.86:80 172.17.3.81

# 在180上设置mc alias（指向81的RGW，通过SSH隧道，使用milvusminio的凭据）
mc alias set prod81-tunnel http://localhost:9001 \
  XVKLJ0B08JVT90ZTGYQM \
  kbMCEUt0Be8D1RoAjNiXvHxaJkxYCD4LIcQh0jY8

# 验证连通性
mc ls prod81-tunnel/milvus-bucket-aec4dbd6-4d5e-4aa7-b88a-442b3e3cd901/backup/

# 执行mc mirror，将81的备份数据拷贝到180的S3 bucket
mc mirror --overwrite \
  prod81-tunnel/milvus-bucket-aec4dbd6-4d5e-4aa7-b88a-442b3e3cd901/backup/migrate_260819 \
  dstrgw/milvus-bucket-7476e10d-75ce-4fcf-9eaf-3efec58bbe68/backup/migrate_260819

# 验证拷贝结果
mc ls dstrgw/milvus-bucket-7476e10d-75ce-4fcf-9eaf-3efec58bbe68/backup/migrate_260819/

# 关闭SSH隧道（数据传输完成后）
kill $(lsof -ti:9001)
```

> 预计耗时：20~40分钟（取决于innies_emb_459c6be7的数据量，预估约17~20GiB）

### Step 3: 调整180 QueryNode资源（变更操作，需确认）

```bash
# SSH到180
ssh 172.17.3.180

# 方案A（推荐）：QueryNode 32Gi Req / 64Gi Lim
kubectl patch deploy milvus-querynode -n milvus --type=json \
  -p='[{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/memory","value":"32Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/memory","value":"64Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/cpu","value":"4"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/cpu","value":"8"}]'

# 方案B（完全对齐81）：QueryNode 64Gi Req / 128Gi Lim
# kubectl patch deploy milvus-querynode -n milvus --type=json \
#   -p='[{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/memory","value":"64Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/memory","value":"128Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/cpu","value":"4"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/cpu","value":"8"}]'

# 同步调整DataNode和StreamingNode（对齐81配置）
kubectl patch deploy milvus-datanode -n milvus --type=json \
  -p='[{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/memory","value":"4Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/memory","value":"16Gi"}]'

kubectl patch deploy milvus-streamingnode -n milvus --type=json \
  -p='[{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/memory","value":"8Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/memory","value":"24Gi"}]'

# 等待Pod重启完成
kubectl rollout status deploy/milvus-querynode -n milvus
kubectl rollout status deploy/milvus-datanode -n milvus
kubectl rollout status deploy/milvus-streamingnode -n milvus

# 验证Pod状态
kubectl get pods -n milvus -o wide
```

> 影响范围：Milvus组件重启，查询服务短暂中断约2~5分钟
> 回滚方案：记录当前资源配置(1C/2Gi Req, 4C/16Gi Lim)，用kubectl patch恢复

### Step 4: 清空180 innies_emb_459c6be7现有数据（变更操作，需确认）

```bash
# 在180上执行，清空innies_emb_459c6be7（当前仅898条测试数据）
# 方式1：通过Milvus API删除collection中所有数据
# ⚠️ 注意：Milvus API需通过Service地址访问，localhost:19530仅在Milvus Pod内可用
curl -s -X POST http://milvus.milvus.svc.cluster.local:19530/v2/vectordb/collections/drop \
  -H "Content-Type: application/json" \
  -d '{"dbName":"innies","collectionName":"innies_emb_459c6be7e638481aa05804d97f9b0070"}'

# 验证已删除
curl -s -X POST http://milvus.milvus.svc.cluster.local:19530/v2/vectordb/collections/list \
  -H "Content-Type: application/json" \
  -d '{"dbName":"innies"}' | python3 -c "import sys,json; data=json.load(sys.stdin); print([c for c in data.get('data',[]) if '459c6be7' in c])"
```

> ⚠️ 此操作会删除180上innies_emb_459c6be7的898条测试数据及collection schema。
> milvus-backup restore时会自动重建collection和schema，所以先drop是安全的。

### Step 5: 在180上恢复备份（变更操作，需确认）

> **索引复刻机制说明（不关索引策略）**：
>
> milvus-backup 的备份内容包含：collection schema（全部字段定义）、index配置（索引类型/参数/字段映射）、数据segment、partition key、BM25 function等完整元数据。
>
> **restore 过程自动执行以下步骤**：
> 1. 通过Milvus API创建collection（含完整schema，与81完全一致）
> 2. 创建index配置（HNSW/INVERTED/BM25等，与81完全一致）
> 3. 通过bulk insert API批量导入数据（2.6M条）
> 4. 数据导入完成后，自动构建索引
>
> **"不关索引"策略**：即不手动干预索引的创建/删除，完全交给milvus-backup自动处理。
> - 优点：操作简单，restore一条命令完成，索引自动重建，schema/索引与81生产环境**完美复刻**
> - 代价：总耗时包含数据导入+索引构建（上次实测约50分钟，可接受）
> - 对比"先关索引"方案：需手动drop index→导入数据→重建索引，步骤多易出错
>
> **结论：采用"不关索引"策略，milvus-backup自动处理索引，restore后collection的schema/索引/数据与81生产环境完全一致。**

```bash
# SSH到180
ssh 172.17.3.180

# 创建恢复配置文件
cat > /usr/local/milvus-backup/restore_260819.yaml << 'EOF'
log:
  level: info
  console: true

milvus:
  address: "127.0.0.1"
  port: 19530
  user: ""
  password: ""
  tlsMode: 0

minio:
  storageType: "s3"
  address: "10.96.1.58"
  port: 80
  accessKeyID: "995CBSBEFDCJLFFKW35S"
  secretAccessKey: "6B7Igjj2m9Qqme275VA7S2HwRbXYHnABsQEfNakH"
  useSSL: false
  bucketName: "milvus-bucket-7476e10d-75ce-4fcf-9eaf-3efec58bbe68"
  rootPath: ""
  useIAM: false

backupStorageType: "s3"
backupAddress: "10.96.1.58"
backupPort: 80
backupAccessKeyID: "995CBSBEFDCJLFFKW35S"
backupSecretAccessKey: "6B7Igjj2m9Qqme275VA7S2HwRbXYHnABsQEfNakH"
backupUseSSL: false
backupBucketName: "milvus-bucket-7476e10d-75ce-4fcf-9eaf-3efec58bbe68"
backupRootPath: "backup/migrate_260819"
EOF

# 执行恢复（后台运行，日志输出到文件）
cd /usr/local/milvus-backup
nohup ./milvus-backup restore \
  --config restore_260819.yaml \
  --collection_names "innies_emb_459c6be7e638481aa05804d97f9b0070" \
  --dbname "innies" \
  --name "migrate_260819" \
  > /usr/local/milvus-backup/restore_260819.log 2>&1 &

# 监控恢复进度
tail -f /usr/local/milvus-backup/restore_260819.log

# 或轮询检查
watch -n 30 'tail -5 /usr/local/milvus-backup/restore_260819.log'
```

> 预计耗时：40~60分钟（参考上次2990秒≈50分钟）
> 恢复过程中Milvus会通过bulk insert API将数据导入，不影响其他collection

### Step 6: 验证Milvus数据

```bash
# 验证collection已恢复
curl -s -X POST http://milvus.milvus.svc.cluster.local:19530/v2/vectordb/collections/list \
  -H "Content-Type: application/json" \
  -d '{"dbName":"innies"}' | grep "459c6be7"

# 验证entity数量（应为2,607,989）
curl -s -X POST http://milvus.milvus.svc.cluster.local:19530/v2/vectordb/collections/get_stats \
  -H "Content-Type: application/json" \
  -d '{"dbName":"innies","collectionName":"innies_emb_459c6be7e638481aa05804d97f9b0070"}'

# 通过attu UI验证（NodePort 30800）
# 浏览器访问 http://172.17.3.180:30800
```

---

## 六、后置验证

### 6.1 PG验证

```bash
# 1. 数据库大小对比
PRIMARY_POD=$(kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod,role=primary -o jsonpath='{.items[0].metadata.name}')
kubectl exec -n cnpg $PRIMARY_POD -- psql -U app -c "SELECT datname, pg_size_pretty(pg_database_size(datname)) as size FROM pg_database WHERE datistemplate = false ORDER BY pg_database_size(datname) DESC;"

# 2. 关键表行数对比（innies_biz）
kubectl exec -n cnpg $PRIMARY_POD -- psql -U app -d innies_biz -c "SELECT 'documents' as tbl, count(*) FROM documents UNION ALL SELECT 'chunks', count(*) FROM chunks UNION ALL SELECT 'knowledge_bases', count(*) FROM knowledge_bases;"

# 3. PG实例状态
kubectl get cluster -n cnpg postgres-cluster-prod -o wide
kubectl get pods -n cnpg -L role
```

### 6.2 Milvus验证

```bash
# 1. Collection列表
curl -s -X POST http://milvus.milvus.svc.cluster.local:19530/v2/vectordb/collections/list \
  -H "Content-Type: application/json" -d '{"dbName":"innies"}'

# 2. innies_emb_459c6be7 entity数量（期望: 2,607,989）
curl -s -X POST http://milvus.milvus.svc.cluster.local:19530/v2/vectordb/collections/get_stats \
  -H "Content-Type: application/json" \
  -d '{"dbName":"innies","collectionName":"innies_emb_459c6be7e638481aa05804d97f9b0070"}'

# 3. Milvus Pod状态
kubectl get pods -n milvus -o wide

# 4. QueryNode内存使用（等待数据加载完成后检查）
kubectl exec -n milvus $(kubectl get pods -n milvus -l app.kubernetes.io/component=querynode -o jsonpath='{.items[0].metadata.name}') -- cat /proc/meminfo | head -5
```

### 6.3 业务服务验证

```bash
# 1. innies-biz健康检查
kubectl get pods -n innies -l app.kubernetes.io/name=innies-biz
kubectl logs deploy/innies-stack-innies-biz -n innies --tail=20

# 2. synapse健康检查（Milvus主要使用者）
kubectl get pods -n innies -l app.kubernetes.io/name=synapse
kubectl logs deploy/innies-stack-synapse -n innies --tail=20

# 3. 前端访问
curl -s -o /dev/null -w "%{http_code}" http://172.17.3.180:31819/

# 4. 知识库搜索测试（通过synapse API）
kubectl exec -n innies deploy/innies-stack-synapse -- curl -s http://localhost:9001/health
```

---

## 七、回滚方案

### PG回滚

| 场景 | 回滚方式 |
|------|----------|
| pg_restore失败 | 180原有数据未被破坏（--clean先删后导，失败时部分表可能为空）→ 从Step 4前置备份恢复 |
| 数据不一致 | 重新执行pg_dump → pg_restore |
| 业务无法连接 | 检查CNPG cluster状态，确认primary节点，检查pooler连接 |

> **Step 4已前置180 PG备份**：备份文件存放在180主机 `/data/backup_pg_pre_migrate/`，回滚时 `kubectl cp` 回Pod后 `pg_restore` 即可

### Milvus回滚

| 场景 | 回滚方式 |
|------|----------|
| restore失败 | 检查restore日志，修复后重试；或重新drop collection后重试 |
| QueryNode OOM | 降低QueryNode资源到16Gi/32Gi，重启Pod |
| 数据不一致 | drop innies_emb_459c6be7 collection，重新restore |
| 需完全回滚 | drop innies_emb_459c6be7 collection，恢复QueryNode到原配置(1C/2Gi, 4C/16Gi) |

### 资源配置回滚

```bash
# QueryNode回滚到原配置
kubectl patch deploy milvus-querynode -n milvus --type=json \
  -p='[{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/memory","value":"2Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/memory","value":"16Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/cpu","value":"1"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/cpu","value":"4"}]'

# DataNode回滚
kubectl patch deploy milvus-datanode -n milvus --type=json \
  -p='[{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/memory","value":"1Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/memory","value":"4Gi"}]'

# StreamingNode回滚
kubectl patch deploy milvus-streamingnode -n milvus --type=json \
  -p='[{"op":"replace","path":"/spec/template/spec/containers/0/resources/requests/memory","value":"1Gi"},{"op":"replace","path":"/spec/template/spec/containers/0/resources/limits/memory","value":"4Gi"}]'
```

---

## 八、风险评估

| 风险项 | 等级 | 说明 | 缓解措施 |
|--------|------|------|----------|
| PG dump期间81业务写入 | 低 | pg_dump是一致性快照，不影响生产读写 | 建议低峰期执行 |
| PG restore覆盖180数据 | 中 | --clean会先删表再导入，中途失败会丢数据 | 提前备份180现有PG数据 |
| Milvus restore耗时较长 | 低 | 预计40~60分钟，期间innies_emb不可查 | 仅影响测试环境，可接受 |
| QueryNode内存不足 | 低 | 2.6M条向量实际占用约20~25Gi，32Gi Request足够 | 监控Pod内存，可动态调整 |
| SSH隧道中断 | 中 | mc mirror过程中隧道断开 | mc mirror支持断点续传，重连后重跑即可；隧道为临时通道，kill后重建 |
| 索引未正确复刻 | 低 | milvus-backup自动处理索引创建，"不关索引"策略下schema+索引与81完全一致 | restore后通过get_stats验证entity数，通过describe验证index配置 |
| kb_ collection迁移 | 低 | 本次Milvus迁移仅迁innies_emb_459c6be7，180现有kb_ collection(175,127条/33个非空)不受影响 | 迁移后用户可单独清理180的kb_ collection |
| 81独有DB(proxymeter/superset) | 低 | 180无对应业务服务，导入后仅存数据不使用 | 可选：只迁移innies_biz等核心库 |
| file表s3_bucket字段 | 中 | 81数据导入后file.s3_bucket指向81的bucket，当前innies-biz不读取此字段(用ENV S3_BUCKET)，但若代码重构改为读取DB字段将导致404 | 迁移后评估是否需批量UPDATE file表s3_bucket指向180 bucket；详见[[ref-database]] §file.s3_bucket字段说明 |
| CNPG managedDB冲突 | 低 | 180 CNPG cluster spec的managedDatabases可能不包含proxymeter/superset/innies，手动CREATE DATABASE后operator reconcile可能不感知 | 创建库前先检查: kubectl get cluster -n cnpg postgres-cluster-prod -o yaml | grep -A20 managedDatabases |

---

## 九、执行顺序建议

```
1. PG迁移（先迁移，不影响Milvus）
   ├── Step 1: 81上pg_dump导出（~30~60分钟）
   ├── Step 2: Pod→主机拷贝（~5分钟）
   ├── Step 3: 81→180 scp传输（~10~20分钟）
   ├── Step 4: 180上pg_restore导入（~30~60分钟）
   └── Step 6: 验证+清理

2. Milvus迁移（PG完成后执行）
   ├── Step 1: 81上milvus-backup backup（~10~20分钟）
   ├── Step 2: SSH隧道+mc mirror传输（~20~40分钟）
   ├── Step 3: 调整180 QueryNode资源（~5分钟，Pod重启2~5分钟）
   ├── Step 4: 清空180 innies_emb_459c6be7（~1分钟）
   ├── Step 5: milvus-backup restore（~40~60分钟）
   └── Step 6: 验证

3. 后置验证
   ├── 6.1 PG验证
   ├── 6.2 Milvus验证
   └── 6.3 业务服务验证

4. 清理（可选）
   └── 删除180的kb_ collection（用户后续单独处理）
```

> **总预估耗时**：3~5小时（PG 1.5~2.5h + Milvus 1.5~2h + 验证 0.5h）
> **建议执行时间**：业务低峰期（夜间或周末）
>
> **关键决策记录**：
> - Milvus迁移采用"不关索引"策略，milvus-backup自动处理schema+数据+索引的完整复刻
> - SSH隧道为临时通道，仅Step 2期间存在，完成后即关闭
> - kb_ collection不迁移，用户计划在180上单独清理
> - ⚠️ file表s3_bucket字段风险：81数据导入后该字段指向81 bucket，当前服务不读取此字段，但代码重构后可能触发404，迁移后需评估是否批量更新
> - PG Pod名不硬编码：使用 `role=primary` label 动态获取，避免主备切换后Pod名失效

---

## 十、milvus-backup vs mc 对比说明

| 对比项 | milvus-backup | mc (MinIO Client) |
|--------|---------------|-------------------|
| 工作层级 | 应用级（通过Milvus API） | 存储级（直接操作S3对象） |
| 理解Milvus语义 | ✅ 理解collection/schema/索引/segment | ❌ 不理解，只看到S3对象 |
| 元数据处理 | ✅ 自动处理etcd元数据（通过API） | ❌ 不处理etcd，需手动迁移 |
| 按collection选择 | ✅ 可指定单个collection备份/恢复 | ❌ 无法按collection选择（S3按segment存储） |
| 数据一致性 | ✅ 保证一致性（通过Milvus bulk insert API） | ⚠️ 不保证（S3对象+etcd可能不匹配） |
| 速度 | 较慢（需通过API导入） | 快（直接拷贝S3对象） |
| 安全性 | 高 | 低（可能导致数据不一致） |
| 适用场景 | 跨集群迁移、选择性恢复 | 全量bucket拷贝、同构集群灾备 |

> **结论：本次迁移使用milvus-backup**，因为：
> 1. 可按collection选择性迁移（只迁innies_emb_459c6be7）
> 2. 自动处理元数据，无需手动操作etcd
> 3. 上次已验证可行（2026-07-03恢复成功，耗时50分钟）
> 4. mc仅用于跨集群传输备份数据（Step 2），不直接操作Milvus数据
> 5. **索引完美复刻**：milvus-backup备份包含完整index配置，restore时自动重建，采用"不关索引"策略，一条命令完成schema+数据+索引的完整复刻
> 6. **SSH隧道为临时通道**：仅在Step 2数据传输期间存在，传输完成后kill即可，不影响任何运行服务

---

> 📎 导航: [[INDEX]] | [[ref-database]] | [[ref-innies-milvus-arch]] | [[ref-resource]]
