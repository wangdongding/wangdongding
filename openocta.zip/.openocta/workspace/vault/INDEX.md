# 知识库索引 (INDEX)

> 🏷️ 环境归属: 179本机 + 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-07-08 | 类型: 导航索引
> doc_id: INDEX v1 | tags: index,navigation,routing | depends: 无

本索引是知识库的入口路由，按主题分发到对应的详细文档。

> 各文档元数据头已统一为双行格式，环境归属字段标注适用环境。

---

## 标准操作流程 (SOP)

| SOP ID | 主题 | 文档 | 说明 |
|--------|------|------|------|
| SOP-001 | Harbor 镜像同步 | [[sop-001-harbor-image-sync]] | 从外部拉取镜像到本地Harbor并复制到生产仓库 |
| SOP-002 | K8s 部署更新 | [[sop-002-k8s-rollout]] | helm/yaml 更新与回滚的完整流程（含执行路径+前置条件+参数表+注意事项） |
| SOP-003 | 服务健康检查 | [[sop-003-service-check]] | Pod状态、日志、端点检查 |
| SOP-004 | 故障排查速查 | [[sop-troubleshooting-quickref]] | 症状->命令速查表，定位方向后再跳完整Runbook |
| SOP-004 | 故障排查 Runbook(高频) | [[sop-troubleshooting-runbook]] | 5类高频故障详细排查步骤+历史案例 |
| SOP-004 | 故障排查 Runbook(扩展) | [[sop-troubleshooting-extended]] | 7类低频运维场景：CNPG主备/TOAST/索引/Ceph/GPU/Redis/RabbitMQ |
| SOP-005 | Helm 操作手册 | [[sop-helm-ops]] | Release清单、升级命令、升级顺序、域名流量 |

## 参考信息 (REF)

| REF ID | 主题 | 文档 | 说明 |
|--------|------|------|------|
| REF-Env | 运维环境上下文 | [[ref-env-context]] | 会话初始化必读：连接方式、路径、平台约束 |
| REF-K8s | K8s 集群信息 | [[ref-k8s-cluster]] | 集群元数据、Namespace、Pod清单（Service/Ingress已下沉到ref-service-call-chain） |
| REF-Deploy | 服务部署注册表 | [[ref-service-deploy-registry]] | 每个服务的部署方式(helm/yaml)和配置路径 |
| REF-Harbor | Harbor 基础设施 | [[ref-harbor-infra]] | Harbor地址、代理项目、复制规则、镜像格式 |
| REF-Call | 服务调用关系链 | [[ref-service-call-chain]] | 流量路由、内部调用关系、数据存储、Service ClusterIP、Ingress清单 |
| REF-DB | 数据库详情 | [[ref-database]] | PostgreSQL(CNPG)、S3/RGW |
| REF-Milvus | Innies Milvus向量架构 | [[ref-innies-milvus-arch]] | Collection schema、路由逻辑、已知问题、环境对比 |
| REF-Storage | PVC/PV/StorageClass | [[ref-storage]] | 存储类、PVC映射、数据卷详情 |
| REF-Ceph | Ceph 存储状态 | [[ref-ceph-storage]] | Ceph集群概况、OSD状态、PG健康 |
| REF-Secret | Secret与证书 | [[ref-secret-cert]] | TLS证书、Secret清单、到期日 |
| REF-Resource | 资源分配 | [[ref-resource]] | 各节点CPU/内存/GPU分配 |
| REF-Values | Helm Values覆盖度 | [[ref-helm-values-coverage]] | values能否覆盖所有配置，盲区分析 |
| REF-ChangeLog | 变更日志 | [[ref-change-log]] | 所有环境变更统一记录 |
| REF-Lessons | 经验教训与常见问题 | [[ref-lessons-learned]] | 常见问题速查表 + 经验教训深度复盘 |
| REF-VaultCLI | vault辅助CLI | [[ref-vault-cli]] | 知识库搜索/读取/部署预检 CLI工具 |
| REF-Monitor | AI-Ops监控告警体系 | [[ref-ai-ops-monitor]] | 组件清单、监控节点、告警规则、PromQL速查、常用命令 |

## Pipeline

| Pipeline ID | 主题 | 文档 | 说明 |
|-------------|------|------|------|
| PL-001 | 镜像同步并部署 | [[pl-001-mirror-sync-and-deploy]] | 从Harbor同步到部署验证的完整流程 |

## 迁移方案 (Plan)

| Plan ID | 主题 | 文档 | 说明 |
|---------|------|------|------|
| PLAN-001 | 81→180 PG+Milvus迁移 | [[plan-migrate-81-to-180]] | PG dump/restore + Milvus backup/restore 完整方案 |
| PLAN-002 | 81→180 S3物理文件迁移 | [[plan-s3-migrate-81-to-180]] | mc mirror跨集群同步 + PG s3_bucket字段修正 |

## 模板

| 模板 | 文档 | 说明 |
|------|------|------|
| SOP模板 | [[_template-sop]] | 新建SOP时复制此模板 |
| Pipeline模板 | [[_template-pipeline]] | 新建Pipeline时复制此模板 |

## 快速导航

| 想查什么 | 去哪查 |
|---------|--------|
| 怎么更新服务镜像 | [[sop-002-k8s-rollout]] |
| 服务用的helm还是yaml | [[ref-service-deploy-registry]] |
| 之前做过什么操作 | [[ref-change-log]] |
| 遇到过什么问题 | [[ref-lessons-learned]] |
| 遇到故障怎么排查 | [[sop-troubleshooting-quickref]] |
| 怎么读vault文件最快 | [[ref-vault-cli]] (⭐ cli_vault.py slice/search) |
| values能否覆盖所有配置 | [[ref-helm-values-coverage]] |
| 连接集群/SSH方式 | [[ref-env-context]] |
| Helm升级命令 | [[sop-helm-ops]] |
| 主机/容器/服务告警怎么查 | [[ref-ai-ops-monitor]] |
| CPU/内存/磁盘飙高怎么分析 | [[ref-ai-ops-monitor]] §9 常用查询速查 |
| 81→180数据迁移怎么做 | [[plan-migrate-81-to-180]] + [[plan-s3-migrate-81-to-180]] |

> 关键词→文档映射详见 [[ref-env-context]] 底部「知识库关键词映射」表

---

## 依赖拓扑图

> → 表示依赖方向（上游 → 下游）。修改上游文件时，沿箭头检查下游文件是否需同步更新。

**根节点（无上游依赖）：**
ref-k8s-cluster · ref-harbor-infra · ref-env-context · ref-change-log · ref-vault-cli

**第一层：**
- ref-k8s-cluster → ref-database · ref-ceph-storage · ref-resource · ref-secret-cert · ref-service-call-chain · ref-service-deploy-registry · ref-storage
- ref-harbor-infra → sop-001-harbor-image-sync
- ref-change-log → ref-lessons-learned

**第二层：**
- ref-ceph-storage → ref-storage
- ref-database → ref-innies-milvus-arch
- ref-service-deploy-registry → ref-innies-milvus-arch · ref-helm-values-coverage · ref-service-call-chain · sop-002-k8s-rollout · sop-003-service-check · sop-helm-ops
- ref-env-context → sop-002-k8s-rollout · ref-ai-ops-monitor
- ref-lessons-learned → sop-troubleshooting-runbook

**第三层：**
- sop-002-k8s-rollout → sop-helm-ops
- sop-troubleshooting-runbook → sop-troubleshooting-quickref · sop-troubleshooting-extended

**顶层编排：**
- sop-001 + sop-002 + sop-003 + ref-harbor-infra + ref-service-deploy-registry + ref-k8s-cluster → pl-001-mirror-sync-and-deploy

---

> 新增主题时，在对应分类表中添加一行即可。
> SOP 模板见 [[_template-sop]]，Pipeline 模板见 [[_template-pipeline]]。