# OpenOcta 运维知识库

> 🏷️ 环境归属: 179本机 + 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-07-09 | 类型: 导航索引
> doc_id: README v2 | tags: readme,knowledge-base | depends: INDEX

本知识库为 **172.17.3.179/180 运维环境** 的 Obsidian 笔记库，涵盖标准操作流程(SOP)、参考信息(REF)和编排流程(Pipeline)。

## 适用范围

- 179 本机：Harbor 镜像仓库 / JumpServer / kubectl 直连入口
- 180 测试集群 (ai-q)：K8s 工作负载 / Helm 部署 / 业务服务

> 📋 **所有文档导航、快速入口、关键词映射请见** [[INDEX]]

## 维护约定

- **所有环境均为纯内网环境，严禁执行任何涉及外网的操作**（apt/yum/pip 联网安装、curl 外部 URL、helm repo add 联网仓库、docker pull 外部镜像、git clone 外部仓库等）。所有镜像、依赖、包必须通过内网 Harbor(172.17.3.179) 或本地文件获取。内网地址（172.17.x.x）的操作是允许的，只有涉及外网/公网的才禁止。
- 每次部署/回滚/配置变更 -> 记录到 [[ref-change-log]]
- 遇到新问题 -> 追加到 [[ref-lessons-learned]]
- Harbor 地址统一写 172.17.3.179，不加 :80
- vault 搜索/读取优先用 cli_vault.py（详见 [[ref-vault-cli]]）

---

用 Obsidian 打开此目录即可浏览编辑；.obsidian/ 文件夹已被索引器忽略。
