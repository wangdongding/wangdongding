# SOP 辅助脚本

> 🏷️ 环境归属: 179本机 | 最后更新: 2026-07-06 | 类型: 只读参考
> doc_id: scripts-README v1 | tags: scripts,harbor,polling | depends: sop-001-harbor-image-sync

本目录存放 SOP 流程中调用的辅助脚本。

| 脚本 | 用途 | 引用SOP |
|------|------|----------|
| repl_status_poll.py | Harbor复制规则状态轮询(自动等待终态) | [[sop-001-harbor-image-sync]] Step 7 |
| repl_status_check.py | Harbor复制规则状态一次性检查 | [[sop-001-harbor-image-sync]] Step 6 |

## 使用方式

脚本路径: /root/.openocta/workspace/vault/sop/scripts/
调用格式: python3 /root/.openocta/workspace/vault/sop/scripts/repl_status_poll.py HARBOR_API USER PASS POLICY_ID INTERVAL MAX_RETRY

> 返回导航: [[INDEX]]