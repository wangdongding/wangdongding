# SOP: K8s 部署更新

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-07-13 | 类型: 只读参考
> doc_id: SOP-002 v2.0 | tags: k8s,deploy,rollout | depends: ref-env-context,ref-service-deploy-registry
> 合并来源: sop-002-k8s-rollout-quickref.md + sop-002-k8s-rollout.md（两者已合并）

## 说明

通用 K8s 服务部署更新 SOP。根据服务部署方式（helm / yaml）自动选择更新路径。
**更新前必须先查 [[ref-service-deploy-registry]] 确认部署方式。**

## ⚠️ 关键原则：部署执行在180节点，查询验证在179直连

- `kubectl apply`、`helm upgrade` 需读取180上的yaml/values/tgz文件 → **必须SSH到180执行**
- `kubectl get pods`、`helm status` 等纯查询命令 → **179直连即可**

## 前置条件

- kubectl 可用且已连接目标集群（部署执行需SSH到180节点）
- 目标服务已在 [[ref-service-deploy-registry]] 中注册
- 新镜像已同步到生产 Harbor（如未同步，先执行 [[sop-001-harbor-image-sync]]）

## 输入参数

| 参数 | 必填 | 说明 | 示例 |
|------|------|------|------|
| SVC | Y | 服务名 | pdf2zh |
| NS | Y | K8s 命名空间 | innies |
| NEW_TAG | Y | 新镜像 tag | latest |
| DEPLOY_METHOD | Y | 部署方式: helm / yaml | yaml |
| NODE | Y | 配置文件所在节点 | 180 |
| DRY_RUN | N | 仅输出命令不执行 | Y |

## 执行流程

### 1. 确认参数（查 ref-service-deploy-registry + ref-env-context）

| 参数 | 来源 |
|------|------|
| SVC / NS / DEPLOY_METHOD / NODE | ref-service-deploy-registry |
| 旧镜像tag | grep yaml/values 或 kubectl get deploy |
| 新镜像tag | 用户指定 |
| kubectl连接 | SSH到180(apply/upgrade)或179直连(查询验证) |
| 文件操作 | SSH到{{NODE}} |

### 2. helm 方式

> 包含独立 Release 和大 Chart 子服务两种场景，流程一致：
> - 独立 Release（如 deer-flow、milvus）：改该 Release 的 values.yaml → helm upgrade 该 Release
> - 大 Chart 子服务（如 innies-stack 下 crab-gateway）：改父 values.yaml 中子服务 tag → helm upgrade 父 Release

```
# 备份(SSH到NODE) — DATE=$(date +%Y%m%d%H%M)
ssh {{NODE}} "cp {{VALUES_PATH}} {{VALUES_PATH}}.bak.$(date +%Y%m%d%H%M)"
# 替换tag(SSH到NODE)
ssh {{NODE}} "grep '{{OLD_TAG}}' {{VALUES_PATH}}"  # 先确认唯一匹配
ssh {{NODE}} "sed -i 's|{{OLD_TAG}}|{{NEW_TAG}}|' {{VALUES_PATH}}"
# helm upgrade(⚠️ SSH到180执行，因values和tgz在180)
ssh {{NODE}} "helm upgrade {{HELM_RELEASE}} {{CHART_PATH}} -n {{NS}} -f {{VALUES_PATH}}"
# 轮询验证(179直连，每步<10s)
helm status {{HELM_RELEASE}} -n {{NS}} | grep deployed
kubectl get pods -n {{NS}} -l app={{SVC}} -o wide
# 回滚（⚠️ 必须两步：集群回滚 + 文件恢复）
ssh {{NODE}} "helm rollback {{HELM_RELEASE}} {{PREV_REVISION}} -n {{NS}}"
ssh {{NODE}} "cp {{VALUES_PATH}}.bak.{备份时的时间戳} {{VALUES_PATH}}"
```

> 📋 13个 Release 的具体 helm upgrade 命令见 [[sop-helm-ops]] 第4节

### 3. yaml 方式

```
# 备份(SSH到NODE) — DATE=$(date +%Y%m%d%H%M)
ssh {{NODE}} "cp {{YAML_PATH}} {{YAML_PATH}}.bak.$(date +%Y%m%d%H%M)"
# 替换image(SSH到NODE)
ssh {{NODE}} "grep '{{OLD_IMAGE}}' {{YAML_PATH}}"  # 先确认唯一匹配
ssh {{NODE}} "sed -i 's|{{OLD_IMAGE}}|{{NEW_IMAGE}}|' {{YAML_PATH}}"
# kubectl apply(⚠️ SSH到180执行，因yaml文件在180)
ssh {{NODE}} "kubectl apply -f {{YAML_PATH}} -n {{NS}}"
# 轮询验证(179直连，每步<10s)
kubectl get pods -n {{NS}} -l app={{SVC}} -o wide
# 回滚（⚠️ 必须两步：集群回滚 + 文件恢复）
ssh {{NODE}} "kubectl rollout undo deployment/{{SVC}} -n {{NS}}"
ssh {{NODE}} "cp {{YAML_PATH}}.bak.{备份时的时间戳} {{YAML_PATH}}"
```

### 4. 通用验证

```
kubectl get pods -n {{NS}} -l app={{SVC}} -o jsonpath='{.items[0].spec.containers[0].image}'
kubectl get pods -n {{NS}} -l app={{SVC}} -o wide
kubectl logs -n {{NS}} -l app={{SVC}} --tail=50
```

## ⚠️ 回滚核心原则：集群回滚 + 文件同步，缺一不可

- **回滚命令也必须在180执行**（同样依赖本地文件）
- helm 回滚后必须 `cp .bak` 恢复 values.yaml，否则下次 helm upgrade 再次前滚
- yaml 回滚后必须 `cp .bak` 恢复 deployment.yaml
- 详见 [[ref-lessons-learned]] Lesson-001

## 平台约束提醒

- ❌ 禁止 `kubectl rollout status --timeout>10s` → 改用轮询 `kubectl get pods`
- ❌ 禁止 Bash 命令含换行符 → 先写文件再传入
- ✅ 部署执行(kubectl apply / helm upgrade) → SSH到180（文件在180）
- ✅ 查询验证(kubectl get / helm status) → 179直连即可

## yaml-set 方式（⚠️ 不推荐，与本地yaml不一致容易混乱）

```
kubectl set image deployment/SVC CONTAINER_NAME=IMAGE_REPO:NEW_TAG -n NS
kubectl rollout undo deployment/SVC -n NS
ssh NODE "sed -i s|NEW_IMAGE|OLD_IMAGE| YAML_PATH"
```

> yaml-set 直接修改集群Pod spec不改本地文件，导致集群状态与本地yaml不一致，回滚还需sed同步。建议优先用sed-i+kubectl apply方式保持一致性

## 注意事项

- **必须先查 [[ref-service-deploy-registry]]**，不要凭记忆判断部署方式
- **必须先查 [[ref-env-context]]**，确认本机角色、kubectl连接方式
- helm 大 Chart 子服务修改 values.yaml 时务必只改目标服务 tag
- helm upgrade 前建议先 `helm get values RELEASE -n NS` 确认当前 values
- kubectl apply 的 yaml 文件中 imagePullPolicy 建议设为 Always
- 备份文件命名带日期+时间戳（`$(date +%Y%m%d%H%M)`），避免多次操作覆盖
- **平台超时适配**：等待类命令必须用轮询模式（每步<10s）

## ⚠️ 部署后必做：更新文档（不可跳过）

> 此章节为变更记录的**权威版本**，[[sop-001-harbor-image-sync]] 和 [[pl-001-mirror-sync-and-deploy]] 引用此处。
> 条目模板见 [[ref-change-log]] 底部「变更日志条目模板」。

### 变量采集表

> 写变更日志前，从本次部署过程中采集以下变量。

| 变量 | 来源 | 示例 |
|------|------|------|
| DATE | 当前日期 | 2026-07-21 |
| SVC_LIST | 本次部署的服务名 | innies-loom, synapse |
| TAG_CHANGE | 旧tag→新tag | innies-loom 2.x→3.0.8 |
| HELM_RELEASE | helm release名 | innies-stack |
| NEW_REV | helm revision(部署后) | 30 |
| PREV_REV | 上一revision(回滚用) | 29 |
| NS | 命名空间 | innies |
| BACKUP_FILE | 备份文件名 | values.yaml.bak.202607211316 |
| CONFIG_CHANGE | 配置变更摘要(无则填"无") | file-parser-api extraEnv 全面更新 |
| POD_COUNT | 验证时Running Pod数 | 5 |
| VERIFY_RESULT | 验证结果摘要 | 5 Pod Running 1/1, 零重启 |

### 执行步骤

1. **追加变更日志** → 在 [[ref-change-log]] 元数据头之后、首条记录之前插入新条目
   - 使用「部署更新场景」模板（见 [[ref-change-log]] 底部）
   - 填入上方变量采集表中采集的值
   - 日期相同则追加到同一日 section 下，不同日则新建 section
2. **更新注册表 tag** → 在 [[ref-service-deploy-registry]] 中更新该服务的 `镜像当前tag` 列
   > ref-k8s-cluster 已不再维护 tag，注册表是 tag 唯一权威源
3. **如涉及节点/资源/GPU变更** → 更新 [[ref-resource]] 静态快照
4. **如涉及配置变更(extraEnv/values字段)** → 在变更日志「配置变更」字段记录摘要
5. **更新本文件元数据头** → 修改「最后更新」日期为当前日期

## 相关文档

- [[ref-service-deploy-registry]] - 服务部署方式注册表（**必查**）
- [[ref-env-context]] - 运维环境上下文
- [[sop-helm-ops]] - Helm 升级命令速查
- [[sop-001-harbor-image-sync]] - 镜像同步 SOP
- [[ref-lessons-learned]] - 经验教训与常见问题
- [[ref-change-log]] - 变更日志（含部署操作记录）

> 返回导航: [[INDEX]]
