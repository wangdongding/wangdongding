# Helm 操作手册

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-07-13 | 类型: 只读参考
> doc_id: sop-helm-ops v1 | tags: helm,upgrade,rollback | depends: ref-service-deploy-registry,ref-k8s-cluster
> 合并来源: sop-helm-ops.md + sop-helm-upgrade-commands.md（两者重叠已合并）

## 一句话结论

**Helm 升级/回滚/镜像管理的完整参考。升级前务必先查 [[ref-service-deploy-registry]] 确认部署方式。**

---

## 1. 镜像仓库

| 项目 | 值 |
|------|----- |
| Harbor地址 | 172.17.3.179（不加 :80） |
| 项目命名空间 | zhiman（业务）、kubernetes（基础设施） |
| 镜像拉取工具 | nerdctl -n k8s.io |
| 镜像地址格式 | 172.17.3.179/zhiman/<组织>/<镜像名>:<tag> 或 172.17.3.179/kubernetes/<组织>/<镜像名>:<tag> |

> 详细 Harbor 信息见 [[ref-harbor-infra]]

## 2. 部署目录结构 /data/zhiman/

| 目录 | 服务 | 说明 |
|------|------|------ |
| cert-manager/ | cert-manager | TLS证书管理 |
| cnpg/ | CloudNativePG | PostgreSQL operator |
| db-migration/ | 数据库迁移 | dump-sql/、restore.sh |
| hami/ | HAMi | GPU虚拟化调度 |
| infinity/ | infinity-vl-embedding | 向量嵌入服务 |
| innies/ | innies-stack | 核心业务栈 |
| k8s/ | 集群配置 | Clusterfile.yaml |
| milvus/ | Milvus | 向量数据库 |
| nginx/ | ingress-nginx | Ingress控制器 |
| pdfminer/ | zhiman-pdfminer | PDF解析 |
| rabbitmq/ | RabbitMQ | 消息队列 |
| reloader/ | deployment-reloader | Pod重启管理 |
| rook-ceph/ | Rook-Ceph | Ceph存储 |
| vllm/ | vllm-reranker | 重排序模型 |
| xinference/ | xinference | 模型推理平台 |

## 3. Helm Release 清单

| Release | Namespace | Chart版本 | Revision | 说明 |
|---------|-----------|----------|----------|------ |
| cert-manager | cert-manager | v1.18.2 | 1 | TLS证书自动管理 |
| cilium | kube-system | 1.13.4 | 1 | CNI网络插件(集群初始化部署，不建议helm upgrade) |
| cnpg | cnpg | 0.25.0 | 1 | PostgreSQL operator |
| hami | hami | 2.6.1 | 2 | GPU虚拟化调度 |
| infinity | llm | 1.0.0 | 2 | VL向量嵌入 |
| ingress-nginx | ingress-nginx | 4.13.0 | 2 | Ingress控制器 |
| innies-stack | innies | 0.1.27 | 13 | 核心业务栈(最活跃) |
| milvus | milvus | 5.0.19 | 4 | 向量数据库 |
| rook-ceph | rook-ceph | v1.17.1 | 3 | Ceph operator |
| rook-ceph-cluster | rook-ceph | v1.17.1 | 2 | Ceph集群配置 |
| vllm | llm | 1.0.3 | 3 | 重排序模型 |
| xinference | llm | 1.0.0 | 3 | 模型推理平台 |
| zhiman-pdfminer | llm | 1.0.0 | 2 | PDF解析(GPU共享50/50,固定node02) |
| deer-flow | innies | 0.1.3 | 1 | 深度搜索 |

## 4. 各服务升级命令速查

| # | Release | Namespace | 升级命令 |
|---|---------|-----------|--------- |
| 1 | innies-stack | innies | helm upgrade innies-stack /data/zhiman/innies/innies-stack-0.1.27.tgz -n innies -f /data/zhiman/innies/values.yaml |
| 2 | milvus | milvus | helm upgrade milvus /data/zhiman/milvus/milvus-5.0.19.tgz -n milvus -f /data/zhiman/milvus/values.yaml |
| 3 | xinference | llm | helm upgrade xinference /data/zhiman/xinference/xinference-1.0.0.tgz -n llm -f /data/zhiman/xinference/values.yaml |
| 4 | vllm | llm | helm upgrade vllm /data/zhiman/vllm/vllm-1.0.3.tgz -n llm -f /data/zhiman/vllm/values.yaml |
| 5 | infinity | llm | helm upgrade infinity /data/zhiman/infinity/infinity-1.0.0.tgz -n llm -f /data/zhiman/infinity/values.yaml |
| 6 | ingress-nginx | ingress-nginx | helm upgrade ingress-nginx /data/zhiman/nginx/ingress-nginx-4.13.0.tgz -n ingress-nginx -f /data/zhiman/nginx/values.yaml |
| 7 | rook-ceph | rook-ceph | helm upgrade rook-ceph /data/zhiman/rook-ceph/rook-ceph-v1.17.1.tgz -n rook-ceph -f /data/zhiman/rook-ceph/operator-values.yaml |
| 8 | rook-ceph-cluster | rook-ceph | helm upgrade rook-ceph-cluster /data/zhiman/rook-ceph/rook-ceph-cluster-v1.17.1.tgz -n rook-ceph -f /data/zhiman/rook-ceph/cluster-values.yaml |
| 9 | hami | hami | helm upgrade hami /data/zhiman/hami/hami-2.6.1.tgz -n hami -f /data/zhiman/hami/values.yaml |
| 10 | cert-manager | cert-manager | helm upgrade cert-manager /data/zhiman/cert-manager/cert-manager-v1.18.2.tgz -n cert-manager -f /data/zhiman/cert-manager/values.yaml |
| 11 | cnpg | cnpg | helm upgrade cnpg /data/zhiman/cnpg/cloudnative-pg-0.25.0.tgz -n cnpg -f /data/zhiman/cnpg/values.yaml |
| 12 | zhiman-pdfminer | llm | helm upgrade zhiman-pdfminer /data/zhiman/vllm/pdfminer/zhiman-pdfminer-1.0.0.tgz -n llm -f /data/zhiman/vllm/pdfminer/values.yaml |
| 13 | deer-flow | innies | helm upgrade deer-flow /data/zhiman/innies/deer-flow-0.1.3.tgz -n innies -f /data/zhiman/innies/deer-flow.values.yaml |

> ⚠️ cilium 无本地values/chart，由集群初始化部署，不建议 helm upgrade

## 5. kubectl apply 管理的服务

| # | 资源 | Namespace | 文件路径 |
|---|------|-----------|--------- |
| 1 | RabbitMQ Cluster Operator | rabbitmq | /data/zhiman/rabbitmq/operator.yaml |
| 2 | RabbitmqCluster 实例 | rabbitmq | /data/zhiman/rabbitmq/rabbitmq-cluster.yaml |
| 3 | PG Cluster (CNPG) | cnpg | /data/zhiman/cnpg/pg-cluster.yaml |
| 4 | PG Pooler (PgBouncer) | cnpg | /data/zhiman/cnpg/pg-bouncer.yaml |
| 5 | deployment-reloader | llm | /data/zhiman/reloader/deployment-reloader.yaml |
| 6 | pdf2zh | innies | /data/zhiman/innies/pdf2zh/deployment.yaml |

> 完整部署方式注册见 [[ref-service-deploy-registry]]

## 6. 推荐升级顺序

基础设施先行，业务后行:
1. rook-ceph / rook-ceph-cluster（存储底座）
2. cnpg（数据库operator）
3. cert-manager（证书管理）
4. ingress-nginx（流量入口）
5. hami（GPU调度）
6. milvus（向量数据库）
7. xinference / vllm / infinity（LLM模型服务）
8. RabbitMQ（消息队列）
9. zhiman-pdfminer / deer-flow（业务辅助服务）
10. innies-stack（核心业务栈，最后升级）

> 原则: 每次只升级一个服务，验证Running后再升级下一个。

## 7. 验证与回滚命令

helm status RELEASE -n NS
kubectl get pods -n NS -o wide
kubectl logs POD -n NS --tail=100
helm rollback RELEASE REVISION -n NS

> ⚠️ 回滚核心原则：集群回滚 + 文件同步，缺一不可。详见 [[sop-002-k8s-rollout]] 和 [[ref-lessons-learned]]

## 8. 域名与流量入口

> 2026-06-30 重构后：域名Ingress已全部关闭，前端通过 IP:NodePort 访问

### 当前流量入口

| 入口方式 | 地址 | 路由 |
|---------|------|------ |
| IP:NodePort | http://172.17.3.180:31819/ | / → innies-fe |
| IP:NodePort | http://172.17.3.180:31819/api/v1 | /api/v1 → crab-gateway |
| IP:NodePort | http://172.17.3.180:31819/aiagent | /aiagent → z8m |

### NodePort 清单

| Service | Namespace | HTTP | HTTPS |
|---------|-----------|------|------- |
| ingress-nginx-controller | ingress-nginx | 31819 | 31517 |
| hami-scheduler | hami | - | 31998 |
| hami-device-plugin-monitor | hami | 31992 | - |
| attu | milvus | 30800 | - |

> 完整流量路由见 [[ref-service-call-chain]]

---

## ⚠️ 升级/回滚后必做：更新文档

> 详见 [[sop-002-k8s-rollout]] 「部署后必做」章节（追加变更日志 + 更新注册表tag + 更新资源快照）

## 相关文档
- [[ref-service-deploy-registry]] - 服务部署方式注册表（必查）
- [[ref-harbor-infra]] - Harbor 镜像仓库详情
- [[ref-k8s-cluster]] - 集群环境信息
- [[sop-002-k8s-rollout]] - K8s 部署更新 SOP（含执行流程+回滚+部署后必做）
- [[ref-lessons-learned]] - 经验教训与常见问题

> 返回导航: [[INDEX]]
