# SOP: Harbor 镜像同步

> 🏷️ 环境归属: 179本机 | 最后更新: 2026-07-04 | 类型: 只读参考
> doc_id: SOP-001 v1.2 | tags: harbor,image,sync | depends: ref-harbor-infra

## 说明
将外部仓库镜像通过 zm 代理拉取到本地 Harbor，tag 后推送到 zhiman 项目，再触发复制规则同步到生产仓库。
支持单镜像和批量镜像两种模式。批量模式下并行拉取/tag/推送，最后统一触发一次复制规则。

## 前置条件
- nerdctl 可用 → `which nerdctl`
- Harbor 可达 → `curl -s -o /dev/null -w '%{http_code}' http://{{HARBOR}}/api/v2.0/systeminfo`
- zm 代理可用 → `nerdctl pull {{HARBOR}}/zm/library/hello-world`（测试性拉取）

## 输入参数

| 参数 | 必填 | 说明 | 示例 |
|------|------|------|------|
| IMAGE | Y | 原始镜像完整地址 | harbor.pvg2.zhiman.tech/yuwei/zilliz/attu:v2.5.3 |
| IMAGE_PATH | Y | 去掉 registry 前缀的路径 | yuwei/zilliz/attu:v2.5.3 |
| IMAGE_NAME | Y | 镜像短名（用于日志命名） | attu |
| TAG | Y | 镜像标签 | v2.5.3 |
| CLEANUP | N | 是否清理代理镜像，默认 Y | Y |

> IMAGE_PATH 和 TAG 可从 IMAGE 自动解析：去掉 `harbor.pvg2.zhiman.tech/` 前缀即可得到 IMAGE_PATH，`:` 后面为 TAG。

## 步骤

### Step 1: 解析镜像地址
- desc: 从原始镜像地址提取 IMAGE_PATH 和 TAG
- exec: echo {{IMAGE}} | sed 's|harbor.pvg2.zhiman.tech/||'
- async: N
- check: echo {{IMAGE_PATH}} | grep -q '/'
- check_desc: IMAGE_PATH 包含至少一层路径（如 yuwei/zilliz/attu）
- timeout: 5s
- on_fail: abort
- rollback: 无

### Step 2: 通过 zm 代理拉取镜像
- desc: 从本地 Harbor zm 代理项目拉取外部镜像
- exec: nohup nerdctl pull {{HARBOR}}/zm/{{IMAGE_PATH}} > /tmp/{{IMAGE_NAME}}-pull.log 2>&1 &
- async: Y
- check: tail -3 /tmp/{{IMAGE_NAME}}-pull.log
- check_desc: 日志末尾出现 elapsed 且无 error/fatal/401/403
- timeout: 300s
- on_fail: notify
- rollback: 无（拉取失败无副作用）

### Step 3: 确认镜像已拉取到本地
- desc: 验证镜像存在于本地镜像列表（使用完整路径匹配，避免截断/歧义）
- exec: nerdctl images | grep '{{HARBOR}}/zm/{{IMAGE_PATH}}'
- async: N
- check: 命令返回非空
- timeout: 10s
- on_fail: abort
- rollback: 无

### Step 4: 打 Tag 到 zhiman 项目
- desc: 将代理镜像 tag 到 zhiman 目标项目
- exec: nerdctl tag {{HARBOR}}/zm/{{IMAGE_PATH}} {{HARBOR}}/zhiman/{{IMAGE_PATH}}
- async: N
- check: nerdctl images | grep 'zhiman/{{IMAGE_PATH}}'
- timeout: 10s
- on_fail: abort
- rollback: nerdctl rmi {{HARBOR}}/zhiman/{{IMAGE_PATH}}

### Step 5: 推送到 zhiman 项目
- desc: 将 tag 后的镜像推送到本地 Harbor zhiman 项目
- exec: nohup nerdctl push {{HARBOR}}/zhiman/{{IMAGE_PATH}} > /tmp/{{IMAGE_NAME}}-push.log 2>&1 &
- async: Y
- check: tail -3 /tmp/{{IMAGE_NAME}}-push.log
- check_desc: 日志末尾所有 layer 显示 done，出现 elapsed
- timeout: 300s
- on_fail: retry(1)→notify
- rollback: 无（推送失败不影响已有镜像）

### Step 6: 触发复制规则
- desc: 通过 Harbor API 触发 zhiman-prod 复制规则，将镜像同步到生产仓库。⚠️ 只调一次，每次 POST 都会创建新 execution
- exec_sub:
    6a: write /tmp/harbor_replication.json '{"policy_id": {{REPLICATION_POLICY_ID}}}'
    6b: curl -s -k -u {{HARBOR_USER}}:{{HARBOR_PASS}} -w '\nHTTP_CODE:%{http_code}' -X POST -H "Content-Type: application/json" -d @/tmp/harbor_replication.json {{HARBOR_API}}/replication/executions
    6c: rm -f /tmp/harbor_replication.json
- async: N
- check: 输出包含 HTTP_CODE:201
- check_desc: curl 返回 HTTP 201 表示触发成功（响应体可能为空，以状态码为准）
- timeout: 15s
- on_fail: retry(2)→notify
- rollback: 无（复制规则可重复触发，但切勿在 retry 之外重复调用）

### Step 7: 检查复制执行状态
- desc: 轮询复制执行状态直到终态（Succeed/Failed/Stopped）或超时
- exec: python3 /root/.openocta/workspace/vault/sop/scripts/repl_status_poll.py {{HARBOR_API}} {{HARBOR_USER}} {{HARBOR_PASS}} {{REPLICATION_POLICY_ID}} 3 60
- async: N
- check: 输出包含 status=Succeed
- check_desc: 轮询脚本自动每 3s 查一次，最多等 60s，终态退出
- timeout: 70s
- on_fail: retry(1)→notify
- rollback: 无（复制失败可重新触发 Step 6）

### Step 8: 清理代理镜像
- desc: 删除本地 zm 代理镜像，释放空间
- exec: nerdctl rmi {{HARBOR}}/zm/{{IMAGE_PATH}}
- async: N
- check: nerdctl images | grep 'zm/{{IMAGE_PATH}}'
- check_desc: 返回空（镜像已删除）
- timeout: 10s
- on_fail: skip（清理失败不影响结果）
- rollback: 无

## 输出
- TARGET_IMAGE = {{HARBOR}}/zhiman/{{IMAGE_PATH}}
- SYNC_STATUS = Succeed / Failed
- REPLICATION_EXECUTION_ID = <最新复制任务 ID>

## 后置验证
- nerdctl images | grep 'zhiman/{{IMAGE_PATH}}' 确认目标镜像存在
- curl -s -k -u {{HARBOR_USER}}:{{HARBOR_PASS}} {{HARBOR_API}}/projects/zhiman/repositories?q={{IMAGE_NAME}} 确认 Harbor 中存在

## 回滚方案
- Step 4 回滚: `nerdctl rmi {{HARBOR}}/zhiman/{{IMAGE_PATH}}`
- 整体回滚: 删除已推送的 zhiman 镜像 + 重新触发复制（如已同步到远端需手动清理）

## 注意事项
- zm 项目是代理入口，拉取外部镜像必须走 zm，不能直接从原始地址拉取
- 复制规则是全量扫描，远端已有 artifact 自动跳过不重复传输
- 后台执行（Step 2/5）需轮询日志确认完成，不要 cat 全量日志，用 tail
- 并行拉取多个镜像时日志文件名用 IMAGE_NAME 区分，避免冲突
- 后台任务完成后及时清理日志: rm -f /tmp/{{IMAGE_NAME}}-*.log
- 所有 exec/exec_sub 中的命令必须为单行，禁止换行符（平台中间件拦截）
- exec_sub 中的子步骤按字母序（6a/6b/6c）顺序执行，每条独立调用 bash
- Step 7 使用 [[sop/scripts/repl_status_poll.py]] 轮询，自动等待终态，无需手动 sleep
- ⚠️ **部署前必查 values.yaml registry 与镜像实际路径是否一致，以镜像路径为准**（详见 [[ref-lessons-learned]] Lesson-006）

## 批量模式

当需要同步多个镜像时，按以下顺序执行以避免重复触发复制规则：

1. **并行拉取**：对所有镜像同时执行 Step 2（nohup nerdctl pull），日志文件名用 IMAGE_NAME 区分
2. **轮询拉取日志**：对所有镜像 tail 日志确认 elapsed 出现且无 error（合并 Step 3 验证到日志确认中）
3. **并行 tag + 确认**：对所有镜像同时执行 Step 4，tag 后无需单独验证（tag 是本地操作，成功即存在）
4. **并行推送**：对所有镜像同时执行 Step 5（nohup nerdctl push），轮询推送日志确认 elapsed
5. **一次性验证**：所有推送完成后，执行一次 `nerdctl images | grep 'zhiman/'` 确认全部目标镜像存在（合并 Step 3 的逐个验证）
6. **触发一次复制**：执行 Step 6 一次（⚠️ 切勿每镜像触发一次）
7. **轮询状态**：执行 Step 7 等待复制完成
8. **批量清理**：对所有镜像执行 Step 8

关键原则：
- **复制规则只触发一次**，全量扫描会自动覆盖本次所有新推送的镜像
- **合并验证**：拉取后直接 tag，tag 后直接 push，无需每步单独验证，最后一次性确认所有目标镜像存在即可

## ⚠️ 同步完成后必做：更新文档

> 仅同步镜像（不部署）场景的变更记录指引。
> 部署场景的完整清单见 [[sop-002-k8s-rollout]] 「部署后必做」章节。
> 条目模板见 [[ref-change-log]] 底部「变更日志条目模板」。

### 变量采集表（仅同步场景）

| 变量 | 来源 | 示例 |
|------|------|------|
| DATE | 当前日期 | 2026-07-13 |
| IMAGE_NAME | 同步的镜像名 | zhiman-pdfminer |
| IMAGE_PATH | 镜像路径 | yuwei/zhiman-pdfminer:3.2.3 |
| SYNC_RESULT | 同步结果 | Succeed |
| EXECUTION_ID | 复制执行ID | 166 |
| EXCEPTION | 异常处理摘要(无则填"无") | nerdctl pull snapshot空目录, mkdir补齐后成功 |
| DEPLOY_INVOLVED | 是否涉及部署 | 否（仅同步镜像） |

### 执行步骤

1. **追加变更日志** → 在 [[ref-change-log]] 使用「镜像同步场景」模板（见底部）
   - 标题格式：`## {DATE} | 镜像同步 | {IMAGE_NAME}:{TAG} 同步到生产仓库`
   - 如同步过程中有异常，在「异常处理」字段记录
   - 明确标注「仅同步镜像，不涉及服务部署」
2. **如涉及服务镜像更新** → 更新 [[ref-service-deploy-registry]] 中该服务的 `镜像当前tag` 列
   > 仅同步但未部署时，tag 列**不更新**（部署后再更新）
3. **更新本文件元数据头** → 修改「最后更新」日期为当前日期

## 相关文档

- [[ref-harbor-infra]] - Harbor 基础设施（地址、代理项目、复制规则）

> 返回导航: [[INDEX]]
