# 运维排查 Runbook (扩展)

> 🏷️ 环境归属: 180测试集群(ai-q, 172.17.3.180) | 最后更新: 2026-07-13 | 类型: 只读参考
> doc_id: sop-troubleshooting-extended v1 | tags: troubleshooting,runbook,extended | depends: sop-troubleshooting-runbook,ref-lessons-learned,ref-change-log
> 从主 Runbook 拆出的低频运维场景，高频场景见 [[sop-troubleshooting-runbook]]

## 6. CNPG 主备切换验证

### 症状
PG主节点故障，需确认备节点是否自动升主

### 排查步骤

1. 查看当前主节点:
   ```bash
   kubectl get cluster -n cnpg postgres-cluster-prod -o wide
   ```

2. 查看Pod角色标识:
   ```bash
   kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod -L role
   ```

3. 查看切换事件:
   ```bash
   kubectl describe cluster -n cnpg postgres-cluster-prod | grep -A5 "Switchover"
   ```

4. 验证pooler连接:
   ```bash
   kubectl exec <pod> -n <namespace> -- psql $DATABASE_URL -c "SELECT pg_is_in_recovery()"
   ```

---

## 7. TOAST膨胀 / 慢查询排查

### 症状
查询慢、磁盘占用远大于实际数据量

### 排查步骤

1. 检查表大小和膨胀率:
   ```bash
   # 从CNPG Pod内执行
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -c "SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname||quote_ident(tablename))) AS total_size FROM pg_tables WHERE schemaname = 'public' ORDER BY pg_total_relation_size(schemaname||quote_ident(tablename)) DESC LIMIT 20;"
   ```

2. 检查TOAST表膨胀:
   ```bash
   # chunk_meta TOAST膨胀17.5GB案例
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d innies_biz -c "SELECT pg_size_pretty(pg_relation_size(chunk_meta_toast::regclass)) AS toast_size;"
   ```

3. 处理膨胀(需确认后执行 ⚠️ 高危):
   ```bash
   # VACUUM FULL 会锁表！必须在业务低峰执行
   # 需用户确认后才可执行
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d innies_biz -c "VACUUM FULL chunk_meta;"
   ```

### 历史案例(6/29)
- 81 chunk_meta TOAST膨胀17.5GB，行数与其他库一致，VACUUM FULL后恢复正常

---

## 8. 索引缺失排查

### 症状
查询性能骤降，EXPLAIN显示Seq Scan

### 排查步骤

1. 检查表索引列表:
   ```bash
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d <db> -c "\di+ <table>*"
   ```

2. 补建索引(需确认后执行 ⚠️ 高危):
   ```bash
   # CREATE INDEX 会锁表，建议 CONCURRENTLY 方式
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d <db> -c "CREATE INDEX CONCURRENTLY idx_name ON table(col);"
   ```

### 历史案例(6/29)
- chunk_meta 4个索引缺失，补建后查询恢复正常

---

## 9. Ceph 健康告警排查

### 症状
kubectl get cephcluster 显示 HEALTH_WARN / HEALTH_ERR

### 排查步骤

1. 获取详细告警:
   ```bash
   kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph health detail
   ```

2. 查看PG状态分布:
   ```bash
   kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph pg stat
   ```

3. 查看crash列表:
   ```bash
   kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph crash ls
   ```

> 详见 [[ref-ceph-storage]] 中的完整状态和修复日志

---

## 10. GPU调度失败排查

### 症状
模型Pod无法启动，报 GPU资源不足 / scheduling failed

### 排查步骤

1. 查看HAMi调度器日志:
   ```bash
   kubectl logs hami-scheduler-<pod> -n hami --tail=100
   ```

2. 查看GPU分配状态:
   ```bash
   kubectl get pods -A -L nvidia.com/gpu
   ```

3. 查看node01/02 GPU可用量:
   ```bash
   kubectl describe node ai-q-node01 | grep -A5 nvidia.com/gpu
   kubectl describe node ai-q-node02 | grep -A5 nvidia.com/gpu
   ```

---

## 11. Redis连接失败排查

### 症状
服务报 Redis connection refused / timeout

### 排查步骤

1. 确认Redis Pod Running:
   ```bash
   kubectl get pods -n innies -l app.kubernetes.io/name=redis
   ```

2. 测试连接(从业务Pod内):
   ```bash
   kubectl exec <pod> -n innies -- redis-cli -h innies-stack-redis ping
   ```

3. 查看Redis日志:
   ```bash
   kubectl logs innies-stack-redis-0 -n innies --tail=50
   ```

---

## 12. RabbitMQ消息堆积排查

### 症状
synapse消费延迟，知识库入库慢

### 排查步骤

1. 确认RabbitMQ Pod Running:
   ```bash
   kubectl get pods -n rabbitmq
   ```

2. 查看队列状态(管理界面):
   - RabbitMQ管理界面可通过 NodePort 或 ClusterIP 访问

3. 查看Pod日志:
   ```bash
   kubectl logs <pod> -n rabbitmq --tail=100
   ```

4. 检查消费者(synapse)日志:
   ```bash
   kubectl logs innies-stack-synapse-<pod> -n innies --tail=200 | grep -i rabbit
   ```

## 相关文档

- [[ref-lessons-learned]] - 经验教训与常见问题
- [[ref-change-log]] - 变更日志

> 返回导航: [[INDEX]]
