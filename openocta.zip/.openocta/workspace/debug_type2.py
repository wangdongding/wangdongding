#!/usr/bin/env python3
"""Debug Type2 token extraction"""
import requests, base64

servers = [
    ('172.17.3.88', 'Compiler', 'Yuwei@2025'),
    ('172.17.3.193', 'administrator', 'admin!123'),
]

# Build Type1
import struct
flags = 0x00088215
type1_msg = b'NTLMSSP\x00' + struct.pack('<I',1) + struct.pack('<I',flags)
type1_msg += struct.pack('<HHI',0,0,0) + struct.pack('<HHI',0,0,0)
type1_b64 = base64.b64encode(type1_msg).decode()

for srv, user, passwd in servers:
    url = f'http://{srv}:5985/wsman'
    resp = requests.post(url, headers={
        'Content-Type': 'application/soap+xml; charset=UTF-8',
        'Authorization': f'Negotiate {type1_b64}'
    }, timeout=8)
    
    print(f"\n=== {srv} ===")
    print(f"HTTP {resp.status_code}")
    for k, v in resp.headers.items():
        if 'auth' in k.lower() or 'negotiate' in v.lower()[:50] if v else False:
            print(f"  {k}: {v[:200]}")
    
    # Get all auth-related headers
    auth_headers = resp.headers.get('WWW-Authenticate', '')
    print(f"\nWWW-Authenticate raw: [{auth_headers[:300]}]")
    
    # Try to extract the token
    # The header might have multiple Negotiate entries
    # Format could be: "Negotiate T1RQVg...==, Negotiate T2RQ..."
    # Or: "Negotiate T1RQVg=="
    parts = auth_headers.split(',')
    for i, part in enumerate(parts):
        part = part.strip()
        if part.startswith('Negotiate '):
            token = part[11:]
            print(f"\n  Part {i}: starts with Negotiate, token len={len(token)}")
            print(f"  Token[:60]: {token[:60]}")
            print(f"  Token[-10:]: {token[-10:]}")
            print(f"  len%4 = {len(token)%4}")
            # Try to decode
            padded = token + '=' * ((4 - len(token) % 4) % 4)
            try:
                decoded = base64.b64decode(padded)
                print(f"  Decoded len: {len(decoded)}")
                print(f"  Decoded[:8]: {decoded[:8]}")
                if decoded[:8] == b'NTLMSSP\x00':
                    msg_type = struct.unpack('<I', decoded[8:12])[0]
                    print(f"  NTLM Type: {msg_type}")
            except Exception as e:
                print(f"  Decode failed: {e}")
