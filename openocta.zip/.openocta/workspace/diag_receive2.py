#!/usr/bin/env python3
"""WinRM Receive - try CommandId as attribute of Receive (per MS-WSMV spec)"""

import requests
from requests.auth import HTTPBasicAuth
import uuid
import time
import xml.etree.ElementTree as ET
import base64

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def uid(): return f"uuid:{str(uuid.uuid4()).upper()}"

def find_tag(xml_text, tag_name):
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name and elem.text:
            return elem.text
    return None

auth = HTTPBasicAuth(USER, PASS)
hdrs = {'Content-Type': 'application/soap+xml; charset=UTF-8'}

# Create shell
create = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OptionSet xmlns:x="http://www.w3.org/2001/XMLSchema-instance">
      <w:Option Name="WINRS_NOPROFILE" x:type="xs:boolean">false</w:Option>
      <w:Option Name="WINRS_CODEPAGE" x:type="xs:int">65001</w:Option>
    </w:OptionSet>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

r = requests.post(URL, data=create, auth=auth, headers=hdrs, timeout=15)
shell_id = find_tag(r.text, 'ShellId')
print(f"ShellId: {shell_id}")

# Command
cmd = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>cmd.exe</rsp:Command>
      <rsp:Arguments>/c whoami</rsp:Arguments>
    </rsp:CommandLine>
  </s:Body>
</s:Envelope>'''

r2 = requests.post(URL, data=cmd, auth=auth, headers=hdrs, timeout=30)
command_id = find_tag(r2.text, 'CommandId')
print(f"CommandId: {command_id}")

time.sleep(3)

# Try different Receive formats
formats = [
    # Format A: CommandId as attribute of Receive
    ("A: CommandId as attr", f'''<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell" CommandId="{command_id}">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
    </rsp:Receive>'''),
    
    # Format B: DesiredStream as attribute  
    ("B: DesiredStream as attr", f'''<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream CommandId="{command_id}">stdout stderr</rsp:DesiredStream>
    </rsp:Receive>'''),
    
    # Format C: Both CommandId and DesiredStream as per MS-WSMV
    ("C: MS-WSMV style", f'''<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell" CommandId="{command_id}">
      <rsp:DesiredStream CommandId="{command_id}">stdout stderr</rsp:DesiredStream>
    </rsp:Receive>'''),

    # Format D: Simplest - no CommandId at all
    ("D: Minimal", '''<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
    </rsp:Receive>'''),
]

for name, body in formats:
    rcv = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    {body}
  </s:Body>
</s:Envelope>'''
    
    r3 = requests.post(URL, data=rcv, auth=auth, headers=hdrs, timeout=15)
    print(f"\n--- {name}: HTTP {r3.status_code} ---")
    if r3.status_code == 200:
        stdout_parts, stderr_parts = [], []
        for elem in ET.fromstring(r3.text).iter():
            local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if local == 'Stream' and elem.text:
                stream_name = elem.attrib.get('Name', '')
                decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                print(f"  {stream_name}: {decoded.strip()}")
            elif local in ('ExitCode', 'State') and elem.text:
                print(f"  {local}: {elem.text}")
    else:
        for elem in ET.fromstring(r3.content).iter():
            local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if local in ('Text', 'Message') and elem.text and elem.text.strip():
                print(f"  {local}: {elem.text.strip()[:200]}")

# Cleanup
del_soap = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>'''
requests.post(URL, data=del_soap, auth=auth, headers=hdrs, timeout=10)
