#!/usr/bin/env python3
"""Debug WinRM command execution on .193 - step by step"""
import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET
import base64, uuid, time

URL = "http://172.17.3.193:5985/wsman"
AUTH = HTTPBasicAuth("administrator", "admin!123")
CONTENT_TYPE = 'application/soap+xml; charset=UTF-8'
SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'

def soap(action, body, selectors=None):
    msg_id = str(uuid.uuid4())
    sid = str(uuid.uuid4())
    res = f'<w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>'
    sel = ''
    if selectors:
        sel = '<w:SelectorSet>' + ''.join(f'<w:Selector Name="{k}">{v}</w:Selector>' for k,v in selectors.items()) + '</w:SelectorSet>'
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
<s:Header>
<a:Action>{action}</a:Action>
<a:To>{URL}</a:To>
<w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
<a:MessageID>uuid:{msg_id}</a:MessageID>
<a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
{res}{sel}
<w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
<p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
<p:SessionId mustUnderstand="false">uuid:{sid}</p:SessionId>
</s:Header>
<s:Body>{body}</s:Body>
</s:Envelope>'''

def post(action, body, selectors=None, timeout=20):
    env = soap(action, body, selectors)
    r = requests.post(URL, auth=AUTH, headers={'Content-Type': CONTENT_TYPE}, data=env, verify=False, timeout=timeout)
    return r

# Step 1: Create Shell
print("=== Step 1: Create Shell ===")
r = post('http://schemas.xmlsoap.org/ws/2004/09/transfer/Create',
    '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>')
print(f"Status: {r.status_code}")
if r.status_code != 200:
    print(r.text[:500])
    exit(1)

root = ET.fromstring(r.content)
shell_id = None
for e in root.iter():
    if e.get('Name') == 'ShellId' and e.text:
        shell_id = e.text
print(f"ShellId: {shell_id}")

# Step 2: Execute a simple command (cmd.exe /c echo hello)
print("\n=== Step 2: Execute Command ===")
cmd = 'cmd.exe /c echo hello'
r = post('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command',
    f'<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>{cmd}</rsp:Command></rsp:CommandLine>',
    selectors={'ShellId': shell_id})
print(f"Status: {r.status_code}")
if r.status_code != 200:
    print(r.text[:500])
    exit(1)

root = ET.fromstring(r.content)
cmd_id = None
for e in root.iter():
    t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
    if t == 'CommandId' and e.text:
        cmd_id = e.text
print(f"CommandId: {cmd_id}")

# Step 3: Wait and receive
print("\n=== Step 3: Receive Output ===")
time.sleep(2)
r = post('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive',
    '<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream>stdout stderr</rsp:DesiredStream></rsp:Receive>',
    selectors={'ShellId': shell_id}, timeout=25)
print(f"Status: {r.status_code}")
print(f"Content length: {len(r.content)}")

# Parse output
root = ET.fromstring(r.content)
print("\n--- All elements with text ---")
for e in root.iter():
    t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
    if e.text and e.text.strip():
        txt = e.text.strip()
        if t == 'Stream':
            try:
                decoded = base64.b64decode(txt).decode('utf-8', errors='replace')
                print(f"  {t} (decoded): {decoded}")
            except:
                print(f"  {t} (raw): {txt[:200]}")
        else:
            print(f"  {t}: {txt[:200]}")

# Step 4: Signal
print("\n=== Step 4: Signal ===")
r = post('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal',
    '<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code></rsp:Signal>',
    selectors={'ShellId': shell_id})
print(f"Status: {r.status_code}")

# Step 5: Delete
print("\n=== Step 5: Delete Shell ===")
r = post('http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', '',
    selectors={'ShellId': shell_id})
print(f"Status: {r.status_code}")
