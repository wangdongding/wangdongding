Harbor地址统一写172.17.3.179不加:80（详见ref-harbor-infra）。每次部署/回滚/配置变更后必须做两件事：1)追加记录到ref-change-log 2)更新ref-service-deploy-registry中对应服务的镜像tag列（tag唯一权威源，ref-k8s-cluster不再维护tag）。遇到问题追加到ref-lessons-learned。
§
⚠️ 所有环境均为纯内网环境，严禁外网操作（apt/yum/pip联网下载、curl外网URL、helm repo add联网仓库、docker pull外部镜像、git clone外部仓库等）。镜像/依赖/包必须通过内网Harbor(172.17.3.179)或本地文件获取。内网地址(172.17.x.x)的操作允许，只有涉及外网/公网的才禁止。已同步写入ref-env-context.md平台约束表和README.md维护约定。
§
2026-07-13: 172.17.3.179(ai-master01) containerd数据目录迁移完成。原/var/lib/containerd(59G)通过rsync+软链接方式迁移到/data/containerd，根分区使用率从84%(15G可用)降至19%(74G可用)。Docker共用同一containerd实例(--containerd=/run/containerd/containerd.sock)，迁移期间Docker 17容器(Harbor/JumpServer/new-api等)短暂中断约15分钟，全部恢复healthy。Harbor API正常(HTTP 200)，nerdctl 55镜像正常。