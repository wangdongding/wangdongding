#!/usr/bin/env python3
"""Debug WinRM Receive output - check raw XML response"""

import requests
from requests.auth import HTTPBasicAuth
import uuid
import time
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def uid(): return f"uuid:{str(uuid.uuid4()).upper()}"

def soap_post(action, body_extra, shell_id=None):
    sel = f'<w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>' if shell_id else ""
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>{action}</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    {sel}
  </s:Header>
  <s:Body>{body_extra}</s:Body>
</s:Envelope>'''

def find_tag(xml_text, tag_name):
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name and elem.text:
            return elem.text
    return None

auth = HTTPBasicAuth(USER, PASS)
hdrs = {'Content-Type': 'application/soap+xml; charset=UTF-8'}

# Create shell
body = '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>'
r = requests.post(URL, data=soap_post("http://schemas.xmlsoap.org/ws/2004/09/transfer/Create", body), auth=auth, headers=hdrs, timeout=15)
shell_id = find_tag(r.text, 'ShellId')
print(f"ShellId: {shell_id}")

# Execute simple command
cmd_body = '<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>cmd.exe</rsp:Command><rsp:Arguments>/c echo hello</rsp:Arguments></rsp:CommandLine>'
r2 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command", cmd_body, shell_id=shell_id), auth=auth, headers=hdrs, timeout=30)
command_id = find_tag(r2.text, 'CommandId')
print(f"CommandId: {command_id}")

# Wait and receive
time.sleep(3)
rcv = f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream>stdout stderr</rsp:DesiredStream><rsp:CommandId>{command_id}</rsp:CommandId></rsp:Receive>'
r3 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive", rcv, shell_id=shell_id), auth=auth, headers=hdrs, timeout=15)
print(f"\nReceive: HTTP {r3.status_code}")
print(f"Response length: {len(r3.text)}")

# Print raw response (truncated)
print("\n--- Raw response (first 2000 chars) ---")
print(r3.text[:2000])

# Also try to parse
if r3.status_code == 200:
    root = ET.fromstring(r3.content)
    print("\n--- All elements with text ---")
    for elem in root.iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if elem.text and elem.text.strip() and local not in ('Action', 'MessageID', 'To', 'RelatesTo', 'Address'):
            text = elem.text.strip()[:200]
            print(f"  {local}: {text}")
        if elem.attrib:
            for k, v in elem.attrib.items():
                klocal = k.split('}')[-1] if '}' in k else k
                if klocal in ('Name', 'State', 'ExitCode'):
                    print(f"  @{klocal} = {v}")

# Delete
requests.post(URL, data=soap_post("http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete", "", shell_id=shell_id), auth=auth, headers=hdrs, timeout=10)
