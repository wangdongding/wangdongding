#!/usr/bin/env python3
"""WinRM client - fixed Receive with CommandId"""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET
import base64, uuid, time, sys

CONTENT_TYPE = 'application/soap+xml; charset=UTF-8'
SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'

def soap(action, body, selectors=None, option_set=None):
    msg_id = str(uuid.uuid4())
    sid = str(uuid.uuid4())
    res = f'<w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>'
    sel = ''
    if selectors:
        sel = '<w:SelectorSet>' + ''.join(f'<w:Selector Name="{k}">{v}</w:Selector>' for k,v in selectors.items()) + '</w:SelectorSet>'
    opt = ''
    if option_set:
        opt = '<w:OptionSet>' + ''.join(f'<w:Option Name="{k}">{v}</w:Option>' for k,v in option_set.items()) + '</w:OptionSet>'
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
<s:Header>
<a:Action>{action}</a:Action>
<a:To>http://172.17.3.193:5985/wsman</a:To>
<w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
<a:MessageID>uuid:{msg_id}</a:MessageID>
<a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
{res}{sel}{opt}
<w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
<p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
<p:SessionId mustUnderstand="false">uuid:{sid}</p:SessionId>
</s:Header>
<s:Body>{body}</s:Body>
</s:Envelope>'''

def run_ps(ps_cmd):
    URL = "http://172.17.3.193:5985/wsman"
    AUTH = HTTPBasicAuth("administrator", "admin!123")
    
    encoded = base64.b64encode(ps_cmd.encode('utf-16-le')).decode('ascii')
    cmd = f'powershell -NoProfile -NonInteractive -EncodedCommand {encoded}'
    
    # Create Shell
    r = requests.post(URL, auth=AUTH, headers={'Content-Type': CONTENT_TYPE},
        data=soap('http://schemas.xmlsoap.org/ws/2004/09/transfer/Create',
            '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>'),
        verify=False, timeout=15)
    if r.status_code != 200: return f"[CreateShell HTTP {r.status_code}]"
    root = ET.fromstring(r.content)
    shell_id = next((e.text for e in root.iter() if e.get('Name')=='ShellId' and e.text), None)
    if not shell_id: return "[No ShellId]"
    
    # Execute
    r = requests.post(URL, auth=AUTH, headers={'Content-Type': CONTENT_TYPE},
        data=soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command',
            f'<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>{cmd}</rsp:Command></rsp:CommandLine>',
            selectors={'ShellId': shell_id}),
        verify=False, timeout=15)
    if r.status_code != 200:
        # cleanup
        requests.post(URL, auth=AUTH, headers={'Content-Type': CONTENT_TYPE},
            data=soap('http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', '', selectors={'ShellId': shell_id}), verify=False, timeout=10)
        return f"[Exec HTTP {r.status_code}]"
    root = ET.fromstring(r.content)
    cmd_id = None
    for e in root.iter():
        t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
        if t == 'CommandId' and e.text: cmd_id = e.text; break
    if not cmd_id: return "[No CommandId]"
    
    # Wait for command to complete
    time.sleep(2)
    
    # Receive - include CommandId in the DesiredStream
    r = requests.post(URL, auth=AUTH, headers={'Content-Type': CONTENT_TYPE},
        data=soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive',
            f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream CommandId="{cmd_id}">stdout stderr</rsp:DesiredStream></rsp:Receive>',
            selectors={'ShellId': shell_id}),
        verify=False, timeout=25)
    output = ""
    if r.status_code == 200:
        root = ET.fromstring(r.content)
        for e in root.iter():
            t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
            if t == 'Stream' and e.text:
                try: output += base64.b64decode(e.text).decode('utf-8', errors='replace')
                except: pass
    else:
        output = f"[Receive HTTP {r.status_code}]"
    
    # Signal
    requests.post(URL, auth=AUTH, headers={'Content-Type': CONTENT_TYPE},
        data=soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal',
            '<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code></rsp:Signal>',
            selectors={'ShellId': shell_id}),
        verify=False, timeout=10)
    
    # Delete
    requests.post(URL, auth=AUTH, headers={'Content-Type': CONTENT_TYPE},
        data=soap('http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', '', selectors={'ShellId': shell_id}),
        verify=False, timeout=10)
    
    return output.strip() if output.strip() else "[No output]"

# === Run diagnostics on .193 ===
print("=" * 70)
print("  172.17.3.193 (PROBLEMATIC SERVER)")
print("=" * 70)

tests = [
    ("Echo Test", "echo hello"),
    ("WinRM Auth", "winrm get winrm/config/service/auth"),
    ("WinRM Service", "winrm get winrm/config/service"),
    ("UAC-LocalAccountTokenFilterPolicy", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name LocalAccountTokenFilterPolicy -EA 0 | Select -Exp LocalAccountTokenFilterPolicy}catch{'NOT SET(0)'}"),
    ("UAC-FilterAdministratorToken", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name FilterAdministratorToken -EA 0 | Select -Exp FilterAdministratorToken}catch{'NOT SET(0)'}"),
    ("UAC-EnableLUA", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name EnableLUA -EA 0 | Select -Exp EnableLUA}catch{'NOT SET'}"),
    ("CredSSP", "Get-WSManCredSSP 2>&1 | Out-String"),
    ("OS Version", "(Get-WmiObject Win32_OperatingSystem).Caption + ' ' + [System.Environment]::OSVersion.Version.ToString()"),
    ("User", "whoami"),
    ("User Groups", "whoami /groups"),
    ("Local Admins", "net localgroup Administrators"),
]

for name, cmd in tests:
    print(f"\n--- {name} ---")
    try:
        result = run_ps(cmd)
        print(result[:1500])
    except Exception as e:
        print(f"ERROR: {e}")
    sys.stdout.flush()
