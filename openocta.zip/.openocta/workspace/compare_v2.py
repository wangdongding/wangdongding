#!/usr/bin/env python3
"""Read-only WinRM config comparison - 172.17.3.88 vs 172.17.3.193
Fixed: Added ReplyTo header required by WinRM"""
import requests, uuid, xml.etree.ElementTree as ET, base64, time

ANON = "http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous"

def winrm_get(host, user, password, resource_uri, timeout=15):
    """Read-only WinRM Get operation"""
    url = f"http://{host}:5985/wsman"
    msg_id = str(uuid.uuid4())
    soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Get</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI>{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
  </s:Header>
  <s:Body/>
</s:Envelope>"""
    
    session = requests.Session()
    session.auth = requests.auth.HTTPBasicAuth(user, password)
    try:
        r = session.post(url, data=soap.encode('utf-8'),
                        headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                        timeout=timeout)
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            lines = []
            for elem in root.iter():
                tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
                if elem.text and elem.text.strip():
                    lines.append(f"  {tag} = {elem.text.strip()}")
            return '\n'.join(lines) if lines else "[Empty response]"
        else:
            # Parse error
            try:
                root = ET.fromstring(r.content)
                for elem in root.iter():
                    tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
                    if 'Message' in tag and elem.text:
                        return f"[HTTP {r.status_code}] {elem.text.strip()}"
                return f"[HTTP {r.status_code}]"
            except:
                return f"[HTTP {r.status_code}] {r.text[:300]}"
    except Exception as e:
        return f"[ERROR] {e}"

def winrm_exec(host, user, password, ps_command, timeout=25):
    """Execute a read-only PowerShell command via WinRM"""
    url = f"http://{host}:5985/wsman"
    resource_uri = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"
    
    session = requests.Session()
    session.auth = requests.auth.HTTPBasicAuth(user, password)
    
    # Step 1: Create Shell
    msg_id = str(uuid.uuid4())
    create_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <p:OptionSet>
      <p:Option Name="WINRS_NOPROFILE" Value="FALSE"/>
    </p:OptionSet>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>"""
    
    r = session.post(url, data=create_soap.encode('utf-8'),
                    headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                    timeout=timeout)
    if r.status_code != 200:
        return f"[Create HTTP {r.status_code}]"
    
    root = ET.fromstring(r.content)
    shell_id = None
    for elem in root.iter():
        if 'ShellId' in elem.tag:
            shell_id = elem.text
            break
    if not shell_id:
        return "[No ShellId]"
    
    # Step 2: Execute Command
    encoded = base64.b64encode(ps_command.encode('utf-16-le')).decode('ascii')
    msg_id = str(uuid.uuid4())
    exec_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>powershell.exe</rsp:Command>
      <rsp:Arguments>-NoProfile -NonInteractive -EncodedCommand {encoded}</rsp:Arguments>
    </rsp:CommandLine>
  </s:Body>
</s:Envelope>"""
    
    r = session.post(url, data=exec_soap.encode('utf-8'),
                    headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                    timeout=timeout)
    if r.status_code != 200:
        return f"[Exec HTTP {r.status_code}]"
    
    root = ET.fromstring(r.content)
    command_id = None
    for elem in root.iter():
        if 'CommandId' in elem.tag:
            command_id = elem.text
            break
    if not command_id:
        return "[No CommandId]"
    
    # Step 3: Receive
    time.sleep(3)
    output = ""
    for _ in range(10):
        msg_id = str(uuid.uuid4())
        recv_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
    </rsp:Receive>
  </s:Body>
</s:Envelope>"""
        
        r = session.post(url, data=recv_soap.encode('utf-8'),
                        headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                        timeout=timeout)
        if r.status_code != 200:
            break
        
        root = ET.fromstring(r.content)
        done = False
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if tag == 'Stream' and elem.text:
                try:
                    decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                    output += decoded
                except:
                    pass
            if tag == 'CommandState':
                if 'Done' in elem.attrib.get('State', ''):
                    done = True
        if done:
            break
        time.sleep(2)
    
    # Cleanup
    try:
        msg_id = str(uuid.uuid4())
        del_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI>{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>"""
        session.post(url, data=del_soap.encode('utf-8'),
                    headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                    timeout=5)
    except:
        pass
    
    return output.strip() if output.strip() else "[No output]"


# ============ MAIN ============
servers = [
    {"host": "172.17.3.88", "user": "Compiler", "password": "Yuwei@2505", "label": "OLD (working)"},
    {"host": "172.17.3.193", "user": "administrator", "password": "admin!123", "label": "NEW (broken)"},
]

# First, try WinRM Get (read-only, no shell needed) - works with Basic auth
print("=" * 80)
print("PART 1: WinRM Config via SOAP Get (read-only)")
print("=" * 80)

config_uris = [
    ("WinRM Service Auth", "http://schemas.microsoft.com/wbem/wsman/1/config/service/auth"),
    ("WinRM Service", "http://schemas.microsoft.com/wbem/wsman/1/config/service"),
    ("WinRM WinRS", "http://schemas.microsoft.com/wbem/wsman/1/config/winrs"),
    ("WinRM Client Auth", "http://schemas.microsoft.com/wbem/wsman/1/config/client/auth"),
]

for name, uri in config_uris:
    print(f"\n{'='*60}")
    print(f"[{name}]")
    print(f"{'='*60}")
    for srv in servers:
        print(f"\n--- {srv['label']} ({srv['host']}) ---")
        result = winrm_get(srv['host'], srv['user'], srv['password'], uri)
        print(result)

# Then, try executing commands on .193 (Basic auth works)
print("\n\n" + "=" * 80)
print("PART 2: PowerShell read-only commands on 172.17.3.193")
print("=" * 80)

ps_commands = [
    ("UAC - LocalAccountTokenFilterPolicy", r"reg query 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v LocalAccountTokenFilterPolicy 2>&1; if(-not $?){Write-Output '[NOT FOUND]'}"),
    ("UAC - FilterAdministratorToken", r"reg query 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v FilterAdministratorToken 2>&1; if(-not $?){Write-Output '[NOT FOUND]'}"),
    ("UAC - EnableLUA", r"reg query 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v EnableLUA 2>&1"),
    ("WhoAmI", "whoami"),
    ("Admin Group Members", "net localgroup Administrators"),
    ("OS Version", "[System.Environment]::OSVersion.VersionString"),
]

for name, cmd in ps_commands:
    print(f"\n{'='*60}")
    print(f"[{name}] on 172.17.3.193")
    print(f"{'='*60}")
    result = winrm_exec("172.17.3.193", "administrator", "admin!123", cmd)
    print(result)

print("\n\nDONE - All checks are READ-ONLY")
