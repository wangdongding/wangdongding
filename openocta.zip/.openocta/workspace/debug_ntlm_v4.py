#!/usr/bin/env python3
"""Manual NTLM debug - check each step"""

import requests, base64, struct, hashlib, hmac, os, time

def md4(data):
    def F(x,y,z): return (x&y)|(~x&z)
    def G(x,y,z): return (x&y)|(x&z)|(y&z)
    def H(x,y,z): return x^y^z
    def lr(n,b): return ((n<<b)|(n>>(32-b)))&0xFFFFFFFF
    msg=bytearray(data); ol=len(data); msg.append(0x80)
    while len(msg)%64!=56: msg.append(0)
    msg+=struct.pack('<Q',ol*8)
    a0,b0,c0,d0=0x67452301,0xefcdab89,0x98badcfe,0x10325476
    for i in range(0,len(msg),64):
        X=[struct.unpack('<I',msg[i+j:i+j+4])[0] for j in range(0,64,4)]
        a,b,c,d=a0,b0,c0,d0
        for k in range(16):
            if k%4==0: a=lr((a+F(b,c,d)+X[k])&0xFFFFFFFF,3)
            elif k%4==1: d=lr((d+F(a,b,c)+X[k])&0xFFFFFFFF,7)
            elif k%4==2: c=lr((c+F(d,a,b)+X[k])&0xFFFFFFFF,11)
            elif k%4==3: b=lr((b+F(c,d,a)+X[k])&0xFFFFFFFF,19)
        order2=[0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]
        for idx,k in enumerate(order2):
            if idx%4==0: a=lr((a+G(b,c,d)+X[k]+0x5A827999)&0xFFFFFFFF,3)
            elif idx%4==1: d=lr((d+G(a,b,c)+X[k]+0x5A827999)&0xFFFFFFFF,5)
            elif idx%4==2: c=lr((c+G(d,a,b)+X[k]+0x5A827999)&0xFFFFFFFF,9)
            elif idx%4==3: b=lr((b+G(c,d,a)+X[k]+0x5A827999)&0xFFFFFFFF,13)
        order3=[0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]
        for idx,k in enumerate(order3):
            if idx%4==0: a=lr((a+H(b,c,d)+X[k]+0x6ED9EBA1)&0xFFFFFFFF,3)
            elif idx%4==1: d=lr((d+H(a,b,c)+X[k]+0x6ED9EBA1)&0xFFFFFFFF,9)
            elif idx%4==2: c=lr((c+H(d,a,b)+X[k]+0x6ED9EBA1)&0xFFFFFFFF,11)
            elif idx%4==3: b=lr((b+H(c,d,a)+X[k]+0x6ED9EBA1)&0xFFFFFFFF,15)
        a0=(a0+a)&0xFFFFFFFF;b0=(b0+b)&0xFFFFFFFF;c0=(c0+c)&0xFFFFFFFF;d0=(d0+d)&0xFFFFFFFF
    return struct.pack('<4I',a0,b0,c0,d0)

# Use a session to maintain TCP connection
s = requests.Session()
URL = "http://172.17.3.88:5985/wsman"
USER = "Compiler"
PASS = "Yuwei@2505"
DOMAIN = "WIN-3Q977300URH"

# Step 1: Type 1
t1 = base64.b64encode(b'NTLMSSP\x00'+struct.pack('<I',1)+struct.pack('<I',0xE20882B7)+struct.pack('<HHI',0,0,32)+struct.pack('<HHI',0,0,32)).decode()
print(f"Type1: {t1}")
r1 = s.post(URL, headers={'Content-Type':'application/soap+xml; charset=UTF-8','Authorization':f'Negotiate {t1}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
print(f"Type1 response: {r1.status_code}")

auth = r1.headers.get('WWW-Authenticate','')
challenge = None
for p in auth.split(','):
    p = p.strip()
    if p.startswith('Negotiate ') and len(p) > 10: challenge = p[10:]; break
if not challenge:
    print("No challenge!")
    exit(1)

d = base64.b64decode(challenge)
server_chal = d[24:32]
ti_len = struct.unpack('<H', d[40:42])[0]
ti_off = struct.unpack('<I', d[44:48])[0]
target_info = d[ti_off:ti_off+ti_len]
neg_flags = struct.unpack('<I', d[20:24])[0]
print(f"NegFlags: {neg_flags:#010x}")
print(f"Server challenge: {server_chal.hex()}")

# Step 3: Build Type3
nt_h = md4(PASS.encode('utf-16-le'))
client_chal = os.urandom(8)

# NTLMv2
temp = hmac.new(nt_h, (USER.upper()+DOMAIN).encode('utf-16-le'), hashlib.md5).digest()
blob = bytearray()
blob += b'\x01\x01\x00\x00\x00\x00\x00\x00'  # signature + reserved
blob += struct.pack('<Q', int(time.time()) + 11644473600)  # timestamp
blob += client_chal + b'\x00\x00\x00\x00' + target_info  # client_chal + reserved + target_info
ntproof = hmac.new(temp, server_chal + bytes(blob), hashlib.md5).digest()
nt_resp = ntproof + bytes(blob)
lm_resp = hmac.new(temp, server_chal + client_chal, hashlib.md5).digest() + client_chal

dom_enc = DOMAIN.upper().encode('utf-16-le')
usr_enc = USER.encode('utf-16-le')
ws_enc = DOMAIN.upper().encode('utf-16-le')

# MIC calculation (required for NTLMv2 with security flags)
# MIC = HMAC-MD5(Session Base Key, Type1 + Type2 + Type3_without_MIC)
# For now, skip MIC

base_off = 88
lm_off = base_off; nt_off = lm_off + len(lm_resp)
dom_off = nt_off + len(nt_resp); usr_off = dom_off + len(dom_enc)
ws_off = usr_off + len(usr_enc); sess_off = ws_off + len(ws_enc)

# Flags: include NTLMSSP_NEGOTIATE_TARGET_INFO (0x00200000) and NTLMSSP_NEGOTIATE_VERSION (0x02000000)
flags = 0xE20882B7

t3 = bytearray()
t3 += b'NTLMSSP\x00' + struct.pack('<I',3)
t3 += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
t3 += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
t3 += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
t3 += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
t3 += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off)
t3 += struct.pack('<HHI', 0, 0, sess_off)  # Encrypted random session key
t3 += struct.pack('<I', flags)
t3 += struct.pack('<Q', 0x0000000F00000001)  # Version: Windows 10.0 Build 19041
t3 += lm_resp + nt_resp + dom_enc + usr_enc + ws_enc

t3_b64 = base64.b64encode(bytes(t3)).decode()
print(f"Type3 length: {len(t3)} bytes, b64: {len(t3_b64)} chars")

# Send Type3
r3 = s.post(URL, headers={'Content-Type':'application/soap+xml; charset=UTF-8','Authorization':f'Negotiate {t3_b64}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
print(f"Type3 response: {r3.status_code}")
if r3.status_code != 401:
    print(f"SUCCESS! Content: {r3.text[:300]}")
else:
    print("Still 401. Let me try with empty domain...")
    # Try with empty domain
    temp2 = hmac.new(nt_h, (USER.upper()+'').encode('utf-16-le'), hashlib.md5).digest()
    blob2 = bytearray()
    blob2 += b'\x01\x01\x00\x00\x00\x00\x00\x00'
    blob2 += struct.pack('<Q', int(time.time()) + 11644473600)
    blob2 += client_chal + b'\x00\x00\x00\x00' + target_info
    ntproof2 = hmac.new(temp2, server_chal + bytes(blob2), hashlib.md5).digest()
    nt_resp2 = ntproof2 + bytes(blob2)
    lm_resp2 = hmac.new(temp2, server_chal + client_chal, hashlib.md5).digest() + client_chal
    
    dom_enc2 = ''.encode('utf-16-le')
    usr_enc2 = USER.encode('utf-16-le')
    ws_enc2 = ''.encode('utf-16-le')
    base_off2 = 88
    lm_off2 = base_off2; nt_off2 = lm_off2 + len(lm_resp2)
    dom_off2 = nt_off2 + len(nt_resp2); usr_off2 = dom_off2 + len(dom_enc2)
    ws_off2 = usr_off2 + len(usr_enc2); sess_off2 = ws_off2 + len(ws_enc2)
    
    t3b = bytearray()
    t3b += b'NTLMSSP\x00' + struct.pack('<I',3)
    t3b += struct.pack('<HHI', len(lm_resp2), len(lm_resp2), lm_off2)
    t3b += struct.pack('<HHI', len(nt_resp2), len(nt_resp2), nt_off2)
    t3b += struct.pack('<HHI', len(dom_enc2), len(dom_enc2), dom_off2)
    t3b += struct.pack('<HHI', len(usr_enc2), len(usr_enc2), usr_off2)
    t3b += struct.pack('<HHI', len(ws_enc2), len(ws_enc2), ws_off2)
    t3b += struct.pack('<HHI', 0, 0, sess_off2)
    t3b += struct.pack('<I', flags)
    t3b += struct.pack('<Q', 0x0000000F00000001)
    t3b += lm_resp2 + nt_resp2 + dom_enc2 + usr_enc2 + ws_enc2
    
    r4 = s.post(URL, headers={'Content-Type':'application/soap+xml; charset=UTF-8','Authorization':f'Negotiate {base64.b64encode(bytes(t3b)).decode()}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
    print(f"Empty domain result: {r4.status_code}")
