#!/usr/bin/env python3
"""Compare WinRM configs using SPNEGO/Negotiate auth (NTLM)"""
import requests, uuid, time, xml.etree.ElementTree as ET, base64, hashlib, hmac, struct, socket, ssl

# ============ NTLM Auth Implementation ============
def ntlm_type1(domain=''):
    """Generate NTLM Type 1 (Negotiate) message"""
    flags = 0x00088215  # NEGOTIATE + NTLM + REQUEST_TARGET + UNICODE + OEM + ALWAYS_SIGN
    if domain:
        flags |= 0x00001000  # DOMAIN_PRESENT
    msg = struct.pack('<I', 0x00000001)  # Type 1
    msg += struct.pack('<I', flags)
    if domain:
        dom_enc = domain.encode('utf-16-le') if flags & 0x00000001 else domain.encode('ascii')
        msg += struct.pack('<HHI', len(dom_enc), len(dom_enc), 32 + len(msg))
        msg += dom_enc
    return base64.b64encode(b'NTLMSSP\x00' + msg).decode()

def ntlm_type3(username, password, domain, server_challenge, target_info):
    """Generate NTLM Type 3 (Auth) message"""
    # NTLMv2 response
    nt_proof_str, nt_response = ntlmv2_response(username, password, domain, server_challenge, target_info)
    lm_response = b'\x00' * 24  # LMv2 dummy
    
    domain_enc = domain.encode('utf-16-le')
    user_enc = username.encode('utf-16-le')
    workstation_enc = socket.gethostname().encode('utf-16-le')
    
    flags = 0x00088215
    
    # Build Type 3 message
    base_offset = 64 + len(lm_response) + len(nt_response)
    
    msg = b'NTLMSSP\x00'
    msg += struct.pack('<I', 3)  # Type 3
    
    # LM response
    msg += struct.pack('<HHI', len(lm_response), len(lm_response), 64)
    # NT response
    msg += struct.pack('<HHI', len(nt_response), len(nt_response), 64 + len(lm_response))
    # Domain
    msg += struct.pack('<HHI', len(domain_enc), len(domain_enc), base_offset)
    # User
    msg += struct.pack('<HHI', len(user_enc), len(user_enc), base_offset + len(domain_enc))
    # Workstation
    msg += struct.pack('<HHI', len(workstation_enc), len(workstation_enc), base_offset + len(domain_enc) + len(user_enc))
    # Session key (empty)
    msg += struct.pack('<HHI', 0, 0, 0)
    # Flags
    msg += struct.pack('<I', flags)
    # Version (Windows 10.0 Build 19041)
    msg += struct.pack('<BBH', 10, 0, 19041)
    msg += b'\x00' * 8  # MIC placeholder
    
    # Add payloads
    msg += lm_response
    msg += nt_response
    msg += domain_enc
    msg += user_enc
    msg += workstation_enc
    
    return base64.b64encode(msg).decode()

def ntlmv2_response(username, password, domain, server_challenge, target_info):
    """Calculate NTLMv2 response"""
    # Derive NTLMv2 hash
    nt_hash = ntowfv1(password)
    nt_hash_hmac = hmac.new(nt_hash, (username.upper() + domain).encode('utf-16-le'), hashlib.md5).digest()
    
    # Build temp
    temp = target_info
    # Add terminator if not present
    temp += struct.pack('<HH', 0, 0)
    
    # NTProofStr = HMAC_MD5(NTLMv2Hash, ServerChallenge + temp)
    blob = server_challenge + b'\x01\x00\x00\x00' + struct.pack('<Q', int(time.time())) + b'\x00' * 8 + temp
    nt_proof = hmac.new(nt_hash_hmac, server_challenge + blob, hashlib.md5).digest()
    
    return nt_proof, nt_proof + blob

def ntowfv1(password):
    """NT hash (MD4 of UTF-16-LE password)"""
    try:
        from hashlib import new as hashlib_new
        return hashlib_new('md4', password.encode('utf-16-le')).digest()
    except:
        # Fallback: manual MD4
        import Crypto.Hash.MD4
        return Crypto.Hash.MD4.new(password.encode('utf-16-le')).digest()

def parse_ntlm_type2(challenge_b64):
    """Parse NTLM Type 2 message to extract server challenge and target info"""
    raw = base64.b64decode(challenge_b64)
    # Skip signature and type
    server_challenge = raw[24:32]
    target_info = b''
    
    if len(raw) > 48:
        flags = struct.unpack_from('<I', raw, 20)[0]
        if flags & 0x00004000:  # TARGET_INFO
            # Get target info from offset
            ti_len = struct.unpack_from('<H', raw, 40)[0]
            ti_off = struct.unpack_from('<I', raw, 44)[0]
            target_info = raw[ti_off:ti_off + ti_len]
    
    return server_challenge, target_info


def run_ps_ntlm(host, user, password, ps_cmd, timeout=30):
    """Execute PowerShell via WinRM using NTLM auth"""
    url = f"http://{host}:5985/wsman"
    headers = {'Content-Type': 'application/soap+xml; charset=UTF-8'}
    
    # Split user\domain
    if '\\' in user:
        domain, username = user.split('\\', 1)
    else:
        domain = ''
        username = user
    
    # Step 0: NTLM handshake
    # Type 1
    type1 = ntlm_type1(domain)
    h1 = headers.copy()
    h1['Authorization'] = f'Negotiate {type1}'
    
    shell_soap = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:{uuid.uuid4()}</wsa:MessageID>
    <wsmv:OptionSet>
      <wsman:Option Name="WINRS_NOPROFILE" MustComply="true">FALSE</wsman:Option>
      <wsman:Option Name="WINRS_CODEPAGE" MustComply="true">65001</wsman:Option>
    </wsmv:OptionSet>
  </s:Header>
  <s:Body>
    <wsmv:Shell>
      <wsmv:InputStreams>stdin</wsmv:InputStreams>
      <wsmv:OutputStreams>stdout stderr</wsmv:OutputStreams>
    </wsmv:Shell>
  </s:Body>
</s:Envelope>'''

    # Send Type 1, expect 401 with Type 2
    r1 = requests.post(url, data=shell_soap, headers=headers, timeout=timeout)
    if r1.status_code == 200:
        # Auth succeeded with just Type 1 (unlikely)
        pass
    elif r1.status_code == 401:
        auth_header = r1.headers.get('WWW-Authenticate', '')
        # Extract Type 2 from WWW-Authenticate header
        import re
        m = re.search(r'Negotiate\s+([A-Za-z0-9+/=]+)', auth_header)
        if m:
            type2_b64 = m.group(1)
        else:
            # Try all www-authenticate headers
            for val in r1.headers.get_all('WWW-Authenticate', []) if hasattr(r1.headers, 'get_all') else [auth_header]:
                m2 = re.search(r'Negotiate\s+([A-Za-z0-9+/=]+)', val)
                if m2:
                    type2_b64 = m2.group(1)
                    break
            else:
                return f"NTLM Type 2 not found in headers: {auth_header[:200]}"
        
        try:
            server_challenge, target_info = parse_ntlm_type2(type2_b64)
        except Exception as e:
            return f"Failed to parse NTLM Type 2: {e}, raw: {type2_b64[:100]}"
        
        # Generate Type 3
        type3 = ntlm_type3(username, password, domain, server_challenge, target_info)
        h2 = headers.copy()
        h2['Authorization'] = f'Negotiate {type3}'
        
        r1 = requests.post(url, data=shell_soap, headers=h2, timeout=timeout)
        if r1.status_code != 200:
            return f"CreateShell auth failed: {r1.status_code} - {r1.text[:500]}"
    else:
        return f"CreateShell unexpected: {r1.status_code} - {r1.text[:500]}"

    # Parse shell ID
    root = ET.fromstring(r1.text)
    shell_id = None
    for elem in root.iter():
        if 'ShellId' in elem.tag:
            shell_id = elem.text
            break
    if not shell_id:
        return f"No ShellId: {r1.text[:500]}"

    # Execute command
    encoded = base64.b64encode(ps_cmd.encode('utf-16-le')).decode('ascii')
    cmd_soap = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:{uuid.uuid4()}</wsa:MessageID>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
  </s:Header>
  <s:Body>
    <wsmv:CommandLine>
      <wsmv:Command>powershell.exe</wsmv:Command>
      <wsmv:Arguments>-NoProfile -NonInteractive -EncodedCommand {encoded}</wsmv:Arguments>
    </wsmv:CommandLine>
  </s:Body>
</s:Envelope>'''

    r2 = requests.post(url, data=cmd_soap, headers=headers, timeout=timeout)
    if r2.status_code == 401:
        r2 = requests.post(url, data=cmd_soap, headers=h2, timeout=timeout)
    if r2.status_code != 200:
        return f"Command failed: {r2.status_code} - {r2.text[:500]}"

    root2 = ET.fromstring(r2.text)
    command_id = None
    for elem in root2.iter():
        if 'CommandId' in elem.tag:
            command_id = elem.text
            break
    if not command_id:
        return f"No CommandId: {r2.text[:500]}"

    # Poll for output
    time.sleep(2)
    output_text = ""
    for attempt in range(15):
        recv_soap = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:{uuid.uuid4()}</wsa:MessageID>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
  </s:Header>
  <s:Body>
    <wsmv:Receive>
      <wsmv:DesiredStream>stdout stderr</wsmv:DesiredStream>
      <wsmv:CommandId>{command_id}</wsmv:CommandId>
    </wsmv:Receive>
  </s:Body>
</s:Envelope>'''

        r3 = requests.post(url, data=recv_soap, headers=headers, timeout=timeout)
        if r3.status_code == 401:
            r3 = requests.post(url, data=recv_soap, headers=h2, timeout=timeout)
        if r3.status_code == 200:
            root3 = ET.fromstring(r3.text)
            done = False
            for elem in root3.iter():
                tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
                if tag == 'Stream':
                    if elem.text:
                        try:
                            decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                            output_text += decoded
                        except:
                            output_text += elem.text
                if tag == 'CommandState':
                    state = elem.get('State', '')
                    if 'Done' in state:
                        done = True
            if done:
                break
        time.sleep(1)

    # Cleanup shell
    del_soap = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:{uuid.uuid4()}</wsa:MessageID>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>'''
    try:
        requests.post(url, data=del_soap, headers=headers, timeout=5)
    except:
        pass

    return output_text.strip()


# ============ Main ============
servers = [
    {"host": "172.17.3.88", "user": "Compiler", "pass": "Yuwei@2605", "label": "88(正常)"},
    {"host": "172.17.3.193", "user": "administrator", "pass": "admin!123", "label": "193(卡住)"},
]

checks = [
    ("WinRM_Service_Auth", "winrm get winrm/config/service/auth"),
    ("WinRM_Service", "winrm get winrm/config/service"),
    ("CredSSP_Status", "winrm get winrm/config/service/auth"),
    ("UAC_LocalAccountTokenFilterPolicy", 'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v LocalAccountTokenFilterPolicy 2>$null; if ($LASTEXITCODE -ne 0) { Write-Output \"NOT_SET\" }'),
    ("UAC_FilterAdministratorToken", 'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v FilterAdministratorToken 2>$null; if ($LASTEXITCODE -ne 0) { Write-Output \"NOT_SET\" }'),
    ("UAC_EnableLUA", 'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v EnableLUA 2>$null; if ($LASTEXITCODE -ne 0) { Write-Output \"NOT_SET\" }'),
    ("OS_Version", "systeminfo | findstr /B /C:\"OS Name\" /C:\"OS Version\""),
    ("PS_Version", "$PSVersionTable.PSVersion.ToString()"),
    ("Admin_Group", "net localgroup Administrators"),
    ("CredSSP_Delegation", 'Get-ItemProperty -Path "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CredentialsDelegation" -ErrorAction SilentlyContinue | Format-List'),
    ("WinRM_MaxShells", "winrm get winrm/config/winrs"),
]

for name, cmd in checks:
    print(f"\n{'='*60}")
    print(f"### {name}")
    print(f"{'='*60}")
    for srv in servers:
        print(f"\n--- {srv['label']} ({srv['host']}) ---")
        try:
            result = run_ps_ntlm(srv['host'], srv['user'], srv['pass'], cmd, timeout=25)
            print(result[:2000] if result else "(empty)")
        except Exception as e:
            print(f"ERROR: {e}")
