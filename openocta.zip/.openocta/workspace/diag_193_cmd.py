#!/usr/bin/env python3
"""Get UAC settings from .193 via cmd.exe, and try to get .88 config via Negotiate"""
import requests, uuid, xml.etree.ElementTree as ET, base64, time, struct, os, hmac, hashlib

ANON = "http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous"

def winrm_exec_cmd(host, user, password, command, timeout=25):
    """Execute a command via WinRM using cmd.exe (not PowerShell)"""
    url = f"http://{host}:5985/wsman"
    resource_uri = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"
    session = requests.Session()
    session.auth = requests.auth.HTTPBasicAuth(user, password)
    
    # Create Shell
    msg_id = str(uuid.uuid4())
    create_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <p:OptionSet>
      <p:Option Name="WINRS_NOPROFILE" Value="FALSE"/>
    </p:OptionSet>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>"""
    
    r = session.post(url, data=create_soap.encode('utf-8'),
                    headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                    timeout=timeout)
    if r.status_code != 200:
        return f"[Create HTTP {r.status_code}]"
    
    root = ET.fromstring(r.content)
    shell_id = None
    for elem in root.iter():
        if 'ShellId' in elem.tag:
            shell_id = elem.text
            break
    if not shell_id:
        return "[No ShellId]"
    
    # Execute Command - use cmd.exe directly
    msg_id = str(uuid.uuid4())
    exec_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>cmd.exe</rsp:Command>
      <rsp:Arguments>/C {command}</rsp:Arguments>
    </rsp:CommandLine>
  </s:Body>
</s:Envelope>"""
    
    r = session.post(url, data=exec_soap.encode('utf-8'),
                    headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                    timeout=timeout)
    if r.status_code != 200:
        return f"[Exec HTTP {r.status_code}]"
    
    root = ET.fromstring(r.content)
    command_id = None
    for elem in root.iter():
        if 'CommandId' in elem.tag:
            command_id = elem.text
            break
    if not command_id:
        return "[No CommandId]"
    
    # Receive Output
    time.sleep(3)
    output = ""
    for _ in range(12):
        msg_id = str(uuid.uuid4())
        recv_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
    </rsp:Receive>
  </s:Body>
</s:Envelope>"""
        
        r = session.post(url, data=recv_soap.encode('utf-8'),
                        headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                        timeout=timeout)
        if r.status_code != 200:
            output += f"\n[Receive HTTP {r.status_code}]"
            break
        
        root = ET.fromstring(r.content)
        done = False
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if tag == 'Stream' and elem.text:
                try:
                    decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                    output += decoded
                except:
                    pass
            if tag == 'CommandState':
                if 'Done' in elem.attrib.get('State', ''):
                    done = True
        if done:
            break
        time.sleep(2)
    
    # Cleanup
    try:
        msg_id = str(uuid.uuid4())
        del_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI>{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>"""
        session.post(url, data=del_soap.encode('utf-8'),
                    headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                    timeout=5)
    except:
        pass
    
    return output.strip() if output.strip() else "[No output]"


# ============ MAIN ============
print("=" * 80)
print("UAC & System checks on 172.17.3.193 via WinRM cmd.exe")
print("=" * 80)

commands = [
    ("Echo Test", "echo hello"),
    ("WhoAmI", "whoami"),
    ("UAC - LocalAccountTokenFilterPolicy", r"reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v LocalAccountTokenFilterPolicy"),
    ("UAC - FilterAdministratorToken", r"reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v FilterAdministratorToken"),
    ("UAC - EnableLUA", r"reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA"),
    ("WinRM Service Auth", "winrm get winrm/config/service/auth"),
    ("WinRM Service AllowUnencrypted", "winrm get winrm/config/service"),
    ("CredSSP Status", "winrm get winrm/config/service/auth"),
    ("Admin Group Members", "net localgroup Administrators"),
    ("OS Version", "ver"),
    ("User Account Type", "whoami /all"),
    ("WinRM CredSSP Server", "winrm get winrm/config/service"),
]

for name, cmd in commands:
    print(f"\n{'='*60}")
    print(f"[{name}]")
    print(f"{'='*60}")
    result = winrm_exec_cmd("172.17.3.193", "administrator", "admin!123", cmd)
    print(result)

print("\n\nDONE - All checks are READ-ONLY")
