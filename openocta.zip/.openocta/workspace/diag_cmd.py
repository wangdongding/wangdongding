#!/usr/bin/env python3
"""Test WinRM with cmd.exe instead of powershell"""

import requests
from requests.auth import HTTPBasicAuth
import base64
import uuid
import time
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def uid(): return f"uuid:{str(uuid.uuid4()).upper()}"

def soap_post(action, body_extra, shell_id=None):
    sel = f'<w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>' if shell_id else ""
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>{action}</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    {sel}
  </s:Header>
  <s:Body>{body_extra}</s:Body>
</s:Envelope>'''

def find_tag(xml_text, tag_name):
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name and elem.text:
            return elem.text
    return None

def extract_streams(xml_text):
    stdout_parts, stderr_parts = [], []
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == 'Stream' and elem.text:
            name = elem.attrib.get('Name', '')
            decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
            if 'stdout' in name: stdout_parts.append(decoded)
            elif 'stderr' in name: stderr_parts.append(decoded)
    return ''.join(stdout_parts), ''.join(stderr_parts)

auth = HTTPBasicAuth(USER, PASS)
hdrs = {'Content-Type': 'application/soap+xml; charset=UTF-8'}

try:
    # Create shell
    body = '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>'
    r = requests.post(URL, data=soap_post("http://schemas.xmlsoap.org/ws/2004/09/transfer/Create", body), auth=auth, headers=hdrs, timeout=15)
    print(f"Create Shell: HTTP {r.status_code}")
    if r.status_code != 200:
        print(r.text[:500]); exit(1)
    shell_id = find_tag(r.text, 'ShellId')
    print(f"ShellId: {shell_id}")
    
    # Test 1: cmd.exe /c whoami
    print("\n--- Test 1: cmd.exe /c whoami ---")
    cmd_body = '<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>cmd.exe</rsp:Command><rsp:Arguments>/c whoami</rsp:Arguments></rsp:CommandLine>'
    r2 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command", cmd_body, shell_id=shell_id), auth=auth, headers=hdrs, timeout=30)
    print(f"Command: HTTP {r2.status_code}")
    command_id = find_tag(r2.text, 'CommandId')
    
    for i in range(15):
        time.sleep(0.5)
        rcv = f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream>stdout stderr</rsp:DesiredStream><rsp:CommandId>{command_id}</rsp:CommandId></rsp:Receive>'
        r3 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive", rcv, shell_id=shell_id), auth=auth, headers=hdrs, timeout=15)
        if r3.status_code == 200:
            out, err = extract_streams(r3.text)
            if out: print(f"  STDOUT: {out.strip()}")
            if err: print(f"  STDERR: {err.strip()}")
            if 'Done' in r3.text:
                print(f"  Done in {i+1} polls")
                break
    
    # Test 2: cmd.exe /c hostname
    print("\n--- Test 2: cmd.exe /c hostname ---")
    cmd_body2 = '<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>cmd.exe</rsp:Command><rsp:Arguments>/c hostname</rsp:Arguments></rsp:CommandLine>'
    r4 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command", cmd_body2, shell_id=shell_id), auth=auth, headers=hdrs, timeout=30)
    command_id2 = find_tag(r4.text, 'CommandId')
    
    for i in range(15):
        time.sleep(0.5)
        rcv2 = f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream>stdout stderr</rsp:DesiredStream><rsp:CommandId>{command_id2}</rsp:CommandId></rsp:Receive>'
        r5 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive", rcv2, shell_id=shell_id), auth=auth, headers=hdrs, timeout=15)
        if r5.status_code == 200:
            out, err = extract_streams(r5.text)
            if out: print(f"  STDOUT: {out.strip()}")
            if err: print(f"  STDERR: {err.strip()}")
            if 'Done' in r5.text:
                print(f"  Done in {i+1} polls")
                break
    
    # Test 3: PowerShell via cmd.exe
    print("\n--- Test 3: cmd.exe /c powershell -NoProfile -Command whoami ---")
    cmd_body3 = '<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>cmd.exe</rsp:Command><rsp:Arguments>/c powershell -NoProfile -Command "whoami"</rsp:Arguments></rsp:CommandLine>'
    r6 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command", cmd_body3, shell_id=shell_id), auth=auth, headers=hdrs, timeout=30)
    command_id3 = find_tag(r6.text, 'CommandId')
    
    for i in range(15):
        time.sleep(0.5)
        rcv3 = f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream>stdout stderr</rsp:DesiredStream><rsp:CommandId>{command_id3}</rsp:CommandId></rsp:Receive>'
        r7 = requests.post(URL, data=soap_post("http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive", rcv3, shell_id=shell_id), auth=auth, headers=hdrs, timeout=15)
        if r7.status_code == 200:
            out, err = extract_streams(r7.text)
            if out: print(f"  STDOUT: {out.strip()}")
            if err: print(f"  STDERR: {err.strip()}")
            if 'Done' in r7.text:
                print(f"  Done in {i+1} polls")
                break
    
    # Delete shell
    requests.post(URL, data=soap_post("http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete", "", shell_id=shell_id), auth=auth, headers=hdrs, timeout=10)
    print("\nShell deleted")

except Exception as e:
    print(f"ERROR: {e}")
    import traceback; traceback.print_exc()
