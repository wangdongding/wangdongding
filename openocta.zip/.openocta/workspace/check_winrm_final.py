#!/usr/bin/env python3
"""Execute PowerShell via WinRM - using the exact SOAP format that pywinrm uses"""

import requests
from requests.auth import HTTPBasicAuth
import base64
import uuid
import time
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"

SOAP_ENV = "http://www.w3.org/2003/05/soap-envelope"
WSA = "http://schemas.xmlsoap.org/ws/2004/08/addressing"
WSMAN = "http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def uid():
    return f"uuid:{str(uuid.uuid4()).upper()}"

# This is the exact SOAP format used by pywinrm library
def soap_create_shell():
    msg_id = uid()
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{msg_id}</a:MessageID>
    <w:OptionSet xmlns:x="http://www.w3.org/2001/XMLSchema-instance">
      <w:Option Name="WINRS_NOPROFILE" x:type="xs:boolean">false</w:Option>
      <w:Option Name="WINRS_CODEPAGE" x:type="xs:int">65001</w:Option>
    </w:OptionSet>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
      <rsp:IdleTimeOut>PT60.000S</rsp:IdleTimeOut>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

def soap_command(shell_id, encoded_cmd):
    msg_id = uid()
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{msg_id}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>powershell.exe</rsp:Command>
      <rsp:Arguments>-NoProfile -NonInteractive -EncodedCommand {encoded_cmd}</rsp:Arguments>
    </rsp:CommandLine>
  </s:Body>
</s:Envelope>'''

def soap_receive(shell_id, command_id):
    msg_id = uid()
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{msg_id}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
      <rsp:CommandId>{command_id}</rsp:CommandId>
    </rsp:Receive>
  </s:Body>
</s:Envelope>'''

def soap_signal(shell_id, command_id):
    msg_id = uid()
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{msg_id}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell" CommandId="{command_id}">
      <rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code>
    </rsp:Signal>
  </s:Body>
</s:Envelope>'''

def soap_delete(shell_id):
    msg_id = uid()
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{msg_id}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>'''

def encode_ps(cmd):
    return base64.b64encode(cmd.encode('utf-16-le')).decode('ascii')

def find_in_xml(xml_text, tag_name):
    root = ET.fromstring(xml_text)
    results = []
    for elem in root.iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name:
            results.append(elem.text or "")
    return results

def extract_streams(xml_text):
    root = ET.fromstring(xml_text)
    stdout_parts, stderr_parts = [], []
    for elem in root.iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == 'Stream':
            name = elem.attrib.get('Name', '')
            if elem.text:
                try:
                    decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                    if 'stdout' in name: stdout_parts.append(decoded)
                    elif 'stderr' in name: stderr_parts.append(decoded)
                except: pass
    return ''.join(stdout_parts), ''.join(stderr_parts)

auth = HTTPBasicAuth(USER, PASS)
hdrs = {'Content-Type': 'application/soap+xml; charset=UTF-8'}

ps_script = r"""
$ErrorActionPreference = 'Continue'
Write-Output "=== 1. WinRM Service Auth ==="
try {
    Get-ChildItem WSMan:\localhost\Service\Auth | ForEach-Object { Write-Output ("  {0} = {1}" -f $_.Name, $_.Value) }
} catch { Write-Output "  [ERROR]" }

Write-Output ""
Write-Output "=== 2. UAC Settings ==="
try {
    $uac = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
    Write-Output "  EnableLUA = $($uac.EnableLUA)"
    Write-Output "  FilterAdministratorToken = $($uac.FilterAdministratorToken)"
    Write-Output "  LocalAccountTokenFilterPolicy = $($uac.LocalAccountTokenFilterPolicy)"
} catch { Write-Output "  [ERROR]" }

Write-Output ""
Write-Output "=== 3. Current User ==="
Write-Output "  $(whoami)"

Write-Output ""
Write-Output "=== 4. Admin Token ==="
try {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $adminSid = [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    Write-Output "  IsAdmin = $($id.Groups -contains $adminSid)"
} catch { Write-Output "  [ERROR]" }

Write-Output ""
Write-Output "=== 5. WinRM AllowUnencrypted ==="
try {
    Write-Output "  AllowUnencrypted = $((Get-Item WSMan:\localhost\Service\AllowUnencrypted).Value)"
} catch { Write-Output "  [ERROR]" }

Write-Output ""
Write-Output "=== 6. OS Version ==="
try {
    Write-Output "  $([System.Environment]::OSVersion.VersionString)"
} catch { Write-Output "  [ERROR]" }
"""

try:
    print("[1] Creating WinRM shell...")
    r = requests.post(URL, data=soap_create_shell(), auth=auth, headers=hdrs, timeout=15)
    print(f"    HTTP {r.status_code}")
    if r.status_code != 200:
        for elem in ET.fromstring(r.content).iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if tag == 'Text' and elem.text:
                print(f"    Error: {elem.text.strip()[:500]}")
        exit(1)
    
    shell_ids = find_in_xml(r.text, 'ShellId')
    shell_id = shell_ids[0] if shell_ids else None
    print(f"    ShellId: {shell_id}")
    if not shell_id:
        print("    ERROR: No ShellId"); exit(1)
    
    print("[2] Executing PowerShell...")
    encoded = encode_ps(ps_script)
    r2 = requests.post(URL, data=soap_command(shell_id, encoded), auth=auth, headers=hdrs, timeout=30)
    print(f"    HTTP {r2.status_code}")
    
    cmd_ids = find_in_xml(r2.text, 'CommandId')
    command_id = cmd_ids[0] if cmd_ids else None
    print(f"    CommandId: {command_id}")
    
    print("[3] Receiving output...")
    all_stdout, all_stderr = "", ""
    for i in range(15):
        time.sleep(1.5)
        r3 = requests.post(URL, data=soap_receive(shell_id, command_id), auth=auth, headers=hdrs, timeout=15)
        if r3.status_code == 200:
            out, err = extract_streams(r3.text)
            if out: all_stdout += out
            if err: all_stderr += err
            if 'Done' in r3.text:
                print(f"    Completed after {i+1} polls")
                break
    
    print(f"\n{'='*60}")
    print(all_stdout)
    if all_stderr: print(f"\nSTDERR:\n{all_stderr}")
    
    # Signal + Delete
    requests.post(URL, data=soap_signal(shell_id, command_id), auth=auth, headers=hdrs, timeout=10)
    requests.post(URL, data=soap_delete(shell_id), auth=auth, headers=hdrs, timeout=10)
    print("\n[4] Shell cleaned up")

except Exception as e:
    print(f"ERROR: {e}")
    import traceback; traceback.print_exc()
