#!/usr/bin/env python3
"""Check WinRM auth methods supported by each server by examining 401 challenge headers"""
import requests

servers = [
    {"host": "172.17.3.88", "user": "Compiler", "password": "Yuwei@2505", "label": "OLD (working)"},
    {"host": "172.17.3.193", "user": "administrator", "password": "admin!123", "label": "NEW (broken)"},
]

print("=" * 80)
print("STEP 1: Check WinRM auth mechanisms (read 401/401 response headers)")
print("=" * 80)

for srv in servers:
    print(f"\n--- {srv['label']} ({srv['host']}) ---")
    url = f"http://{srv['host']}:5985/wsman"
    
    # Test 1: No auth - see what auth methods are offered
    try:
        r = requests.post(url, headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                         data=b'<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body/></s:Envelope>',
                         timeout=10)
        print(f"  No-auth response: HTTP {r.status_code}")
        for h in ['WWW-Authenticate', 'X-WinRM-ErrorCode', 'Content-Type']:
            if h in r.headers:
                print(f"  {h}: {r.headers[h]}")
        # Show all headers
        print(f"  All response headers:")
        for k, v in r.headers.items():
            print(f"    {k}: {v}")
    except Exception as e:
        print(f"  ERROR: {e}")

    # Test 2: Basic auth - see if accepted
    try:
        r = requests.post(url, headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                         data=b'<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body/></s:Envelope>',
                         auth=requests.auth.HTTPBasicAuth(srv['user'], srv['password']),
                         timeout=10)
        print(f"  Basic-auth response: HTTP {r.status_code}")
        if r.status_code != 200:
            for h in ['WWW-Authenticate', 'X-WinRM-ErrorCode']:
                if h in r.headers:
                    print(f"  {h}: {r.headers[h]}")
    except Exception as e:
        print(f"  Basic auth ERROR: {e}")

    # Test 3: WinRM Identify (no auth needed usually)
    identify = """<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsmid="http://schemas.dmtf.org/wbem/wsman/identity/1/wsmanidentity.xsd">
  <s:Header/>
  <s:Body>
    <wsmid:Identify/>
  </s:Body>
</s:Envelope>"""
    
    try:
        r = requests.post(url, 
                         headers={'Content-Type': 'application/soap+xml; charset=UTF-8',
                                  'WSMANIDENTIFY': 'unauthenticated',
                                  'Action': 'http://schemas.dmtf.org/wbem/wsman/identity/1/wsmanidentity/Identify'},
                         data=identify.encode('utf-8'),
                         timeout=10)
        print(f"  Identify response: HTTP {r.status_code}")
        if r.status_code == 200:
            # Parse and show
            import xml.etree.ElementTree as ET
            try:
                root = ET.fromstring(r.content)
                for elem in root.iter():
                    if elem.text and elem.text.strip():
                        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
                        print(f"    {tag}: {elem.text.strip()}")
            except:
                print(f"    Raw: {r.text[:500]}")
    except Exception as e:
        print(f"  Identify ERROR: {e}")

print("\n" + "=" * 80)
print("STEP 2: Try Negotiate (NTLM) auth with requests-ntlm check")
print("=" * 80)

try:
    from requests_ntlm import HttpNtlmAuth
    print("  requests_ntlm IS available - will use it")
    
    for srv in servers:
        print(f"\n--- {srv['label']} ({srv['host']}) ---")
        url = f"http://{srv['host']}:5985/wsman"
        ntlm_user = f".\\{srv['user']}" if '\\' not in srv['user'] else srv['user']
        
        try:
            r = requests.post(url, headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                             data=b'<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body/></s:Envelope>',
                             auth=HttpNtlmAuth(ntlm_user, srv['password']),
                             timeout=15)
            print(f"  NTLM-auth response: HTTP {r.status_code}")
            for h in ['WWW-Authenticate', 'Content-Type']:
                if h in r.headers:
                    print(f"  {h}: {r.headers[h]}")
        except Exception as e:
            print(f"  NTLM auth ERROR: {e}")
except ImportError:
    print("  requests_ntlm NOT available")

    # Try manual SPNEGO/NTLM detection
    print("\n  Trying manual NTLM detection via curl...")
    import subprocess
    for srv in servers:
        print(f"\n--- {srv['label']} ({srv['host']}) ---")
        try:
            result = subprocess.run(
                ['curl', '-v', '--max-time', '5', 
                 '-u', f"{srv['user']}:{srv['password']}",
                 '--negotiate', '-u', ':',
                 f"http://{srv['host']}:5985/wsman"],
                capture_output=True, text=True, timeout=10)
            print(f"  stdout: {result.stdout[:300]}")
            print(f"  stderr: {result.stderr[:500]}")
        except Exception as e:
            print(f"  ERROR: {e}")

print("\nDONE")
