#!/usr/bin/env python3
"""Verify WinRM auth method on 172.17.3.193 to diagnose the become/runas double-hop issue"""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
WINRM_URL = f"http://{TARGET}:5985/wsman"

# 1) Check WinRM service config via WSMAN SOAP
CONFIG_SOAP = """<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
            xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.dmtf.org/wbem/wsman/1/wsman/Get</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/config/service</wsman:ResourceURI>
    <wsmv:OptionSet/>
  </s:Header>
  <s:Body/>
</s:Envelope>"""

headers = {
    'Content-Type': 'application/soap+xml; charset=UTF-8',
    'WSMANIDENTIFY': 'unauthenticated'
}

# Get service config
try:
    resp = requests.post(WINRM_URL, data=CONFIG_SOAP.format(url=WINRM_URL),
                         auth=HTTPBasicAuth(USER, PASS),
                         headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                         timeout=10)
    print(f"WinRM Service Config Response: HTTP {resp.status_code}")
    if resp.status_code == 200:
        # Parse key fields
        root = ET.fromstring(resp.content)
        ns = {'cfg': 'http://schemas.microsoft.com/wbem/wsman/1/config/service'}
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if tag in ('AllowUnencrypted', 'Auth', 'DefaultPorts', 'MaxConcurrentOperations',
                        'MaxConnections', 'EnumerationTimeoutms', 'MaxPacketRetrievalTimeSeconds'):
                # For Auth, list sub-elements
                if tag == 'Auth':
                    print(f"\n  === Auth Configuration ===")
                    for sub in elem:
                        stag = sub.tag.split('}')[-1] if '}' in sub.tag else sub.tag
                        print(f"    {stag}: {sub.text}")
                else:
                    print(f"  {tag}: {elem.text}")
    else:
        print(f"  Body preview: {resp.text[:500]}")
except Exception as e:
    print(f"Error: {e}")

# 2) Check if CredSSP is available
CREDSSP_SOAP = """<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
            xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.dmtf.org/wbem/wsman/1/wsman/Get</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/config/service/auth</wsman:ResourceURI>
  </s:Header>
  <s:Body/>
</s:Envelope>"""

try:
    resp2 = requests.post(WINRM_URL, data=CREDSSP_SOAP.format(url=WINRM_URL),
                          auth=HTTPBasicAuth(USER, PASS),
                          headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                          timeout=10)
    print(f"\nWinRM Auth Detail: HTTP {resp2.status_code}")
    if resp2.status_code == 200:
        root2 = ET.fromstring(resp2.content)
        for elem in root2.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if tag in ('Basic', 'Kerberos', 'Negotiate', 'CredSSP', 'Certificate', 'Digest'):
                print(f"  {tag}: {elem.text}")
except Exception as e:
    print(f"Auth detail error: {e}")

print("\n" + "="*60)
print("DIAGNOSIS SUMMARY")
print("="*60)
print("""
The become:yes + become_method:runas hang is caused by the
Windows 'Double-Hop' problem:

  1. WinRM authenticates you as Administrator (1st hop) ✅
  2. become:runas tries to create a NEW elevated process (2nd hop) ❌
  
With Basic/Negotiate auth, credentials are NOT delegated,
so the 2nd hop CANNOT authenticate → process hangs forever.

SOLUTIONS (pick one):

[A] REMOVE become (recommended if already Administrator):
    Since ansible_user=Administrator already has full admin rights,
    become is REDUNDANT. Remove all 3 lines from the playbook.

[B] ENABLE CredSSP authentication:
    On 172.17.3.193 run in PowerShell (as Admin):
      Enable-WSManCredSSP -Role Server -Force
    Then in inventory set:
      ansible_auth=credssp
      ansible_winrm_transport=credssp
    CredSSP delegates credentials → 2nd hop works.

[C] USE become_flags for UAC bypass (if become is truly needed):
    In inventory or playbook:
      ansible_become_flags: logon_type=new_credentials logon_flags=netcredentials_only
""")
