#!/usr/bin/env python3
"""Debug the HTTP 500 from 172.17.3.193 and try alternate approaches"""
import requests, uuid, xml.etree.ElementTree as ET, base64, time

host = "172.17.3.193"
user = "administrator"
password = "admin!123"
url = f"http://{host}:5985/wsman"

session = requests.Session()
session.auth = requests.auth.HTTPBasicAuth(user, password)

NS = {
    's': 'http://www.w3.org/2003/05/soap-envelope',
    'a': 'http://schemas.xmlsoap.org/ws/2004/08/addressing',
    'w': 'http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd',
    'p': 'http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd',
    'rsp': 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell',
}

resource_uri = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

# Step 1: Try Create Shell and parse the 500 error
msg_id = str(uuid.uuid4())
create_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI mustUnderstand="true">{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <p:OptionSet>
      <p:Option Name="WINRS_NOPROFILE" Value="FALSE"/>
    </p:OptionSet>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>"""

print("=" * 60)
print("TEST 1: Create Shell with Basic Auth")
print("=" * 60)
r = session.post(url, data=create_soap.encode('utf-8'),
                 headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                 timeout=15)
print(f"HTTP Status: {r.status_code}")
print(f"Response Headers: {dict(r.headers)}")

# Parse the SOAP fault
try:
    root = ET.fromstring(r.content)
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if elem.text and elem.text.strip():
            print(f"  {tag}: {elem.text.strip()}")
        for attr_name, attr_val in elem.attrib.items():
            if attr_val.strip():
                print(f"  {tag}[@{attr_name}]: {attr_val.strip()}")
except Exception as e:
    print(f"Parse error: {e}")
    print(f"Raw text: {r.text[:1000]}")

# Step 2: Try using WinRM with PowerShell resource URI instead of cmd
print("\n" + "=" * 60)
print("TEST 2: Try PowerShell resource URI")
print("=" * 60)

ps_resource = "http://schemas.microsoft.com/powershell/Microsoft.PowerShell"
msg_id = str(uuid.uuid4())
ps_create_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI mustUnderstand="true">{ps_resource}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <p:OptionSet>
      <p:Option Name="WINRS_NOPROFILE" Value="FALSE"/>
      <p:Option Name="PSVERSION" Value="2.0"/>
    </p:OptionSet>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>"""

r = session.post(url, data=ps_create_soap.encode('utf-8'),
                 headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                 timeout=15)
print(f"HTTP Status: {r.status_code}")
if r.status_code != 200:
    try:
        root = ET.fromstring(r.content)
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if elem.text and elem.text.strip():
                print(f"  {tag}: {elem.text.strip()}")
    except:
        print(f"Raw: {r.text[:500]}")

# Step 3: Try WinRM Get (read config directly) instead of creating a shell
print("\n" + "=" * 60)
print("TEST 3: WinRM Get config via SOAP (no shell needed)")
print("=" * 60)

# Get WinRM Service config
msg_id = str(uuid.uuid4())
get_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Get</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/config/service</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
  </s:Header>
  <s:Body/>
</s:Envelope>"""

r = session.post(url, data=get_soap.encode('utf-8'),
                 headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                 timeout=15)
print(f"HTTP Status: {r.status_code}")
if r.status_code == 200:
    try:
        root = ET.fromstring(r.content)
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if elem.text and elem.text.strip():
                print(f"  {tag}: {elem.text.strip()}")
    except:
        print(f"Parse error, raw: {r.text[:2000]}")
else:
    try:
        root = ET.fromstring(r.content)
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if elem.text and elem.text.strip():
                print(f"  {tag}: {elem.text.strip()}")
    except:
        print(f"Raw: {r.text[:500]}")

# Step 4: Try WinRM Get auth config
print("\n" + "=" * 60)
print("TEST 4: WinRM Get service/auth config")
print("=" * 60)

msg_id = str(uuid.uuid4())
get_auth_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Get</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/config/service/auth</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
  </s:Header>
  <s:Body/>
</s:Envelope>"""

r = session.post(url, data=get_auth_soap.encode('utf-8'),
                 headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                 timeout=15)
print(f"HTTP Status: {r.status_code}")
if r.status_code == 200:
    try:
        root = ET.fromstring(r.content)
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if elem.text and elem.text.strip():
                print(f"  {tag}: {elem.text.strip()}")
    except:
        print(f"Parse error, raw: {r.text[:2000]}")
else:
    try:
        root = ET.fromstring(r.content)
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if elem.text and elem.text.strip():
                print(f"  {tag}: {elem.text.strip()}")
    except:
        print(f"Raw: {r.text[:500]}")

# Step 5: Try WinRM Get winrs config
print("\n" + "=" * 60)
print("TEST 5: WinRM Get winrs config")
print("=" * 60)

msg_id = str(uuid.uuid4())
get_winrs_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Get</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/config/winrs</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
  </s:Header>
  <s:Body/>
</s:Envelope>"""

r = session.post(url, data=get_winrs_soap.encode('utf-8'),
                 headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                 timeout=15)
print(f"HTTP Status: {r.status_code}")
if r.status_code == 200:
    try:
        root = ET.fromstring(r.content)
        for elem in root.iter():
            tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if elem.text and elem.text.strip():
                print(f"  {tag}: {elem.text.strip()}")
    except:
        print(f"Parse error, raw: {r.text[:2000]}")
else:
    print(f"Raw: {r.text[:500]}")

print("\nDONE")
