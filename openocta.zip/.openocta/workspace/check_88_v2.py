#!/usr/bin/env python3
"""Pure Python MD4 + NTLM auth for WinRM - to check .88 config"""
import struct, os, base64, hmac, time, requests, uuid, xml.etree.ElementTree as ET

ANON = "http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous"

# ============ Pure Python MD4 ============
def md4(data):
    """Pure Python MD4 implementation"""
    def f(x, y, z): return (x & y) | (~x & z)
    def g(x, y, z): return (x & y) | (x & z) | (y & z)
    def h(x, y, z): return x ^ y ^ z
    def left_rotate(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    
    # Pre-processing
    msg = bytearray(data)
    orig_len = len(msg) * 8
    msg.append(0x80)
    while len(msg) % 64 != 56:
        msg.append(0)
    msg += struct.pack('<Q', orig_len)
    
    # Initialize
    a0 = 0x67452301
    b0 = 0xEFCDAB89
    c0 = 0x98BADCFE
    d0 = 0x10325476
    
    # Process each 512-bit block
    for i in range(0, len(msg), 64):
        block = msg[i:i+64]
        M = [struct.unpack('<I', block[j:j+4])[0] for j in range(0, 64, 4)]
        
        A, B, C, D = a0, b0, c0, d0
        
        # Round 1
        for k in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]:
            s = [3,7,11,19][k%4]
            t = left_rotate((A + f(B,C,D) + M[k]) & 0xFFFFFFFF, s)
            A, B, C, D = D, t, B, C
        
        # Round 2
        for k in [0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]:
            s = [3,5,9,13][(k//4)%4]
            t = left_rotate((A + g(B,C,D) + M[k] + 0x5A827999) & 0xFFFFFFFF, s)
            A, B, C, D = D, t, B, C
        
        # Round 3
        for k in [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]:
            s = [3,9,11,15][(k//4)%4]
            t = left_rotate((A + h(B,C,D) + M[k] + 0x6ED9EBA1) & 0xFFFFFFFF, s)
            A, B, C, D = D, t, B, C
        
        a0 = (a0 + A) & 0xFFFFFFFF
        b0 = (b0 + B) & 0xFFFFFFFF
        c0 = (c0 + C) & 0xFFFFFFFF
        d0 = (d0 + D) & 0xFFFFFFFF
    
    return struct.pack('<4I', a0, b0, c0, d0)

# ============ NTLM ============
def ntlm_type1(domain=''):
    sig = b'NTLMSSP\x00'
    msg_type = struct.pack('<I', 1)
    flags = 0x00088215
    domain_bytes = domain.encode('utf-16-le') if domain else b''
    if domain_bytes:
        flags |= 0x00001000
    msg = sig + msg_type + struct.pack('<I', flags)
    msg += struct.pack('<HH', len(domain_bytes), len(domain_bytes))
    msg += struct.pack('<I', 32)
    msg += b'\x00' * 8
    msg += domain_bytes
    return base64.b64encode(msg).decode()

def ntlmv2_response(server_challenge, password, user, domain, target_info):
    nt_hash = md4(password.encode('utf-16-le'))
    hmac_key = user.upper().encode('utf-16-le') + domain.encode('utf-16-le')
    ntproof_key = hmac.new(nt_hash, hmac_key, hashlib.md5).digest()
    blob = struct.pack('<I', 0x01010000)
    blob += struct.pack('<I', 0)
    blob += struct.pack('<Q', int(time.time()) + 11644473600)
    blob += os.urandom(8)
    blob += struct.pack('<I', 0)
    blob += target_info
    blob += struct.pack('<I', 0)
    ntproof = hmac.new(ntproof_key, server_challenge + blob, hashlib.md5).digest()
    return ntproof, ntproof + blob

import hashlib

def ntlm_type3(type2_b64, user, password, domain=''):
    type2 = base64.b64decode(type2_b64)
    server_challenge = type2[24:32]
    target_info = b''
    if len(type2) > 48:
        ti_len = struct.unpack('<H', type2[40:42])[0]
        ti_off = struct.unpack('<I', type2[44:48])[0]
        if ti_len > 0 and ti_off + ti_len <= len(type2):
            target_info = type2[ti_off:ti_off+ti_len]
    
    ntproof, nt_resp = ntlmv2_response(server_challenge, password, user, domain, target_info)
    lm_response = b'\x00' * 24
    domain_unicode = domain.upper().encode('utf-16-le') if domain else b''
    user_unicode = user.encode('utf-16-le')
    workstation_unicode = 'WORKSTATION'.encode('utf-16-le')
    
    base_offset = 88
    lm_off = base_offset
    nt_off = lm_off + len(lm_response)
    tgt_off = nt_off + len(nt_resp)
    usr_off = tgt_off + len(domain_unicode)
    wkst_off = usr_off + len(user_unicode)
    sk_off = wkst_off + len(workstation_unicode)
    
    def sec_buf(offset, data):
        return struct.pack('<HHI', len(data), len(data), offset)
    
    flags = 0x00088215
    msg = b'NTLMSSP\x00'
    msg += struct.pack('<I', 3)
    msg += sec_buf(lm_off, lm_response)
    msg += sec_buf(nt_off, nt_resp)
    msg += sec_buf(tgt_off, domain_unicode)
    msg += sec_buf(usr_off, user_unicode)
    msg += sec_buf(wkst_off, workstation_unicode)
    msg += sec_buf(sk_off, b'')
    msg += struct.pack('<I', flags)
    msg += struct.pack('<Q', 0x0000000600010000)
    msg += lm_response
    msg += nt_resp
    msg += domain_unicode
    msg += user_unicode
    msg += workstation_unicode
    return base64.b64encode(msg).decode()

def winrm_get_ntlm(host, user, password, resource_uri, domain='', timeout=15):
    url = f"http://{host}:5985/wsman"
    msg_id = str(uuid.uuid4())
    soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Get</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI>{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
  </s:Header>
  <s:Body/>
</s:Envelope>"""
    
    # Step 1: NTLM Type 1
    type1 = ntlm_type1(domain)
    r = requests.post(url, data=soap.encode('utf-8'),
                    headers={
                        'Content-Type': 'application/soap+xml; charset=UTF-8',
                        'Authorization': f'Negotiate {type1}'
                    },
                    timeout=timeout)
    
    if r.status_code != 401:
        return f"[Step1 HTTP {r.status_code}]"
    
    auth_header = r.headers.get('WWW-Authenticate', '')
    if 'Negotiate' not in auth_header:
        return f"[No Negotiate challenge] {auth_header}"
    
    type2 = auth_header.split('Negotiate')[1].strip()
    if not type2:
        return f"[Empty Type 2]"
    
    # Step 2: NTLM Type 3
    type3 = ntlm_type3(type2, user, password, domain)
    r = requests.post(url, data=soap.encode('utf-8'),
                    headers={
                        'Content-Type': 'application/soap+xml; charset=UTF-8',
                        'Authorization': f'Negotiate {type3}'
                    },
                    timeout=timeout)
    
    if r.status_code != 200:
        return f"[Step2 HTTP {r.status_code}] {r.text[:300]}"
    
    root = ET.fromstring(r.content)
    lines = []
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if elem.text and elem.text.strip():
            lines.append(f"  {tag} = {elem.text.strip()}")
    return '\n'.join(lines) if lines else "[Empty response]"

# ============ MAIN ============
print("=" * 80)
print("WinRM Config on 172.17.3.88 via NTLM auth")
print("=" * 80)

config_uris = [
    ("WinRM Service Auth", "http://schemas.microsoft.com/wbem/wsman/1/config/service/auth"),
    ("WinRM Service", "http://schemas.microsoft.com/wbem/wsman/1/config/service"),
    ("WinRM WinRS", "http://schemas.microsoft.com/wbem/wsman/1/config/winrs"),
    ("WinRM Client Auth", "http://schemas.microsoft.com/wbem/wsman/1/config/client/auth"),
]

for name, uri in config_uris:
    print(f"\n{'='*60}")
    print(f"[{name}]")
    print(f"{'='*60}")
    result = winrm_get_ntlm("172.17.3.88", "Compiler", "Yuwei@2505", uri)
    print(result)

print("\n\nDONE")
