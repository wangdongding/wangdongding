#!/usr/bin/env python3
"""Verify NTLM hash calculation"""
import hashlib

def md4(data):
    msg = bytearray(data)
    msg_len = len(data)
    msg.append(0x80)
    while len(msg) % 64 != 56: msg.append(0)
    msg += struct.pack('<Q', msg_len * 8)
    a0, b0, c0, d0 = 0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
    def lr(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    for i in range(0, len(msg), 64):
        M = [struct.unpack('<I', msg[i+j:i+j+4])[0] for j in range(0, 64, 4)]
        a, b, c, d = a0, b0, c0, d0
        for k in range(16):
            a = lr((a + ((b&c)|(~b&d)) + M[k]) & 0xFFFFFFFF, [3,7,11,19][k%4]); a,b,c,d = d,a,b,c
        for k in [0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]:
            a = lr((a + ((b&c)|(b&d)|(c&d)) + M[k] + 0x5A827999) & 0xFFFFFFFF, [3,5,9,13][([0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15].index(k))%4]); a,b,c,d = d,a,b,c
        for k in [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]:
            a = lr((a + (b^c^d) + M[k] + 0x6ED9EBA1) & 0xFFFFFFFF, [3,9,11,15][([0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15].index(k))%4]); a,b,c,d = d,a,b,c
        a0=(a0+a)&0xFFFFFFFF; b0=(b0+b)&0xFFFFFFFF; c0=(c0+c)&0xFFFFFFFF; d0=(d0+d)&0xFFFFFFFF
    return struct.pack('<4I', a0, b0, c0, d0)

import struct

# Test with known password "Password" -> NTLM hash should be 8846f7eaee8fb117ad06bdd830b7586c
test_hash = md4("Password".encode('utf-16-le'))
print(f"MD4 test: {test_hash.hex()}")
print(f"Expected: 8846f7eaee8fb117ad06bdd830b7586c")
print(f"Match: {test_hash.hex() == '8846f7eaee8fb117ad06bdd830b7586c'}")

# Also test with the actual password
actual_hash = md4("Yuwei@2505".encode('utf-16-le'))
print(f"\nActual password hash: {actual_hash.hex()}")

# The user said password is Yuwei@2505. Let me also try Yuwei@2605 (from earlier message)
hash2 = md4("Yuwei@2605".encode('utf-16-le'))
print(f"Alt password hash: {hash2.hex()}")

# Wait, the user originally said "Yuwei@2605" but then corrected to "Yuwei@2505"
# Let me check both
print("\nNote: original message said Yuwei@2605, correction said Yuwei@2505")
print("Trying both passwords...")
