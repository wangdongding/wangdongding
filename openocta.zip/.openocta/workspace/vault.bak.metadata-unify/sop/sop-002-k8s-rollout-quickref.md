|# SOP: K8s 部署更新 (精简速查版)

> 🏷️ 核心执行路径，避免全文翻找
> 最后更新: 2026-07-08 | 依赖: [[ref-env-context]], [[ref-service-deploy-registry]]

## ⚠️ 关键原则：部署执行在180节点，查询验证在179直连

- `kubectl apply`、`helm upgrade` 需读取180上的yaml/values/tgz文件 → **必须SSH到180执行**
- `kubectl get pods`、`helm status` 等纯查询命令 → **179直连即可**

## 执行流程速查

### 1. 确认参数（查 ref-service-deploy-registry + ref-env-context）
| 参数 | 来源 |
|------|------|
| SVC / NS / DEPLOY_METHOD / NODE | ref-service-deploy-registry |
| 旧镜像tag | grep yaml/values 或 kubectl get deploy |
| 新镜像tag | 用户指定 |
| kubectl连接 | SSH到180(apply/upgrade)或179直连(查询验证) |
| 文件操作 | SSH到{{NODE}} |

### 2. helm 方式
> 包含独立 Release 和大 Chart 子服务两种场景，流程一致：
> - 独立 Release（如 deer-flow、milvus）：改该 Release 的 values.yaml → helm upgrade 该 Release
> - 大 Chart 子服务（如 innies-stack 下 crab-gateway）：改父 values.yaml 中子服务 tag → helm upgrade 父 Release

```
# 备份(SSH到NODE)
ssh {{NODE}} "cp {{VALUES_PATH}} {{VALUES_PATH}}.bak.{{DATE}}"
# 替换tag(SSH到NODE)
ssh {{NODE}} "grep '{{OLD_TAG}}' {{VALUES_PATH}}"  # 先确认唯一匹配
ssh {{NODE}} "sed -i 's|{{OLD_TAG}}|{{NEW_TAG}}|' {{VALUES_PATH}}"
# helm upgrade(⚠️ SSH到180执行，因values和tgz在180)
ssh {{NODE}} "helm upgrade {{HELM_RELEASE}} {{CHART_PATH}} -n {{NS}} -f {{VALUES_PATH}}"
# 轮询验证(179直连，每步<10s)
helm status {{HELM_RELEASE}} -n {{NS}} | grep deployed
kubectl get pods -n {{NS}} -l app={{SVC}} -o wide
# 回滚（⚠️ 必须两步：集群回滚 + 文件恢复）
ssh {{NODE}} "helm rollback {{HELM_RELEASE}} {{PREV_REVISION}} -n {{NS}}"
ssh {{NODE}} "cp {{VALUES_PATH}}.bak.{{DATE}} {{VALUES_PATH}}"
```

### 3. yaml 方式
```
# 备份(SSH到NODE)
ssh {{NODE}} "cp {{YAML_PATH}} {{YAML_PATH}}.bak.{{DATE}}"
# 替换image(SSH到NODE)
ssh {{NODE}} "grep '{{OLD_IMAGE}}' {{YAML_PATH}}"  # 先确认唯一匹配
ssh {{NODE}} "sed -i 's|{{OLD_IMAGE}}|{{NEW_IMAGE}}|' {{YAML_PATH}}"
# kubectl apply(⚠️ SSH到180执行，因yaml文件在180)
ssh {{NODE}} "kubectl apply -f {{YAML_PATH}} -n {{NS}}"
# 轮询验证(179直连，每步<10s)
kubectl get pods -n {{NS}} -l app={{SVC}} -o wide
# 回滚（⚠️ 必须两步：集群回滚 + 文件恢复）
ssh {{NODE}} "kubectl rollout undo deployment/{{SVC}} -n {{NS}}"
ssh {{NODE}} "cp {{YAML_PATH}}.bak.{{DATE}} {{YAML_PATH}}"
```

### 4. 通用验证
```
kubectl get pods -n {{NS}} -l app={{SVC}} -o jsonpath='{.items[0].spec.containers[0].image}'
kubectl get pods -n {{NS}} -l app={{SVC}} -o wide
kubectl logs -n {{NS}} -l app={{SVC}} --tail=50
```

## ⚠️ 回滚核心原则：集群回滚 + 文件同步，缺一不可
- **回滚命令也必须在180执行**（同样依赖本地文件）
- helm 回滚后必须 `cp .bak` 恢复 values.yaml，否则下次 helm upgrade 再次前滚
- yaml 回滚后必须 `cp .bak` 恢复 deployment.yaml

## 平台约束提醒
- ❌ 禁止 `kubectl rollout status --timeout>10s` → 改用轮询 `kubectl get pods`
- ❌ 禁止 Bash 命令含换行符 → 先写文件再传入
- ✅ 部署执行(kubectl apply / helm upgrade) → SSH到180（文件在180）
- ✅ 查询验证(kubectl get / helm status) → 179直连即可

> 补充文档详见 [[sop-002-k8s-rollout]] | 返回导航: [[INDEX]]