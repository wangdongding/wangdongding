# 故障排查速查版

> 环境归属: 180测试集群 (ai-q, 172.17.3.180)
> 最后更新: 2026-07-07 | 深度参考见 [[sop-troubleshooting-runbook]]

## 一句话结论

**遇到故障先看此表定位排查方向，再跳转完整 Runbook 执行详细步骤。**

## 故障速查表

| # | 症状关键词 | 快速排查命令 | 深度参考 |
|---|-----------|-------------|----------|
| 1 | CrashLoopBackOff | kubectl get pods -n NS -o wide; kubectl logs POD -n NS --previous | [[sop-troubleshooting-runbook#1. Pod CrashLoopBackOff 排查]] |
| 2 | DB连接失败 | kubectl get cluster -n cnpg; kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod | [[sop-troubleshooting-runbook#2. 数据库连接失败排查]] |
| 3 | 前端502/无响应 | curl -s -o /dev/null -w %{http_code} http://172.17.3.180:31819/; kubectl get ingress -A | [[sop-troubleshooting-runbook#3. Ingress/前端访问不通排查]] |
| 4 | Milvus连接超时 | kubectl get pods -n milvus; kubectl exec POD -n innies -- curl -s http://milvus.milvus.svc.cluster.local:9091/healthz | [[sop-troubleshooting-runbook#4. Milvus 连接失败排查]] |
| 5 | S3上传失败 | kubectl get pods -n rook-ceph -l app=rook-ceph-rgw; kubectl get secret innies-bucket -n innies | [[sop-troubleshooting-runbook#5. S3(对象存储)上传失败排查]] |
| 6 | PG主备切换 | kubectl get cluster -n cnpg postgres-cluster-prod -o wide; kubectl get pods -n cnpg -L role | [[sop-troubleshooting-runbook#6. CNPG 主备切换验证]] |
| 7 | TOAST膨胀/慢查询 | kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -c 表大小查询SQL | [[sop-troubleshooting-runbook#7. TOAST膨胀 / 慢查询排查]] |
| 8 | 索引缺失/Seq Scan | kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d DB -c "\di+ TABLE*" | [[sop-troubleshooting-runbook#8. 索引缺失排查]] |
| 9 | Ceph告警 | kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph health detail | [[sop-troubleshooting-runbook#9. Ceph 健康告警排查]] |
| 10 | GPU调度失败 | kubectl describe node ai-q-node01 | grep -A5 nvidia.com/gpu; kubectl logs hami-scheduler-POD -n hami --tail=100 | [[sop-troubleshooting-runbook#10. GPU调度失败排查]] |
| 11 | Redis连接失败 | kubectl get pods -n innies -l app.kubernetes.io/name=redis; kubectl exec POD -n innies -- redis-cli -h innies-stack-redis ping | [[sop-troubleshooting-runbook#11. Redis连接失败排查]] |
| 12 | RabbitMQ堆积 | kubectl get pods -n rabbitmq; kubectl logs POD -n innies -l app=synapse --tail=200 | grep -i rabbit | [[sop-troubleshooting-runbook#12. RabbitMQ消息堆积排查]] |

## 常见问题秒查

| 症状 | 最可能根因 | 一句话解决 |
|------|-----------|----------|
| Pod crash | 环境变量/DB连接/迁移缺失 | 查日志 -> 补环境变量/Secret/迁移记录 |
| 服务间调用不通 | base_url指向外部IP | 改为Ingress域名或Service短名 |
| 查询慢 | 索引缺失/TOAST膨胀 | CREATE INDEX CONCURRENTLY / VACUUM FULL |
| 镜像拉取失败 | Harbor地址带:80 | 地址统一172.17.3.179不带:80 |
| 回滚后又前滚 | 本地文件未恢复 | 集群回滚 + cp .bak恢复文件 |

> 详细排查步骤见 [[sop-troubleshooting-runbook]] | 返回导航: [[INDEX]]