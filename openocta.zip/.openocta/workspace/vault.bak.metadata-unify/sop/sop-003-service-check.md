# SOP: 服务健康检查

## 元数据
- sop_id: SOP-003
- version: 1.0
- owner: 运维
- last_updated: 2026-07-06
- tags: [k8s, health, check, monitor]
- depends_ref: [ref-k8s-cluster, ref-service-deploy-registry]

## 说明
K8s 服务部署后的健康检查 SOP。检查 Pod 状态、就绪探针、启动日志、关键端口可达性。
支持单服务和多服务检查。

## 前置条件
- kubectl 可用且已连接目标集群

## 输入参数

| 参数 | 必填 | 说明 | 示例 |
|------|------|------|------|
| SVC | Y | 服务名 | pdf2zh |
| NS | Y | K8s 命名空间 | innies |
| CHECK_PORT | N | 服务端口（用于端口探活） | 11008 |
| CHECK_URL | N | 健康检查 URL（如有 HTTP 接口） | http://pdf2zh.innies:11008/health |
| TIMEOUT | N | 等待就绪超时秒数，默认 120 | 120 |

## 步骤

### Step 1: 检查 Deployment 状态
- desc: 确认 Deployment 已 rollout 完成
- exec: kubectl rollout status deployment/{{SVC}} -n {{NS}} --timeout={{TIMEOUT}}s
- async: N
- check: 命令返回 "successfully rolled out" 或 exit 0
- timeout: {{TIMEOUT}}s
- on_fail: abort
- rollback: 无

### Step 1.5: 获取实际 Label Selector
- desc: 查询 Deployment 实际使用的 label selector，避免猜测
- exec: kubectl get deploy {{SVC}} -n {{NS}} -o jsonpath='{.spec.selector.matchLabels}'
- async: N
- check: 返回非空 JSON（如 {"app.kubernetes.io/name":"synapse"}）
- timeout: 10s
- on_fail: notify
- rollback: 无
- note: Helm chart 常用 app.kubernetes.io/name 而非 app，必须用实际 selector 查 Pod

### Step 2: 检查 Pod 状态
- desc: 获取 Pod 详细状态，确认 Running 且 Ready（使用 Step 1.5 获取的实际 label）
- exec: kubectl get pods -n {{NS}} -l {{ACTUAL_SELECTOR}} -o wide
- async: N
- check: Pod 状态为 Running，READY 为 n/n，RESTARTS 为 0 或不增长
- check_desc: 无 CrashLoopBackOff / ImagePullBackOff / Pending
- timeout: 10s
- on_fail: notify
- rollback: 无

### Step 3: 检查 Pod 事件
- desc: 查看 Recent Events，确认无 Warning 级别事件
- exec: kubectl describe pod -n {{NS}} -l app={{SVC}} | tail -20
- async: N
- check: Events 中无 Warning（或仅有正常的 Scheduled/Pulled/Started/Ready）
- timeout: 10s
- on_fail: notify
- rollback: 无

### Step 4: 检查启动日志
- desc: 查看最近 50 行日志，确认无 error/fatal/panic 等异常
- exec: kubectl logs -n {{NS}} -l app={{SVC}} --tail=50
- async: N
- check: 日志中无 error/fatal/panic/exception（小写匹配）
- check_desc: 服务正常启动，无运行时异常
- timeout: 10s
- on_fail: notify（可能为正常业务日志，需人工判断）
- rollback: 无

### Step 5: 端口可达性检查（可选，CHECK_PORT 非空时执行）
- desc: 在集群内验证服务端口可达
- exec: kubectl run check-{{SVC}} --rm -i --restart=Never --image=busybox -- wget -qO- --spider http://{{SVC}}.{{NS}}.svc.cluster.local:{{CHECK_PORT}}/ 2>&1 || true
- async: N
- check: 输出无 "can't connect" / "refused"
- timeout: 30s
- on_fail: notify
- rollback: 无

### Step 6: HTTP 健康检查（可选，CHECK_URL 非空时执行）
- desc: 请求健康检查接口
- exec: kubectl run check-url-{{SVC}} --rm -i --restart=Never --image=curlimages/curl -- -sSf {{CHECK_URL}} 2>&1 || true
- async: N
- check: HTTP 返回 200
- timeout: 30s
- on_fail: notify
- rollback: 无

## 输出
- HEALTH_STATUS = Healthy / Degraded / Unhealthy
- POD_PHASE = Running / Pending / Failed
- RESTART_COUNT = <重启次数>
- LOG_ANOMALY = None / <异常关键词列表>

## 后置验证
- 5 分钟后再次执行 Step 2 确认 Pod 无重启（RESTARTS 未增长）
- 如有监控/告警系统，确认无新告警

## 回滚方案
- 本 SOP 为只读检查，无回滚
- 如检查发现异常，建议执行对应部署方式的回滚（参见 [[sop-002-k8s-rollout]] 回滚方案）

## 注意事项
- Step 4 日志检查可能误报（某些框架的 INFO 日志包含 "error" 字样），需人工判断
- Step 5/6 使用临时 Pod 检查，完成后自动删除（--rm）
- 多服务检查时，对每个服务独立执行 Step 1-4
- 检查超时不要设太短，某些服务启动慢（如 Milvus、PDFminer GPU 加载）

## 相关文档
- [[sop-002-k8s-rollout]] - K8s 部署更新 SOP
- [[ref-service-deploy-registry]] - 服务部署方式注册表
- [[ref-k8s-cluster]] - 集群环境信息
> 返回导航: [[INDEX]]
