# SOP: K8s 部署更新 (补充文档)

> 🏷️ 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-07-08 | 类型: 只读参考
> **核心执行路径见 [[sop-002-k8s-rollout-quickref]]，本文件仅补充前置条件、参数表、注意事项等细节**

## 说明

通用 K8s 服务部署更新 SOP。根据服务部署方式（helm / yaml）自动选择更新路径。
**更新前必须先查 [[ref-service-deploy-registry]] 确认部署方式。**

---

## 前置条件

- kubectl 可用且已连接目标集群（部署执行需SSH到180节点）
- 目标服务已在 [[ref-service-deploy-registry]] 中注册
- 新镜像已同步到生产 Harbor（如未同步，先执行 [[sop-001-harbor-image-sync]]）

## 输入参数

| 参数 | 必填 | 说明 | 示例 |
|------|------|------|------|
| SVC | Y | 服务名 | pdf2zh |
| NS | Y | K8s 命名空间 | innies |
| NEW_TAG | Y | 新镜像 tag | latest |
| DEPLOY_METHOD | Y | 部署方式: helm / yaml | yaml |
| NODE | Y | 配置文件所在节点 | 180 |
| DRY_RUN | N | 仅输出命令不执行 | Y |

## 注意事项

- **必须先查 [[ref-service-deploy-registry]]**，不要凭记忆判断部署方式
- **必须先查 [[ref-env-context]]**，确认本机角色、kubectl连接方式；⚠️ kubectl apply / helm upgrade 需SSH到180执行（文件在180），查询验证在179直连
- helm 大 Chart 子服务修改 values.yaml 时务必只改目标服务 tag
- helm upgrade 前建议先 helm get values RELEASE -n NS 确认当前 values
- kubectl apply 的 yaml 文件中 imagePullPolicy 建议设为 Always
- **回滚必须同步恢复文件**：详见 [[ref-lessons-learned]] Lesson-001
- 备份文件命名带日期，避免多次操作覆盖
- **平台超时适配**：等待类命令必须用轮询模式（每步<10s）

## yaml-set 方式（⚠️ 不推荐，与本地yaml不一致容易混乱）

kubectl set image deployment/SVC CONTAINER_NAME=IMAGE_REPO:NEW_TAG -n NS
kubectl rollout undo deployment/SVC -n NS
ssh NODE "sed -i s|NEW_IMAGE|OLD_IMAGE| YAML_PATH"

> yaml-set 直接修改集群Pod spec不改本地文件，导致集群状态与本地yaml不一致，回滚还需sed同步。建议优先用sed-i+kubectl apply方式保持一致性

## 相关文档
- [[sop-002-k8s-rollout-quickref]] - 核心执行路径
- [[ref-service-deploy-registry]] - 服务部署方式注册表
- [[ref-env-context]] - 运维环境上下文
- [[ref-lessons-learned]] - 经验教训与常见问题
- [[ref-change-log]] - 变更日志（含部署操作记录）

> 返回导航: [[INDEX]]
