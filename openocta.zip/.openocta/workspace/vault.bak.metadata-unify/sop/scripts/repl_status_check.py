#!/usr/bin/env python3
"""读取 Harbor 复制执行状态 JSON，输出状态和 execution id"""
import sys, json

if len(sys.argv) < 2:
    print("Usage: repl_status_check.py <json_file>")
    sys.exit(1)

with open(sys.argv[1]) as f:
    data = json.load(f)

if isinstance(data, list) and len(data) > 0:
    latest = data[0]
    status = latest.get("status", "Unknown")
    eid = latest.get("id", "N/A")
    print(f"status={status} execution_id={eid}")
else:
    print("status=Unknown execution_id=N/A")
