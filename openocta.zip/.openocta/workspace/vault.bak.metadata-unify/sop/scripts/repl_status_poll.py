#!/usr/bin/env python3
"""Poll Harbor replication execution status until terminal state or timeout.
Usage: python3 repl_status_poll.py <HARBOR_API> <HARBOR_USER> <HARBOR_PASS> <POLICY_ID> [INTERVAL] [MAX_WAIT]
Example: python3 repl_status_poll.py http://172.17.3.179/api/v2.0 admin admin 1 3 60
"""
import sys, json, time, urllib.request, urllib.error, ssl
if len(sys.argv) < 5:
    print("Usage: repl_status_poll.py <API> <USER> <PASS> <POLICY_ID> [INTERVAL=3] [MAX_WAIT=60]")
    sys.exit(1)
api, user, passwd, policy_id = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
interval = int(sys.argv[5]) if len(sys.argv) > 5 else 3
max_wait = int(sys.argv[6]) if len(sys.argv) > 7 else 60
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
url = f"{api}/replication/executions?page=1&page_size=1&policy_id={policy_id}"
elapsed = 0
while elapsed <= max_wait:
    try:
        req = urllib.request.Request(url)
        cred = f"{user}:{passwd}"
        import base64
        req.add_header("Authorization", f"Basic {base64.b64encode(cred.encode()).decode()}")
        with urllib.request.urlopen(req, context=ctx) as resp:
            data = json.loads(resp.read())
        if data and len(data) > 0:
            status = data[0].get("status", "Unknown")
            eid = data[0].get("id", "?")
            if status in ("Succeed", "Failed", "Stopped"):
                print(f"status={status} execution_id={eid}")
                sys.exit(0 if status == "Succeed" else 1)
            print(f"[{elapsed}s] status={status} execution_id={eid} - waiting...")
    except Exception as e:
        print(f"[{elapsed}s] error: {e} - retrying...")
    time.sleep(interval)
    elapsed += interval
print(f"TIMEOUT after {max_wait}s")
sys.exit(2)
