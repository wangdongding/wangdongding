# SOP 模板
> 复制此模板创建新 SOP，替换所有 `<>` 占位符

## 元数据
- sop_id: <SOP-xxx>
- version: <1.0>
- owner: <负责人>
- last_updated: <日期>
- tags: [<分类标签>]
- depends_ref: [<引用的 ref 文档，如 ref-harbor-infra>]

## 说明
<一句话描述此 SOP 做什么>

## 前置条件
- <执行前必须满足的条件，每条可验证>
- 例: nerdctl 可用 -> which nerdctl

## 输入参数

| 参数 | 必填 | 说明 | 示例 |
|------|------|------|------|
| <name> | Y/N | <描述> | <值> |
| DRY_RUN | N | 仅输出命令不实际变更 | Y |

## 步骤

> 格式灵活：可用结构化字段(desc/exec/check/rollback)或叙述性段落+代码块。
> 关键是每个步骤可执行、可验证、可回滚，与现有 SOP 风格保持一致即可。

### Step 1: <步骤名称>
- desc: <一句话描述>
- exec: <可执行命令，支持 {{变量}} 替换，必须单行无换行符>
- exec_sub: <多子步骤时使用，格式为 1a/1b/1c，每条独立调用 bash>
- async: N
- check: <验证命令>
- check_desc: <验证成功的人工可读描述>
- timeout: <超时时间>
- on_fail: <retry(N) / abort / notify / skip>
- rollback: <回滚命令，可为空>

### Step 2: <步骤名称>
- desc: ...
- exec: ...
- async: ...
- check: ...
- timeout: ...
- on_fail: ...
- rollback: ...

## 输出
- <此 SOP 产出的变量，可被 Pipeline 下一步引用>
- 例: TARGET_IMAGE = {{HARBOR}}/{{TARGET_PROJECT}}/{{IMAGE_PATH}}:{{TAG}}

## 后置验证
- <流程完成后整体验证命令>

## 回滚方案
- <整体回滚步骤>

## 注意事项
- <关键提醒>

> 返回导航: [[INDEX]]