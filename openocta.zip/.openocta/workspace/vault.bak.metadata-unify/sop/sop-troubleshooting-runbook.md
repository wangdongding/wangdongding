# 运维排查 Runbook

> 🏷️ 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-06-30

## 1. Pod CrashLoopBackOff 排查

### 症状
Pod反复重启，STATUS列显示 CrashLoopBackOff

### 排查步骤

1. 查看Pod状态和重启次数:
   ```bash
   kubectl get pods -n <namespace> -o wide
   ```

2. 查看上次crash日志:
   ```bash
   kubectl logs <pod> -n <namespace> --previous
   ```

3. 查看当前日志:
   ```bash
   kubectl logs <pod> -n <namespace> --tail=200
   ```

4. 查看Pod事件:
   ```bash
   kubectl describe pod <pod> -n <namespace>
   ```

### 常见原因
- 环境变量缺失/错误 → 检查 ConfigMap/Secret 是否正确挂载
- 数据库连接失败 → 检查 DB URL、Secret、CNPG Pod 是否 Running
- S3配置错误 → 检查 innies-bucket Secret 中 AK/SK
- 端口冲突/配置错误 → 检查 values.yaml 中端口设置

### 历史案例
- innies-users Pod crash: 导入46条迁移记录后数据库表结构不匹配导致，修复后重建Pod

---

## 2. 数据库连接失败排查

### 症状
服务报 "connection refused" / "no such host" / FATAL: database does not exist

### 排查步骤

1. 确认CNPG集群状态:
   ```bash
   kubectl get cluster -n cnpg
   ```

2. 确认PG Pod Running:
   ```bash
   kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod
   ```

3. 测试连接(从业务Pod内):
   ```bash
   kubectl exec <pod> -n <namespace> -- psql $DATABASE_URL -c "SELECT 1"
   ```

4. 检查Secret中的连接信息:
   ```bash
   kubectl get secret <db-secret> -n <namespace> -o yaml
   ```

5. 检查pooler服务:
   ```bash
   kubectl get svc -n cnpg postgres-cluster-prod-pooler-rw
   ```

### 常见原因
- Secret中DB URL指向错误主机 → 确认pooler-rw ClusterIP
- Pod内DNS解析失败 → 检查集群DNS (kube-system/coredns)
- 数据库未创建 → CNPG cluster spec中未列出该DB

---

## 3. Ingress/前端访问不通排查

### 瘾状
前端访问 http://172.17.3.180:31819/ 无响应或502

### 排查步骤

1. 确认Ingress存在且配置正确:
   ```bash
   kubectl get ingress -A
   kubectl describe ingress <name> -n <namespace>
   ```

2. 确认Ingress Controller Running:
   ```bash
   kubectl get pods -n ingress-nginx -o wide
   ```

3. 确认后端Service和Pod Running:
   ```bash
   kubectl get svc -n <namespace>
   kubectl get pods -n <namespace>
   ```

4. 确认NodePort可达(本环境Ingress用NodePort):
   - NodePort: 80→31819, 443→31517
   - 前端访问: http://172.17.3.180:31819/
   - curl -s -o /dev/null -w "%{http_code}" http://172.17.3.180:31819/

5. Pod内测试81模型Ingress可达性(通过81域名):
   ```bash
   kubectl exec <pod> -n innies -- wget -q -O /dev/null --timeout=3 http://aikb.yuwei.com/
   ```

### 关键发现(6/30重构后)
- 前端访问改为 IP:NodePort，不再使用域名Ingress
- 内部服务间调用走 Service 短名直连，不走Ingress
- DNS搜索域已去掉 yuwei.com，Pod访问81域名直达81不再被劫持
- 集群仅1个Ingress: innies-stack-direct（无host，路径路由）

---

## 4. Milvus 连接失败排查

### 症状
synapse/innies-biz 报 Milvus连接超时或RPC错误

### 排查步骤

1. 确认Milvus所有组件Running:
   ```bash
   kubectl get pods -n milvus
   ```

2. 测试Milvus端口可达(从业务Pod内):
   ```bash
   kubectl exec <pod> -n innies -- curl -s http://milvus.milvus.svc.cluster.local:9091/healthz
   ```

3. 检查Milvus配置(bucket/minio):
   ```bash
   kubectl get configmap milvus milvus-bucket -n milvus -o yaml
   ```

4. 检查Milvus日志:
   ```bash
   kubectl logs milvus-mixcoord-<pod> -n milvus --tail=100
   ```

---

## 5. S3(对象存储)上传失败排查

### 症状
文件上传失败，报 S3 connection error / Access Denied

### 排查步骤

1. 确认RGW Pod Running:
   ```bash
   kubectl get pods -n rook-ceph -l app=rook-ceph-rgw
   ```

2. 检查S3 Secret:
   ```bash
   kubectl get secret innies-bucket -n innies -o jsonpath="{.data.AWS_ACCESS_KEY_ID}" | base64 -d
   ```

3. 测试S3连接(从Pod内):
   ```bash
   kubectl exec <pod> -n innies -- curl -s http://rook-ceph-rgw-ceph-objectstore.rook-ceph.svc.cluster.local
   ```

4. 检查CephObjectStore状态:
   ```bash
   kubectl get cephobjectstore -n rook-ceph
   ```

---

## 6. CNPG 主备切换验证

### 症状
PG主节点故障，需确认备节点是否自动升主

### 排查步骤

1. 查看当前主节点:
   ```bash
   kubectl get cluster -n cnpg postgres-cluster-prod -o wide
   ```

2. 查看Pod角色标识:
   ```bash
   kubectl get pods -n cnpg -l cnpg.io/cluster=postgres-cluster-prod -L role
   ```

3. 查看切换事件:
   ```bash
   kubectl describe cluster -n cnpg postgres-cluster-prod | grep -A5 "Switchover"
   ```

4. 验证pooler连接:
   ```bash
   kubectl exec <pod> -n <namespace> -- psql $DATABASE_URL -c "SELECT pg_is_in_recovery()"
   ```

---

## 7. TOAST膨胀 / 慢查询排查

### 症状
查询慢、磁盘占用远大于实际数据量

### 排查步骤

1. 检查表大小和膨胀率:
   ```bash
   # 从CNPG Pod内执行
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -c "SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname||quote_ident(tablename))) AS total_size FROM pg_tables WHERE schemaname = 'public' ORDER BY pg_total_relation_size(schemaname||quote_ident(tablename)) DESC LIMIT 20;"
   ```

2. 检查TOAST表膨胀:
   ```bash
   # chunk_meta TOAST膨胀17.5GB案例
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d innies_biz -c "SELECT pg_size_pretty(pg_relation_size(chunk_meta_toast::regclass)) AS toast_size;"
   ```

3. 处理膨胀(需确认后执行 ⚠️ 高危):
   ```bash
   # VACUUM FULL 会锁表！必须在业务低峰执行
   # 需用户确认后才可执行
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d innies_biz -c "VACUUM FULL chunk_meta;"
   ```

### 历史案例(6/29)
- 81 chunk_meta TOAST膨胀17.5GB，行数与其他库一致，VACUUM FULL后恢复正常

---

## 8. 索引缺失排查

### 症状
查询性能骤降，EXPLAIN显示Seq Scan

### 排查步骤

1. 检查表索引列表:
   ```bash
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d <db> -c "\di+ <table>*"
   ```

2. 补建索引(需确认后执行 ⚠️ 高危):
   ```bash
   # CREATE INDEX 会锁表，建议 CONCURRENTLY 方式
   kubectl exec postgres-cluster-prod-1 -n cnpg -c postgres -- psql -d <db> -c "CREATE INDEX CONCURRENTLY idx_name ON table(col);"
   ```

### 历史案例(6/29)
- chunk_meta 4个索引缺失，补建后查询恢复正常

---

## 9. Ceph 健康告警排查

### 症状
kubectl get cephcluster 显示 HEALTH_WARN / HEALTH_ERR

### 排查步骤

1. 获取详细告警:
   ```bash
   kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph health detail
   ```

2. 查看PG状态分布:
   ```bash
   kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph pg stat
   ```

3. 查看crash列表:
   ```bash
   kubectl -n rook-ceph exec deploy/rook-ceph-tools -- ceph crash ls
   ```

> 详见 ceph-storage-status.md 中的完整状态和修复日志

---

## 10. GPU调度失败排查

### 症状
模型Pod无法启动，报 GPU资源不足 / scheduling failed

### 排查步骤

1. 查看HAMi调度器日志:
   ```bash
   kubectl logs hami-scheduler-<pod> -n hami --tail=100
   ```

2. 查看GPU分配状态:
   ```bash
   kubectl get pods -A -L nvidia.com/gpu
   ```

3. 查看node01/02 GPU可用量:
   ```bash
   kubectl describe node ai-q-node01 | grep -A5 nvidia.com/gpu
   kubectl describe node ai-q-node02 | grep -A5 nvidia.com/gpu
   ```

---

## 11. Redis连接失败排查

### 症状
服务报 Redis connection refused / timeout

### 掗查步骤

1. 确认Redis Pod Running:
   ```bash
   kubectl get pods -n innies -l app.kubernetes.io/name=redis
   ```

2. 测试连接(从业务Pod内):
   ```bash
   kubectl exec <pod> -n innies -- redis-cli -h innies-stack-redis ping
   ```

3. 查看Redis日志:
   ```bash
   kubectl logs innies-stack-redis-0 -n innies --tail=50
   ```

---

## 12. RabbitMQ消息堆积排查

### 症状
synapse消费延迟，知识库入库慢

### 排查步骤

1. 确认RabbitMQ Pod Running:
   ```bash
   kubectl get pods -n rabbitmq
   ```

2. 查看队列状态(管理界面):
   - RabbitMQ管理界面可通过 NodePort 或 ClusterIP 访问

3. 查看Pod日志:
   ```bash
   kubectl logs <pod> -n rabbitmq --tail=100
   ```

4. 检查消费者(synapse)日志:
   ```bash
   kubectl logs innies-stack-synapse-<pod> -n innies --tail=200 | grep -i rabbit
   ```

---

## 13. 历史修复记录

> 完整变更日志见 [[ref-change-log]]（按日期降序，含全量操作记录）
> 经验教训见 [[ref-lessons-learned]]（含根因分析和模式提炼）

> 返回导航: [[INDEX]]
