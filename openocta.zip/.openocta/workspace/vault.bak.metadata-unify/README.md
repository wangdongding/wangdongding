# OpenOcta 运维知识库

本知识库为 **172.17.3.179/180 运维环境** 的 Obsidian 笔记库，涵盖标准操作流程(SOP)、参考信息(REF)和编排流程(Pipeline)。

> 入口索引 -> [[INDEX]]

## 适用范围

- 179 本机：Harbor 镜像仓库 / JumpServer / kubectl 直连入口
- 180 测试集群 (ai-q)：K8s 工作负载 / Helm 部署 / 业务服务

## 文档结构

| 目录 | 内容 | 示例 |
|------|------|------|
| sop/ | 标准操作流程，含模板和辅助脚本 | 镜像同步、K8s部署更新、健康检查 |
| ref/ | 环境参考信息，只读查阅 | 集群信息、部署注册表、Harbor配置 |
| pipeline/ | 多SOP编排流程，含模板 | 镜像同步->部署->验证全链路 |

## 快速入口

| 想做什么 | 去哪 |
|---------|------|
| 更新服务镜像 | [[sop-002-k8s-rollout-quickref]] |
| 同步外部镜像 | [[sop-001-harbor-image-sync]] |
| 检查服务健康 | [[sop-003-service-check]] |
| 排查故障 | [[sop-troubleshooting-runbook]] |
| 查服务部署方式 | [[ref-service-deploy-registry]] |
| 看做了什么变更 | [[ref-change-log]] |
| vault辅助CLI工具 | [[ref-vault-cli]] |

## 维护约定

- 每次部署/回滚/配置变更 -> 记录到 [[ref-change-log]]
- 遇到新问题 -> 追加到 [[ref-lessons-learned]]
- Harbor 地址统一写 172.17.3.179，不加 :80
- vault 搜索/读取优先用 cli_vault.py，替代 memory_search 嵌套链（详见 [[ref-vault-cli]]）

---

用 Obsidian 打开此目录即可浏览编辑；.obsidian/ 文件夹已被索引器忽略。
