# K8S 集群环境信息

> 🏷️ 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-07-01

## 集群概况

| 项目 | 值 |
|------|-----|
| K8S版本 | v1.29.9 |
| CNI | Cilium |
| CSI | Rook-Ceph(rbd+cephfs) |
| Ingress | nginx(ingress-nginx) |
| 容器运行时 | containerd 1.7.23 |
| GPU调度 | HAMI v2.6.1 |
| 镜像仓库 | 172.17.3.179 |
| Helm | innies-stack-0.1.27 |

## 节点信息

| 节点 | 角色 | IP | CPU | 内存 | OS | 内核 |
|------|------|-----|-----|------|----|------|
| ai-q-master01 | control-plane | 172.17.3.180 | 8核 | 16Gi | Ubuntu 24.04.4 | 6.8.0-100 |
| ai-q-node01 | worker | 172.25.20.27 | 32核 | 128Gi | Ubuntu 24.04.3 | 6.8.0-71 |
| ai-q-node02 | worker | 172.25.20.28 | 32核 | 128Gi | Ubuntu 24.04.3 | 6.8.0-71 |

> node01/02有GPU(HAMI调度),master无GPU

## Namespace(12个)

| ns | 用途 |
|----|------|
| cert-manager | TLS证书 |
| cnpg | CloudNative-PG |
| hami | GPU插件+调度 |
| ingress-nginx | Ingress |
| innies | 核心业务-AI知识库 |
| llm | 大模型推理 |
| milvus | Milvus向量库 |
| rabbitmq | RMQ集群 |
| kube-system | 系统组件 |


## Pod清单

### innies(9 Deploy+1 STS)

| Pod | 镜像tag | 端口 | 类型 |
|-----|---------|------|------|
| crab-gateway | 3.0.1 | 3000 | Deploy |
| file-parser-api | 3.0.0 | 5002 | Deploy |
| innies-biz | 3.0.1 | 9004 | Deploy |
| innies-fe | 2.0.60 | 80 | Deploy |
| innies-loom | 3.0.1 | 9005 | Deploy |
| innies-users | 0.1.37 | 9002 | Deploy |
| prism | 3.0.1 | 9003 | Deploy |
| redis | Redis | 6379 | STS |
| synapse | 3.0.1 | 9001/60001 | Deploy |
| z8m(N8N) | 3.0.1 | 5678 | Deploy |
| pdf2zh | 1.9.11-offline-0.1.0 | 11008 | Deploy(yaml) |
| deer-flow-backend | 1.0.3 | 8000 | Deploy |
| deer-flow-frontend | 1.0.3 | 3000 | Deploy |

### llm(8 Pod)

| Pod | 镜像 | 端口 |
|-----|------|------|
| xinference | v1.5.0 | 9997 |
| vllm-reranker | v0.9.1 | 8000 |
| infinity-vl-embedding | latest | 8000 |
| zhiman-pdfminer | 2.6.8-core | 8000 |
| deployment-reloader | main-c16c462 | 8000 |
| 3*NFS-server | alpine:12 | 2049 |

### milvus(19 Pod,v2.6.15)

核心: mixcoord/proxy/datanode/querynode/streamingnode(各1)
消息: pulsarv3(broker1+proxy2+bookie3+zk3+recovery1)
存储: etcd(STS 3实例), attu(NodePort:30800)

### cnpg(5 Pod,PG 17.4)

postgres-cluster-prod(主备2���例) + pooler-rw(2 PgBouncer) + operator

### rabbitmq(4 Pod,2节点集群)

server-0/1 + cluster-operator + topology-operator

### rook-ceph(v19.2.2 Squid)

mon(3)+mgr(2)+osd(5)+rgw(1)+CSI plugins
> 状态: HEALTH_WARN(MON_DISK_LOW+PG_DEGRADED+RECENT_CRASH)


## Service清单

### innies

| Service | ClusterIP | Port |
|---------|-----------|------|
| crab-gateway | 10.96.3.97 | 3000 |
| file-parser-api | 10.96.3.135 | 5002 |
| innies-biz | 10.96.0.243 | 9004 |
| innies-fe | 10.96.3.96 | 80 |
| innies-loom | 10.96.3.51 | 9005 |
| innies-users | 10.96.2.95 | 9002 |
| prism | 10.96.0.240 | 9003 |
| redis | Headless | 6379 |
| synapse | 10.96.3.98 | 9001/60001 |
| z8m | 10.96.1.48 | 5678 |
| deer-flow-backend | 10.96.2.214 | 8000 |
| deer-flow-frontend | 10.96.2.134 | 3000 |
| pdf2zh | 10.96.2.95 | 11008 |

### llm

| Service | ClusterIP | Port |
|---------|-----------|------|
| zhiman-pdfminer | 10.96.2.148 | 8000 |
| deployment-reloader | 10.96.3.232 | 80 |
| xinference | 10.96.3.56 | 9997 |
| vllm-reranker | 10.96.2.237 | 8000 |
| infinity-vl-embedding | 10.96.0.127 | 8000 |

### cnpg(PG访问入口)

| Service | ClusterIP | Port | 模式 |
|---------|-----------|------|------|
| postgres-cluster-prod-rw | 10.96.2.247 | 5432 | 读写 |
| postgres-cluster-prod-r | 10.96.2.228 | 5432 | 只读 |
| postgres-cluster-prod-ro | 10.96.2.225 | 5432 | 只读 |
| pooler-postgres-cluster-prod-rw | 10.96.0.149 | 5432 | 池化读写 |

### milvus

| Service | ClusterIP | Port |
|---------|-----------|------|
| milvus(主入口) | 10.96.0.186 | 19530/9091 |
| attu(NodePort:30800) | 10.96.3.201 | 3000 |
| milvus-minio | 10.96.2.191 | 9000 |
| milvus-etcd | 10.96.3.24 | 2379/2380 |

### llm

| Service | ClusterIP | Port |
|---------|-----------|------|
| xinference | 10.96.3.56 | 9997 |
| vllm-reranker | 10.96.2.237 | 8000 |
| infinity-vl-embedding | 10.96.0.127 | 8000 |

### rabbitmq

| Service | ClusterIP | Port |
|---------|-----------|------|
| rabbitmq-cluster-prod | 10.96.2.147 | 5672/15672 |
| rabbitmq-cluster-prod-nodes | Headless | 4369/25672 |

### rook-ceph(关键)

| Service | ClusterIP | Port |
|---------|-----------|------|
| rook-ceph-mgr-dashboard | 10.96.2.26 | 8443 |
| rook-ceph-rgw-ceph-objectstore | 10.96.1.58 | 80 |


## Ingress清单

> 2026-06-30 重构后：所有域名Ingress已关闭，仅保留 direct Ingress（无host），前端通过 IP:NodePort 访问

| Ingress | 域名 | 后端Service | 路径 | TLS | 状态 |
|---------|------|------------|------|------|------|
| innies-stack-direct | *(无域名) | crab-gateway | /api/v1 | No | ✅ 活跃 |
| innies-stack-direct | *(无域名) | z8m | /aiagent | No | ✅ 活跃 |
| innies-stack-direct | *(无域名) | innies-fe | / | No | ✅ 活跃 |
| ~~innies-stack-ingress~~ | ~~aikb.yuwei.com~~ | ~~innies-fe + crab-gateway~~ | - | - | ❌ 已关闭 |
| ~~innies-stack-z8m~~ | ~~aiagent.yuwei.com~~ | ~~z8m~~ | - | - | ❌ 已关闭 |
| ~~xinference~~ | ~~xinference.yuwei.com~~ | ~~xinference~~ | - | - | ❌ 已关闭 |
| ~~vllm-ingress~~ | ~~vllm.yuwei.com~~ | ~~vllm-reranker~~ | - | - | ❌ 已关闭 |
| ~~infinity-ingress~~ | ~~infinity.yuwei.com~~ | ~~infinity-vl-embedding~~ | - | - | ❌ 已关闭 |

**前端访问方式**: `http://172.17.3.180:31819/`（IP + NodePort）
- `/` → innies-fe
- `/api/v1` → crab-gateway
- `/aiagent` → z8m

**内部服务调用**: Service 短名直连（不走 Ingress）
**跨集群连81模型**: Pod 通过81 Ingress 域名直达（DNS搜索域已去掉 yuwei.com，不再劫持）



## PVC清单与StorageClass

> 详见 [[ref-storage]] - PVC/PV完整映射表、容量、SC、扩容策略

## Rook-Ceph 存储概览

> 详见 [[ref-ceph-storage]] - OSD/Pool/PG/告警详情

## ConfigMap(innies)

| CM | 内容 |
|----|------|
| innies-bucket | S3连接(host/bucket/port) |
| file-parser-api-config | ENV,MINERU_SERVICE_URL |
| prism-config | env.yaml |
| synapse-config | env.yaml |
| z8m-config | DB_TYPE,LOG_LEVEL |

## Secret与证书

> 详见 [[ref-secret-cert]] - 全量Secret/证书清单、到期日、轮换方式

简要: innies业务7个Secret(S3/DB连接/API Key), cnpg 4个TLS+2个basic-auth, hami/rabbitmq/kube-system TLS

> 返回导航: [[INDEX]]
