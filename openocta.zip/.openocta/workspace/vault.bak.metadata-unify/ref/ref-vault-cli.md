# vault辅助CLI工具

> 最后更新: 2026-07-08 | 脚本路径: /root/.openocta/employee_skills/资深运维架构师/skill-cli/cli/cli_vault.py

## 一句话结论

**用 cli_vault.py 替代 memory_search 的嵌套读取链和手动 bash cat 嵌套，单条命令直达信息。**

---

## 为什么需要它

原流程痛点：
- memory_search 输出存到 .output 文件 -> cat 读又存一层 -> 嵌套链 3条命令才看到结果
- bash cat vault文件同样嵌套存文件 -> 又要多条命令
- 部署参数散落在5个文件，需逐个读取拼齐

cli_vault.py 解决方案：
- search/read/grep/slice/deploy-check 5个子命令，单条命令直达信息
- 虽然 bash 输出仍存 .output 文件，但**单条命令返回更多结构化信息**，减少来回次数

---

## 命令用法

| 命令 | 用途 | 示例 | 替代原来几步 |
|------|------|------|-------------|
| search | 全vault关键词搜索 | cli_vault.py search pdf2zh | 替代 3-12条 memory_search + cat 链 |
| read | 读取vault文件全文 | cli_vault.py read ref/ref-env-context.md | 替代 2条 cat 嵌套 |
| grep | 定位关键词行号 | cli_vault.py grep ref/ref-service-deploy-registry.md pdf2zh | 替代 2条 grep + cat |
| slice | 精准提取行范围 | cli_vault.py slice ref/ref-env-context.md 23 32 | 替代 2条 sed + cat |
| deploy-check | 一键采集部署参数 | cli_vault.py deploy-check pdf2zh | 替代 5条分散读取 |

---

## deploy-check 输出字段说明

| 字段 | 含义 |
|------|------|
| service | 服务名 |
| deploy_method | helm / yaml |
| yaml_or_values_path | 配置文件路径(180节点上) |
| node | 配置文件所在节点 |
| current_tag | 注册表记录的当前tag |
| yaml_current_image | 180节点yaml/values中实际image行 |
| cluster_current_image | kubectl get deploy 查到的集群实际image |

> 注意：helm 方式含"->"的yaml路径（如 innies-stack -> /data/.../values.yaml）暂不支持自动grep，需手动SSH查

---

## 最佳实践

1. 先 search 找到相关文件名 -> 再 slice 精准提取，不全文 cat
2. 部署前一条 deploy-check 即可拉齐所有参数，无需逐文件读取
3. search 结果已含文件名+行号+文本片段，通常不需要再 read 全文
4. 该工具仅读取 vault 本地文件，不涉及集群操作（集群查询仍用 kubectl/helm 命令）

---

## 命令调用方式

python3 /root/.openocta/employee_skills/资深运维架构师/skill-cli/cli/cli_vault.py search pdf2zh
python3 /root/.openocta/employee_skills/资深运维架构师/skill-cli/cli/cli_vault.py deploy-check pdf2zh

> 返回导航: [[INDEX]]
