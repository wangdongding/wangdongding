# 资源分配详情

> 🏷️ 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-07-01 | 类型: 只读快照
> ⚠️ 此为 2026-07-01 静态快照，重大扩缩容/节点变更后需更新

## 服务器硬件与已分配资源

| 节点 | 角色 | CPU可分配 | 内存可分配 | GPU | CPU已Request | CPU已Limit | 内存已Request | 内存已Limit | GPU已分配 |
|------|------|----------|----------|-----|-------------|-----------|-------------|------------|----------|
| ai-q-master01 | master | 8核 | 15.5Gi | 0 | 3.6核(45%) | 0 | 3.5Gi(22%) | 8.1Gi(52%) | 0 |
| ai-q-node01 | worker | 32核 | 125Gi | 5 | 17.1核(53%) | 10.5核(32%) | 39Gi(31%) | 46Gi(36%) | 2 |
| ai-q-node02 | worker | 32核 | 125Gi | 5 | 17.6核(55%) | 19核(59%) | 41Gi(33%) | 67Gi(54%) | 1 |

> metrics-server未安装,无实时用量数据,以上为资源分配比(Request/Limit占可分配百分比)

## GPU资源分配详情

| 节点 | GPU总数 | GPU已分配 | 分配给 |
|------|---------|----------|-------|
| ai-q-node01 | 5 | 2 | infinity-vl-embedding(1GPU) + vllm-reranker(1GPU) |
| ai-q-node02 | 5 | 1 | xinference(1GPU) |
| ai-q-master01 | 0 | 0 | - |

> 剩余可用: node01 3GPU, node02 4GPU, 共7GPU空闲

## 各Pod资源分配明细

### innies ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim |
|-----|------|---------|---------|---------|--------|
| crab-gateway | node01 | 1 | 1 | 2Gi | 2Gi |
| file-parser-api | node01 | 500m | 1 | 1Gi | 2Gi |
| innies-biz | node01 | 2 | 2 | 4Gi | 4Gi |
| innies-fe | node01 | 1 | 1 | 2Gi | 2Gi |
| innies-loom | node01 | 1 | 1 | 2Gi | 2Gi |
| innies-users | node01 | 1 | 1 | 2Gi | 2Gi |
| prism | node02 | 1 | 4 | 2Gi | 8Gi |
| redis | node01 | 100m | 500m | 128Mi | 512Mi |
| synapse | node02 | 1 | 4 | 2Gi | 8Gi |
| z8m | node01 | - | - | - | - |

> innies-biz是innies ns中资源消耗最大的服务(CPU 2核/Mem 4Gi),prism和synapseLimit弹性到4核/8Gi

### llm ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim | GPU |
|-----|------|---------|---------|---------|---------|-----|
| xinference | node02 | 4 | 8 | 8Gi | 16Gi | 1 |
| vllm-reranker | node01 | - | - | - | - | 1 |
| infinity-vl-embedding | node01 | - | - | - | - | 1 |
| 3*NFS-server | node01 | - | - | - | - | 0 |

> xinference是llm ns资源消耗最大的服务(CPU 4~8核/Mem 8~16Gi/GPU 1)

### milvus ns

| Pod | 节点 | CPU Req | Mem Req | 备注 |
|-----|------|---------|---------|------|
| attu | node02 | 100m | 128Mi | 管理UI |
| mixcoord | node02 | - | - | 无显式限制 |
| proxy | node02 | - | - | 无显式限制 |
| datanode | node02 | - | - | 无显式限制 |
| querynode | node01 | - | - | 无显式限制 |
| streamingnode | node02 | - | - | 无显式限制 |
| pulsarv3-bookie(3) | node01/02 | 500m | 2Gi | 存储最重 |
| pulsarv3-broker | node02 | 500m | 2Gi | |
| pulsarv3-proxy(2) | node01/02 | 500m | 1Gi | |
| pulsarv3-zk(3) | node01/02 | 200m | 256Mi | |
| etcd(3) | node01/02 | - | - | 无显式限制 |

> milvus核心组件大多无显式资源限制,依赖节点默认调度

### cnpg ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim |
|-----|------|---------|---------|---------|--------|
| postgres-cluster-prod-1 | node01 | - | - | - | - |
| postgres-cluster-prod-2 | node02 | - | - | - | - |
| pooler-rw(2) | node01/02 | 100m | 500m | 100Mi | 500Mi |
| cnpg-operator | node01 | - | - | - | - |

> PG实例资源由CNPG Operator自动管理,无手动配置

### rabbitmq ns

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim |
|-----|------|---------|---------|---------|--------|
| server-0 | node01 | 1 | 2 | 2Gi | 2Gi |
| server-1 | node02 | 1 | 2 | 2Gi | 2Gi |
| cluster-operator | node01 | 200m | 200m | 500Mi | 500Mi |
| topology-operator | node01 | 100m | 300m | 100Mi | 500Mi |

### rook-ceph ns(核心组件)

| Pod | 节点 | CPU Req | CPU Lim | Mem Req | Mem Lim |
|-----|------|---------|---------|---------|--------|
| mon-a | node01 | 1 | - | 1Gi | 2Gi |
| mon-b | node02 | 1 | - | 1Gi | 2Gi |
| mon-c | master | 1 | - | 1Gi | 2Gi |
| mgr-a | master | 500m | - | 512Mi | 1Gi |
| mgr-b | node01 | 500m | - | 512Mi | 1Gi |
| osd-0 | node02 | 1 | - | 4Gi | 4Gi |
| osd-1 | node02 | 1 | - | 4Gi | 4Gi |
| osd-2 | node02 | 1 | - | 4Gi | 4Gi |
| osd-3 | node02 | 1 | - | 4Gi | 4Gi |
| osd-4 | node01 | 1 | - | 4Gi | 4Gi |
| rgw | node02 | 1 | - | 1Gi | 2Gi |

> OSD是Ceph最重的组件(node02上4个OSD,共16Gi mem request)


## Ceph存储用量与OSD分布

> 详见 [[ref-ceph-storage]] - 集群总览、OSD分布、Pool用量、PG状态、告警跟踪

一句话: 100TiB总容量/252GiB已用(0.25%)/HEALTH_WARN/5 OSD/3副本(osd.2空→PG不均衡)

> 返回导航: [[INDEX]]
