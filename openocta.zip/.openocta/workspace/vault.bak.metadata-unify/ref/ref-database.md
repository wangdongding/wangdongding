# 数据库详细信息

> 🏷️ 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-06-29

## PostgreSQL (CloudNative-PG)

| 项目 | 值 |
|------|-----|
| Operator | cnpg |
| PG版本 | 17.4 |
| 镜像 | 172.17.3.179/zhiman/cloudnative-pg/postgresql:17.4 |
| 实例数 | 2(主备) |
| 存储 | 100Gi/实例,ceph-block(RWO) |
| 默认DB | app(owner:app) |
| 编码 | UTF8, locale C |

### 访问入口

| Service | ClusterIP | 端口 | 用途 |
|---------|-----------|------|------|
| postgres-cluster-prod-rw | 10.96.2.247 | 5432 | 直接读写 |
| postgres-cluster-prod-r | 10.96.2.228 | 5432 | 直接只读 |
| postgres-cluster-prod-ro | 10.96.2.225 | 5432 | 直接只读 |
| pooler-postgres-cluster-prod-rw | 10.96.0.149 | 5432 | PgBouncer池化读写 |

> 业务服务统一通过pooler入口连接,减少连接开销

### 业务数据库

| DB名 | 使用者 | 连接Secret |
|------|--------|-----------|
| innies_biz | innies-biz | innies-stack-innies-biz-db |
| innies_loom | innies-loom | innies-stack-innies-loom-db |
| innies_users | innies-users | innies-stack-innies-users-db |
| prism | prism | innies-stack-prism-db |
| z8m | z8m(N8N) | innies-stack-z8m-secret |

> 所有DB共用同一PG用户(app),密码在各自Secret的DATABASE_URL中
> 连接格式: postgresql://app:xxx@pooler-postgres-cluster-prod-rw.cnpg.svc.cluster.local.:5432/{db名}

### PG关键参数

| 参数 | 值 |
|------|-----|
| wal_level | logical |
| max_parallel_workers | 32 |
| max_replication_slots | 32 |
| wal_keep_size | 512MB |
| archive_mode | on |
| ssl_min/max_protocol | TLSv1.3 |

## Milvus (向量数据库)

| 项目 | 值 |
|------|-----|
| 版本 | v2.6.15 |
| 镜像 | 172.17.3.179/zhiman/milvusdb/milvus:v2.6.15 |
| 架构 | 混合协调器(mixcoord)+分布式组件 |
| 访问入口 | milvus.milvus.svc.cluster.local:19530 |
| 管理UI | attu NodePort:30800 |

### Milvus内部依赖

| 依赖 | 说明 |
|------|------|
| etcd | 元数据存储(3实例STS) |
| pulsarv3 | 消息队列(broker1+proxy2+bookie3+zk3) |
| minio | 内部对象存储(独立于rook-ceph) |

### 业务连接

| 服务 | 连接方式 |
|------|----------|
| synapse | http://milvus.milvus.svc.cluster.local.:19530, DB=innies |
| innies-biz | http://milvus.milvus.svc.cluster.local.:19530 |
| 认证信息 | Secret: innies-stack-synapse-secrets (MILVUS_USER/PASSWORD) |

### Milvus存储

| PVC | 大小 | SC |
|-----|------|----|
| etcd data(3) | 10Gi | ceph-block |
| logs | 10Gi | ceph-filesystem |
| pulsar journal(3) | 100Gi | ceph-block |
| pulsar ledgers(3) | 200Gi | ceph-block |
| zk data(3) | 20Gi | ceph-block |
| milvus-bucket(OBC) | - | ceph-bucket(rook rgw) |

## RabbitMQ

| 项目 | 值 |
|------|-----|
| Operator | rabbitmq-cluster-operator |
| 集群名 | rabbitmq-cluster-prod |
| 副本数 | 2 |
| 访问入口 | rabbitmq-cluster-prod.rabbitmq.svc:5672 |
| 管理UI | rabbitmq-cluster-prod.rabbitmq.svc:15672 |

### 业务连接

| 服务 | 队队/交换 |
|------|----------|
| synapse | queue=synapse_ingestion_queue, exchange=synapse_exchange, routing_key=document.update |
| 认证信息 | Secret: innies-stack-synapse-secrets (RABBITMQ_URL) |

## Redis

| 项目 | 值 |
|------|-----|
| 类型 | StatefulSet单实例 |
| Service | innies-stack-redis.innies(Headless) |
| 端口 | 6379 |
| 存储 | 20Gi ceph-block(RWO) |

### 业务连接

| 服务 | 用途 |
|------|------|
| innies-biz | 缓存+会话 |
| innies-users | 会话+认证 |
| prism | 临时缓存 |


## Rook-Ceph (对象存储/S3)

> 详见 [[ref-ceph-storage]] 和 [[ref-storage]] 中的S3/RGW部分

简要: RGW → rook-ceph-rgw-ceph-objectstore.rook-ceph.svc:80
innies Bucket → Secret:innies-bucket + CM:innies-bucket
milvus Bucket → OBC(milvus-bucket)

> 返回导航: [[INDEX]]

