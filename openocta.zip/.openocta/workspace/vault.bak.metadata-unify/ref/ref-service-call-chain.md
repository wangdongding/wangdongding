# 服务调用关系链-流量路由

> 🏷️ 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-07-01

## 外部流量入口

- aikb.yuwei.com/ --> innies-fe [前端页面]
- aikb.yuwei.com/api/v1 --> crab-gateway [API网关]
- aiagent.yuwei.com/ --> z8m(N8N) [工作流]
- xinference.yuwei.com/ --> xinference [模型管理]
- vllm.yuwei.com/ --> vllm-reranker [重排模型]
- infinity.yuwei.com/ --> infinity-vl-embedding [向量模型]

## 内部调用关系链

### crab-gateway-3000 API入口

- innies-users-9002 [认证鉴权]
- synapse-9001 [RAG检索]
- prism-9003 [LLM调用]
- innies-biz-9004 [业务逻辑]
- innies-loom-9005 [Agent推理]
- S3-rgw [文件上传]

### innies-biz-9004 核心业务

- deployment-reloader-llm-80 [MinerU Pod重启管理]

- synapse-9001 [RAG检索]
- prism-9003 [LLM调用]
- innies-users-9002 [用户服务]
- z8m-5678 [工作流]
- deer-flow-backend-8000 [深度搜索]
- milvus-19530 [向量检索]
- redis-6379 [缓存]
- PG-pooler-rw [数据持久化-innies_biz]
- S3-rgw [文件读写]

### innies-loom-9005 Agent推理

- synapse-9001 [检索]
- prism-9003 [LLM]
- innies-biz-9004 [业务]
- z8m-5678 [工作流]
- deer-flow-backend-8000 [深度搜索]

### prism-9003 LLM调度

- innies-biz-9004 [模型管理+配额+文件服务]
- file-parser-api-5002 [文件解析]
- redis-6379 [缓存]
- PG-pooler-rw [数据持久化-prism]
- S3-rgw [文件处理]

### synapse-9001 RAG知识库

- rabbitmq-5672 [消息消费 queue-synapse_ingestion_queue]
- S3-rgw [文件入库]
- milvus-19530 [向量读写 DB-innies]

### file-parser-api-5002 文件解析

- zhiman-pdfminer-llm-8000 [MinerU/PDF解析]
- deployment-reloader-llm-80 [Pod重启管理]

### innies-users-9002 用户服务

- innies-biz-9004 [业务]
- redis-6379 [缓存]
- PG-pooler-rw [数据持久化-innies_users]

### z8m-N8N-5678 工作流引擎

- PG-pooler-rw [数据持久化-z8m]

## 消息队列流

- exchange: synapse_exchange
- routing_key: document.update
- queue: synapse_ingestion_queue
- 消费者: synapse
- 处理: 文件入库+向量化+存入milvus

## 数据存储关系

- PG-innies_biz <--- innies-biz, innies-users
- PG-innies_loom <--- innies-loom
- PG-innies_users <--- innies-users
- PG-prism <--- prism
- PG-z8m <--- z8m
- Redis <--- innies-biz, innies-users, prism
- Milvus-innies <--- synapse, innies-biz
- S3 Bucket <--- synapse, innies-biz, prism, crab-gateway
- RabbitMQ <--- synapse

## LLM调用链

- prism --> xinference [模型管理+调度 via xinference.yuwei.com]
- prism --> vllm-reranker [重排模型 via vllm.yuwei.com]
- prism --> infinity-vl-embedding [向量模型 via infinity.yuwei.com]
- 注: LLM走Ingress域名 Pod内DNS解析yuwei.com指向LB
- 6/29修复: llm表base_url改为Ingress地址

> 返回导航: [[INDEX]]
