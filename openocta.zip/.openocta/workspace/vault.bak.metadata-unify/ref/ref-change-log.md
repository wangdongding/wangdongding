# 变更日志

> 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-07-08 | 类型: 活跃维护
> **本日志按时间降序排列，最新变更在最前。新增记录插入到对应日期section的表格首行(同日期)或新增日期section插入到文件最前(新日期)。**

## 一句话结论

**所有环境变更统一记录于此，最新记录在最前，一眼可见。**

## 变更级别说明

| 级别 | 定义 | 典型场景 |
|------|------|----------|
| 轻量 | 配置微调/文档更新/单参数修改 | 改1个env、补1个annotation、修1行文档 |
| 重量 | 镜像更新/服务新增/批量操作/数据修复 | helm upgrade改tag、kubectl apply换镜像、SQL数据修复 |
| 紧急 | 影响在线服务的故障修复 | Pod CrashLoop、服务不可达、磁盘告警 |

## 记录格式

| 列 | 说明 |
|----|------|
| # | 该日期section内序号 |
| 日期 | 月-日 |
| 服务 | 服务名或文档名 |
| 命名空间 | K8s ns 或 - |
| 级别 | 轻量/重量/紧急 |
| 类型 | 部署更新/回滚/配置修复/文档更新/新增部署/数据修复 |
| 变更前 | 旧tag/配置/状态 |
| 变更后 | 新tag/配置/状态 |
| 部署方式 | helm/yaml/kubectl/SQL/- |
| 操作人 | AI运维 |
| 验证 | 结果 |

> 后续每次部署/回滚/配置变更后由运维在此追加记录，轻量操作单行即可，重量操作附关键决策。

## 相关文档
- [[ref-service-deploy-registry]] - 服务部署方式注册表（部署前必查）
- [[sop-002-k8s-rollout-quickref]] - 部署更新执行速查
- [[ref-lessons-learned]] - 经验教训与常见问题

> 返回导航: [[INDEX]]

---

## 实际记录（降序：最新在前）

### 2026-07-08 vault知识库结构优化 (轻量)

| # | 时间 | 服务 | 命名空间 | 级别 | 类型 | 变更前 | 变更后 | 部署方式 | 操作人 | 验证 |
|---|------|------|----------|------|------|--------|--------|----------|--------|------|
| 1 | 07-08 | sop-troubleshooting-runbook | - | 轻量 | 文档更新 | 底部5行历史修复表与ref-change-log重复 | 删除重复表，保留引用ref-change-log+ref-lessons-learned | - | AI运维 | 无重复 OK |
| 2 | 07-08 | INDEX | - | 轻量 | 文档更新 | 关键词映射表与ref-env-context重复 | 改为引用ref-env-context，消除双份维护 | - | AI运维 | 单一来源 OK |
| 3 | 07-08 | INDEX | - | 轻量 | 文档更新 | 无最近更新时间戳 | 顶部加最近更新行(4文档) | - | AI运维 | 可见 OK |
| 4 | 07-08 | ref-resource | - | 轻量 | 文档更新 | 无快照标注 | 加快照日期+扩缩容提醒 | - | AI运维 | 标注 OK |
| 5 | 07-08 | ref-storage/ref-ceph-storage | - | 轻量 | 文档更新 | 无交叉引用 | 互加对方文档引用 | - | AI运维 | 双向链接 OK |

**优化目标**：消除重复数据、统一引用来源、标注静态快照过期风险。

### 2026-07-07 innies-stack 5服务批量镜像更新 + registry路径修正 (重量)

| # | 日期 | 服务 | 命名空间 | 级别 | 类型 | 变更前 | 变更后 | 部署方式 | 操作人 | 验证 |
|---|------|------|----------|------|------|--------|--------|----------|--------|------|
| 8 | 07-07 | synapse | innies | 重量 | 部署更新 | zhiman/synapse:3.0.1 | zhiman/yuwei/synapse:3.0.2 | helm upgrade innies-stack R18→R21 | AI运维 | Pod Running ✅ |
| 9 | 07-07 | innies-biz | innies | 重量 | 部署更新 | zhiman/innies-biz:3.0.1 | zhiman/yuwei/innies-biz:3.0.3 | helm upgrade innies-stack R18→R21 | AI运维 | Pod Running ✅ |
| 10 | 07-07 | crab-gateway | innies | 重量 | 部署更新 | zhiman/crab-gateway:3.0.1 | zhiman/yuwei/crab-gateway:3.0.3 | helm upgrade innies-stack R18→R21 | AI运维 | Pod Running ✅ |
| 11 | 07-07 | innies-fe | innies | 重量 | 部署更新 | zhiman/innies-fe:2.0.60 | zhiman/yuwei/innies-fe:2.0.66 | helm upgrade innies-stack R18→R21 | AI运维 | Pod Running ✅ |
| 12 | 07-07 | innies-users | innies | 重量 | 部署更新 | zhiman/innies-users:0.1.37 | zhiman/yuwei/innies-users:1.3.2 | helm upgrade innies-stack R18→R21 | AI运维 | Pod Running ✅ |
| 13 | 07-07 | values.yaml registry | innies | 轻量 | 配置修正 | 5服务registry=zhiman/<svc> | 改为zhiman/yuwei/<svc>匹配镜像实际路径 | - | AI运维 | 已验证 |
| 14 | 07-07 | crab-gateway | innies | 重量 | 镜像同步 | - | 同步crab-gateway:customer-3.0.3到Harbor(未部署,CUSTOMER模式需license) | nerdctl pull/tag/push | AI运维 | Harbor已存储,未部署 |

**关键决策**：
1. crab-gateway customer-3.0.3 是 CUSTOMER 模式，强制 license 校验，81 上无 license 文件，最终改用标准模式 3.0.3
2. 发现 Helm chart registry 路径(zhiman/<svc>)与镜像实际路径(zhiman/yuwei/<svc>)不一致，导致首次 ImagePullBackOff。修正 values.yaml 中 5 个服务的 registry 字段后解决
3. 复制规则只触发一次(exec_id=144)，全量扫描覆盖全部6个镜像
4. 备份: values.yaml.bak.20260708 @180, helm REVISION 21(回滚目标18)

### 2026-07-08 pdf2zh回滚 + 知识库修正 (重量/轻量)

| # | 日期 | 服务 | 命名空间 | 级别 | 类型 | 变更前 | 变更后 | 部署方式 | 操作人 | 验证 |
|---|------|------|----------|------|------|--------|--------|----------|--------|------|
| 7 | 07-08 | pdf2zh | innies | 重量 | 回滚 | busybox误配导致CrashLoopBackOff | 回滚至revision5(镜像1.9.11-offline-0.1.0)+同步恢复deployment.yaml | kubectl rollout undo | AI运维 | Pod Running |
| 6 | 07-08 | ref-lessons-learned | - | 轻量 | 文档更新 | 无Lesson-004 | 新增Lesson-004(vault读取效率优化) | - | AI运维 | 已验证 |
| 5 | 07-08 | INDEX | - | 轻量 | 文档更新 | 无vault-cli入口 | 新增REF-VaultCLI+快速导航入口 | - | AI运维 | 已验证 |
| 4 | 07-08 | ref-vault-cli(新增) | - | 轻量 | 工具新增 | 无 | 新增cli_vault.py(search/read/grep/slice/deploy-check) | - | AI运维 | 已验证 |
| 3 | 07-08 | ref-env-context | - | 轻量 | 文档修正 | SSH仅用于文件操作 | SSH用于文件操作+部署执行 | - | AI运维 | 已验证 |
| 2 | 07-08 | sop-002-k8s-rollout | - | 轻量 | 文档修正 | 前置条件/注意事项未区分查询vs部署 | 补充SSH到180部署执行说明 | - | AI运维 | 已验证 |
| 1 | 07-08 | sop-002-k8s-rollout-quickref | - | 轻量 | 文档修正 | kubectl apply/helm upgrade标注为179直连 | 改为SSH到180执行 | - | AI运维 | 已验证 |

**关键决策**：
1. kubectl apply/helm upgrade/helm rollback/kubectl rollout undo均需SSH到180执行
2. kubectl get/helm status等查询命令179直连即可
3. ref-env-context连接方式表格和说明同步修正

### 2026-07-07 知识库优化 (轻量)

| # | 日期 | 服务 | 命名空间 | 级别 | 类型 | 变更前 | 变更后 | 部署方式 | 操作人 | 验证 |
|---|------|------|----------|------|------|--------|--------|----------|--------|------|
| - | 07-07 | 知识库(vault) | - | 轻量 | 文档优化 | 原始README/INDEX/模板 | 优化后版本 | - | AI运维 | 已验证 |

**关键决策**：
1. 修复年份不一致(2025->2026)
2. README改为简要介绍(含适用范围+快速入口)
3. INDEX增加故障排查速查+模板分类
4. 新增sop-troubleshooting-quickref.md(12类故障速查表)
5. SOP/Pipeline模板增加DRY_RUN参数+风格灵活性说明+底部导航
6. scripts/新增README.md(脚本索引)
7. 所有文档尾部统一添加返回导航
8. yaml-set方式标注为不推荐
9. sop-001脚本路径改为Obsidian链接引用

### 2026-07-01 Values修复与部署 (重量)

| # | 时间 | 服务 | 命名空间 | 变更级别 | 动作 | 旧tag/配置 | 新tag/配置 | 部署方式 | 操作人 | 备注 |
|---|------|------|----------|----------|------|------------|------------|----------|--------|------|
| 1 | 07-01 | ingress-nginx | innies | 重量 | 配置修复 | type=ClusterIP | type=NodePort+固定端口 | helm | AI运维 | 配置已修复 |
| 2 | 07-01 | innies-ingress | innies | 重量 | Annotation移除 | cert-manager annotation | 移除 | kubectl | AI运维 | annotation已移除 |
| 3 | 07-01 | innies values | innies | 重量 | 配置清理 | 含cert-manager行 | 删除该行 | helm | AI运维 | 配置已清理 |
| 4 | 07-01 | innies-biz/file-parser-api | innies | 重量 | 配置补全 | 缺少MINERU相关env | 补全27个env | helm | AI运维 | rev15成功 |
| 5 | 07-01 | deer-flow | innies | 重量 | 新增部署 | 无 | deer-flow-0.1.3.tgz | helm | AI运维 | Pod Running |
| 6 | 07-01 | deployment-reloader | llm | 重量 | 新增部署 | 无 | SA+Role+RB+Svc+Deploy | yaml | AI运维 | Pod Running |
| 7 | 07-01 | innies-loom | innies | 重量 | 配置补全 | 缺DEEP_SEARCH env | 补2个env | helm | AI运维 | rev16成功 |

**关键决策**：deer-flow不需要GPU；deployment-reloader资源极小(200m/256Mi)；zhiman-pdfminer需要GPU(hami共享50/50)；ingress-nginx必须NodePort+固定端口31819/31517。

### 2026-06-30 知识库文档体系建设 (重量)

| # | 时间 | 服务 | 命名空间 | 变更级别 | 动作 | 旧tag/配置 | 新tag/配置 | 部署方式 | 操作人 | 备注 |
|---|------|------|----------|----------|------|------------|------------|----------|--------|------|
| 1 | 06-30 | Vault | - | 重量 | 文档新增 | 无 | ceph-storage/storage/secret-cert等 | - | AI运维 | OK |
| 2 | 06-30 | Vault | - | 重量 | 文档重构 | -detail.md散落 | 统一命名+去重引用 | - | AI运维 | OK |

### 2026-06-29 innies数据同步与运维修复 (重量)

| # | 时间 | 服务 | 命名空间 | 变更级别 | 动作 | 旧tag/配置 | 新tag/配置 | 部署方式 | 操作人 | 备注 |
|---|------|------|----------|----------|------|------------|------------|----------|--------|------|
| 1 | 06-29 | innies-users | innies | 重量 | 数据修复 | 缺失46条迁移记录 | 补全迁移记录 | SQL | AI运维 | Pod正常Running OK |
| 2 | 06-29 | llm模型调用 | llm | 重量 | 数据修复 | base_url=172.17.47.137:3000 | base_url=81 Ingress地址 | SQL | AI运维 | 模型调用恢复 OK |
| 3 | 06-29 | chunk_meta查询 | innies | 重量 | 索引补建 | 无索引 | CREATE INDEX CONCURRENTLY 4个 | SQL | AI运维 | 查询性能恢复 OK |
| 4 | 06-29 | chunk_meta磁盘 | innies | 重量 | 数据维护 | TOAST膨胀17.5GB | VACUUM FULL后正常 | SQL | AI运维 | 磁盘恢复正常 OK |
| 5 | 06-29 | QUOTA_ENDPOINT | innies | 重量 | 配置修复 | innies-dev | innies | DB配置 | AI运维 | 配额服务正常 OK |
| 6 | 06-29 | 全栈Pod | 多ns | 重量 | Pod重启 | 旧状态 | 重启验证 | kubectl | AI运维 | 全部Running OK |

**关键发现**：Pod内通过Ingress域名可访问81模型服务；Pod内无法直接访问172.17.47.137:3000(网络隔离)；llm表base_url是模型地址唯一来源。
