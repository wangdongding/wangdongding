# 存储详情 — PVC/PV/StorageClass 完整映射

> 🏷️ 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-06-30 | 类型: 只读参考

## 1. StorageClass

| SC | Provisioner | 默认 | 卷模式 | 适用场景 |
|------|-----------|------|--------|----------|
| ceph-block | rbd.csi.ceph.com | ✅ | Block | RBD块存储(低延迟/数据库/消息队列) |
| ceph-filesystem | cephfs.csi.ceph.com | ❌ | Filesystem | CephFS共享文件(多Pod读写/模型数据) |
| ceph-bucket | ceph.rook.io/bucket | ❌ | Object | S3对象存储(通过OBC provision) |

> ceph-block → RWO(单节点读写) | ceph-filesystem → RWX(多节点共享)
> 所有SC均支持卷扩容(allowVolumeExpansion=true)

## 2. PVC 完整清单

### 2.1 ceph-block (RWO)

| Namespace | PVC名 | 容量 | 用途 | PV名(前缀) |
|-----------|-------|------|------|------------|
| cnpg | postgres-cluster-prod-1 | 100Gi | PG主库数据 | pvc-7d3f6cff |
| cnpg | postgres-cluster-prod-2 | 100Gi | PG备库数据 | pvc-6d65de10 |
| innies | redis-data-innies-stack-redis-0 | 20Gi | Redis持久化 | pvc-7b2ac479 |
| rabbitmq | persistence-rabbitmq-cluster-prod-server-0 | 20Gi | RMQ节点0 | pvc-3d70bc30 |
| rabbitmq | persistence-rabbitmq-cluster-prod-server-1 | 20Gi | RMQ节点1 | pvc-3b31ff58 |
| milvus | data-milvus-etcd-0 | 10Gi | etcd数据0 | pvc-36bd1a0c |
| milvus | data-milvus-etcd-1 | 10Gi | etcd数据1 | pvc-bcc9c65a |
| milvus | data-milvus-etcd-2 | 10Gi | etcd数据2 | pvc-0b1afd9c |
| milvus | pulsarv3-bookie-journal-0 | 100Gi | Pulsar journal 0 | pvc-865a98a6 |
| milvus | pulsarv3-bookie-journal-1 | 100Gi | Pulsar journal 1 | pvc-d9bb03b6 |
| milvus | pulsarv3-bookie-journal-2 | 100Gi | Pulsar journal 2 | pvc-e2cd64a8 |
| milvus | pulsarv3-bookie-ledgers-0 | 200Gi | Pulsar ledger 0 | pvc-57acfa83 |
| milvus | pulsarv3-bookie-ledgers-1 | 200Gi | Pulsar ledger 1 | pvc-52f95ee0 |
| milvus | pulsarv3-bookie-ledgers-2 | 200Gi | Pulsar ledger 2 | pvc-b6388d17 |
| milvus | pulsarv3-zookeeper-data-0 | 20Gi | ZK数据0 | pvc-d38f50b8 |
| milvus | pulsarv3-zookeeper-data-1 | 20Gi | ZK数据1 | pvc-ad5f862c |
| milvus | pulsarv3-zookeeper-data-2 | 20Gi | ZK数据2 | pvc-3221554 |
| **小计** | **17个** | **1142Gi** | | |

### 2.2 ceph-filesystem (RWX)

| Namespace | PVC名 | 容量 | 用途 | PV名(前缀) |
|-----------|-------|------|------|------------|
| innies | innies-stack-prism | 1Gi | LLM模型配置 | pvc-a3d4ee04 |
| innies | innies-stack-synapse | 1Gi | 知识库配置 | pvc-22d1aa78 |
| innies | innies-stack-z8m | 10Gi | N8N工作流数据 | pvc-c3e937ab |
| llm | infinity-model-data | 10Gi | VL Embedding模型 | pvc-66fceeef |
| llm | vllm-adapter-data | 50Gi | VLLM adapter数据 | pvc-a9105518 |
| llm | vllm-model-data | 200Gi | VLLM模型文件 | pvc-3b812086 |
| llm | xinference-model-data | 10Gi | Xinference模型 | pvc-3cbceef8 |
| milvus | milvus-logs | 10Gi | Milvus日志 | pvc-c931abe3 |
| **小计** | **8个** | **400Gi** | | |

## 3. 汇总统计

| SC | PVC数 | 总容量 | 访问模式 |
|------|-------|--------|----------|
| ceph-block | 17 | 1142Gi | RWO |
| ceph-filesystem | 8 | 400Gi | RWX |
| **合计** | **25** | **1542Gi** | |

## 4. 大容量PVC TOP5

| 排名 | PVC | 容量 | 用途 | 可扩容? |
|------|-----|------|------|---------|
| 1 | vllm-model-data | 200Gi | VLLM模型 | ✅ |
| 2 | pulsarv3-bookie-ledgers-0/1/2 | 各200Gi | Pulsar存储 | ✅ |
| 3 | pulsarv3-bookie-journal-0/1/2 | 各100Gi | Pulsar日志 | ✅ |
| 4 | postgres-cluster-prod-1/2 | 各100Gi | PG数据 | ✅ |
| 5 | vllm-adapter-data | 50Gi | VLLM adapter | ✅ |

> ⚠️ Pulsar 3组 ledger(600Gi) + 3组 journal(300Gi) = 900Gi，占总量58%
> 这些Pulsar PVC是Milvus消息队列的依赖，Milvus v2.6仍需Pulsar

## 5. PVC扩容操作

```bash
# 1. 修改PVC容量(不需要重启Pod,ceph-block/ceph-filesystem均支持在线扩容)
kubectl patch pvc <pvc名> -n <namespace> -p '{"spec":{"resources":{"requests":{"storage":"<新容量>"}}}}'

# 2. 验证扩容结果
kubectl get pvc <pvc名> -n <namespace>
```

## 6. PVC删除注意事项

- ReclaimPolicy=Delete，删除PVC后数据**不可恢复**
- 优先删除Deployment/StatefulSet，再删PVC
- 数据库PVC(cnpg)不可随意删除，需要先做备份

> Ceph 层集群状态/PG/OSD 监控见 [[ref-ceph-storage]]
> 返回导航: [[INDEX]]
