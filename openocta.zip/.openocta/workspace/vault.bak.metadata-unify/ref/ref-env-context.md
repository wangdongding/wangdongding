# 运维环境上下文卡片

> 🏷️ 会话初始化必读 | 最后更新: 2026-07-08

## 一句话结论

**会话开始时直接读取此文件，无需探测环境，0步即可定位。**

---

## 本机信息 (179)

| 项目 | 值 |
|------|----- |
| IP | 172.17.3.179 |
| 角色 | Harbor 镜像仓库 + JumpServer + LLM Dashboard |
| kubectl | ✅ v1.29.9 (直连180集群) |
| Helm | ✅ v3.17.4 (直连180集群) |
| Harbor | 运行中 (9容器, healthy) |

> 详细集群信息见 [[ref-k8s-cluster]]

## 连接方式

| 方式 | 详情 | 优先使用 |
|------|------|---------|
| **kubectl 直连** | kubeconfig → /root/.kube/config, server: https://172.17.3.180:6443 | ⭐ **首选** |
| **SSH** | ssh 172.17.3.180 | 文件操作(yaml/values备份/修改) + 部署执行(kubectl apply/helm upgrade) |

> ⚠️ 查询类命令(kubectl get/helm status)在179直连执行。部署类命令(kubectl apply/helm upgrade)和文件操作需SSH到180，因yaml/values/tgz文件在180节点。

## 常用路径 (180节点)

| 路径 | 用途 |
|------|------ |
| /data/zhiman/innies/ | innies 业务配置根目录 |
| /data/zhiman/innies/values.yaml | innies-stack Helm values |
| /data/zhiman/innies/pdf2zh/deployment.yaml | pdf2zh yaml 直部署 |
| /data/zhiman/vllm/values.yaml | vllm Helm values |
| /data/zhiman/xinference/values.yaml | xinference Helm values |
| /data/zhiman/milvus/values.yaml | milvus Helm values |
| /data/zhiman/infinity/values.yaml | infinity Helm values |

> 完整目录结构见 [[sop-helm-ops]] §2

## Harbor 仓库

| 项目 | 值 |
|------|----- |
| 地址 | 172.17.3.179 (不加 :80) |
| 镜像格式 | 172.17.3.179/kubernetes/<服务名>/<镜像名>:<tag> |

> 详细 Harbor 信息见 [[ref-harbor-infra]]

## 平台约束

| 约束 | 说明 |
|------|------ |
| Bash 硬超时 | 10 秒，超时截断无返回 |
| 命令禁止换行 | Bash 命令不能包含换行符 |
| 等待类命令 | ❌ 禁止 rollout status --timeout>10s 等；改用轮询模式 |
| 读取vault文件 | ❌ read 工具会折叠长文件中间部分；✅ 优先用 `cli_vault.py slice` 精准提取行范围，或 `bash sed -n` 分段读取 |

## 知识库关键词映射

| 搜索关键词 | 实际文档 |
|-----------|--------- |
| 180集群 / 180 / ai-q | ref-k8s-cluster |
| 部署方式 / 服务注册 | ref-service-deploy-registry |
| 环境上下文 / 连接方式 | ref-env-context |
| 镜像同步 / Harbor同步 | sop-001-harbor-image-sync |
| 部署更新 / rollout | sop-002-k8s-rollout-quickref |
| 健康检查 / pod状态 | sop-003-service-check |
| 经验教训 / 常见问题 | ref-lessons-learned |
| vault读取 / vault搜索 | ref-vault-cli (⭐ 优先用 cli_vault.py slice/search 代替 read 工具) |
| Helm升级 / helm命令 | sop-helm-ops |

> 返回导航: [[INDEX]]
