# 经验教训与常见问题

> 🏷️ 环境归属: **180测试集群** (ai-q, 172.17.3.180)
> 最后更新: 2026-07-08 | 类型: 活跃维护（遇到问题后追加）

## 一句话结论

**遇到问题排查解决后，在此记录根因和解决方案，供下次快速参考。**

---

## 常见问题速查

| # | 症状 | 根因 | 解决方案 | 首次发现 | 相关文档 |
|---|------|------|----------|----------|----------|
| 1 | llm模型调用不通 | llm表base_url指向外部IP(172.17.47.137:3000)，Pod内不可达 | 改base_url为Ingress域名地址 | 2026-06-29 | [[ref-service-call-chain]] |
| 2 | innies-users Pod CrashLoopBackOff | 数据迁移后表结构不匹配，缺少46条迁移记录 | 导入迁移记录后重建Pod | 2026-06-29 | [[sop-troubleshooting-runbook]] |
| 3 | chunk_meta查询慢 | 4个索引缺失 | CREATE INDEX CONCURRENTLY补建 | 2026-06-29 | [[ref-database]] |
| 4 | 回滚后下次部署又前滚 | 只做了集群回滚(kubectl rollout undo / helm rollback)，没恢复本地values/yaml文件 | 回滚必须两步：集群回滚 + cp .bak恢复文件 | 多次发生 | [[sop-002-k8s-rollout-quickref]] |
| 5 | Harbor镜像地址带:80导致拉取失败 | HTTP默认80端口，地址中不应写:80 | 地址统一写172.17.3.179不带:80，certs.d也去掉:80 | 2026-06-29 | [[ref-harbor-infra]] |
| 6 | helm upgrade子服务触发全Chart reconcile | 修改values.yaml中子服务tag后helm upgrade整个release | 这是helm大Chart的正常行为，注意影响范围 | 2026-06-29 | [[ref-helm-values-coverage]] |
| 7 | memory_search嵌套链读取失败 | 平台中间件多层.output嵌套 | 直接bash cat/grep读vault原始文件 | 2026-07-08 | [[ref-vault-cli]] |


---

## 经验教训（深度复盘）

### Lesson-001: 回滚必须同步文件
- **场景**: 多次部署回滚后发现服务又自动"前滚"
- **根因**: kubectl rollout undo / helm rollback 只回滚了集群状态，本地values.yaml或deployment.yaml的image tag仍然是新值，下次apply/upgrade又触发前滚
- **原则**: **集群回滚 + 文件同步，缺一不可**
- **操作**: 回滚后必须 `cp .bak` 恢复 values/yaml

### Lesson-002: Harbor地址不带:80
- **场景**: 镜像拉取失败，containerd certs.d配置不一致
- **根因**: HTTP默认80端口，Harbor地址写172.17.3.179:80与certs.d目录名不匹配
- **原则**: **地址统一172.17.3.179不带:80，certs.d目录名、hosts.toml、config.toml都不带:80**
- **操作**: 已全部修正，详见 [[ref-harbor-infra]]

### Lesson-003: LLM调用必须走Ingress

### Lesson-004: vault读取效率优化(cli_vault.py)
- **场景**: memory_search 输出存文件 -> cat又存文件 -> 嵌套链3-12条命令才看到结果；部署参数散落5个文件
- **根因**: 平台中间件将bash/memory_search输出存到.output文件，cat该文件又存一层，形成嵌套链
- **原则**: **用cli_vault.py单条命令直达信息，替代嵌套读取链**
- **操作**: search/read/grep/slice/deploy-check 5个子命令，详见 [[ref-vault-cli]]
- **场景**: Pod内调用外部LLM服务不通
- **根因**: llm表base_url写的外部IP地址，Pod网络不可达
- **原则**: **集群内服务调用走Ingress域名，Pod内DNS可解析**
- **操作**: base_url改为Ingress地址

---
### Lesson-007: 服务起不来时直接读日志总结原因，不要自行跨机器排查
- **场景**: crab-gateway customer-3.0.3 CrashLoopBackOff，SSH到81机器找license文件，全盘搜索无果，再等用户决策，耗时约15分钟
- **根因**: 无文档记录customer-模式需license，Pod崩溃后自行跨机器排查license文件，拉长了整体处理时间
- **原则**: **⚠️ 服务起不来时，直接在179用 `kubectl logs <pod> --tail=30` 读日志（179 kubectl直连180集群），提取关键错误，一句话总结原因+建议方案交给用户决策。不要自行SSH到其他机器找文件/排查，会拉长整体时间。**
- **操作**: crab-gateway customer- tag 需 license 的事实已记录在 [[ref-service-deploy-registry]] crab-gateway 行备注中

### Lesson-006: values.yaml registry路径必须与实际拉取的镜像路径对齐，以镜像为准
- **场景**: 批量更新innies-stack 5个服务镜像，SOP-001同步推送到`zhiman/yuwei/<svc>`，但Helm chart的values.yaml中registry字段为`zhiman/<svc>`(不含`yuwei/`)，helm upgrade后所有新Pod报ImagePullBackOff/ErrImagePull
- **根因**: 镜像同步流程(SOP-001)推送路径为`zhiman/yuwei/<svc>`，而values.yaml中`image.registry`字段写的是`zhiman/<svc>`，两者不匹配，K8s拼接出的镜像地址在Harbor中不存在
- **原则**: **⚠️ 核心原则：values.yaml 中的 registry 必须以我们实际拉取/推送的镜像路径为标准去改 values，而不是反过来迁就 values 中的旧路径。遇到不一致时，改 values.yaml 去匹配镜像，不要补打 tag 去迁就 values。**
- **操作**: 已修正synapse/innies-biz/crab-gateway/innies-fe/innies-users共5个服务的registry为`zhiman/yuwei/<svc>`。redis(×2)/file-parser-api/z8m暂不改（Harbor中无对应yuwei路径镜像，Pod靠节点缓存运行，改了会ImagePullBackOff），待后续有这些镜像的新版本时一并处理

### Lesson-005: memory_search嵌套链实测失败 + 变更日志降序改造
- **场景**: pdf2zh回滚任务中，memory_search返回结果经bash cat读取后仍只得到"hits"元数据，无法获取实际搜索内容；变更日志按时间升序排列，每次需翻到末尾才看到最新记录
- **根因**: memory_search输出经平台中间件存为.output文件，bash cat读取该.output又存一层，嵌套2-3层后仍无法还原实际snippet内容；变更日志追加用echo >> 末尾追加，导致最新记录永远在最底部
- **原则**: **memory_search不可靠时直接bash cat读vault原始文件，不走嵌套链；变更日志改为时间降序排列，新增记录插入文件前部**
- **操作**: 1) 放弃memory_search嵌套链，直接grep/cat读vault文件获取上下文 2) ref-change-log重构为降序(07-08在前->06-29在末)，新增记录插入对应日期section首行或新增section到最前


## 新问题追加模板

遇到新问题时按以下格式追加到「常见问题速查」表和「经验教训」节：

**常见问题速查表新增行**:
| # | 症状 | 根因 | 解决方案 | 首次发现 | 相关文档 |

**经验教训新增节**:
### Lesson-XXX: 简要标题
- **场景**: ...
- **根因**: ...
- **原则**: ...
- **操作**: ...

---

## 相关文档
- [[sop-troubleshooting-runbook]] - 完整排查 Runbook
- [[ref-service-call-chain]] - 服务调用关系链
- [[ref-change-log]] - 变更日志（含部署操作记录）

> 返回导航: [[INDEX]]
