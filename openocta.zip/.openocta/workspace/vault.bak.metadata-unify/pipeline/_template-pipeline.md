# Pipeline 模板

> 复制此模板创建新 Pipeline，替换所有 <> 占位符

## 元数据
- pipeline_id: <PL-xxx>
- version: <1.0>
- owner: <负责人>
- last_updated: <日期>
- tags: [<标签>]
- depends_sop: [<引用的 SOP 文档>]
- depends_ref: [<引用的 ref 文档>]

## 说明
<一段话描述整个 Pipeline 做什么>

## 输入参数

| 参数 | 必填 | 说明 | 示例 |
|------|------|------|------|
| <name> | Y/N | <描述> | <值> |
| DRY_RUN | N | 仅输出命令不实际变更 | Y |

## 编排

| 序号 | SOP | 输入参数 | 条件 | 失败策略 |
|------|-----|----------|------|----------|
| 1 | [[sop-xxx-xxx]] | param={{xxx}} | 无 | abort |
| 2 | [[sop-xxx-xxx]] | param={{step1.output.xxx}} | step1=成功 | retry(N) then abort |

## 参数传递
- step1 -> step2: <说明上一步输出如何作为下一步输入>

## 整体回滚
- <按反序回滚各 SOP，或指定关键回滚点>

## 注意事项
- <跨 SOP 的依赖提醒>

> 返回导航: [[INDEX]]