# Pipeline: 镜像同步并部署

## 元数据
- pipeline_id: PL-001
- version: 2.0
- owner: 运维
- last_updated: 2026-07-06
- tags: [harbor, k8s, deploy, full-flow]
- depends_sop: [sop-001-harbor-image-sync, sop-002-k8s-rollout, sop-003-service-check]
- depends_ref: [ref-harbor-infra, ref-service-deploy-registry, ref-k8s-cluster]

## 说明
完整的应用镜像更新流程：将外部镜像同步到本地 Harbor → 更新 K8s 部署 → 健康检查。
支持三种执行模式：全流程 / 仅同步 / 仅部署，通过参数控制。

## 输入参数

| 参数 | 必填 | 说明 | 示例 |
|------|------|------|------|
| SVC | Y | 服务名（ref-service-deploy-registry 中注册的服务名） | pdf2zh |
| NS | Y | K8s 命名空间 | innies |
| NEW_TAG | Y | 新镜像 tag | latest |
| IMAGE | C | 原始镜像完整地址（SKIP_SYNC=N 时必填） | harbor.pvg2.zhiman.tech/yuwei/pdf2zh-api:latest |
| SKIP_SYNC | N | 跳过镜像同步（镜像已在生产 Harbor），默认 N | Y |
| SKIP_DEPLOY | N | 跳过部署更新（仅同步镜像），默认 N | Y |
| DRY_RUN | N | 仅输出命令不执行，默认 N | Y |

## 编排

| 序号 | SOP | 输入参数 | 条件 | 失败策略 |
|------|-----|----------|------|----------|
| 1 | [[sop-001-harbor-image-sync]] | IMAGE={{IMAGE}} | SKIP_SYNC=N | abort |
| 1.5 | **部署前校验门** | 见下方 | SKIP_DEPLOY=N | abort |
| 2 | [[sop-002-k8s-rollout]] | SVC={{SVC}}, NS={{NS}}, NEW_TAG={{NEW_TAG}}, DEPLOY_METHOD=从注册表查 | SKIP_DEPLOY=N, step1=成功或SKIP_SYNC=Y, step1.5=通过 | retry(1)→abort |
| 3 | [[sop-003-service-check]] | SVC={{SVC}}, NS={{NS}} | step2=成功或SKIP_DEPLOY=Y | notify+wait |

> **执行模式**：
> - **全流程**（默认）：SKIP_SYNC=N, SKIP_DEPLOY=N → step1→step2→step3
> - **仅同步**：SKIP_DEPLOY=Y → step1→step3（仅检查已有服务）
> - **仅部署**：SKIP_SYNC=Y → step1.5→step2→step3（镜像已就绪，直接更新部署）

## Step 1.5: 部署前校验门

> ⚠️ **核心原则：以实际拉取/推送的镜像路径为标准，不迁就 values.yaml 中的旧路径。**

| 子步骤 | 操作 | 说明 |
|--------|------|------|
| 1.5a | 从 values.yaml 提取 registry 字段 | `grep 'registry:' VALUES_PATH` 获取当前 registry 路径 |
| 1.5b | 拼接目标镜像地址 | `repo/registry:NEW_TAG`，如 `172.17.3.179/zhiman/yuwei/synapse:3.0.2` |
| 1.5c | 查 Harbor 中该镜像是否存在 | `curl -s -k -u admin:admin HARBOR_API/projects/zhiman/repositories` 匹配 registry 字段 |
| 1.5d | 比对 | 若 values.yaml registry 与 Harbor 实际镜像路径不一致 → **以镜像路径为准，自动修正 values.yaml registry 字段** |
| 1.5e | 修正后确认 | `sed -n 'LINEp' VALUES_PATH` 确认修改生效 |

- **触发条件**：SKIP_DEPLOY=N
- **通过条件**：values.yaml registry 与 Harbor 实际镜像路径一致
- **不一致处理**：自动修正 values.yaml → 重新确认 → 通过
- **失败策略**：abort（镜像不存在于 Harbor 任何路径）
- **依赖**：[[ref-lessons-learned]] Lesson-006

## 参数传递
- step1 → step2: 镜像同步产出的 TARGET_IMAGE 中的 tag → 确认 NEW_TAG 在生产 Harbor 可用
- step2 → step3: namespace + service → 健康检查目标
- 注册表查询: step2 执行前，从 [[ref-service-deploy-registry]] 查询 SVC 的 DEPLOY_METHOD 和配置路径

## 整体回滚
1. step2 回滚: 按 [[sop-002-k8s-rollout]] 回滚方案执行（helm rollback 或 kubectl rollout undo）
2. step1 回滚: 无需（镜像已推送不影响现有运行部署）

## 触发话语映射

| 用户意图 | 触发话语示例 | 执行路径 |
|---------|------------|---------|
| 镜像同步 + 部署 + 检查 | 「升级 pdf2zh 到 latest」「更新 xxx 服务到 v2.0」 | PL-001 全流程 |
| 仅镜像同步 | 「同步 xxx 镜像」「把 xxx 镜像拉到本地 Harbor」 | SOP-001 单独执行 |
| 仅部署更新 | 「部署 pdf2zh 用 latest」「更新 xxx 服务镜像（已同步）」 | SOP-002 单独执行 |
| 仅健康检查 | 「检查 xxx 服务状态」「xxx 服务健康吗」 | SOP-003 单独执行 |

## 注意事项
- step1 的复制规则推送到远端有延迟，step2 需确认远端镜像可用再执行
- step2 执行前**必须**先查 [[ref-service-deploy-registry]] 确认部署方式，不要凭记忆判断
- step3 检查失败不自动回滚，需人工判断是否回滚
- helm 方式更新大 Chart 子服务时，helm upgrade 会触发父 release 所有子服务 reconcile，注意影响范围
- DRY_RUN=Y 时仅输出将要执行的命令，不实际变更

## 相关文档
- [[ref-service-deploy-registry]] - 服务部署方式注册表（**必查**）
- [[sop-001-harbor-image-sync]] - 镜像同步 SOP
- [[sop-002-k8s-rollout]] - K8s 部署更新 SOP
- [[sop-003-service-check]] - 服务健康检查 SOP
- [[ref-k8s-cluster]] - 集群环境信息
> 返回导航: [[INDEX]]
