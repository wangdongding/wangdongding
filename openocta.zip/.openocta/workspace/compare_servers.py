#!/usr/bin/env python3
"""Robust WinRM SOAP client - execute PowerShell commands via WinRM Basic auth"""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET
import base64, uuid, time

NS = {
    's': 'http://www.w3.org/2003/05/soap-envelope',
    'wsa': 'http://schemas.xmlsoap.org/ws/2004/08/addressing',
    'wsman': 'http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd',
    'wsmv': 'http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd',
    'rsp': 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell',
}

CONTENT_TYPE = 'application/soap+xml; charset=UTF-8'
SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'

def soap_env(body_inner, to_url, action, max_envelope='153600'):
    msg_id = str(uuid.uuid4())
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
 xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
 xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
 xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
 <s:Header>
  <a:Action>{action}</a:Action>
  <a:To>{to_url}</a:To>
  <w:MaxEnvelopeSize p:MustUnderstand="true">{max_envelope}</w:MaxEnvelopeSize>
  <a:MessageID>uuid:{msg_id}</a:MessageID>
  <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
  <w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
  <p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
  <p:SessionId mustUnderstand="false">uuid:{str(uuid.uuid4())}</p:SessionId>
 </s:Header>
 <s:Body>{body_inner}</s:Body>
</s:Envelope>'''

def create_shell(url, auth):
    action = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Create'
    body = '''<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
  <rsp:InputStreams>stdin</rsp:InputStreams>
  <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
</rsp:Shell>'''
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
                      data=soap_env(body, url, action), verify=False, timeout=15)
    if r.status_code != 200:
        return None, f"HTTP {r.status_code}: {r.text[:500]}"
    root = ET.fromstring(r.content)
    sel = '{http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd}SelectorSet'
    sh = root.find(f'.//{{{NS["s"][0]}}}Body//{{{NS["wsman"]}}}SelectorSet')
    shell_id = None
    if sh is not None:
        for sel_e in sh.findall(f'{{{NS["wsman"]}}}Selector'):
            if sel_e.get('Name') == 'ShellId':
                shell_id = sel_e.text
    return shell_id, r.text[:300]

def exec_cmd(url, auth, shell_id, command):
    action = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command'
    body = f'''<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
  <rsp:Command>{command}</rsp:Command>
</rsp:CommandLine>'''
    selector = f'''<w:SelectorSet xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <w:Selector Name="ShellId">{shell_id}</w:Selector>
</w:SelectorSet>'''
    env = soap_env(body + selector, url, action)
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
                      data=env, verify=False, timeout=15)
    if r.status_code != 200:
        return None, f"HTTP {r.status_code}: {r.text[:500]}"
    root = ET.fromstring(r.content)
    cmd_id = None
    for e in root.iter():
        if e.tag.endswith('}CommandId') or e.tag == 'CommandId':
            cmd_id = e.text
            break
    return cmd_id, r.text[:300]

def receive_output(url, auth, shell_id, cmd_id):
    action = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive'
    body = f'''<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
  <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
</rsp:Receive>'''
    selector = f'''<w:SelectorSet xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <w:Selector Name="ShellId">{shell_id}</w:Selector>
</w:SelectorSet>'''
    env = soap_env(body + selector, url, action)
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
                      data=env, verify=False, timeout=20)
    if r.status_code != 200:
        return f"HTTP {r.status_code}: {r.text[:500]}"
    root = ET.fromstring(r.content)
    streams = []
    for e in root.iter():
        if e.tag.endswith('}Stream') or e.tag == 'Stream':
            if e.text:
                try:
                    decoded = base64.b64decode(e.text).decode('utf-8', errors='replace')
                    streams.append(decoded)
                except:
                    streams.append(f"[b64:{e.text[:100]}]")
    # Check exit code
    exit_code = None
    for e in root.iter():
        if e.tag.endswith('}ExitCode') or e.tag == 'ExitCode':
            exit_code = e.text
    result = ''.join(streams).strip()
    if exit_code:
        result += f"\n[ExitCode: {exit_code}]"
    return result if result else "[No output]"

def signal(url, auth, shell_id, cmd_id):
    action = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal'
    body = f'''<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
  <rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code>
</rsp:Signal>'''
    selector = f'''<w:SelectorSet xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <w:Selector Name="ShellId">{shell_id}</w:Selector>
</w:SelectorSet>'''
    env = soap_env(body + selector, url, action)
    requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
                  data=env, verify=False, timeout=10)

def delete_shell(url, auth, shell_id):
    action = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete'
    selector = f'''<w:SelectorSet xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <w:Selector Name="ShellId">{shell_id}</w:Selector>
</w:SelectorSet>'''
    env = soap_env(selector, url, action)
    requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
                  data=env, verify=False, timeout=10)

def run_ps(url, auth, ps_cmd):
    """Run a PowerShell command via WinRM"""
    # Encode the PowerShell command
    encoded = base64.b64encode(ps_cmd.encode('utf-16-le')).decode('ascii')
    cmd = f'powershell -NoProfile -NonInteractive -EncodedCommand {encoded}'
    
    sid, serr = create_shell(url, auth)
    if not sid:
        return f"Create shell failed: {serr}"
    
    cid, cerr = exec_cmd(url, auth, sid, cmd)
    if not cid:
        delete_shell(url, auth, sid)
        return f"Exec failed: {cerr}"
    
    # Wait a bit for command to complete
    time.sleep(1)
    
    output = receive_output(url, auth, sid, cid)
    signal(url, auth, sid, cid)
    delete_shell(url, auth, sid)
    return output

# === Compare both servers ===
TARGET_88 = "172.17.3.88"
AUTH_88 = HTTPBasicAuth("Compiler", "Yuwei@2505")
URL_88 = f"http://{TARGET_88}:5985/wsman"

TARGET_193 = "172.17.3.193"
AUTH_193 = HTTPBasicAuth("administrator", "admin!123")
URL_193 = f"http://{TARGET_193}:5985/wsman"

# Commands to run on both servers
CMDS = {
    "WinRM_Service_Auth": "winrm get winrm/config/service/auth",
    "WinRM_Service_AllowUnencrypted": "winrm get winrm/config/service | Select-String AllowUnencrypted",
    "WinRM_Service_CbtHardeningLevel": "winrm get winrm/config/service | Select-String CbtHardeningLevel",
    "UAC_LocalAccountTokenFilterPolicy": "Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name LocalAccountTokenFilterPolicy -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalAccountTokenFilterPolicy",
    "UAC_FilterAdministratorToken": "Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name FilterAdministratorToken -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FilterAdministratorToken",
    "UAC_EnableLUA": "Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name EnableLUA -ErrorAction SilentlyContinue | Select-Object -ExpandProperty EnableLUA",
    "CredSSP_Service": "Get-WSManCredSSP 2>&1 | Out-String",
    "Windows_Version": "[System.Environment]::OSVersion.VersionString; (Get-WmiObject Win32_OperatingSystem).Caption",
    "User_Groups": "whoami /groups /fo list",
    "User_Privileges": "whoami /priv /fo list",
}

# Test .193 first (Basic auth should work)
print("=" * 70)
print(f"=== 172.17.3.193 (PROBLEMATIC SERVER) ===")
print("=" * 70)
for name, cmd in CMDS.items():
    try:
        result = run_ps(URL_193, AUTH_193, cmd)
        print(f"\n--- {name} ---")
        print(result[:600])
    except Exception as e:
        print(f"\n--- {name} --- ERROR: {e}")

# Test .88 (Basic auth likely fails)
print("\n" + "=" * 70)
print(f"=== 172.17.3.88 (WORKING SERVER) ===")
print("=" * 70)
# First test if Basic auth works
try:
    result = run_ps(URL_88, AUTH_88, "echo hello")
    print(f"Basic auth test: {result[:200]}")
except Exception as e:
    print(f"Basic auth test FAILED: {e}")
    print("Need NTLM auth for .88 - cannot proceed with Basic auth")
