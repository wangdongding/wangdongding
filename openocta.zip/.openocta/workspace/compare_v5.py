#!/usr/bin/env python3
"""Compare WinRM config on 172.17.3.88 vs 172.17.3.193 via NTLM auth - FIXED"""

import requests, struct, hashlib, hmac, base64, uuid, xml.etree.ElementTree as ET

def md4(data):
    def f(x,y,z): return (x&y)|(~x&z)
    def g(x,y,z): return (x&y)|(x&z)|(y&z)
    def h(x,y,z): return x^y^z
    def rr(n,b): return ((n<<b)|(n>>(32-b)))&0xFFFFFFFF
    A,B,C,D = 0x67452301,0xefcdab89,0x98badcfe,0x10325476
    msg = bytearray(data)
    orig = len(data)*8
    msg.append(0x80)
    while len(msg)%64!=56: msg.append(0)
    msg += struct.pack('<Q',orig)
    for i in range(0,len(msg),64):
        X=list(struct.unpack('<16I',msg[i:i+64]))
        AA,BB,CC,DD = A,B,C,D
        for j in range(48):
            if j<16:   fn,s,ki = f,0,j
            elif j<32: fn,s,ki = g,0x5A827999,j//5
            else:      fn,s,ki = h,0x6ED9EBA1,j//3
            t = (rr(A,[3,7,11,19][j//16]) + fn(B,C,D) + X[ki] + s) & 0xFFFFFFFF
            A,D,C,B = D,C,B,t
        A=(A+AA)&0xFFFFFFFF; B=(B+BB)&0xFFFFFFFF
        C=(C+CC)&0xFFFFFFFF; D=(D+DD)&0xFFFFFFFF
    return struct.pack('<4I',A,B,C,D)

def build_type1():
    flags = 0x00088215
    msg = b'NTLMSSP\x00' + struct.pack('<I',1) + struct.pack('<I',flags)
    msg += struct.pack('<HHI',0,0,0) + struct.pack('<HHI',0,0,0)
    return base64.b64encode(msg).decode()

def extract_type2_token(auth_header):
    """Extract the Negotiate token from WWW-Authenticate header, handling multiple entries."""
    # The header might be like: "Negotiate TlRMTVNTU..., Negotiate TlRMTVNTU..."
    # Or: "Negotiate TlRMTVNTU..."
    # We need the token that starts with TlRMTVNTUA (NTLMSSP base64)
    # Important: "Negotiate " is 10 chars, and the token follows immediately
    idx = 0
    while True:
        idx = auth_header.find('Negotiate ', idx)
        if idx == -1:
            break
        # Token starts right after "Negotiate "
        token_start = idx + 10
        # Find end of token (next comma or end of string)
        token_end = auth_header.find(',', token_start)
        if token_end == -1:
            token_end = len(auth_header)
        token = auth_header[token_start:token_end].strip()
        # Check if this looks like a valid NTLM Type2 (starts with TlRMTVNTUA)
        if token.startswith('TlRMTVNTUA'):
            return token
        idx = token_start
    return ''

def parse_type2(raw):
    # Add base64 padding if needed
    raw += '=' * ((4 - len(raw) % 4) % 4)
    msg = base64.b64decode(raw)
    server_challenge = msg[24:32]
    neg_flags = struct.unpack('<I', msg[20:24])[0]
    target_info = b''
    if len(msg) > 48:
        ti_len = struct.unpack('<H', msg[40:42])[0]
        ti_off = struct.unpack('<I', msg[44:48])[0]
        target_info = msg[ti_off:ti_off+ti_len]
    return server_challenge, target_info, neg_flags

def build_type3(username, password, domain, server_challenge, target_info, neg_flags):
    ntpw = md4(password.encode('utf-16-le'))
    ntowfv2 = hmac.new(ntpw, (username.upper().encode('utf-16-le') + domain.encode('utf-16-le')), hashlib.md5).digest()
    temp = target_info + b'\x00\x00\x00\x00'
    nt_proof = hmac.new(ntowfv2, server_challenge + temp, hashlib.md5).digest()
    nt_resp = nt_proof + temp
    lm_resp = hmac.new(ntowfv2, server_challenge + b'\x00'*8, hashlib.md5).digest()
    domain_up = domain.upper() if domain else ''
    workstation = 'ANSIBLE'
    dom_enc = domain_up.encode('utf-16-le')
    usr_enc = username.encode('utf-16-le')
    ws_enc = workstation.encode('utf-16-le')
    base = 64
    lm_off = base
    nt_off = lm_off + len(lm_resp)
    dom_off = nt_off + len(nt_resp)
    usr_off = dom_off + len(dom_enc)
    ws_off = usr_off + len(usr_enc)
    sk_off = ws_off + len(ws_enc)
    msg = b'NTLMSSP\x00'
    msg += struct.pack('<I', 3)
    msg += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
    msg += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
    msg += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
    msg += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
    msg += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off)
    msg += struct.pack('<HHI', 0, 0, sk_off)
    msg += struct.pack('<I', 0x00088215)
    msg += lm_resp + nt_resp + dom_enc + usr_enc + ws_enc
    return base64.b64encode(msg).decode()

# ---- WinRM SOAP ----
SOAP_TPL = '''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>{action}</wsa:Action>
    <wsa:To>{to}</wsa:To>
    <wsman:ResourceURI wsmv:OptimizeEnumeration="true">{uri}</wsman:ResourceURI>
    <wsa:MessageID>uuid:{msgid}</wsa:MessageID>
    <wsa:ReplyTo><wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo>
    {extra_header}
  </s:Header>
  <s:Body>{body}</s:Body>
</s:Envelope>'''

SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'
CMD_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command'

def winrm_run(host, user, passwd, command, domain=''):
    url = f'http://{host}:5985/wsman'
    session = requests.Session()

    # NTLM Type1
    type1 = build_type1()
    resp1 = session.post(url, headers={
        'Content-Type': 'application/soap+xml; charset=UTF-8',
        'Authorization': f'Negotiate {type1}'
    }, timeout=8)
    if resp1.status_code not in (401, 407):
        return f"Unexpected after Type1: HTTP {resp1.status_code}"

    # Extract Type2
    auth_h = resp1.headers.get('WWW-Authenticate', '')
    t2 = extract_type2_token(auth_h)
    if not t2:
        return f"No Type2 token in: {auth_h[:200]}"

    server_challenge, target_info, neg_flags = parse_type2(t2)
    type3 = build_type3(user, passwd, domain, server_challenge, target_info, neg_flags)

    def soap(action, uri, body='', extra_header=''):
        msgid = str(uuid.uuid4())
        return SOAP_TPL.format(action=action, to=url, uri=uri, msgid=msgid, body=body, extra_header=extra_header)

    def sel(shell_id):
        return f'<wsman:SelectorSet><wsman:Selector Name="ShellId">{shell_id}</wsman:Selector></wsman:SelectorSet>'

    auth_header = f'Negotiate {type3}'

    # Create Shell
    create_body = '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>'
    r = session.post(url, data=soap('http://schemas.xmlsoap.org/ws/2004/09/transfer/Create', SHELL_URI, create_body).encode(),
        headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': auth_header}, timeout=8)
    if r.status_code != 200:
        return f"CreateShell HTTP {r.status_code}: {r.text[:300]}"

    root = ET.fromstring(r.text)
    shell_id = None
    for elem in root.iter():
        if 'ShellId' in elem.tag: shell_id = elem.text; break
    if not shell_id: return "No ShellId"

    # Execute
    b64_cmd = base64.b64encode(command.encode('utf-16-le')).decode()
    exec_body = f'<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>powershell.exe</rsp:Command><rsp:Arguments>-NoProfile -NonInteractive -EncodedCommand {b64_cmd}</rsp:Arguments></rsp:CommandLine>'
    r = session.post(url, data=soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command', CMD_URI, exec_body, sel(shell_id)).encode(),
        headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': auth_header}, timeout=8)
    if r.status_code != 200:
        return f"Execute HTTP {r.status_code}: {r.text[:300]}"

    root = ET.fromstring(r.text)
    command_id = None
    for elem in root.iter():
        if 'CommandId' in elem.tag: command_id = elem.text; break
    if not command_id: return "No CommandId"

    # Receive
    recv_body = f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream CommandId="{command_id}">stdout stderr</rsp:DesiredStream></rsp:Receive>'
    r = session.post(url, data=soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive', SHELL_URI, recv_body,
        sel(shell_id) + '<wsmv:OperationTimeout>PT60.000S</wsmv:OperationTimeout>').encode(),
        headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': auth_header}, timeout=15)
    if r.status_code != 200:
        return f"Receive HTTP {r.status_code}: {r.text[:300]}"

    root = ET.fromstring(r.text)
    stdout_b64, stderr_b64 = '', ''
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if tag == 'Stream':
            name = elem.attrib.get('Name','')
            content = elem.text or ''
            if 'stdout' in name: stdout_b64 += content
            elif 'stderr' in name: stderr_b64 += content

    stdout = base64.b64decode(stdout_b64).decode('utf-8', errors='replace') if stdout_b64 else ''
    stderr = base64.b64decode(stderr_b64).decode('utf-8', errors='replace') if stderr_b64 else ''

    # Signal + Delete
    sig_body = f'<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Code CommandId="{command_id}">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code></rsp:Signal>'
    try:
        session.post(url, data=soap('http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal', SHELL_URI, sig_body, sel(shell_id)).encode(),
            headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': auth_header}, timeout=5)
    except: pass
    try:
        session.post(url, data=soap('http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', SHELL_URI, '', sel(shell_id)).encode(),
            headers={'Content-Type': 'application/soap+xml; charset=UTF-8', 'Authorization': auth_header}, timeout=5)
    except: pass

    return stdout.strip() or stderr.strip() or '(no output)'

# ---- Main ----
cmds = [
    ('WinRM_Service', 'winrm get winrm/config/Service'),
    ('WinRM_Client', 'winrm get winrm/config/Client'),
    ('WinRM_WinRS', 'winrm get winrm/config/Winrs'),
    ('UAC_LocalAccountTokenFilterPolicy', 'Get-ItemProperty -Path HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System -Name LocalAccountTokenFilterPolicy -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalAccountTokenFilterPolicy'),
    ('UAC_FilterAdministratorToken', 'Get-ItemProperty -Path HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System -Name FilterAdministratorToken -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FilterAdministratorToken'),
    ('CredSSP_Service', 'Get-ItemProperty WSMan:\\localhost\\Service\\Auth\\CredSSP | Select-Object -ExpandProperty Value'),
    ('OS_Version', '[System.Environment]::OSVersion.VersionString'),
    ('CredSSP_Delegate', 'Get-ItemProperty WSMan:\\localhost\\Service\\Auth\\CredSSP -ErrorAction SilentlyContinue; Get-ItemProperty WSMan:\\localhost\\Client\\Auth\\CredSSP -ErrorAction SilentlyContinue'),
]

servers = [
    ('172.17.3.88', 'Compiler', 'Yuwei@2025', ''),
    ('172.17.3.193', 'administrator', 'admin!123', ''),
]

for srv, user, passwd, domain in servers:
    print(f"\n{'='*60}")
    print(f"  SERVER: {srv}  USER: {user}")
    print(f"{'='*60}")
    for cmd_name, ps_cmd in cmds:
        try:
            result = winrm_run(srv, user, passwd, ps_cmd, domain)
            print(f"\n--- {cmd_name} ---")
            print(result[:1200])
        except Exception as e:
            print(f"\n--- {cmd_name} --- ERROR: {type(e).__name__}: {e}")
