#!/usr/bin/env python3
"""Debug Create Shell - print full error"""
import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

URL = "http://172.17.3.193:5985/wsman"
AUTH = HTTPBasicAuth("administrator", "admin!123")

soap = '''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>http://172.17.3.193:5985/wsman</a:To>
    <w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:MessageID>uuid:aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee</a:MessageID>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</w:ResourceURI>
    <w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:SessionId mustUnderstand="false">uuid:ffffffff-eeee-dddd-cccc-bbbbbbbbbbbb</p:SessionId>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

r = requests.post(URL, auth=AUTH, headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                  data=soap, verify=False, timeout=15)
print(f"Status: {r.status_code}")
print(f"Content length: {len(r.content)}")

# Parse and print all text elements
root = ET.fromstring(r.content)
for elem in root.iter():
    if elem.text and elem.text.strip():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        print(f"  {tag}: {elem.text.strip()}")
