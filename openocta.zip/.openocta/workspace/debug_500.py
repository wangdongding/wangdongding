#!/usr/bin/env python3
"""Debug WinRM Create Shell HTTP 500 error"""
import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

URL = "http://172.17.3.193:5985/wsman"
AUTH = HTTPBasicAuth("administrator", "admin!123")

# Try the exact same SOAP that pywinrm uses
soap = '''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>http://172.17.3.193:5985/wsman</a:To>
    <w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:MessageID>uuid:11111111-1111-1111-1111-111111111111</a:MessageID>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:SessionId mustUnderstand="false">uuid:22222222-2222-2222-2222-222222222222</p:SessionId>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

r = requests.post(URL, auth=AUTH, headers={'Content-Type': 'application/soap+xml; charset=UTF-8'},
                  data=soap, verify=False, timeout=15)
print(f"Status: {r.status_code}")
print(f"Headers: {dict(r.headers)}")
print()

# Parse the SOAP fault
try:
    root = ET.fromstring(r.content)
    # Find fault details
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if elem.text and elem.text.strip():
            print(f"  {tag}: {elem.text.strip()}")
except:
    print(f"Raw: {r.text[:2000]}")
