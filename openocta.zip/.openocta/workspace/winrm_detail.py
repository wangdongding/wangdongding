import requests
from requests.auth import HTTPBasicAuth

url = 'http://172.17.3.193:5985/wsman'
soap = '<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:wsmid="http://schemas.dmtf.org/wbem/wsman/identity/1/wsmanidentity.xsd"><s:Header/><s:Body><wsmid:Identify/></s:Body></s:Envelope>'
headers = {'Content-Type': 'application/soap+xml;charset=UTF-8'}
r = requests.post(url, data=soap, headers=headers, auth=HTTPBasicAuth('administrator', 'admin!123'), timeout=10)
print(r.text)
