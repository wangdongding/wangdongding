#!/usr/bin/env python3
"""Execute short PowerShell commands via WinRM on 172.17.3.193"""

import requests
from requests.auth import HTTPBasicAuth
import base64
import uuid
import time
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def uid(): return f"uuid:{str(uuid.uuid4()).upper()}"

def soap_create_shell():
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OptionSet xmlns:x="http://www.w3.org/2001/XMLSchema-instance">
      <w:Option Name="WINRS_NOPROFILE" x:type="xs:boolean">false</w:Option>
      <w:Option Name="WINRS_CODEPAGE" x:type="xs:int">65001</w:Option>
    </w:OptionSet>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

def soap_command(shell_id, cmd, args=""):
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>{cmd}</rsp:Command>
      <rsp:Arguments>{args}</rsp:Arguments>
    </rsp:CommandLine>
  </s:Body>
</s:Envelope>'''

def soap_receive(shell_id, command_id):
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
      <rsp:CommandId>{command_id}</rsp:CommandId>
    </rsp:Receive>
  </s:Body>
</s:Envelope>'''

def soap_delete(shell_id):
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>'''

def encode_ps(cmd):
    return base64.b64encode(cmd.encode('utf-16-le')).decode('ascii')

def find_in_xml(xml_text, tag_name):
    root = ET.fromstring(xml_text)
    results = []
    for elem in root.iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name:
            results.append(elem.text or "")
    return results

def extract_streams(xml_text):
    root = ET.fromstring(xml_text)
    stdout_parts, stderr_parts = [], []
    for elem in root.iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == 'Stream':
            name = elem.attrib.get('Name', '')
            if elem.text:
                try:
                    decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                    if 'stdout' in name: stdout_parts.append(decoded)
                    elif 'stderr' in name: stderr_parts.append(decoded)
                except: pass
    return ''.join(stdout_parts), ''.join(stderr_parts)

def run_ps(ps_cmd, shell=None):
    """Run a PowerShell command and return output"""
    auth = HTTPBasicAuth(USER, PASS)
    hdrs = {'Content-Type': 'application/soap+xml; charset=UTF-8'}
    
    need_cleanup = False
    if shell is None:
        # Create new shell
        r = requests.post(URL, data=soap_create_shell(), auth=auth, headers=hdrs, timeout=15)
        if r.status_code != 200:
            return None, f"Create shell failed: HTTP {r.status_code}"
        shell_ids = find_in_xml(r.text, 'ShellId')
        shell = shell_ids[0] if shell_ids else None
        need_cleanup = True
    
    # Execute
    encoded = encode_ps(ps_cmd)
    r2 = requests.post(URL, data=soap_command(shell, "powershell.exe", f"-NoProfile -NonInteractive -EncodedCommand {encoded}"), auth=auth, headers=hdrs, timeout=30)
    if r2.status_code != 200:
        if need_cleanup: requests.post(URL, data=soap_delete(shell), auth=auth, headers=hdrs, timeout=10)
        return None, f"Command failed: HTTP {r2.status_code}"
    
    cmd_ids = find_in_xml(r2.text, 'CommandId')
    command_id = cmd_ids[0] if cmd_ids else None
    
    # Receive
    all_stdout, all_stderr = "", ""
    for i in range(20):
        time.sleep(1)
        r3 = requests.post(URL, data=soap_receive(shell, command_id), auth=auth, headers=hdrs, timeout=15)
        if r3.status_code == 200:
            out, err = extract_streams(r3.text)
            if out: all_stdout += out
            if err: all_stderr += err
            if 'Done' in r3.text:
                break
    
    if need_cleanup:
        requests.post(URL, data=soap_delete(shell), auth=auth, headers=hdrs, timeout=10)
    
    return all_stdout, all_stderr

# === Run diagnostic commands ===
print("=" * 60)
print("DIAGNOSING: Ansible become/runas hang on Windows")
print("=" * 60)

# 1. Basic connectivity
print("\n[1] Basic connectivity (whoami)...")
out, err = run_ps("whoami")
print(f"    Result: {out.strip() if out else 'EMPTY'}")

# 2. WinRM Auth config
print("\n[2] WinRM Auth configuration...")
out, err = run_ps("Get-ChildItem WSMan:\\localhost\\Service\\Auth | ForEach-Object { '{0}={1}' -f $_.Name,$_.Value }")
if out: print(f"    {out.strip()}")

# 3. CredSSP specifically
print("\n[3] CredSSP status...")
out, err = run_ps("(Get-Item WSMan:\\localhost\\Service\\Auth\\CredSSP).Value")
if out: print(f"    CredSSP = {out.strip()}")

# 4. UAC settings
print("\n[4] UAC settings...")
out, err = run_ps("$u=Get-ItemProperty HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System; 'EnableLUA={0} FilterAdminToken={1} LocalAcctFilter={2}' -f $u.EnableLUA,$u.FilterAdministratorToken,$u.LocalAccountTokenFilterPolicy")
if out: print(f"    {out.strip()}")

# 5. Check if current session has admin token
print("\n[5] Admin token check...")
out, err = run_ps("$id=[Security.Principal.WindowsIdentity]::GetCurrent(); $adminSid=[Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'); 'IsAdmin={0}' -f ($id.Groups -contains $adminSid)")
if out: print(f"    {out.strip()}")

# 6. AllowUnencrypted
print("\n[6] AllowUnencrypted...")
out, err = run_ps("(Get-Item WSMan:\\localhost\\Service\\AllowUnencrypted).Value")
if out: print(f"    AllowUnencrypted = {out.strip()}")

# 7. OS info
print("\n[7] OS info...")
out, err = run_ps("[System.Environment]::OSVersion.VersionString")
if out: print(f"    {out.strip()}")

print("\n" + "=" * 60)
print("ANALYSIS")
print("=" * 60)
