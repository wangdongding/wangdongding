#!/usr/bin/env python3
"""Compare WinRM configs between 172.17.3.88 (working) and 172.17.3.193 (broken)"""
import requests, uuid, time, xml.etree.ElementTree as ET

def run_ps(host, user, password, ps_cmd, timeout=30):
    url = f"http://{host}:5985/wsman"
    session_id = uuid.uuid4()
    # SOAP namespaces
    ns = {
        's': 'http://www.w3.org/2003/05/soap-envelope',
        'wsa': 'http://schemas.xmlsoap.org/ws/2004/08/addressing',
        'wsman': 'http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd',
        'wsmv': 'http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd',
    }
    # Step 1: Create shell
    create_shell = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:{session_id}</wsa:MessageID>
    <wsmv:OptionSet>
      <wsman:Option Name="WINRS_NOPROFILE" MustComply="true">FALSE</wsman:Option>
      <wsman:Option Name="WINRS_CODEPAGE" MustComply="true">65001</wsman:Option>
    </wsmv:OptionSet>
  </s:Header>
  <s:Body>
    <wsmv:Shell>
      <wsmv:InputStreams>stdin</wsmv:InputStreams>
      <wsmv:OutputStreams>stdout stderr</wsmv:OutputStreams>
    </wsmv:Shell>
  </s:Body>
</s:Envelope>'''

    auth = requests.auth.HTTPBasicAuth(user, password)
    headers = {'Content-Type': 'application/soap+xml; charset=UTF-8'}

    r1 = requests.post(url, data=create_shell, auth=auth, headers=headers, timeout=timeout)
    if r1.status_code != 200:
        return f"CreateShell failed: {r1.status_code} - {r1.text[:500]}"

    # Extract shell ID
    root = ET.fromstring(r1.text)
    shell_id = None
    for elem in root.iter():
        if 'ShellId' in elem.tag:
            shell_id = elem.text
            break
    if not shell_id:
        return f"No ShellId found in response: {r1.text[:500]}"

    # Step 2: Execute command
    cmd_id = uuid.uuid4()
    # Use PowerShell to run the command
    ps_wrapped = f'powershell -NoProfile -Command "{ps_cmd}"'
    run_cmd = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:{cmd_id}</wsa:MessageID>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
  </s:Header>
  <s:Body>
    <wsmv:CommandLine>
      <wsmv:Command>powershell.exe</wsmv:Command>
      <wsmv:Arguments>-NoProfile -NonInteractive -EncodedCommand {__ENC__}</wsmv:Arguments>
    </wsmv:CommandLine>
  </s:Body>
</s:Envelope>'''

    import base64
    encoded = base64.b64encode(ps_cmd.encode('utf-16-le')).decode('ascii')
    run_cmd = run_cmd.replace('__ENC__', encoded)

    r2 = requests.post(url, data=run_cmd, auth=auth, headers=headers, timeout=timeout)
    if r2.status_code != 200:
        return f"Command failed: {r2.status_code} - {r2.text[:500]}"

    # Extract command ID
    root2 = ET.fromstring(r2.text)
    command_id = None
    for elem in root2.iter():
        if 'CommandId' in elem.tag:
            command_id = elem.text
            break
    if not command_id:
        return f"No CommandId found: {r2.text[:500]}"

    # Step 3: Get output (poll)
    time.sleep(2)
    output_text = ""
    for _ in range(10):
        receive = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:{uuid.uuid4()}</wsa:MessageID>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
  </s:Header>
  <s:Body>
    <wsmv:Receive>
      <wsmv:DesiredStream>stdout stderr</wsmv:DesiredStream>
      <wsmv:CommandId>{command_id}</wsmv:CommandId>
    </wsmv:Receive>
  </s:Body>
</s:Envelope>'''

        r3 = requests.post(url, data=receive, auth=auth, headers=headers, timeout=timeout)
        if r3.status_code == 200:
            root3 = ET.fromstring(r3.text)
            done = False
            for elem in root3.iter():
                if 'Stream' in elem.tag:
                    if elem.text:
                        import base64 as b64
                        try:
                            decoded = b64.b64decode(elem.text).decode('utf-8', errors='replace')
                            output_text += decoded
                        except:
                            output_text += elem.text
                if 'CommandState' in elem.tag:
                    state = elem.get('State', '')
                    if 'Done' in state:
                        done = True
            if done:
                break
        time.sleep(1)

    # Step 4: Delete shell
    delete = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:{uuid.uuid4()}</wsa:MessageID>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>'''
    try:
        requests.post(url, data=delete, auth=auth, headers=headers, timeout=5)
    except:
        pass

    return output_text.strip()


# Commands to compare
commands = {
    "WinRM_Service_Auth": "winrm get winrm/config/service/auth",
    "WinRM_Service": "winrm get winrm/config/service",
    "WinRM_Client": "winrm get winrm/config/client",
    "WinRM_Config": "winrm get winrm/config",
    "CredSSP_Service": "winrm get winrm/config/service/auth | findstr CredSSP",
    "UAC_FilterPolicy": 'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v LocalAccountTokenFilterPolicy 2>nul || echo NOT_SET',
    "UAC_FilterPolicy2": 'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v FilterAdministratorToken 2>nul || echo NOT_SET',
    "CredSSP_Registry": 'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WinRM\\Service" /v AllowCredSSP 2>nul || echo NOT_SET',
    "CredSSP_Policy": 'reg query "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\CredentialsDelegation" /s 2>nul || echo NOT_SET',
    "User_Groups_admin": 'net user Administrator 2>nul | findstr /i "account active group"',
    "OS_Version": "systeminfo | findstr /B /C:\"OS Name\" /C:\"OS Version\"",
    "PS_Version": "$PSVersionTable.PSVersion.ToString()",
    "WinRM_Listen": "winrm enumerate winrm/config/listener",
    "UAC_Setting": 'reg query "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" /v EnableLUA 2>nul || echo NOT_SET',
}

servers = [
    {"host": "172.17.3.88", "user": "Compiler", "pass": "Yuwei@2605", "label": "88(正常)"},
    {"host": "172.17.3.193", "user": "administrator", "pass": "admin!123", "label": "193(卡住)"},
]

for name, cmd in commands.items():
    print(f"\n{'='*60}")
    print(f"### {name}")
    print(f"{'='*60}")
    for srv in servers:
        print(f"\n--- {srv['label']} ({srv['host']}) ---")
        try:
            result = run_ps(srv['host'], srv['user'], srv['pass'], cmd, timeout=25)
            print(result[:2000] if result else "(empty)")
        except Exception as e:
            print(f"ERROR: {e}")
