#!/usr/bin/env python3
"""WinRM SOAP client with proper ResourceURI - compare two servers"""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET
import base64, uuid, time

CONTENT_TYPE = 'application/soap+xml; charset=UTF-8'
SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'

def make_envelope(to_url, action, body_inner, resource_uri=None, selector_set=None):
    msg_id = str(uuid.uuid4())
    session_id = str(uuid.uuid4())
    res_header = ''
    if resource_uri:
        res_header = f'<w:ResourceURI xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" mustUnderstand="true">{resource_uri}</w:ResourceURI>'
    sel_header = ''
    if selector_set:
        sel_header = f'<w:SelectorSet xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">{selector_set}</w:SelectorSet>'
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>{action}</a:Action>
    <a:To>{to_url}</a:To>
    <w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:SessionId mustUnderstand="false">uuid:{session_id}</p:SessionId>
    {res_header}
    {sel_header}
  </s:Header>
  <s:Body>{body_inner}</s:Body>
</s:Envelope>'''

def create_shell(url, auth):
    action = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Create'
    body = '''<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
  <rsp:InputStreams>stdin</rsp:InputStreams>
  <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
</rsp:Shell>'''
    env = make_envelope(url, action, body, resource_uri=SHELL_URI)
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE}, data=env, verify=False, timeout=15)
    if r.status_code != 200:
        return None, f"HTTP {r.status_code}"
    root = ET.fromstring(r.content)
    shell_id = None
    for e in root.iter():
        tag = e.tag.split('}')[-1] if '}' in e.tag else e.tag
        if e.get('Name') == 'ShellId' and e.text:
            shell_id = e.text
    return shell_id, "OK"

def exec_cmd(url, auth, shell_id, command):
    action = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command'
    body = f'''<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
  <rsp:Command>{command}</rsp:Command>
</rsp:CommandLine>'''
    sel = f'<w:Selector Name="ShellId">{shell_id}</w:Selector>'
    env = make_envelope(url, action, body, resource_uri=SHELL_URI, selector_set=sel)
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE}, data=env, verify=False, timeout=15)
    if r.status_code != 200:
        return None, f"HTTP {r.status_code}"
    root = ET.fromstring(r.content)
    cmd_id = None
    for e in root.iter():
        tag = e.tag.split('}')[-1] if '}' in e.tag else e.tag
        if tag == 'CommandId' and e.text:
            cmd_id = e.text
    return cmd_id, "OK"

def receive(url, auth, shell_id, cmd_id):
    action = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive'
    body = f'''<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
  <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
</rsp:Receive>'''
    sel = f'<w:Selector Name="ShellId">{shell_id}</w:Selector>'
    env = make_envelope(url, action, body, resource_uri=SHELL_URI, selector_set=sel)
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE}, data=env, verify=False, timeout=20)
    if r.status_code != 200:
        return f"HTTP {r.status_code}"
    root = ET.fromstring(r.content)
    streams = []
    for e in root.iter():
        tag = e.tag.split('}')[-1] if '}' in e.tag else e.tag
        if tag == 'Stream' and e.text:
            try:
                streams.append(base64.b64decode(e.text).decode('utf-8', errors='replace'))
            except:
                streams.append(f"[decode error]")
    exit_code = None
    for e in root.iter():
        tag = e.tag.split('}')[-1] if '}' in e.tag else e.tag
        if tag == 'ExitCode' and e.text:
            exit_code = e.text
    result = ''.join(streams).strip()
    return result if result else "[No output]"

def signal(url, auth, shell_id, cmd_id):
    action = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal'
    body = f'''<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
  <rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code>
</rsp:Signal>'''
    sel = f'<w:Selector Name="ShellId">{shell_id}</w:Selector>'
    env = make_envelope(url, action, body, resource_uri=SHELL_URI, selector_set=sel)
    requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE}, data=env, verify=False, timeout=10)

def delete_shell(url, auth, shell_id):
    action = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete'
    sel = f'<w:Selector Name="ShellId">{shell_id}</w:Selector>'
    env = make_envelope(url, action, '', resource_uri=SHELL_URI, selector_set=sel)
    requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE}, data=env, verify=False, timeout=10)

def run_ps(url, auth, ps_cmd):
    encoded = base64.b64encode(ps_cmd.encode('utf-16-le')).decode('ascii')
    cmd = f'powershell -NoProfile -NonInteractive -EncodedCommand {encoded}'
    sid, serr = create_shell(url, auth)
    if not sid:
        return f"Create shell failed: {serr}"
    cid, cerr = exec_cmd(url, auth, sid, cmd)
    if not cid:
        delete_shell(url, auth, sid)
        return f"Exec failed: {cerr}"
    time.sleep(1)
    output = receive(url, auth, sid, cid)
    signal(url, auth, sid, cid)
    delete_shell(url, auth, sid)
    return output

# === Compare ===
TARGET_193 = "172.17.3.193"
AUTH_193 = HTTPBasicAuth("administrator", "admin!123")
URL_193 = f"http://{TARGET_193}:5985/wsman"

print("=" * 70)
print(f"=== 172.17.3.193 (PROBLEMATIC) ===")
print("=" * 70)

# Test simple echo first
print("\n--- Echo Test ---")
result = run_ps(URL_193, AUTH_193, "echo hello")
print(result)

# Now run diagnostic commands
cmds = [
    ("WinRM Auth Config", "winrm get winrm/config/service/auth"),
    ("WinRM Service Config", "winrm get winrm/config/service"),
    ("UAC LocalAccountTokenFilterPolicy", "Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name LocalAccountTokenFilterPolicy -ErrorAction SilentlyContinue | Format-List"),
    ("UAC FilterAdministratorToken", "Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name FilterAdministratorToken -ErrorAction SilentlyContinue | Format-List"),
    ("UAC EnableLUA", "Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name EnableLUA -ErrorAction SilentlyContinue | Format-List"),
    ("CredSSP Config", "Get-WSManCredSSP 2>&1 | Out-String"),
    ("Windows Version", "(Get-WmiObject Win32_OperatingSystem).Caption; [System.Environment]::OSVersion.VersionString"),
    ("User & Groups", "whoami /all"),
]

for name, cmd in cmds:
    print(f"\n--- {name} ---")
    try:
        result = run_ps(URL_193, AUTH_193, cmd)
        print(result[:800])
    except Exception as e:
        print(f"ERROR: {e}")
