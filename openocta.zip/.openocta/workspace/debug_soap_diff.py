#!/usr/bin/env python3
"""Test: the exact same SOAP that worked manually vs the generated one"""
import requests
from requests.auth import HTTPBasicAuth

URL = "http://172.17.3.193:5985/wsman"
AUTH = HTTPBasicAuth("administrator", "admin!123")

# The one that WORKED (from debug_500_v2.py)
soap_working = '''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>http://172.17.3.193:5985/wsman</a:To>
    <w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:MessageID>uuid:aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee</a:MessageID>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</w:ResourceURI>
    <w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:SessionId mustUnderstand="false">uuid:ffffffff-eeee-dddd-cccc-bbbbbbbbbbbb</p:SessionId>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

# The generated one from compare_v4.py
import uuid
msg_id = str(uuid.uuid4())
session_id = str(uuid.uuid4())
soap_generated = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>http://172.17.3.193:5985/wsman</a:To>
    <w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</w:ResourceURI>
    <w:SelectorSet></w:SelectorSet>
    <w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:SessionId mustUnderstand="false">uuid:{session_id}</p:SessionId>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

print("Testing WORKING version:")
r1 = requests.post(URL, auth=AUTH, headers={'Content-Type': 'application/soap+xml; charset=UTF-8'}, data=soap_working, verify=False, timeout=15)
print(f"  Status: {r1.status_code}")

print("\nTesting GENERATED version:")
r2 = requests.post(URL, auth=AUTH, headers={'Content-Type': 'application/soap+xml; charset=UTF-8'}, data=soap_generated, verify=False, timeout=15)
print(f"  Status: {r2.status_code}")

# The difference is the empty SelectorSet - let's try without it
soap_no_sel = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>http://172.17.3.193:5985/wsman</a:To>
    <w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:ResourceURI mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</w:ResourceURI>
    <w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
    <p:SessionId mustUnderstand="false">uuid:{session_id}</p:SessionId>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

print("\nTesting NO-SELECTOR version:")
r3 = requests.post(URL, auth=AUTH, headers={'Content-Type': 'application/soap+xml; charset=UTF-8'}, data=soap_no_sel, verify=False, timeout=15)
print(f"  Status: {r3.status_code}")
