#!/usr/bin/env python3
"""Minimal NTLMv2 auth + WinRM SOAP to run commands on Windows servers.
Pure Python - no external deps beyond requests."""

import requests, struct, hashlib, hmac, base64, time, uuid, random, string
# (md4 is defined below as pure Python)

# ---- MD4 (pure Python, for NTLMv2) ----
def md4(data: bytes) -> bytes:
    """Pure-Python MD4."""
    def f(x, y, z): return (x & y) | (~x & z)
    def g(x, y, z): return (x & y) | (x & z) | (y & z)
    def h(x, y, z): return x ^ y ^ z
    def left_rotate(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    A, B, C, D = 0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
    msg = bytearray(data)
    orig_len = len(data) * 8
    msg.append(0x80)
    while len(msg) % 64 != 56: msg.append(0)
    msg += struct.pack('<Q', orig_len)
    for i in range(0, len(msg), 64):
        X = list(struct.unpack('<16I', msg[i:i+64]))
        AA, BB, CC, DD = A, B, C, D
        for j in range(48):
            if j < 16:   a, b, c, d = f, 0, j, 0
            elif j < 32: a, b, c, d = g, 0x5A827999, (j//5), 0
            else:        a, b, c, d = h, 0x6ED9EBA1, (j//3), 0
            t = (left_rotate(A, [3,7,11,19][j//16]) + a(B,C,D) + X[c] + b) & 0xFFFFFFFF
            A, D, C, B = D, C, B, t
        A = (A + AA) & 0xFFFFFFFF; B = (B + BB) & 0xFFFFFFFF
        C = (C + CC) & 0xFFFFFFFF; D = (D + DD) & 0xFFFFFFFF
    return struct.pack('<4I', A, B, C, D)

# ---- NTLMv2 ----
def ntlmv2_response(password, username, domain, server_challenge, target_info):
    # NT Proof Str = HMAC-MD5(NTOWFv2, server_challenge || temp)
    # temp = concat all target_info fields + 4 zero bytes
    ntowfv2 = hmac.new(md4(password.encode('utf-16-le')), (username.upper().encode('utf-16-le') + domain.encode('utf-16-le')), hashlib.md5).digest()
    temp = target_info + b'\x00\x00\x00\x00'
    nt_proof = hmac.new(ntowfv2, server_challenge + temp, hashlib.md5).digest()
    return nt_proof + temp, ntowfv2

def build_type1(domain='', workstation=''):
    flags = 0x00088215  # NegotiateUnicode | NTLM | AlwaysSign | NegotiateNTLM2Key | Negotiate128 | Negotiate56
    sig = b'NTLMSSP\x00'
    type1 = 0x00000001
    data = struct.pack('<I', type1) + struct.pack('<I', flags)
    if domain:
        d = domain.encode('utf-16-le')
        data += struct.pack('<HHI', len(d), len(d), 32 + len(workstation.encode('utf-16-le')))
    else:
        data += struct.pack('<HHI', 0, 0, 0)
    if workstation:
        w = workstation.encode('utf-16-le')
        data += struct.pack('<HHI', len(w), len(w), 32)
    else:
        data += struct.pack('<HHI', 0, 0, 0)
    msg = sig + data
    if domain: msg += workstation.encode('utf-16-le') + domain.encode('utf-16-le')
    return base64.b64encode(msg).decode()

def parse_type2(raw):
    msg = base64.b64decode(raw)
    sig = msg[0:8]
    assert sig == b'NTLMSSP\x00', f"Bad sig: {sig}"
    server_challenge = msg[24:32]
    # TargetInfo
    if len(msg) > 48:
        ti_len = struct.unpack('<H', msg[40:42])[0]
        ti_off = struct.unpack('<I', msg[44:48])[0]
        target_info = msg[ti_off:ti_off+ti_len]
    else:
        target_info = b''
    # Negotiate flags
    neg_flags = struct.unpack('<I', msg[20:24])[0]
    return server_challenge, target_info, neg_flags

def build_type3(username, password, domain, server_challenge, target_info, neg_flags):
    nt_resp, ntowfv2 = ntlmv2_response(password, username, domain, server_challenge, target_info)
    lm_resp = hmac.new(ntowfv2, server_challenge + b'\x00'*8, hashlib.md5).digest()  # LMv2
    workstation = 'ANSIBLE'
    domain_up = domain.upper() if domain else ''
    # Base offset for data
    base = 72  # fixed header size
    dom_enc = domain_up.encode('utf-16-le')
    usr_enc = username.encode('utf-16-le')
    ws_enc = workstation.encode('utf-16-le')
    # Layout: lm_resp | nt_resp | domain | user | workstation
    lm_off = base
    nt_off = lm_off + len(lm_resp)
    dom_off = nt_off + len(nt_resp)
    usr_off = dom_off + len(dom_enc)
    ws_off = usr_off + len(usr_enc)
    msg_flags = 0x00088215
    sig = b'NTLMSSP\x00'
    header = sig
    header += struct.pack('<I', 3)  # Type3
    header += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)  # LM
    header += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)  # NT
    header += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)  # Domain
    header += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)  # User
    header += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off)  # Workstation
    header += struct.pack('<HHI', 0, 0, 0)  # Session key
    header += struct.pack('<I', msg_flags)
    assert len(header) == base, f"Header size mismatch: {len(header)} vs {base}"
    full = header + lm_resp + nt_resp + dom_enc + usr_enc + ws_enc
    return base64.b64encode(full).decode()

# ---- WinRM SOAP ----
NS = {
    's': 'http://www.w3.org/2003/05/soap-envelope',
    'wsa': 'http://schemas.xmlsoap.org/ws/2004/08/addressing',
    'wsman': 'http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd',
    'wsmv': 'http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd',
}
SOAP_HEADER = '''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>{action}</wsa:Action>
    <wsa:To>{to}</wsa:To>
    <wsman:ResourceURI wsmv:OptimizeEnumeration="true">{uri}</wsman:ResourceURI>
    <wsa:MessageID>uuid:{msgid}</wsa:MessageID>
    <wsa:ReplyTo><wsa:Address>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo>
  </s:Header>
  <s:Body>{body}</s:Body>
</s:Envelope>'''

SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'
CMD_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command'

def winrm_run(host, user, passwd, command, domain=''):
    url = f'http://{host}:5985/wsman'
    session = requests.Session()
    session.headers.update({'Content-Type': 'application/soap+xml; charset=UTF-8'})

    # Step 0: NTLM Type 1
    type1 = build_type1(domain=domain)
    resp1 = session.post(url, headers={'Authorization': f'Negotiate {type1}'}, timeout=8)
    if resp1.status_code not in (401, 407):
        return f"Unexpected status after Type1: {resp1.status_code}"

    # Get Type2 challenge from WWW-Authenticate header
    auth_header = resp1.headers.get('WWW-Authenticate', '')
    if 'Negotiate' not in auth_header:
        return f"No Negotiate challenge: {auth_header}"
    # Parse the token after "Negotiate "
    parts = auth_header.split('Negotiate ')
    type2_token = parts[1].strip() if len(parts) > 1 else ''
    if not type2_token:
        # Try X-Ms-Authorization-NTLM header
        type2_token = resp1.headers.get('X-Ms-Authorization-NTLM', '').replace('Negotiate ', '').strip()
    if not type2_token:
        return f"Empty Type2 token. Headers: {dict(resp1.headers)}"

    server_challenge, target_info, neg_flags = parse_type2(type2_token)
    type3 = build_type3(user, passwd, domain, server_challenge, target_info, neg_flags)

    # Step 1: Create Shell
    msgid = str(uuid.uuid4())
    create_body = '''
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
      <rsp:WorkingDirectory>C:\\</rsp:WorkingDirectory>
      <rsp:IdleTimeout>PT60.000S</rsp:IdleTimeout>
    </rsp:Shell>'''
    create_soap = SOAP_HEADER.format(
        action='http://schemas.xmlsoap.org/ws/2004/09/transfer/Create',
        to=url, uri=SHELL_URI, msgid=msgid, body=create_body)

    resp_create = session.post(url, data=create_soap.encode(),
        headers={'Authorization': f'Negotiate {type3}'}, timeout=8)
    if resp_create.status_code != 200:
        return f"Create shell failed: HTTP {resp_create.status_code}\n{resp_create.text[:500]}"

    # Extract ShellId from response
    import xml.etree.ElementTree as ET
    root = ET.fromstring(resp_create.text)
    ns_shell = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell'
    shell_id = None
    for elem in root.iter():
        if 'ShellId' in elem.tag:
            shell_id = elem.text
            break
    if not shell_id:
        return f"No ShellId found in create response"

    # Step 2: Execute command
    msgid = str(uuid.uuid4())
    b64_cmd = base64.b64encode(command.encode('utf-16-le')).decode()
    exec_body = f'''
    <rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>powershell.exe</rsp:Command>
      <rsp:Arguments>-NoProfile -NonInteractive -EncodedCommand {b64_cmd}</rsp:Arguments>
    </rsp:CommandLine>'''
    exec_soap = SOAP_HEADER.format(
        action='http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command',
        to=url, uri=CMD_URI, msgid=msgid, body=exec_body)

    # Need selector for ShellId
    selector_header = f'''<wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>'''
    exec_soap = exec_soap.replace('</wsa:ReplyTo>', f'</wsa:ReplyTo>\n    {selector_header}')

    resp_exec = session.post(url, data=exec_soap.encode(),
        headers={'Authorization': f'Negotiate {type3}'}, timeout=8)
    if resp_exec.status_code != 200:
        return f"Execute failed: HTTP {resp_exec.status_code}\n{resp_exec.text[:500]}"

    # Extract CommandId
    root = ET.fromstring(resp_exec.text)
    command_id = None
    for elem in root.iter():
        if 'CommandId' in elem.tag:
            command_id = elem.text
            break
    if not command_id:
        return f"No CommandId found"

    # Step 3: Receive output
    msgid = str(uuid.uuid4())
    recv_body = f'''
    <rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
    </rsp:Receive>'''
    recv_soap = SOAP_HEADER.format(
        action='http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive',
        to=url, uri=SHELL_URI, msgid=msgid, body=recv_body)
    recv_soap = recv_soap.replace('</wsa:ReplyTo>', f'''
    </wsa:ReplyTo>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
    <wsmv:OperationTimeout>PT60.000S</wsmv:OperationTimeout>''')

    # Add command ID to receive body
    recv_soap = recv_soap.replace('<rsp:DesiredStream>stdout stderr</rsp:DesiredStream>',
        f'<rsp:DesiredStream CommandId="{command_id}">stdout stderr</rsp:DesiredStream>')

    resp_recv = session.post(url, data=recv_soap.encode(), timeout=15)
    if resp_recv.status_code != 200:
        return f"Receive failed: HTTP {resp_recv.status_code}\n{resp_recv.text[:500]}"

    # Parse output
    root = ET.fromstring(resp_recv.text)
    stdout_b64, stderr_b64 = '', ''
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if tag == 'Stream':
            stream_name = elem.attrib.get('Name', '')
            content = elem.text or ''
            if 'stdout' in stream_name:
                stdout_b64 += content
            elif 'stderr' in stream_name:
                stderr_b64 += content

    stdout = base64.b64decode(stdout_b64).decode('utf-16-le', errors='replace') if stdout_b64 else ''
    stderr = base64.b64decode(stderr_b64).decode('utf-16-le', errors='replace') if stderr_b64 else ''

    # Step 4: Signal (terminate)
    msgid = str(uuid.uuid4())
    sig_body = f'''
    <rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code>
    </rsp:Signal>'''
    sig_soap = SOAP_HEADER.format(
        action='http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal',
        to=url, uri=SHELL_URI, msgid=msgid, body=sig_body)
    sig_soap = sig_soap.replace('</wsa:ReplyTo>', f'''
    </wsa:ReplyTo>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>''')
    sig_soap = sig_soap.replace('<rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code>',
        f'<rsp:Code CommandId="{command_id}">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code>')

    try:
        session.post(url, data=sig_soap.encode(), timeout=5)
    except: pass

    # Step 5: Delete shell
    msgid = str(uuid.uuid4())
    del_soap = SOAP_HEADER.format(
        action='http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete',
        to=url, uri=SHELL_URI, msgid=msgid, body='')
    del_soap = del_soap.replace('</wsa:ReplyTo>', f'''
    </wsa:ReplyTo>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>''')
    try:
        session.post(url, data=del_soap.encode(), timeout=5)
    except: pass

    return stdout or stderr or '(no output)'

# ---- Main: Compare both servers ----
cmds = [
    ('WinRM_Service', 'winrm get winrm/config/Service'),
    ('WinRM_Client', 'winrm get winrm/config/Client'),
    ('WinRM_WinRS', 'winrm get winrm/config/Winrs'),
    ('UAC_LocalAccountTokenFilterPolicy', 'reg query HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v LocalAccountTokenFilterPolicy'),
    ('UAC_FilterAdministratorToken', 'reg query HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v FilterAdministratorToken'),
    ('CredSSP_Service', 'Get-ItemProperty WSMan:\\localhost\\Service\\Auth\\CredSSP | Select-Object -ExpandProperty Value'),
    ('OS_Version', 'Get-ItemProperty "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion" | Select-Object ProductName, DisplayVersion, CurrentBuild'),
    ('User_Groups', 'net user Administrator'),
]

servers = [
    ('172.17.3.88', 'Compiler', 'Yuwei@2025', ''),
    ('172.17.3.193', 'administrator', 'admin!123', ''),
]

for srv_name, user, passwd, domain in servers:
    print(f"\n{'='*60}")
    print(f"  SERVER: {srv_name}  USER: {user}")
    print(f"{'='*60}")
    for cmd_name, ps_cmd in cmds:
        try:
            result = winrm_run(srv_name, user, passwd, ps_cmd, domain)
            print(f"\n--- {cmd_name} ---")
            print(result[:800])
        except Exception as e:
            print(f"\n--- {cmd_name} --- ERROR: {e}")
