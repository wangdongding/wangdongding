#!/usr/bin/env python3
"""Minimal NTLM auth implementation for WinRM - to check .88 config"""
import hashlib, struct, os, base64, hmac, time, requests, uuid, xml.etree.ElementTree as ET

ANON = "http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous"

def ntlm_type1(domain=''):
    sig = b'NTLMSSP\x00'
    msg_type = struct.pack('<I', 1)
    flags = 0x00088215
    domain_bytes = domain.encode('utf-16-le') if domain else b''
    if domain_bytes:
        flags |= 0x00001000
    msg = sig + msg_type + struct.pack('<I', flags)
    msg += struct.pack('<HH', len(domain_bytes), len(domain_bytes))
    msg += struct.pack('<I', 32)
    msg += b'\x00' * 8
    msg += domain_bytes
    return base64.b64encode(msg).decode()

def ntlmv2_response(server_challenge, password, user, domain, target_info):
    nt_hash = hashlib.new('md4', password.encode('utf-16-le')).digest()
    hmac_key = user.upper().encode('utf-16-le') + domain.encode('utf-16-le')
    ntproof_key = hmac.new(nt_hash, hmac_key, hashlib.md5).digest()
    blob = struct.pack('<I', 0x01010000)
    blob += struct.pack('<I', 0)
    blob += struct.pack('<Q', int(time.time()) + 11644473600)
    blob += os.urandom(8)
    blob += struct.pack('<I', 0)
    blob += target_info
    blob += struct.pack('<I', 0)
    ntproof = hmac.new(ntproof_key, server_challenge + blob, hashlib.md5).digest()
    return ntproof, ntproof + blob

def ntlm_type3(type2_b64, user, password, domain=''):
    type2 = base64.b64decode(type2_b64)
    server_challenge = type2[24:32]
    target_info = b''
    if len(type2) > 48:
        ti_len = struct.unpack('<H', type2[40:42])[0]
        ti_off = struct.unpack('<I', type2[44:48])[0]
        if ti_len > 0:
            target_info = type2[ti_off:ti_off+ti_len]
    
    ntproof, nt_resp = ntlmv2_response(server_challenge, password, user, domain, target_info)
    lm_response = b'\x00' * 24
    domain_unicode = domain.upper().encode('utf-16-le') if domain else b''
    user_unicode = user.encode('utf-16-le')
    workstation_unicode = os.urandom(8).hex().upper().encode('utf-16-le')
    
    base_offset = 88
    lm_off = base_offset
    nt_off = lm_off + len(lm_response)
    tgt_off = nt_off + len(nt_resp)
    usr_off = tgt_off + len(domain_unicode)
    wkst_off = usr_off + len(user_unicode)
    sk_off = wkst_off + len(workstation_unicode)
    
    def sec_buf(offset, data):
        return struct.pack('<HHI', len(data), len(data), offset)
    
    flags = 0x00088215
    msg = b'NTLMSSP\x00'
    msg += struct.pack('<I', 3)
    msg += sec_buf(lm_off, lm_response)
    msg += sec_buf(nt_off, nt_resp)
    msg += sec_buf(tgt_off, domain_unicode)
    msg += sec_buf(usr_off, user_unicode)
    msg += sec_buf(wkst_off, workstation_unicode)
    msg += sec_buf(sk_off, b'')
    msg += struct.pack('<I', flags)
    msg += struct.pack('<Q', 0x0000000600010000)
    msg += lm_response
    msg += nt_resp
    msg += domain_unicode
    msg += user_unicode
    msg += workstation_unicode
    return base64.b64encode(msg).decode()

def winrm_get_ntlm(host, user, password, resource_uri, domain='', timeout=15):
    url = f"http://{host}:5985/wsman"
    msg_id = str(uuid.uuid4())
    soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Get</a:Action>
    <a:To>{url}</a:To>
    <a:ReplyTo><a:Address>{ANON}</a:Address></a:ReplyTo>
    <w:ResourceURI>{resource_uri}</w:ResourceURI>
    <a:MessageID>uuid:{msg_id}</a:MessageID>
  </s:Header>
  <s:Body/>
</s:Envelope>"""
    
    session = requests.Session()
    
    # Step 1: Send with NTLM Type 1
    type1 = ntlm_type1(domain)
    r = session.post(url, data=soap.encode('utf-8'),
                    headers={
                        'Content-Type': 'application/soap+xml; charset=UTF-8',
                        'Authorization': f'Negotiate {type1}'
                    },
                    timeout=timeout)
    
    if r.status_code != 401:
        return f"[Step1 HTTP {r.status_code}] Expected 401 with NTLM challenge"
    
    auth_header = r.headers.get('WWW-Authenticate', '')
    if 'Negotiate' not in auth_header:
        return f"[No Negotiate challenge] WWW-Authenticate: {auth_header}"
    
    # Extract Type 2 token
    type2 = auth_header.split('Negotiate')[1].strip() if 'Negotiate' in auth_header else ''
    if not type2:
        return f"[Empty Type 2] auth_header: {auth_header}"
    
    # Step 2: Send with NTLM Type 3
    type3 = ntlm_type3(type2, user, password, domain)
    r = session.post(url, data=soap.encode('utf-8'),
                    headers={
                        'Content-Type': 'application/soap+xml; charset=UTF-8',
                        'Authorization': f'Negotiate {type3}'
                    },
                    timeout=timeout)
    
    if r.status_code != 200:
        return f"[Step2 HTTP {r.status_code}] {r.text[:300]}"
    
    root = ET.fromstring(r.content)
    lines = []
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if elem.text and elem.text.strip():
            lines.append(f"  {tag} = {elem.text.strip()}")
    return '\n'.join(lines) if lines else "[Empty response]"

# ============ MAIN ============
print("=" * 80)
print("WinRM Config on 172.17.3.88 via NTLM auth")
print("=" * 80)

config_uris = [
    ("WinRM Service Auth", "http://schemas.microsoft.com/wbem/wsman/1/config/service/auth"),
    ("WinRM Service", "http://schemas.microsoft.com/wbem/wsman/1/config/service"),
    ("WinRM WinRS", "http://schemas.microsoft.com/wbem/wsman/1/config/winrs"),
    ("WinRM Client Auth", "http://schemas.microsoft.com/wbem/wsman/1/config/client/auth"),
]

for name, uri in config_uris:
    print(f"\n{'='*60}")
    print(f"[{name}]")
    print(f"{'='*60}")
    result = winrm_get_ntlm("172.17.3.88", "Compiler", "Yuwei@2505", uri)
    print(result)

print("\n\nDONE")
