#!/usr/bin/env python3
"""Read-only WinRM comparison between 172.17.3.88 and 172.17.3.193
Uses Basic auth + WinRM SOAP to run read-only PowerShell commands.
"""
import requests, uuid, xml.etree.ElementTree as ET, sys, time

def winrm_run(host, user, password, ps_command, timeout=20):
    url = f"http://{host}:5985/wsman"
    soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI s:mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</w:ResourceURI>
    <a:MessageID>uuid:{uuid.uuid4()}</a:MessageID>
    <p:OptionSet xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
      <p:Option Name="WINRS_NOPROFILE" Value="FALSE"/>
    </p:OptionSet>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>"""

    session = requests.Session()
    session.auth = requests.auth.HTTPBasicAuth(user, password)
    session.headers.update({
        'Content-Type': 'application/soap+xml; charset=UTF-8',
        'User-Agent': 'OpenOcta-Diag'
    })

    # Step 1: Create Shell
    try:
        r = session.post(url, data=soap.encode('utf-8'), timeout=timeout)
    except Exception as e:
        return f"[Create Shell ERROR] {e}"

    if r.status_code != 200:
        return f"[Create Shell HTTP {r.status_code}] {r.text[:300]}"

    # Extract ShellId
    try:
        root = ET.fromstring(r.content)
        ns = {'s': 'http://www.w3.org/2003/05/soap-envelope',
              'rsp': 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell'}
        shell_id = None
        for elem in root.iter():
            if elem.tag.endswith('}ShellId') or elem.tag == 'ShellId':
                shell_id = elem.text
                break
        if not shell_id:
            # Try another way
            for elem in root.iter():
                if 'ShellId' in elem.tag:
                    shell_id = elem.text
                    break
        if not shell_id:
            return f"[No ShellId found] Response: {r.text[:500]}"
    except Exception as e:
        return f"[Parse ShellId ERROR] {e}"

    # Step 2: Execute Command
    cmd_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
  xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI s:mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</w:ResourceURI>
    <a:MessageID>uuid:{uuid.uuid4()}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>powershell</rsp:Command>
      <rsp:Arguments>-NoProfile -NonInteractive -EncodedCommand {__ENC__}</rsp:Arguments>
    </rsp:CommandLine>
  </s:Body>
</s:Envelope>"""

    import base64
    encoded = base64.b64encode(ps_command.encode('utf-16-le')).decode('ascii')
    cmd_soap = cmd_soap.replace('__ENC__', encoded)

    try:
        r = session.post(url, data=cmd_soap.encode('utf-8'), timeout=timeout)
    except Exception as e:
        return f"[Execute ERROR] {e}"

    if r.status_code != 200:
        return f"[Execute HTTP {r.status_code}] {r.text[:300]}"

    # Extract CommandId
    try:
        root = ET.fromstring(r.content)
        command_id = None
        for elem in root.iter():
            if 'CommandId' in elem.tag:
                command_id = elem.text
                break
        if not command_id:
            return f"[No CommandId] {r.text[:500]}"
    except Exception as e:
        return f"[Parse CommandId ERROR] {e}"

    # Step 3: Receive Output (poll up to a few times)
    time.sleep(2)
    output_text = ""
    for attempt in range(6):
        recv_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI s:mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</w:ResourceURI>
    <a:MessageID>uuid:{uuid.uuid4()}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
    </rsp:Receive>
  </s:Body>
</s:Envelope>"""

        try:
            r = session.post(url, data=recv_soap.encode('utf-8'), timeout=timeout)
        except Exception as e:
            return f"[Receive ERROR] {e}"

        if r.status_code == 200:
            # Decode base64 output
            try:
                root = ET.fromstring(r.content)
                for elem in root.iter():
                    if elem.tag.endswith('}Stream') or 'Stream' in elem.tag:
                        if elem.text:
                            import base64 as b64
                            try:
                                decoded = b64.b64decode(elem.text).decode('utf-8', errors='replace')
                                output_text += decoded
                            except:
                                output_text += f"[base64 decode error]"
                    if elem.tag.endswith('}CommandState') or 'CommandState' in elem.tag:
                        state = elem.attrib.get('State', '')
                        if 'Done' in state:
                            # Command finished, delete shell and return
                            # Delete shell (cleanup)
                            del_soap = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
  xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing"
  xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</a:Action>
    <a:To>{url}</a:To>
    <w:ResourceURI>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</w:ResourceURI>
    <a:MessageID>uuid:{uuid.uuid4()}</a:MessageID>
    <w:SelectorSet>
      <w:Selector Name="ShellId">{shell_id}</w:Selector>
    </w:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>"""
                            try:
                                session.post(url, data=del_soap.encode('utf-8'), timeout=5)
                            except:
                                pass
                            return output_text if output_text else "[No output - command may have produced no stdout]"
            except Exception as e:
                return f"[Parse Receive ERROR] {e}"
        time.sleep(2)

    # Timeout - delete shell
    return f"[TIMEOUT after polling] Partial output: {output_text[:500]}"


# ============ MAIN ============
servers = [
    {"host": "172.17.3.88", "user": "Compiler", "password": "Yuwei@2505", "label": "OLD (working)"},
    {"host": "172.17.3.193", "user": "administrator", "password": "admin!123", "label": "NEW (broken)"},
]

# Read-only commands to compare
commands = {
    "WinRM_Service_Auth": "winrm get winrm/config/service/auth",
    "WinRM_Service_AllowUnencrypted": "winrm get winrm/config/service | Select-String AllowUnencrypted",
    "WinRM_Client_TrustedHosts": "winrm get winrm/config/client | Select-String TrustedHosts",
    "WinRM_Service_DefaultPorts": "winrm get winrm/config/service | Select-String -Pattern 'Port|EnableCompatibilityHttpListener'",
    "WinRM_CredSSP": "winrm get winrm/config/service/auth | Select-String CredSSP",
    "UAC_LocalAccountTokenFilterPolicy": r"reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v LocalAccountTokenFilterPolicy 2>&1; if (-not $?) { Write-Output '[KEY NOT FOUND]' }",
    "UAC_FilterAdministratorToken": r"reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v FilterAdministratorToken 2>&1; if (-not $?) { Write-Output '[KEY NOT FOUND]' }",
    "UAC_EnableLUA": r"reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA 2>&1",
    "WhoAmI_Groups": "whoami /groups /fo csv",
    "WhoAmI_User": "whoami",
    "Admin_Group_Members": "net localgroup Administrators",
    "WinRM_MaxConcurrentUsers": "winrm get winrm/config/service | Select-String MaxConcurrentUsers",
    "WinRM_MaxShellsPerUser": "winrm get winrm/config/winrs | Select-String MaxShellsPerUser",
    "PS_Version": "$PSVersionTable.PSVersion.ToString()",
    "OS_Version": "(Get-WmiObject Win32_OperatingSystem).Caption + ' ' + (Get-WmiObject Win32_OperatingSystem).Version",
}

print("=" * 80)
print("READ-ONLY WinRM CONFIGURATION COMPARISON")
print("=" * 80)

for cmd_name, ps_cmd in commands.items():
    print(f"\n{'='*80}")
    print(f"[{cmd_name}]")
    print(f"{'='*80}")
    for srv in servers:
        print(f"\n--- {srv['label']} ({srv['host']}) ---")
        result = winrm_run(srv['host'], srv['user'], srv['password'], ps_cmd)
        print(result)

print("\n\nDONE - All checks are read-only, no changes made.")
