#!/usr/bin/env python3
"""Full NTLM auth for .88 - complete the 3-way handshake"""

import requests, base64, struct, hashlib, hmac, os, time, uuid
import xml.etree.ElementTree as ET

# === MD4 ===
def md4(data):
    msg = bytearray(data)
    msg_len = len(data)
    msg.append(0x80)
    while len(msg) % 64 != 56: msg.append(0)
    msg += struct.pack('<Q', msg_len * 8)
    a0, b0, c0, d0 = 0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
    def lr(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    for i in range(0, len(msg), 64):
        M = [struct.unpack('<I', msg[i+j:i+j+4])[0] for j in range(0, 64, 4)]
        a, b, c, d = a0, b0, c0, d0
        for k in range(16):
            a = lr((a + ((b&c)|(~b&d)) + M[k]) & 0xFFFFFFFF, [3,7,11,19][k%4]); a,b,c,d = d,a,b,c
        for k in [0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]:
            a = lr((a + ((b&c)|(b&d)|(c&d)) + M[k] + 0x5A827999) & 0xFFFFFFFF, [3,5,9,13][([0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15].index(k))%4]); a,b,c,d = d,a,b,c
        for k in [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]:
            a = lr((a + (b^c^d) + M[k] + 0x6ED9EBA1) & 0xFFFFFFFF, [3,9,11,15][([0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15].index(k))%4]); a,b,c,d = d,a,b,c
        a0=(a0+a)&0xFFFFFFFF; b0=(b0+b)&0xFFFFFFFF; c0=(c0+c)&0xFFFFFFFF; d0=(d0+d)&0xFFFFFFFF
    return struct.pack('<4I', a0, b0, c0, d0)

def ntlm_hash(pw): return md4(pw.encode('utf-16-le'))

def ntlmv2_response(nt_h, server_chal, target_info, user, domain, client_chal=None):
    if not client_chal: client_chal = os.urandom(8)
    temp = hmac.new(nt_h, (user.upper()+domain).encode('utf-16-le'), hashlib.md5).digest()
    blob = bytearray()
    blob += b'\x01\x01\x00\x00\x00\x00\x00\x00'  # sig + reserved
    blob += struct.pack('<Q', int(time.time()) + 11644473600)  # timestamp
    blob += client_chal + b'\x00\x00\x00\x00' + target_info  # client_chal + reserved + target_info
    ntproof = hmac.new(temp, server_chal + bytes(blob), hashlib.md5).digest()
    return ntproof, bytes(blob)

# === NTLM Auth Class ===
class NTLMAuth:
    def __init__(self, user, pw):
        if '\\' in user: self.domain, self.user = user.split('\\', 1)
        else: self.domain, self.user = '', user
        self.pw = pw
    
    def __call__(self, r):
        # Type 1
        t1 = base64.b64encode(b'NTLMSSP\x00' + struct.pack('<I',1) + struct.pack('<I',0x00088215) + struct.pack('<HHI',0,0,32) + struct.pack('<HHI',0,0,32)).decode()
        r.headers['Authorization'] = f'Negotiate {t1}'
        r.register_hook('response', self._handle_401)
        return r
    
    def _handle_401(self, resp, **kwargs):
        if resp.status_code != 401: return resp
        auth = resp.headers.get('WWW-Authenticate','')
        challenge = None
        for p in auth.split(','):
            p = p.strip()
            if p.startswith('Negotiate ') and len(p) > 10: challenge = p[10:]; break
        if not challenge: return resp
        
        # Parse Type 2
        d = base64.b64decode(challenge)
        server_chal = d[24:32]
        ti_len = struct.unpack('<H', d[40:42])[0]
        ti_off = struct.unpack('<I', d[44:48])[0]
        target_info = d[ti_off:ti_off+ti_len]
        
        # Build Type 3
        nt_h = ntlm_hash(self.pw)
        client_chal = os.urandom(8)
        ntproof, blob = ntlmv2_response(nt_h, server_chal, target_info, self.user, self.domain, client_chal)
        nt_resp = ntproof + blob
        lm_resp = hmac.new(hmac.new(nt_h, (self.user.upper()+self.domain).encode('utf-16-le'), hashlib.md5).digest(), server_chal + client_chal, hashlib.md5).digest() + client_chal
        
        dom_enc = self.domain.upper().encode('utf-16-le')
        usr_enc = self.user.encode('utf-16-le')
        base = 88
        lm_off = base
        nt_off = lm_off + len(lm_resp)
        dom_off = nt_off + len(nt_resp)
        usr_off = dom_off + len(dom_enc)
        ws_off = usr_off + len(usr_enc)
        
        t3 = bytearray()
        t3 += b'NTLMSSP\x00' + struct.pack('<I',3)
        t3 += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
        t3 += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
        t3 += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
        t3 += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
        t3 += struct.pack('<HHI', 0, 0, ws_off)
        t3 += struct.pack('<I', 0x00088215)
        t3 += struct.pack('<Q', 0)
        t3 += lm_resp + nt_resp + dom_enc + usr_enc
        
        t3_b64 = base64.b64encode(bytes(t3)).decode()
        resp.content
        resp.raw.close()
        new_req = resp.request.copy()
        new_req.headers['Authorization'] = f'Negotiate {t3_b64}'
        _ = kwargs.pop('cookies', None)
        new_resp = resp.connection.send(new_req, **kwargs)
        new_resp.history.append(resp)
        new_resp.request = new_req
        return new_resp

# === WinRM Client ===
CONTENT_TYPE = 'application/soap+xml; charset=UTF-8'
SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'

def soap(url, action, body, selectors=None):
    msg_id = str(uuid.uuid4())
    sid = str(uuid.uuid4())
    res = f'<w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>'
    sel = ''
    if selectors:
        sel = '<w:SelectorSet>' + ''.join(f'<w:Selector Name="{k}">{v}</w:Selector>' for k,v in selectors.items()) + '</w:SelectorSet>'
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
<s:Header>
<a:Action>{action}</a:Action>
<a:To>{url}</a:To>
<w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
<a:MessageID>uuid:{msg_id}</a:MessageID>
<a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
{res}{sel}
<w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
<p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
<p:SessionId mustUnderstand="false">uuid:{sid}</p:SessionId>
</s:Header>
<s:Body>{body}</s:Body>
</s:Envelope>'''

def run_ps(url, auth, ps_cmd):
    encoded = base64.b64encode(ps_cmd.encode('utf-16-le')).decode('ascii')
    cmd = f'powershell -NoProfile -NonInteractive -EncodedCommand {encoded}'
    
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Create',
            '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>'),
        verify=False, timeout=15)
    if r.status_code != 200: return f"[CreateShell HTTP {r.status_code}]"
    root = ET.fromstring(r.content)
    shell_id = next((e.text for e in root.iter() if e.get('Name')=='ShellId' and e.text), None)
    if not shell_id: return "[No ShellId]"
    
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command',
            f'<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>{cmd}</rsp:Command></rsp:CommandLine>',
            selectors={'ShellId': shell_id}),
        verify=False, timeout=15)
    if r.status_code != 200:
        requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
            data=soap(url, 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', '', selectors={'ShellId': shell_id}), verify=False, timeout=10)
        return f"[Exec HTTP {r.status_code}]"
    root = ET.fromstring(r.content)
    cmd_id = None
    for e in root.iter():
        t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
        if t == 'CommandId' and e.text: cmd_id = e.text; break
    if not cmd_id: return "[No CommandId]"
    
    time.sleep(2)
    
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive',
            f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream CommandId="{cmd_id}">stdout stderr</rsp:DesiredStream></rsp:Receive>',
            selectors={'ShellId': shell_id}),
        verify=False, timeout=25)
    output = ""
    if r.status_code == 200:
        root = ET.fromstring(r.content)
        for e in root.iter():
            t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
            if t == 'Stream' and e.text:
                try: output += base64.b64decode(e.text).decode('utf-8', errors='replace')
                except: pass
    else:
        output = f"[Receive HTTP {r.status_code}]"
    
    requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal',
            '<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code></rsp:Signal>',
            selectors={'ShellId': shell_id}), verify=False, timeout=10)
    requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', '', selectors={'ShellId': shell_id}), verify=False, timeout=10)
    
    return output.strip() if output.strip() else "[No output]"

# === 172.17.3.88 ===
URL_88 = "http://172.17.3.88:5985/wsman"
AUTH_88 = NTLMAuth("Compiler", "Yuwei@2505")

print("=" * 70)
print("  172.17.3.88 (WORKING SERVER)")
print("=" * 70)

tests = [
    ("Echo Test", "echo hello"),
    ("WinRM Auth", "winrm get winrm/config/service/auth"),
    ("WinRM Service", "winrm get winrm/config/service"),
    ("UAC-LocalAccountTokenFilterPolicy", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name LocalAccountTokenFilterPolicy -EA 0 | Select -Exp LocalAccountTokenFilterPolicy}catch{'NOT SET(0)'}"),
    ("UAC-FilterAdministratorToken", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name FilterAdministratorToken -EA 0 | Select -Exp FilterAdministratorToken}catch{'NOT SET(0)'}"),
    ("UAC-EnableLUA", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name EnableLUA -EA 0 | Select -Exp EnableLUA}catch{'NOT SET'}"),
    ("CredSSP", "Get-WSManCredSSP 2>&1 | Out-String"),
    ("OS Version", "(Get-WmiObject Win32_OperatingSystem).Caption + ' ' + [System.Environment]::OSVersion.Version.ToString()"),
    ("User", "whoami"),
    ("User Groups", "whoami /groups"),
    ("Local Admins", "net localgroup Administrators"),
]

for name, cmd in tests:
    print(f"\n--- {name} ---")
    try:
        result = run_ps(URL_88, AUTH_88, cmd)
        print(result[:1500])
    except Exception as e:
        print(f"ERROR: {e}")
    sys.stdout.flush()
