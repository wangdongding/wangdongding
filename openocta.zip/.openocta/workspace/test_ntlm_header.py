#!/usr/bin/env python3
"""Test NTLM Type3 header structure"""
import struct, hashlib, hmac, base64

def md4(data):
    def f(x,y,z): return (x&y)|(~x&z)
    def g(x,y,z): return (x&y)|(x&z)|(y&z)
    def h(x,y,z): return x^y^z
    def rr(n,b): return ((n<<b)|(n>>(32-b)))&0xFFFFFFFF
    A,B,C,D = 0x67452301,0xefcdab89,0x98badcfe,0x10325476
    msg = bytearray(data)
    orig = len(data)*8
    msg.append(0x80)
    while len(msg)%64!=56: msg.append(0)
    msg += struct.pack('<Q',orig)
    for i in range(0,len(msg),64):
        X=list(struct.unpack('<16I',msg[i:i+64]))
        AA,BB,CC,DD = A,B,C,D
        for j in range(48):
            if j<16:   fn,s,ki = f,0,j
            elif j<32: fn,s,ki = g,0x5A827999,j//5
            else:      fn,s,ki = h,0x6ED9EBA1,j//3
            t = (rr(A,[3,7,11,19][j//16]) + fn(B,C,D) + X[ki] + s) & 0xFFFFFFFF
            A,D,C,B = D,C,B,t
        A=(A+AA)&0xFFFFFFFF; B=(B+BB)&0xFFFFFFFF
        C=(C+CC)&0xFFFFFFFF; D=(D+DD)&0xFFFFFFFF
    return struct.pack('<4I',A,B,C,D)

# NTLM Type3 header structure:
# Signature(8) + MessageType(4) + 6*SecurityBuffer(8 each) + Flags(4)
# = 8 + 4 + 48 + 4 = 64 bytes
base = 64

# Test data
ntpw = md4('admin!123'.encode('utf-16-le'))
ntowfv2 = hmac.new(ntpw, b'ADMINISTRATOR\x00', hashlib.md5).digest()
lm_resp = hmac.new(ntowfv2, b'\x00'*16, hashlib.md5).digest()
nt_resp = hmac.new(ntowfv2, b'\x00'*16, hashlib.md5).digest()

print(f"LM resp len: {len(lm_resp)}")  # 16
print(f"NT resp len: {len(nt_resp)}")  # 16

# Domain/User/WS in Unicode
dom_enc = ''.encode('utf-16-le')  # empty
usr_enc = 'ADMINISTRATOR'.encode('utf-16-le')  # 26 bytes
ws_enc = 'ANSIBLE'.encode('utf-16-le')  # 16 bytes

lm_off = base
nt_off = lm_off + len(lm_resp)
dom_off = nt_off + len(nt_resp)
usr_off = dom_off + len(dom_enc)
ws_off = usr_off + len(usr_enc)
sk_off = ws_off + len(ws_enc)

msg = b'NTLMSSP\x00'
msg += struct.pack('<I', 3)
msg += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
msg += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
msg += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
msg += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
msg += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off)
msg += struct.pack('<HHI', 0, 0, sk_off)
msg += struct.pack('<I', 0x00088215)

print(f"Header len: {len(msg)}")  # should be 64
msg += lm_resp + nt_resp + dom_enc + usr_enc + ws_enc

b64 = base64.b64encode(msg).decode()
print(f"Total len: {len(msg)}")
print(f"Base64 len: {len(b64)}")
print(f"Base64 len % 4: {len(b64) % 4}")
print(f"Base64 valid: {len(b64) % 4 == 0}")

# Now test with actual target_info
# Simulate a Type2 response
target_info = b'\x02\x00\x0c\x00\x44\x00\x4f\x00\x4d\x00\x41\x00\x49\x00\x4e\x00\x01\x00\x0c\x00\x53\x00\x45\x00\x52\x00\x56\x00\x45\x00\x52\x00\x04\x00\x14\x00\x64\x00\x6f\x00\x6d\x00\x61\x00\x69\x00\x6e\x00\x2e\x00\x63\x00\x6f\x00\x6d\x00\x03\x00\x22\x00\x73\x00\x65\x00\x72\x00\x76\x00\x65\x00\x72\x00\x2e\x00\x64\x00\x6f\x00\x6d\x00\x61\x00\x69\x00\x6e\x00\x2e\x00\x63\x00\x6f\x00\x6d\x00\x00\x00\x00\x00'
server_challenge = b'\x01\x23\x45\x67\x89\xab\xcd\xef'

nt_resp_full, _ = hmac.new(ntowfv2, server_challenge + target_info + b'\x00'*4, hashlib.md5).digest(), None
# Actually NTv2 response is: nt_proof + temp
temp = target_info + b'\x00\x00\x00\x00'
nt_proof = hmac.new(ntowfv2, server_challenge + temp, hashlib.md5).digest()
nt_resp_full = nt_proof + temp

print(f"\nWith target_info:")
print(f"NT resp full len: {len(nt_resp_full)}")  # variable

nt_off2 = lm_off + len(lm_resp)
dom_off2 = nt_off2 + len(nt_resp_full)
usr_off2 = dom_off2 + len(dom_enc)
ws_off2 = usr_off2 + len(usr_enc)
sk_off2 = ws_off2 + len(ws_enc)

msg2 = b'NTLMSSP\x00'
msg2 += struct.pack('<I', 3)
msg2 += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
msg2 += struct.pack('<HHI', len(nt_resp_full), len(nt_resp_full), nt_off2)
msg2 += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off2)
msg2 += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off2)
msg2 += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off2)
msg2 += struct.pack('<HHI', 0, 0, sk_off2)
msg2 += struct.pack('<I', 0x00088215)
msg2 += lm_resp + nt_resp_full + dom_enc + usr_enc + ws_enc

b64_2 = base64.b64encode(msg2).decode()
print(f"Total len: {len(msg2)}")
print(f"Base64 len: {len(b64_2)}")
print(f"Base64 len % 4: {len(b64_2) % 4}")
print(f"Base64 valid: {len(b64_2) % 4 == 0}")
