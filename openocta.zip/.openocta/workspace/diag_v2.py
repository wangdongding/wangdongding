#!/usr/bin/env python3
"""WinRM with exact pywinrm-compatible SOAP format"""

import requests
from requests.auth import HTTPBasicAuth
import base64
import uuid
import time
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def uid(): return f"uuid:{str(uuid.uuid4()).upper()}"

# Use exact namespace prefixes from pywinrm/pypsrp
def build_envelope(header_items, body_content):
    """Build a SOAP envelope with proper namespace declarations"""
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<env:Envelope xmlns:env="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <env:Header>
    <a:Action>{header_items["action"]}</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    {header_items.get("extra", "")}
  </env:Header>
  <env:Body>
    {body_content}
  </env:Body>
</env:Envelope>'''

def find_tag(xml_text, tag_name):
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name and elem.text:
            return elem.text
    return None

def extract_streams(xml_text):
    import base64 as b64
    stdout_parts, stderr_parts = [], []
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == 'Stream' and elem.text:
            name = elem.attrib.get('Name', '')
            decoded = b64.b64decode(elem.text).decode('utf-8', errors='replace')
            if 'stdout' in name: stdout_parts.append(decoded)
            elif 'stderr' in name: stderr_parts.append(decoded)
    return ''.join(stdout_parts), ''.join(stderr_parts)

auth = HTTPBasicAuth(USER, PASS)
hdrs = {'Content-Type': 'application/soap+xml; charset=UTF-8'}

# === 1. Create Shell ===
print("[1] Creating shell...")
create_body = '''<p:Shell>
      <p:InputStreams>stdin</p:InputStreams>
      <p:OutputStreams>stdout stderr</p:OutputStreams>
    </p:Shell>'''
r = requests.post(URL, data=build_envelope({"action": "http://schemas.xmlsoap.org/ws/2004/09/transfer/Create"}, create_body), auth=auth, headers=hdrs, timeout=15)
print(f"  HTTP {r.status_code}")
if r.status_code != 200:
    print(f"  Error: {r.text[:500]}")
    exit(1)
shell_id = find_tag(r.text, 'ShellId')
print(f"  ShellId: {shell_id}")

# === 2. Execute command ===
print("[2] Executing command...")
selector = f'<w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>'
cmd_body = f'''<p:CommandLine>
      <p:Command>cmd.exe</p:Command>
      <p:Arguments>/c whoami</p:Arguments>
    </p:CommandLine>'''
r2 = requests.post(URL, data=build_envelope({"action": "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command", "extra": selector}, cmd_body), auth=auth, headers=hdrs, timeout=30)
print(f"  HTTP {r2.status_code}")
if r2.status_code != 200:
    print(f"  Error: {r2.text[:500]}")
    exit(1)
command_id = find_tag(r2.text, 'CommandId')
print(f"  CommandId: {command_id}")

# === 3. Receive output ===
print("[3] Receiving output...")
time.sleep(2)
rcv_body = f'''<p:Receive>
      <p:DesiredStream>stdout stderr</p:DesiredStream>
      <p:CommandId>{command_id}</p:CommandId>
    </p:Receive>'''
r3 = requests.post(URL, data=build_envelope({"action": "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive", "extra": selector}, rcv_body), auth=auth, headers=hdrs, timeout=15)
print(f"  HTTP {r3.status_code}")
if r3.status_code != 200:
    print(f"  Error: {r3.text[:800]}")
else:
    out, err = extract_streams(r3.text)
    print(f"  STDOUT: {out.strip()}")
    print(f"  STDERR: {err.strip()}")
    # Check state
    for elem in ET.fromstring(r3.text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == 'ExitCode':
            print(f"  ExitCode: {elem.text}")
        if local == 'State':
            print(f"  State: {elem.text}")

# === 4. Delete shell ===
print("[4] Deleting shell...")
r4 = requests.post(URL, data=build_envelope({"action": "http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete", "extra": selector}, ""), auth=auth, headers=hdrs, timeout=10)
print(f"  HTTP {r4.status_code}")
