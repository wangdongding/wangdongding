#!/usr/bin/env python3
"""Step-by-step NTLM auth test against both servers"""
import requests, struct, hashlib, hmac, base64, uuid

def md4(data):
    def f(x,y,z): return (x&y)|(~x&z)
    def g(x,y,z): return (x&y)|(x&z)|(y&z)
    def h(x,y,z): return x^y^z
    def rr(n,b): return ((n<<b)|(n>>(32-b)))&0xFFFFFFFF
    A,B,C,D = 0x67452301,0xefcdab89,0x98badcfe,0x10325476
    msg = bytearray(data)
    orig = len(data)*8
    msg.append(0x80)
    while len(msg)%64!=56: msg.append(0)
    msg += struct.pack('<Q',orig)
    for i in range(0,len(msg),64):
        X=list(struct.unpack('<16I',msg[i:i+64]))
        AA,BB,CC,DD = A,B,C,D
        for j in range(48):
            if j<16:   fn,s,ki = f,0,j
            elif j<32: fn,s,ki = g,0x5A827999,j//5
            else:      fn,s,ki = h,0x6ED9EBA1,j//3
            t = (rr(A,[3,7,11,19][j//16]) + fn(B,C,D) + X[ki] + s) & 0xFFFFFFFF
            A,D,C,B = D,C,B,t
        A=(A+AA)&0xFFFFFFFF; B=(B+BB)&0xFFFFFFFF
        C=(C+CC)&0xFFFFFFFF; D=(D+DD)&0xFFFFFFFF
    return struct.pack('<4I',A,B,C,D)

def build_type1():
    flags = 0x00088215
    msg = b'NTLMSSP\x00' + struct.pack('<I',1) + struct.pack('<I',flags)
    msg += struct.pack('<HHI',0,0,0) + struct.pack('<HHI',0,0,0)
    return base64.b64encode(msg).decode()

def parse_type2(raw):
    # Add base64 padding if needed
    raw += '=' * ((4 - len(raw) % 4) % 4)
    msg = base64.b64decode(raw)
    server_challenge = msg[24:32]
    neg_flags = struct.unpack('<I', msg[20:24])[0]
    target_info = b''
    if len(msg) > 48:
        ti_len = struct.unpack('<H', msg[40:42])[0]
        ti_off = struct.unpack('<I', msg[44:48])[0]
        target_info = msg[ti_off:ti_off+ti_len]
    return server_challenge, target_info, neg_flags

def build_type3(username, password, domain, server_challenge, target_info, neg_flags):
    ntpw = md4(password.encode('utf-16-le'))
    ntowfv2 = hmac.new(ntpw, (username.upper().encode('utf-16-le') + domain.encode('utf-16-le')), hashlib.md5).digest()
    temp = target_info + b'\x00\x00\x00\x00'
    nt_proof = hmac.new(ntowfv2, server_challenge + temp, hashlib.md5).digest()
    nt_resp = nt_proof + temp
    lm_resp = hmac.new(ntowfv2, server_challenge + b'\x00'*8, hashlib.md5).digest()
    domain_up = domain.upper() if domain else ''
    workstation = 'ANSIBLE'
    dom_enc = domain_up.encode('utf-16-le')
    usr_enc = username.encode('utf-16-le')
    ws_enc = workstation.encode('utf-16-le')
    base = 64
    lm_off = base
    nt_off = lm_off + len(lm_resp)
    dom_off = nt_off + len(nt_resp)
    usr_off = dom_off + len(dom_enc)
    ws_off = usr_off + len(usr_enc)
    sk_off = ws_off + len(ws_enc)
    msg = b'NTLMSSP\x00'
    msg += struct.pack('<I', 3)
    msg += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
    msg += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
    msg += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
    msg += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
    msg += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off)
    msg += struct.pack('<HHI', 0, 0, sk_off)
    msg += struct.pack('<I', 0x00088215)
    msg += lm_resp + nt_resp + dom_enc + usr_enc + ws_enc
    b64 = base64.b64encode(msg).decode()
    if len(b64) % 4 != 0:
        # Add padding
        b64 += '=' * (4 - len(b64) % 4)
    return b64

# Test NTLM handshake step by step
servers = [
    ('172.17.3.88', 'Compiler', 'Yuwei@2025', ''),
    ('172.17.3.193', 'administrator', 'admin!123', ''),
]

for srv, user, passwd, domain in servers:
    print(f"\n{'='*50}")
    print(f"  {srv} / {user}")
    print(f"{'='*50}")
    url = f'http://{srv}:5985/wsman'
    try:
        # Step 1: Type1
        type1 = build_type1()
        print(f"Type1 sent ({len(type1)} chars)")
        resp1 = requests.post(url, headers={
            'Content-Type': 'application/soap+xml; charset=UTF-8',
            'Authorization': f'Negotiate {type1}'
        }, timeout=8)
        print(f"Type1 response: HTTP {resp1.status_code}")
        
        # Get Type2
        auth_h = resp1.headers.get('WWW-Authenticate', '')
        t2 = ''
        for part in auth_h.replace('Negotiate', '\nNegotiate').split('\n'):
            part = part.strip()
            if part.startswith('Negotiate ') and len(part) > 11:
                t2 = part[11:]
                break
        if not t2:
            print(f"  No Type2! Auth header: {auth_h[:200]}")
            continue
        print(f"Type2 received ({len(t2)} chars)")
        
        server_challenge, target_info, neg_flags = parse_type2(t2)
        print(f"  Server challenge: {server_challenge.hex()}")
        print(f"  Target info len: {len(target_info)}")
        print(f"  Neg flags: 0x{neg_flags:08x}")
        
        # Build Type3
        type3 = build_type3(user, passwd, domain, server_challenge, target_info, neg_flags)
        print(f"Type3 built ({len(type3)} chars, valid b64: {len(type3)%4==0})")
        
        # Step 2: Authenticate with Type3
        resp2 = requests.post(url, headers={
            'Content-Type': 'application/soap+xml; charset=UTF-8',
            'Authorization': f'Negotiate {type3}'
        }, timeout=8)
        print(f"Type3 response: HTTP {resp2.status_code}")
        if resp2.status_code == 200:
            print(f"  AUTH SUCCESS! Content length: {len(resp2.text)}")
        else:
            print(f"  AUTH FAILED")
            print(f"  Response: {resp2.text[:300]}")
            # Check if there's additional auth in response
            auth_h2 = resp2.headers.get('WWW-Authenticate', '')
            print(f"  Auth header: {auth_h2[:200]}")
    except Exception as e:
        print(f"  ERROR: {type(e).__name__}: {e}")
