#!/bin/bash
set -e
VALUES_FILE="/data/zhiman/innies/values.yaml"
BACKUP_FILE="/data/zhiman/innies/values.yaml.bak.$(date +%Y%m%d%H%M)"

# 1. 备份
cp "$VALUES_FILE" "$BACKUP_FILE"
echo "✅ 备份完成: $BACKUP_FILE"

# 2. 修改内存限制 (仅 file-parser-api 段)
sed -i '/^file-parser-api:/,/^z8m:/s/memory: 2Gi/memory: 8Gi/' "$VALUES_FILE"
echo "✅ memory: 2Gi → 8Gi"

# 3. 修改环境变量
sed -i '/name: MAX_UPLOAD_SIZE_MB/{n;s/value: "500"/value: "1024"/}' "$VALUES_FILE"
echo "✅ MAX_UPLOAD_SIZE_MB: 500 → 1024"

sed -i '/name: PDF_ENGINES_PDF_MAX_PDF_FILE_SIZE_MB/{n;s/value: "500.0"/value: "1024"/}' "$VALUES_FILE"
echo "✅ PDF_ENGINES_PDF_MAX_PDF_FILE_SIZE_MB: 500.0 → 1024"

sed -i '/name: PPT_PARSER_MAX_PPTX_FILE_SIZE_MB/{n;s/value: "300.0"/value: "1024"/}' "$VALUES_FILE"
echo "✅ PPT_PARSER_MAX_PPTX_FILE_SIZE_MB: 300.0 → 1024"

sed -i '/name: PPT_PARSER_MAX_PPT_FILE_SIZE_MB/{n;s/value: "300.0"/value: "1024"/}' "$VALUES_FILE"
echo "✅ PPT_PARSER_MAX_PPT_FILE_SIZE_MB: 300.0 → 1024"

sed -i '/name: EXCEL_PARSER_MAX_XLS_SIZE_MB/{n;s/value: "300"/value: "1024"/}' "$VALUES_FILE"
echo "✅ EXCEL_PARSER_MAX_XLS_SIZE_MB: 300 → 1024"

sed -i '/name: WORD_PARSER_MAX_DOCX_FILE_SIZE_MB/{n;s/value: "300.0"/value: "1024"/}' "$VALUES_FILE"
echo "✅ WORD_PARSER_MAX_DOCX_FILE_SIZE_MB: 300.0 → 1024"

sed -i '/name: WORD_PARSER_MAX_DOC_FILE_SIZE_MB/{n;s/value: "300.0"/value: "1024"/}' "$VALUES_FILE"
echo "✅ WORD_PARSER_MAX_DOC_FILE_SIZE_MB: 300.0 → 1024"

echo ""
echo "=== 验证修改结果 ==="
grep -A1 'MAX_UPLOAD_SIZE_MB\|PDF_ENGINES_PDF_MAX_PDF_FILE_SIZE_MB\|PPT_PARSER_MAX_PPTX_FILE_SIZE_MB\|PPT_PARSER_MAX_PPT_FILE_SIZE_MB\|EXCEL_PARSER_MAX_XLS_SIZE_MB\|WORD_PARSER_MAX_DOCX_FILE_SIZE_MB\|WORD_PARSER_MAX_DOC_FILE_SIZE_MB' "$VALUES_FILE" | grep 'value:'
echo ""
echo "=== file-parser-api 内存限制 ==="
sed -n '/^file-parser-api:/,/^z8m:/p' "$VALUES_FILE" | grep 'memory:'
