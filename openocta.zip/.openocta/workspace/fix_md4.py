#!/usr/bin/env python3
"""Fixed MD4 implementation - test against known values"""

import struct

def md4(data):
    """MD4 hash - RFC 1320"""
    def F(x, y, z): return (x & y) | (~x & z)
    def G(x, y, z): return (x & y) | (x & z) | (y & z)
    def H(x, y, z): return x ^ y ^ z
    def left_rotate(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    
    # Pre-processing
    msg = bytearray(data)
    orig_len = len(data)
    msg.append(0x80)
    while len(msg) % 64 != 56:
        msg.append(0)
    msg += struct.pack('<Q', orig_len * 8)
    
    # Initialize
    a0 = 0x67452301
    b0 = 0xefcdab89
    c0 = 0x98badcfe
    d0 = 0x10325476
    
    # Process each 512-bit block
    for i in range(0, len(msg), 64):
        X = [struct.unpack('<I', msg[i+j:i+j+4])[0] for j in range(0, 64, 4)]
        a, b, c, d = a0, b0, c0, d0
        
        # Round 1: F, [3,7,11,19]
        for k in range(16):
            if k % 4 == 0:   a = left_rotate((a + F(b,c,d) + X[k]) & 0xFFFFFFFF, 3)
            elif k % 4 == 1: d = left_rotate((d + F(a,b,c) + X[k]) & 0xFFFFFFFF, 7)
            elif k % 4 == 2: c = left_rotate((c + F(d,a,b) + X[k]) & 0xFFFFFFFF, 11)
            elif k % 4 == 3: b = left_rotate((b + F(c,d,a) + X[k]) & 0xFFFFFFFF, 19)
        
        # Round 2: G, [3,5,9,13]
        order2 = [0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]
        for idx, k in enumerate(order2):
            if idx % 4 == 0:   a = left_rotate((a + G(b,c,d) + X[k] + 0x5A827999) & 0xFFFFFFFF, 3)
            elif idx % 4 == 1: d = left_rotate((d + G(a,b,c) + X[k] + 0x5A827999) & 0xFFFFFFFF, 5)
            elif idx % 4 == 2: c = left_rotate((c + G(d,a,b) + X[k] + 0x5A827999) & 0xFFFFFFFF, 9)
            elif idx % 4 == 3: b = left_rotate((b + G(c,d,a) + X[k] + 0x5A827999) & 0xFFFFFFFF, 13)
        
        # Round 3: H, [3,9,11,15]
        order3 = [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]
        for idx, k in enumerate(order3):
            if idx % 4 == 0:   a = left_rotate((a + H(b,c,d) + X[k] + 0x6ED9EBA1) & 0xFFFFFFFF, 3)
            elif idx % 4 == 1: d = left_rotate((d + H(a,b,c) + X[k] + 0x6ED9EBA1) & 0xFFFFFFFF, 9)
            elif idx % 4 == 2: c = left_rotate((c + H(d,a,b) + X[k] + 0x6ED9EBA1) & 0xFFFFFFFF, 11)
            elif idx % 4 == 3: b = left_rotate((b + H(c,d,a) + X[k] + 0x6ED9EBA1) & 0xFFFFFFFF, 15)
        
        a0 = (a0 + a) & 0xFFFFFFFF
        b0 = (b0 + b) & 0xFFFFFFFF
        c0 = (c0 + c) & 0xFFFFFFFF
        d0 = (d0 + d) & 0xFFFFFFFF
    
    return struct.pack('<4I', a0, b0, c0, d0)

# Test: MD4("") should be 31d6cfe0d16ae931b73c59d7e0c089c0
test1 = md4(b'').hex()
print(f"MD4('') = {test1}")
print(f"Expected: 31d6cfe0d16ae931b73c59d7e0c089c0")
print(f"Match: {test1 == '31d6cfe0d16ae931b73c59d7e0c089c0'}")

# Test: MD4("abc") should be a448017aaf21d8525fc10ae87aa6729d
test2 = md4(b'abc').hex()
print(f"\nMD4('abc') = {test2}")
print(f"Expected: a448017aaf21d8525fc10ae87aa6729d")
print(f"Match: {test2 == 'a448017aaf21d8525fc10ae87aa6729d'}")

# Test: NTLM hash of "Password" should be 8846f7eaee8fb117ad06bdd830b7586c
test3 = md4("Password".encode('utf-16-le')).hex()
print(f"\nNTLM('Password') = {test3}")
print(f"Expected: 8846f7eaee8fb117ad06bdd830b7586c")
print(f"Match: {test3 == '8846f7eaee8fb117ad06bdd830b7586c'}")
