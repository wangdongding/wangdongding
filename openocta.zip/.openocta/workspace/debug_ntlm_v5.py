#!/usr/bin/env python3
"""Try NTLM auth with the .88 server - matching what actually works"""

import requests, base64, struct, hashlib, hmac, os, time

def md4(data):
    def F(x,y,z): return (x&y)|(~x&z)
    def G(x,y,z): return (x&y)|(x&z)|(y&z)
    def H(x,y,z): return x^y^z
    def lr(n,b): return ((n<<b)|(n>>(32-b)))&0xFFFFFFFF
    msg=bytearray(data); ol=len(data); msg.append(0x80)
    while len(msg)%64!=56: msg.append(0)
    msg+=struct.pack('<Q',ol*8)
    a0,b0,c0,d0=0x67452301,0xefcdab89,0x98badcfe,0x10325476
    for i in range(0,len(msg),64):
        X=[struct.unpack('<I',msg[i+j:i+j+4])[0] for j in range(0,64,4)]
        a,b,c,d=a0,b0,c0,d0
        for k in range(16):
            if k%4==0: a=lr((a+F(b,c,d)+X[k])&0xFFFFFFFF,3)
            elif k%4==1: d=lr((d+F(a,b,c)+X[k])&0xFFFFFFFF,7)
            elif k%4==2: c=lr((c+F(d,a,b)+X[k])&0xFFFFFFFF,11)
            elif k%4==3: b=lr((b+F(c,d,a)+X[k])&0xFFFFFFFF,19)
        order2=[0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]
        for idx,k in enumerate(order2):
            if idx%4==0: a=lr((a+G(b,c,d)+X[k]+0x5A827999)&0xFFFFFFFF,3)
            elif idx%4==1: d=lr((d+G(a,b,c)+X[k]+0x5A827999)&0xFFFFFFFF,5)
            elif idx%4==2: c=lr((c+G(d,a,b)+X[k]+0x5A827999)&0xFFFFFFFF,9)
            elif idx%4==3: b=lr((b+G(c,d,a)+X[k]+0x5A827999)&0xFFFFFFFF,13)
        order3=[0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]
        for idx,k in enumerate(order3):
            if idx%4==0: a=lr((a+H(b,c,d)+X[k]+0x6ED9EBA1)&0xFFFFFFFF,3)
            elif idx%4==1: d=lr((d+H(a,b,c)+X[k]+0x6ED9EBA1)&0xFFFFFFFF,9)
            elif idx%4==2: c=lr((c+H(d,a,b)+X[k]+0x6ED9EBA1)&0xFFFFFFFF,11)
            elif idx%4==3: b=lr((b+H(c,d,a)+X[k]+0x6ED9EBA1)&0xFFFFFFFF,15)
        a0=(a0+a)&0xFFFFFFFF;b0=(b0+b)&0xFFFFFFFF;c0=(c0+c)&0xFFFFFFFF;d0=(d0+d)&0xFFFFFFFF
    return struct.pack('<4I',a0,b0,c0,d0)

URL = "http://172.17.3.88:5985/wsman"
USER = "Compiler"
PASS = "Yuwei@2505"
DOMAIN = "WIN-3Q977300URH"

# Use session for connection reuse
session = requests.Session()

# Type 1 with simple flags that worked before
t1 = base64.b64encode(b'NTLMSSP\x00'+struct.pack('<I',1)+struct.pack('<I',0x00088215)+struct.pack('<HHI',0,0,32)+struct.pack('<HHI',0,0,32)).decode()
r1 = session.post(URL, headers={'Content-Type':'application/soap+xml; charset=UTF-8','Authorization':f'Negotiate {t1}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
print(f"Type1 -> {r1.status_code}")

auth = r1.headers.get('WWW-Authenticate','')
challenge = None
for p in auth.split(','):
    p = p.strip()
    if p.startswith('Negotiate ') and len(p) > 10: challenge = p[10:]; break
if not challenge:
    print("No challenge!")
    exit(1)

d = base64.b64decode(challenge)
server_chal = d[24:32]
ti_len = struct.unpack('<H', d[40:42])[0]
ti_off = struct.unpack('<I', d[44:48])[0]
target_info = d[ti_off:ti_off+ti_len]
neg_flags = struct.unpack('<I', d[20:24])[0]
print(f"Server challenge: {server_chal.hex()}, NegFlags: {neg_flags:#010x}")

# Build Type3
nt_h = md4(PASS.encode('utf-16-le'))
client_chal = os.urandom(8)

# NTLMv2 with domain
temp = hmac.new(nt_h, (USER.upper()+DOMAIN).encode('utf-16-le'), hashlib.md5).digest()
blob = bytearray()
blob += b'\x01\x01\x00\x00\x00\x00\x00\x00'
blob += struct.pack('<Q', int(time.time()) + 11644473600)
blob += client_chal + b'\x00\x00\x00\x00' + target_info
ntproof = hmac.new(temp, server_chal + bytes(blob), hashlib.md5).digest()
nt_resp = ntproof + bytes(blob)
lm_resp = hmac.new(temp, server_chal + client_chal, hashlib.md5).digest() + client_chal

dom_enc = DOMAIN.upper().encode('utf-16-le')
usr_enc = USER.encode('utf-16-le')
ws_enc = DOMAIN.upper().encode('utf-16-le')

base_off = 88
lm_off = base_off; nt_off = lm_off + len(lm_resp)
dom_off = nt_off + len(nt_resp); usr_off = dom_off + len(dom_enc)
ws_off = usr_off + len(usr_enc); sess_off = ws_off + len(ws_enc)

# Use same flags as Type1
flags = 0x00088215

t3 = bytearray()
t3 += b'NTLMSSP\x00' + struct.pack('<I',3)
t3 += struct.pack('<HHI', len(lm_resp), len(lm_resp), lm_off)
t3 += struct.pack('<HHI', len(nt_resp), len(nt_resp), nt_off)
t3 += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off)
t3 += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off)
t3 += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off)
t3 += struct.pack('<HHI', 0, 0, sess_off)
t3 += struct.pack('<I', flags)
t3 += struct.pack('<Q', 0x0000000F00000001)  # Version
t3 += lm_resp + nt_resp + dom_enc + usr_enc + ws_enc

t3_b64 = base64.b64encode(bytes(t3)).decode()
print(f"Type3: {len(t3)} bytes")

# Send Type3 on the SAME connection
r3 = session.post(URL, headers={'Content-Type':'application/soap+xml; charset=UTF-8','Authorization':f'Negotiate {t3_b64}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
print(f"Type3 -> {r3.status_code}")

if r3.status_code != 401:
    print("SUCCESS!")
else:
    print("Failed. Trying with Yuwei@2605 password...")
    nt_h2 = md4("Yuwei@2605".encode('utf-16-le'))
    temp2 = hmac.new(nt_h2, (USER.upper()+DOMAIN).encode('utf-16-le'), hashlib.md5).digest()
    blob2 = bytearray()
    blob2 += b'\x01\x01\x00\x00\x00\x00\x00\x00'
    blob2 += struct.pack('<Q', int(time.time()) + 11644473600)
    blob2 += client_chal + b'\x00\x00\x00\x00' + target_info
    ntproof2 = hmac.new(temp2, server_chal + bytes(blob2), hashlib.md5).digest()
    nt_resp2 = ntproof2 + bytes(blob2)
    lm_resp2 = hmac.new(temp2, server_chal + client_chal, hashlib.md5).digest() + client_chal
    
    dom_off2 = 88 + len(lm_resp2) + len(nt_resp2)
    usr_off2 = dom_off2 + len(dom_enc)
    ws_off2 = usr_off2 + len(usr_enc)
    sess_off2 = ws_off2 + len(ws_enc)
    
    t3b = bytearray()
    t3b += b'NTLMSSP\x00' + struct.pack('<I',3)
    t3b += struct.pack('<HHI', len(lm_resp2), len(lm_resp2), 88)
    t3b += struct.pack('<HHI', len(nt_resp2), len(nt_resp2), 88+len(lm_resp2))
    t3b += struct.pack('<HHI', len(dom_enc), len(dom_enc), dom_off2)
    t3b += struct.pack('<HHI', len(usr_enc), len(usr_enc), usr_off2)
    t3b += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_off2)
    t3b += struct.pack('<HHI', 0, 0, sess_off2)
    t3b += struct.pack('<I', flags)
    t3b += struct.pack('<Q', 0x0000000F00000001)
    t3b += lm_resp2 + nt_resp2 + dom_enc + usr_enc + ws_enc
    
    r4 = session.post(URL, headers={'Content-Type':'application/soap+xml; charset=UTF-8','Authorization':f'Negotiate {base64.b64encode(bytes(t3b)).decode()}'}, data='<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body></s:Body></s:Envelope>', verify=False, timeout=10)
    print(f"Type3 (alt pw) -> {r4.status_code}")
