#!/usr/bin/env python3
"""WinRM test - use the exact format that worked before, fix Receive"""

import requests
from requests.auth import HTTPBasicAuth
import base64
import uuid
import time
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def uid(): return f"uuid:{str(uuid.uuid4()).upper()}"

def find_tag(xml_text, tag_name):
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name and elem.text:
            return elem.text
    return None

def extract_streams(xml_text):
    stdout_parts, stderr_parts = [], []
    for elem in ET.fromstring(xml_text).iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == 'Stream' and elem.text:
            name = elem.attrib.get('Name', '')
            decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
            if 'stdout' in name: stdout_parts.append(decoded)
            elif 'stderr' in name: stderr_parts.append(decoded)
    return ''.join(stdout_parts), ''.join(stderr_parts)

auth = HTTPBasicAuth(USER, PASS)
hdrs = {'Content-Type': 'application/soap+xml; charset=UTF-8'}

# The Create Shell that worked before (with rsp: namespace)
def soap_create():
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OptionSet xmlns:x="http://www.w3.org/2001/XMLSchema-instance">
      <w:Option Name="WINRS_NOPROFILE" x:type="xs:boolean">false</w:Option>
      <w:Option Name="WINRS_CODEPAGE" x:type="xs:int">65001</w:Option>
    </w:OptionSet>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
    </rsp:Shell>
  </s:Body>
</s:Envelope>'''

def soap_command(shell_id, cmd, args):
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:Command>{cmd}</rsp:Command>
      <rsp:Arguments>{args}</rsp:Arguments>
    </rsp:CommandLine>
  </s:Body>
</s:Envelope>'''

# Receive with rsp: namespace (same as Command)
def soap_receive(shell_id, command_id):
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body>
    <rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:DesiredStream>stdout stderr</rsp:DesiredStream>
      <rsp:CommandId>{command_id}</rsp:CommandId>
    </rsp:Receive>
  </s:Body>
</s:Envelope>'''

def soap_delete(shell_id):
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <a:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</a:Action>
    <a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
    <w:MaxEnvelopeSize mustUnderstand="true">153600</w:MaxEnvelopeSize>
    <a:To>{URL}</a:To>
    <w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>
    <a:MessageID>{uid()}</a:MessageID>
    <w:OperationTimeout>PT60.000S</w:OperationTimeout>
    <w:SelectorSet><w:Selector Name="ShellId">{shell_id}</w:Selector></w:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>'''

try:
    # Create shell
    r = requests.post(URL, data=soap_create(), auth=auth, headers=hdrs, timeout=15)
    print(f"Create: HTTP {r.status_code}")
    if r.status_code != 200:
        print(r.text[:500]); exit(1)
    shell_id = find_tag(r.text, 'ShellId')
    print(f"ShellId: {shell_id}")
    
    # Command
    r2 = requests.post(URL, data=soap_command(shell_id, "cmd.exe", "/c whoami"), auth=auth, headers=hdrs, timeout=30)
    print(f"Command: HTTP {r2.status_code}")
    command_id = find_tag(r2.text, 'CommandId')
    print(f"CommandId: {command_id}")
    
    # Wait for command to complete
    time.sleep(3)
    
    # Receive
    r3 = requests.post(URL, data=soap_receive(shell_id, command_id), auth=auth, headers=hdrs, timeout=15)
    print(f"Receive: HTTP {r3.status_code}")
    if r3.status_code == 200:
        out, err = extract_streams(r3.text)
        print(f"STDOUT: [{out.strip()}]")
        print(f"STDERR: [{err.strip()}]")
        # Check state/exit code
        for elem in ET.fromstring(r3.text).iter():
            local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if local in ('ExitCode', 'State') and elem.text:
                print(f"{local}: {elem.text}")
    else:
        print(f"Error: {r3.text[:500]}")
    
    # Delete
    r4 = requests.post(URL, data=soap_delete(shell_id), auth=auth, headers=hdrs, timeout=10)
    print(f"Delete: HTTP {r4.status_code}")

except Exception as e:
    print(f"ERROR: {e}")
    import traceback; traceback.print_exc()
