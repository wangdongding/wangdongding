#!/usr/bin/env python3
"""Execute PowerShell via WinRM on 172.17.3.193 - properly formatted SOAP"""

import requests
from requests.auth import HTTPBasicAuth
import base64
import uuid
import time
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
WINRM_URL = f"http://{TARGET}:5985/wsman"

SOAP_ENV = "http://www.w3.org/2003/05/soap-envelope"
WSA = "http://schemas.xmlsoap.org/ws/2004/08/addressing"
WSMAN = "http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
WSMV = "http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

def soap_create_shell():
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="{SOAP_ENV}" xmlns:wsa="{WSA}" xmlns:wsman="{WSMAN}" xmlns:wsmv="{WSMV}">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</wsa:Action>
    <wsa:ReplyTo><wsa:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo>
    <wsa:To>{WINRM_URL}</wsa:To>
    <wsman:MaxEnvelopeSize mustUnderstand="true">153600</wsman:MaxEnvelopeSize>
    <wsman:ResourceURI mustUnderstand="true">{SHELL_URI}</wsman:ResourceURI>
    <wsmv:OptionSet xmlns:wsmv="{WSMV}">
      <wsman:Option Name="WINRS_NOPROFILE" mustUnderstand="false">FALSE</wsman:Option>
      <wsman:Option Name="WINRS_CODEPAGE" mustUnderstand="true">65001</wsman:Option>
    </wsmv:OptionSet>
    <wsman:OperationTimeout>PT60S</wsman:OperationTimeout>
  </s:Header>
  <s:Body>
    <wsmv:Shell xmlns:wsmv="{WSMV}">
      <wsmv:InputStreams>stdin</wsmv:InputStreams>
      <wsmv:OutputStreams>stdout stderr</wsmv:OutputStreams>
      <wsmv:IdleTimeOut>PT60S</wsmv:IdleTimeOut>
    </wsmv:Shell>
  </s:Body>
</s:Envelope>"""

def soap_command(shell_id, encoded_cmd):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="{SOAP_ENV}" xmlns:wsa="{WSA}" xmlns:wsman="{WSMAN}" xmlns:wsmv="{WSMV}">
  <s:Header>
    <wsa:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command</wsa:Action>
    <wsa:ReplyTo><wsa:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo>
    <wsa:To>{WINRM_URL}</wsa:To>
    <wsman:MaxEnvelopeSize mustUnderstand="true">153600</wsman:MaxEnvelopeSize>
    <wsman:ResourceURI mustUnderstand="true">{SHELL_URI}</wsman:ResourceURI>
    <wsman:OperationTimeout>PT60S</wsman:OperationTimeout>
    <wsmv:ShellId>{shell_id}</wsmv:ShellId>
  </s:Header>
  <s:Body>
    <wsmv:CommandLine xmlns:wsmv="{WSMV}">
      <wsmv:Command>powershell.exe</wsmv:Command>
      <wsmv:Arguments>-NoProfile -NonInteractive -EncodedCommand {encoded_cmd}</wsmv:Arguments>
    </wsmv:CommandLine>
  </s:Body>
</s:Envelope>"""

def soap_receive(shell_id, command_id):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="{SOAP_ENV}" xmlns:wsa="{WSA}" xmlns:wsman="{WSMAN}" xmlns:wsmv="{WSMV}">
  <s:Header>
    <wsa:Action>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive</wsa:Action>
    <wsa:ReplyTo><wsa:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo>
    <wsa:To>{WINRM_URL}</wsa:To>
    <wsman:MaxEnvelopeSize mustUnderstand="true">153600</wsman:MaxEnvelopeSize>
    <wsman:ResourceURI mustUnderstand="true">{SHELL_URI}</wsman:ResourceURI>
    <wsman:OperationTimeout>PT60S</wsman:OperationTimeout>
    <wsmv:ShellId>{shell_id}</wsmv:ShellId>
  </s:Header>
  <s:Body>
    <wsmv:Receive xmlns:wsmv="{WSMV}">
      <wsmv:DesiredStream>stdout stderr</wsmv:DesiredStream>
      <wsmv:CommandId>{command_id}</wsmv:CommandId>
    </wsmv:Receive>
  </s:Body>
</s:Envelope>"""

def soap_delete(shell_id):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="{SOAP_ENV}" xmlns:wsa="{WSA}" xmlns:wsman="{WSMAN}">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete</wsa:Action>
    <wsa:ReplyTo><wsa:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:Address></wsa:ReplyTo>
    <wsa:To>{WINRM_URL}</wsa:To>
    <wsman:MaxEnvelopeSize mustUnderstand="true">153600</wsman:MaxEnvelopeSize>
    <wsman:ResourceURI mustUnderstand="true">{SHELL_URI}</wsman:ResourceURI>
    <wsman:OperationTimeout>PT60S</wsman:OperationTimeout>
    <wsman:SelectorSet>
      <wsman:Selector Name="ShellId">{shell_id}</wsman:Selector>
    </wsman:SelectorSet>
  </s:Header>
  <s:Body/>
</s:Envelope>"""

def encode_ps(cmd):
    return base64.b64encode(cmd.encode('utf-16-le')).decode('ascii')

def find_in_xml(xml_text, tag_name):
    """Simple tag finder that handles namespaces"""
    root = ET.fromstring(xml_text)
    results = []
    for elem in root.iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == tag_name:
            results.append(elem.text or "")
    return results

def extract_streams(xml_text):
    """Extract stdout/stderr stream content"""
    root = ET.fromstring(xml_text)
    stdout_parts = []
    stderr_parts = []
    for elem in root.iter():
        local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if local == 'Stream':
            name = elem.attrib.get('Name', '')
            if elem.text:
                try:
                    decoded = base64.b64decode(elem.text).decode('utf-8', errors='replace')
                    if 'stdout' in name:
                        stdout_parts.append(decoded)
                    elif 'stderr' in name:
                        stderr_parts.append(decoded)
                except:
                    pass
    return ''.join(stdout_parts), ''.join(stderr_parts)

def is_done(xml_text):
    return 'Done' in xml_text

auth = HTTPBasicAuth(USER, PASS)
hdrs = {
    'Content-Type': 'application/soap+xml; charset=UTF-8',
}

# === Main execution ===
# Check WinRM auth config, CredSSP, UAC, current user
ps_script = r"""
$ErrorActionPreference = 'Continue'
Write-Output "=== 1. WinRM Auth Configuration ==="
try {
    $auth = Get-ChildItem WSMan:\localhost\Service\Auth
    foreach ($a in $auth) { Write-Output ("{0} = {1}" -f $a.Name, $a.Value) }
} catch { Write-Output "Failed to read WSMan auth" }

Write-Output ""
Write-Output "=== 2. CredSSP Service Configuration ==="
try {
    $credssp = Get-Item WSMan:\localhost\Service\Auth\CredSSP
    Write-Output ("CredSSP = {0}" -f $credssp.Value)
} catch { Write-Output "CredSSP key not found or inaccessible" }

Write-Output ""
Write-Output "=== 3. CredSSP Client Delegation ==="
try {
    $delegate = Get-Item WSMan:\localhost\Client\TrustedHosts
    Write-Output ("TrustedHosts = {0}" -f $delegate.Value)
} catch { Write-Output "TrustedHosts not readable" }

Write-Output ""
Write-Output "=== 4. UAC Registry Settings ==="
try {
    $uac = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
    Write-Output ("EnableLUA = {0}" -f $uac.EnableLUA)
    Write-Output ("FilterAdministratorToken = {0}" -f $uac.FilterAdministratorToken)
    Write-Output ("LocalAccountTokenFilterPolicy = {0}" -f $uac.LocalAccountTokenFilterPolicy)
} catch { Write-Output "UAC registry read failed" }

Write-Output ""
Write-Output "=== 5. Current Identity ==="
Write-Output ("User: {0}" -f (whoami))

Write-Output ""
Write-Output "=== 6. Group Memberships ==="
try {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    Write-Output ("IsSystem: {0}" -f $id.IsSystem)
    Write-Output ("IsAdmin: {0}" -f ($id.Groups -contains [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')))
    $id.Groups | ForEach-Object { Write-Output ("  Group: {0}" -f $_.Value) }
} catch { Write-Output "Identity check failed" }
"""

try:
    # 1. Create shell
    print("[1] Creating WinRM shell...")
    r = requests.post(WINRM_URL, data=soap_create_shell(), auth=auth, headers=hdrs, timeout=15)
    print(f"    HTTP {r.status_code}")
    if r.status_code != 200:
        print(f"    ERROR: {r.text[:600]}")
        exit(1)
    
    shell_ids = find_in_xml(r.text, 'ShellId')
    if not shell_ids:
        # Try to find in Selector
        for elem in ET.fromstring(r.text).iter():
            local = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
            if local == 'Selector' and elem.text and len(elem.text) > 20:
                shell_ids.append(elem.text)
    
    shell_id = shell_ids[0] if shell_ids else None
    print(f"    ShellId: {shell_id}")
    
    if not shell_id:
        print("    ERROR: Could not extract ShellId")
        # Print response for debugging
        print(r.text[:1000])
        exit(1)
    
    # 2. Execute command
    print("[2] Executing PowerShell...")
    encoded = encode_ps(ps_script)
    r2 = requests.post(WINRM_URL, data=soap_command(shell_id, encoded), auth=auth, headers=hdrs, timeout=30)
    print(f"    HTTP {r2.status_code}")
    
    cmd_ids = find_in_xml(r2.text, 'CommandId')
    command_id = cmd_ids[0] if cmd_ids else None
    print(f"    CommandId: {command_id}")
    
    # 3. Receive output
    print("[3] Receiving output...")
    all_stdout = ""
    all_stderr = ""
    for i in range(15):
        time.sleep(1)
        r3 = requests.post(WINRM_URL, data=soap_receive(shell_id, command_id), auth=auth, headers=hdrs, timeout=15)
        if r3.status_code == 200:
            out, err = extract_streams(r3.text)
            if out:
                all_stdout += out
            if err:
                all_stderr += err
            if is_done(r3.text):
                print(f"    Command completed after {i+1}s")
                break
    
    print(f"\n{'='*60}")
    print(all_stdout)
    if all_stderr:
        print(f"\nSTDERR:\n{all_stderr}")
    
    # 4. Cleanup
    print(f"\n[4] Cleaning up shell...")
    requests.post(WINRM_URL, data=soap_delete(shell_id), auth=auth, headers=hdrs, timeout=10)
    print("    Done")

except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
