#!/usr/bin/env python3
"""Test WinRM shell creation with proper auth - debug the 500 error"""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
URL = f"http://{TARGET}:5985/wsman"

SOAP_ENV = "http://www.w3.org/2003/05/soap-envelope"
WSA = "http://schemas.xmlsoap.org/ws/2004/08/addressing"
WSMAN = "http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
WSMV = "http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd"
SHELL_URI = "http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd"

# Minimal Create Shell
create_shell = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="{SOAP_ENV}" xmlns:wsa="{WSA}" xmlns:wsman="{WSMAN}" xmlns:wsmv="{WSMV}">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</wsa:Action>
    <wsa:To>{URL}</wsa:To>
    <wsman:ResourceURI>{SHELL_URI}</wsman:ResourceURI>
    <wsmv:OptionSet>
      <wsman:Option Name="WINRS_NOPROFILE">FALSE</wsman:Option>
      <wsman:Option Name="WINRS_CODEPAGE">65001</wsman:Option>
    </wsmv:OptionSet>
  </s:Header>
  <s:Body>
    <wsmv:Shell>
      <wsmv:InputStreams>stdin</wsmv:InputStreams>
      <wsmv:OutputStreams>stdout stderr</wsmv:OutputStreams>
    </wsmv:Shell>
  </s:Body>
</s:Envelope>'''

headers = {'Content-Type': 'application/soap+xml; charset=UTF-8'}
auth = HTTPBasicAuth(USER, PASS)

# Try with Basic auth
print("=== Test 1: Create Shell with Basic Auth ===")
r = requests.post(URL, data=create_shell, auth=auth, headers=headers, timeout=15)
print(f"HTTP {r.status_code}")
if r.status_code != 200:
    # Parse the fault
    root = ET.fromstring(r.content)
    for elem in root.iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if tag in ('Subcode', 'Reason', 'Text', 'Detail', 'Message', 'faultcode', 'faultstring') or 'Error' in tag:
            if elem.text and elem.text.strip():
                print(f"  {tag}: {elem.text.strip()[:200]}")

# Try with different Content-Type
print("\n=== Test 2: Create Shell with application/soap+xml ===")
headers2 = {'Content-Type': 'application/soap+xml'}
r2 = requests.post(URL, data=create_shell, auth=auth, headers=headers2, timeout=15)
print(f"HTTP {r2.status_code}")
if r2.status_code != 200:
    for elem in ET.fromstring(r2.content).iter():
        tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
        if elem.text and elem.text.strip() and tag not in ('Action', 'MessageID', 'To'):
            print(f"  {tag}: {elem.text.strip()[:200]}")

# Try with text/xml
print("\n=== Test 3: Create Shell with text/xml ===")
headers3 = {'Content-Type': 'text/xml; charset=UTF-8'}
r3 = requests.post(URL, data=create_shell, auth=auth, headers=headers3, timeout=15)
print(f"HTTP {r3.status_code}")

# Check if maybe Negotiate auth is required (not Basic)
print("\n=== Test 4: Check auth methods via HTTP headers ===")
r4 = requests.get(f"http://{TARGET}:5985/", timeout=5)
print(f"HTTP {r4.status_code}")
print(f"Headers: {dict(r4.headers)}")
