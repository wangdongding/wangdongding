#!/usr/bin/env python3
"""Pure Python NTLM auth for WinRM - connect to 172.17.3.88"""

import requests
import struct, hashlib, hmac, base64, uuid, time, os, sys
import xml.etree.ElementTree as ET
from requests.auth import AuthBase

# === NTLM Auth Implementation ===

def md4(data):
    """Pure Python MD4 implementation"""
    import struct
    def f(x, y, z): return (x & y) | (~x & z)
    def g(x, y, z): return (x & y) | (x & z) | (y & z)
    def h(x, y, z): return x ^ y ^ z
    def left_rotate(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    
    # Pre-processing: adding padding bits
    msg = bytearray(data)
    msg_len = len(data)
    msg.append(0x80)
    while len(msg) % 64 != 56:
        msg.append(0)
    msg += struct.pack('<Q', msg_len * 8)
    
    # Initialize hash values
    a0 = 0x67452301
    b0 = 0xefcdab89
    c0 = 0x98badcfe
    d0 = 0x10325476
    
    for i in range(0, len(msg), 64):
        M = [struct.unpack('<I', msg[i+j:i+j+4])[0] for j in range(0, 64, 4)]
        a, b, c, d = a0, b0, c0, d0
        
        # Round 1
        for k in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]:
            s = [3,7,11,19][k%4]
            a = left_rotate((a + f(b,c,d) + M[k]) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c
        
        # Round 2
        for k in [0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]:
            s = [3,5,9,13][([0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15].index(k))%4]
            a = left_rotate((a + g(b,c,d) + M[k] + 0x5A827999) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c
        
        # Round 3
        for k in [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]:
            s = [3,9,11,15][([0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15].index(k))%4]
            a = left_rotate((a + h(b,c,d) + M[k] + 0x6ED9EBA1) & 0xFFFFFFFF, s)
            a, b, c, d = d, a, b, c
        
        a0 = (a0 + a) & 0xFFFFFFFF
        b0 = (b0 + b) & 0xFFFFFFFF
        c0 = (c0 + c) & 0xFFFFFFFF
        d0 = (d0 + d) & 0xFFFFFFFF
    
    return struct.pack('<4I', a0, b0, c0, d0)

def ntlm_hash(password):
    """NTLM hash of password"""
    return md4(password.encode('utf-16-le'))

def ntlmv2_response(ntlmhash, server_challenge, target_info, username, domain, client_challenge=None):
    """Calculate NTLMv2 response"""
    # NTProofStr = HMAC-MD5(MD5(ntlmhash), server_challenge + blob)
    # blob = NTLMv2 blob structure
    
    if client_challenge is None:
        client_challenge = os.urandom(8)
    
    # Calculate NTv2 temp key
    temp_key = hmac.new(ntlmhash, (username.upper() + domain).encode('utf-16-le'), hashlib.md5).digest()
    
    # Build blob
    blob = bytearray()
    blob_sig = b'\x01\x01\x00\x00'
    reserved = b'\x00\x00\x00\x00'
    timestamp = struct.pack('<Q', int(time.time()) + 11644473600)  # Windows FILETIME
    blob += blob_sig + reserved + timestamp + client_challenge + reserved + target_info
    
    # Calculate NTProofStr
    ntproof = hmac.new(temp_key, server_challenge + bytes(blob), hashlib.md5).digest()
    
    return ntproof, bytes(blob)

def build_type1_message(domain='', workstation=''):
    """Build NTLM Type 1 (Negotiate) message"""
    flags = 0x00088215  # NTLMSSP_NEGOTIATE_56 | NTLMSSP_NEGOTIATE_128 | NTLMSSP_NEGOTIATE_NTLM | ...
    msg = bytearray()
    msg += b'NTLMSSP\x00'  # Signature
    msg += struct.pack('<I', 1)  # Type 1
    msg += struct.pack('<I', flags)  # Flags
    dom_offset = 32
    ws_offset = 32
    if domain:
        dom_off = domain.encode('utf-16-le')
        msg += struct.pack('<HHI', len(dom_off), len(dom_off), ws_offset + len(workstation.encode('utf-16-le')) if workstation else dom_offset)
    else:
        msg += struct.pack('<HHI', 0, 0, dom_offset)
    if workstation:
        ws_off = workstation.encode('utf-16-le')
        msg += struct.pack('<HHI', len(ws_off), len(ws_off), dom_offset)
    else:
        msg += struct.pack('<HHI', 0, 0, ws_offset)
    return base64.b64encode(bytes(msg)).decode('ascii')

def parse_type2_message(data):
    """Parse NTLM Type 2 (Challenge) message"""
    msg = base64.b64decode(data)
    if msg[:8] != b'NTLMSSP\x00':
        raise ValueError("Not NTLM Type 2 message")
    msg_type = struct.unpack('<I', msg[8:12])[0]
    if msg_type != 2:
        raise ValueError(f"Expected Type 2, got {msg_type}")
    
    server_challenge = msg[24:32]
    target_info_len = struct.unpack('<H', msg[40:42])[0]
    target_info_offset = struct.unpack('<I', msg[44:48])[0]
    target_info = msg[target_info_offset:target_info_offset + target_info_len]
    
    # Get target name
    target_name_len = struct.unpack('<H', msg[12:14])[0]
    target_name_offset = struct.unpack('<I', msg[16:20])[0]
    target_name = msg[target_name_offset:target_name_offset + target_name_len].decode('utf-16-le', errors='replace')
    
    return server_challenge, target_info, target_name

def build_type3_message(username, password, server_challenge, target_info, target_name, domain=''):
    """Build NTLM Type 3 (Auth) message"""
    nt_hash = ntlm_hash(password)
    client_challenge = os.urandom(8)
    
    ntproof, blob = ntlmv2_response(nt_hash, server_challenge, target_info, username, domain, client_challenge)
    nt_response = ntproof + blob
    
    lm_response = hmac.new(hmac.new(nt_hash, (username.upper() + domain).encode('utf-16-le'), hashlib.md5).digest(),
                           server_challenge + client_challenge, hashlib.md5).digest() + client_challenge
    
    domain_enc = domain.upper().encode('utf-16-le')
    user_enc = username.encode('utf-16-le')
    ws_enc = b''  # empty workstation
    
    base_offset = 88  # Fixed header size for Type 3
    lm_offset = base_offset
    nt_offset = lm_offset + len(lm_response)
    domain_offset = nt_offset + len(nt_response)
    user_offset = domain_offset + len(domain_enc)
    ws_offset = user_offset + len(user_enc)
    
    flags = 0x00088215
    
    msg = bytearray()
    msg += b'NTLMSSP\x00'
    msg += struct.pack('<I', 3)  # Type 3
    msg += struct.pack('<HHI', len(lm_response), len(lm_response), lm_offset)
    msg += struct.pack('<HHI', len(nt_response), len(nt_response), nt_offset)
    msg += struct.pack('<HHI', len(domain_enc), len(domain_enc), domain_offset)
    msg += struct.pack('<HHI', len(user_enc), len(user_enc), user_offset)
    msg += struct.pack('<HHI', len(ws_enc), len(ws_enc), ws_offset)
    msg += struct.pack('<HHI', 0, 0, ws_offset + len(ws_enc))  # Encrypted random session key
    msg += struct.pack('<I', flags)  # Flags
    msg += struct.pack('<Q', 0)  # Version
    
    msg += lm_response
    msg += nt_response
    msg += domain_enc
    msg += user_enc
    msg += ws_enc
    
    return base64.b64encode(bytes(msg)).decode('ascii')

class NTLMAuth(AuthBase):
    """NTLM authentication for requests"""
    def __init__(self, username, password):
        self.username = username
        self.password = password
        parts = username.split('\\', 1)
        if len(parts) == 2:
            self.domain, self.user = parts
        else:
            self.domain, self.user = '', username
    
    def __call__(self, r):
        # Step 1: Send Type 1
        type1 = build_type1_message(self.domain)
        r.headers['Authorization'] = f'Negotiate {type1}'
        r.register_hook('response', self.handle_401)
        return r
    
    def handle_401(self, response, **kwargs):
        if response.status_code != 401:
            return response
        
        auth_header = response.headers.get('WWW-Authenticate', '')
        if 'Negotiate' not in auth_header:
            return response
        
        # Extract the challenge
        for part in auth_header.split(','):
            part = part.strip()
            if part.startswith('Negotiate '):
                challenge = part[10:]
                break
        else:
            return response
        
        try:
            server_challenge, target_info, target_name = parse_type2_message(challenge)
        except Exception as e:
            return response
        
        # Step 3: Send Type 3
        type3 = build_type3_message(self.user, self.password, server_challenge, target_info, target_name, self.domain)
        
        # Consume the response body
        response.content
        response.raw.close()
        
        # Create new request with Type 3
        new_req = response.request.copy()
        new_req.headers['Authorization'] = f'Negotiate {type3}'
        
        # Remove cookies from the original request
        _ = kwargs.pop('cookies', None)
        
        new_resp = response.connection.send(new_req, **kwargs)
        new_resp.history.append(response)
        new_resp.request = new_req
        return new_resp

# === WinRM Client ===
CONTENT_TYPE = 'application/soap+xml; charset=UTF-8'
SHELL_URI = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'

def soap(url, action, body, selectors=None):
    msg_id = str(uuid.uuid4())
    sid = str(uuid.uuid4())
    res = f'<w:ResourceURI mustUnderstand="true">{SHELL_URI}</w:ResourceURI>'
    sel = ''
    if selectors:
        sel = '<w:SelectorSet>' + ''.join(f'<w:Selector Name="{k}">{v}</w:Selector>' for k,v in selectors.items()) + '</w:SelectorSet>'
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:w="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd" xmlns:p="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
<s:Header>
<a:Action>{action}</a:Action>
<a:To>{url}</a:To>
<w:MaxEnvelopeSize p:MustUnderstand="true">153600</w:MaxEnvelopeSize>
<a:MessageID>uuid:{msg_id}</a:MessageID>
<a:ReplyTo><a:Address mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</a:Address></a:ReplyTo>
{res}{sel}
<w:Locale p:MustUnderstand="false" xml:lang="en-US"/>
<p:DataLocale p:MustUnderstand="false" xml:lang="en-US"/>
<p:SessionId mustUnderstand="false">uuid:{sid}</p:SessionId>
</s:Header>
<s:Body>{body}</s:Body>
</s:Envelope>'''

def run_ps(url, auth, ps_cmd):
    encoded = base64.b64encode(ps_cmd.encode('utf-16-le')).decode('ascii')
    cmd = f'powershell -NoProfile -NonInteractive -EncodedCommand {encoded}'
    
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Create',
            '<rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:InputStreams>stdin</rsp:InputStreams><rsp:OutputStreams>stdout stderr</rsp:OutputStreams></rsp:Shell>'),
        verify=False, timeout=15)
    if r.status_code != 200: return f"[CreateShell HTTP {r.status_code}]"
    root = ET.fromstring(r.content)
    shell_id = next((e.text for e in root.iter() if e.get('Name')=='ShellId' and e.text), None)
    if not shell_id: return "[No ShellId]"
    
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command',
            f'<rsp:CommandLine xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Command>{cmd}</rsp:Command></rsp:CommandLine>',
            selectors={'ShellId': shell_id}),
        verify=False, timeout=15)
    if r.status_code != 200:
        requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
            data=soap(url, 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', '', selectors={'ShellId': shell_id}), verify=False, timeout=10)
        return f"[Exec HTTP {r.status_code}]"
    root = ET.fromstring(r.content)
    cmd_id = None
    for e in root.iter():
        t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
        if t == 'CommandId' and e.text: cmd_id = e.text; break
    if not cmd_id: return "[No CommandId]"
    
    time.sleep(2)
    
    r = requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive',
            f'<rsp:Receive xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:DesiredStream CommandId="{cmd_id}">stdout stderr</rsp:DesiredStream></rsp:Receive>',
            selectors={'ShellId': shell_id}),
        verify=False, timeout=25)
    output = ""
    if r.status_code == 200:
        root = ET.fromstring(r.content)
        for e in root.iter():
            t = e.tag.split('}')[-1] if '}' in e.tag else e.tag
            if t == 'Stream' and e.text:
                try: output += base64.b64decode(e.text).decode('utf-8', errors='replace')
                except: pass
    else:
        output = f"[Receive HTTP {r.status_code}]"
    
    requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal',
            '<rsp:Signal xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell"><rsp:Code>http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/terminate</rsp:Code></rsp:Signal>',
            selectors={'ShellId': shell_id}), verify=False, timeout=10)
    requests.post(url, auth=auth, headers={'Content-Type': CONTENT_TYPE},
        data=soap(url, 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete', '', selectors={'ShellId': shell_id}), verify=False, timeout=10)
    
    return output.strip() if output.strip() else "[No output]"

# === Run diagnostics on .88 ===
URL_88 = "http://172.17.3.88:5985/wsman"
AUTH_88 = NTLMAuth("Compiler", "Yuwei@2505")

print("=" * 70)
print("  172.17.3.88 (WORKING SERVER)")
print("=" * 70)

tests = [
    ("Echo Test", "echo hello"),
    ("WinRM Auth", "winrm get winrm/config/service/auth"),
    ("WinRM Service", "winrm get winrm/config/service"),
    ("UAC-LocalAccountTokenFilterPolicy", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name LocalAccountTokenFilterPolicy -EA 0 | Select -Exp LocalAccountTokenFilterPolicy}catch{'NOT SET(0)'}"),
    ("UAC-FilterAdministratorToken", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name FilterAdministratorToken -EA 0 | Select -Exp FilterAdministratorToken}catch{'NOT SET(0)'}"),
    ("UAC-EnableLUA", "Try{Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' -Name EnableLUA -EA 0 | Select -Exp EnableLUA}catch{'NOT SET'}"),
    ("CredSSP", "Get-WSManCredSSP 2>&1 | Out-String"),
    ("OS Version", "(Get-WmiObject Win32_OperatingSystem).Caption + ' ' + [System.Environment]::OSVersion.Version.ToString()"),
    ("User", "whoami"),
    ("User Groups", "whoami /groups"),
    ("Local Admins", "net localgroup Administrators"),
]

for name, cmd in tests:
    print(f"\n--- {name} ---")
    try:
        result = run_ps(URL_88, AUTH_88, cmd)
        print(result[:1500])
    except Exception as e:
        print(f"ERROR: {e}")
    sys.stdout.flush()
