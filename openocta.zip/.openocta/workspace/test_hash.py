#!/usr/bin/env python3
pw = "Password"
encoded = pw.encode('utf-16-le')
print(f"UTF-16-LE bytes: {encoded.hex()}")
print(f"Length: {len(encoded)}")

# The known NTLM hash for "Password" uses the Unicode (UTF-16-LE) encoding
# Let me verify with a different approach
import hashlib
try:
    # Try OpenSSL MD4
    h = hashlib.new('md4', encoded)
    print(f"hashlib MD4: {h.hexdigest()}")
except Exception as e:
    print(f"hashlib MD4 not available: {e}")

# My MD4
import struct
def md4(data):
    def F(x, y, z): return (x & y) | (~x & z)
    def G(x, y, z): return (x & y) | (x & z) | (y & z)
    def H(x, y, z): return x ^ y ^ z
    def left_rotate(n, b): return ((n << b) | (n >> (32 - b))) & 0xFFFFFFFF
    msg = bytearray(data)
    orig_len = len(data)
    msg.append(0x80)
    while len(msg) % 64 != 56: msg.append(0)
    msg += struct.pack('<Q', orig_len * 8)
    a0, b0, c0, d0 = 0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
    for i in range(0, len(msg), 64):
        X = [struct.unpack('<I', msg[i+j:i+j+4])[0] for j in range(0, 64, 4)]
        a, b, c, d = a0, b0, c0, d0
        for k in range(16):
            if k % 4 == 0:   a = left_rotate((a + F(b,c,d) + X[k]) & 0xFFFFFFFF, 3)
            elif k % 4 == 1: d = left_rotate((d + F(a,b,c) + X[k]) & 0xFFFFFFFF, 7)
            elif k % 4 == 2: c = left_rotate((c + F(d,a,b) + X[k]) & 0xFFFFFFFF, 11)
            elif k % 4 == 3: b = left_rotate((b + F(c,d,a) + X[k]) & 0xFFFFFFFF, 19)
        order2 = [0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15]
        for idx, k in enumerate(order2):
            if idx % 4 == 0:   a = left_rotate((a + G(b,c,d) + X[k] + 0x5A827999) & 0xFFFFFFFF, 3)
            elif idx % 4 == 1: d = left_rotate((d + G(a,b,c) + X[k] + 0x5A827999) & 0xFFFFFFFF, 5)
            elif idx % 4 == 2: c = left_rotate((c + G(d,a,b) + X[k] + 0x5A827999) & 0xFFFFFFFF, 9)
            elif idx % 4 == 3: b = left_rotate((b + G(c,d,a) + X[k] + 0x5A827999) & 0xFFFFFFFF, 13)
        order3 = [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]
        for idx, k in enumerate(order3):
            if idx % 4 == 0:   a = left_rotate((a + H(b,c,d) + X[k] + 0x6ED9EBA1) & 0xFFFFFFFF, 3)
            elif idx % 4 == 1: d = left_rotate((d + H(a,b,c) + X[k] + 0x6ED9EBA1) & 0xFFFFFFFF, 9)
            elif idx % 4 == 2: c = left_rotate((c + H(d,a,b) + X[k] + 0x6ED9EBA1) & 0xFFFFFFFF, 11)
            elif idx % 4 == 3: b = left_rotate((b + H(c,d,a) + X[k] + 0x6ED9EBA1) & 0xFFFFFFFF, 15)
        a0=(a0+a)&0xFFFFFFFF; b0=(b0+b)&0xFFFFFFFF; c0=(c0+c)&0xFFFFFFFF; d0=(d0+d)&0xFFFFFFFF
    return struct.pack('<4I', a0, b0, c0, d0)

my_hash = md4(encoded).hex()
print(f"My MD4 of UTF-16-LE 'Password': {my_hash}")
print(f"Expected NTLM hash: 8846f7eaee8fb117ad06bdd830b7586c")

# The issue might be that the NTLM hash reference is for a different encoding
# Let me check: maybe the reference hash is for "password" (lowercase)?
lower_hash = md4("password".encode('utf-16-le')).hex()
print(f"My MD4 of UTF-16-LE 'password': {lower_hash}")
