#!/usr/bin/env python3
"""Check Ansible readiness on a Windows server via WinRM"""

import requests
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET

TARGET = "172.17.3.193"
USER = "administrator"
PASS = "admin!123"
WINRM_URL = f"http://{TARGET}:5985/wsman"

# WinRM Identify SOAP envelope (standard WSMAN Identity request)
IDENTIFY_SOAP = """<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsmid="http://schemas.dmtf.org/wbem/wsman/identity/1/wsmanidentity.xsd">
  <s:Header/>
  <s:Body>
    <wsmid:Identify/>
  </s:Body>
</s:Envelope>"""

# WinRM Shell SOAP - try to create a shell to test command execution
CREATE_SHELL_SOAP = """<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:wsman="http://schemas.dmtf.org/wbem/wsman/1/wsman.xsd"
            xmlns:wsmv="http://schemas.microsoft.com/wbem/wsman/1/wsman.xsd">
  <s:Header>
    <wsa:Action>http://schemas.xmlsoap.org/ws/2004/09/transfer/Create</wsa:Action>
    <wsa:To>{url}</wsa:To>
    <wsman:ResourceURI s:mustUnderstand="true">http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd</wsman:ResourceURI>
    <wsa:MessageID>uuid:00000000-0000-0000-0000-000000000001</wsa:MessageID>
    <wsa:ReplyWith s:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:ReplyWith>
    <wsmv:Locale s:mustUnderstand="false" xml:lang="en-US"/>
    <wsman:Locale s:mustUnderstand="false" xml:lang="en-US"/>
    <wsman:MaxEnvelopeSize s:mustUnderstand="true">153600</wsman:MaxEnvelopeSize>
    <wsman:OperationTimeout>PT60.000S</wsman:OperationTimeout>
  </s:Header>
  <s:Body>
    <rsp:Shell xmlns:rsp="http://schemas.microsoft.com/wbem/wsman/1/windows/shell">
      <rsp:InputStreams>stdin</rsp:InputStreams>
      <rsp:OutputStreams>stdout stderr</rsp:OutputStreams>
      <rsp:WorkingDirectory>C:\\Windows\\System32</rsp:WorkingDirectory>
      <rsp:IdleTimeOut>PT600.000S</rsp:IdleTimeOut>
    </rsp:Shell>
  </s:Body>
</s:Envelope>"""

headers = {
    "Content-Type": "application/soap+xml;charset=UTF-8",
}

print("=" * 60)
print("Ansible 环境检查报告 - 172.17.3.193")
print("=" * 60)

# 1. Test 1: WinRM Identify (no auth needed usually, but try with auth)
print("\n[1] WinRM Identify 测试")
try:
    r = requests.post(WINRM_URL, data=IDENTIFY_SOAP, headers=headers,
                      auth=HTTPBasicAuth(USER, PASS), timeout=10)
    print(f"    状态码: {r.status_code}")
    if r.status_code == 200:
        print("    ✓ WinRM Identify 成功")
        print(f"    响应: {r.text[:500]}")
    else:
        print(f"    响应: {r.text[:300]}")
except Exception as e:
    print(f"    ✗ Identify 失败: {e}")

# 2. Test 2: Try NTLM auth with requests_ntlm
print("\n[2] WinRM NTLM 认证测试")
try:
    from requests_ntlm import HttpNtlmAuth
    auth = HttpNtlmAuth(f"{TARGET}\\{USER}", PASS)
    r = requests.post(WINRM_URL, data=IDENTIFY_SOAP, headers=headers,
                      auth=auth, timeout=10)
    print(f"    状态码: {r.status_code}")
    if r.status_code == 200:
        print("    ✓ NTLM 认证成功")
        print(f"    响应: {r.text[:500]}")
    else:
        print(f"    响应: {r.text[:300]}")
except ImportError:
    print("    - requests_ntlm 未安装，跳过 NTLM 测试")
except Exception as e:
    print(f"    ✗ NTLM 认证失败: {e}")

# 3. Test with curl NTLM (already confirmed working earlier)
print("\n[3] WinRM Create Shell 测试 (curl NTLM)")
import subprocess
curl_cmd = f'''curl -s -w "\\nHTTP_CODE:%{{http_code}}" -X POST --ntlm -u "{USER}:{PASS}" -H "Content-Type: application/soap+xml;charset=UTF-8" -d '{IDENTIFY_SOAP}' http://{TARGET}:5985/wsman'''
result = subprocess.run(curl_cmd, shell=True, capture_output=True, text=True, timeout=15)
output = result.stdout + result.stderr
print(f"    结果: {output[:500]}")

# 4. Check Ansible on local controller
print("\n[4] 本地 Ansible 控制节点检查")
import shutil
for cmd in ["ansible", "ansible-playbook", "ansible-inventory"]:
    path = shutil.which(cmd)
    if path:
        print(f"    ✓ {cmd}: {path}")
    else:
        print(f"    ✗ {cmd}: 未安装")

# Check Python packages
print("\n[5] Python 依赖检查")
for pkg in ["pywinrm", "requests_ntlm", "kerberos", "ntlm_auth"]:
    try:
        __import__(pkg)
        print(f"    ✓ {pkg}: 已安装")
    except ImportError:
        print(f"    ✗ {pkg}: 未安装")

print("\n" + "=" * 60)
print("检查完成")
print("=" * 60)
