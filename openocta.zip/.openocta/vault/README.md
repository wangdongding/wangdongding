# OpenOcta Knowledge Vault

This folder is your Obsidian-compatible knowledge base. Add .md notes here; the agent indexes them for memory_search.

- Open this directory in [Obsidian](https://obsidian.md) to browse and edit notes.
- Subfolders are supported; .obsidian/ is ignored by the indexer.
