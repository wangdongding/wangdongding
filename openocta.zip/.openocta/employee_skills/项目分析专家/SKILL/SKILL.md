---
displayName: SKILL
name: deploy-analyzer
description: 深度分析新项目代码库，梳理调用链、硬编码值、环境变量、端口，生成适配内网环境的 Docker 部署方案。使用 /deploy-analyzer 或 /deploy-analyzer /path/to/project 调用。
user-invocable: true
---


# Deploy Analyzer — 项目部署分析器

系统化完成 **代码分析 → 调用链梳理 → 部署方案生成**，产出可直接执行的 Docker 部署计划。

## 与 deploy-ops 的关系

deploy-analyzer 是 `/deploy-ops` P2 阶段的子流程，也可通过 `/deploy-analyzer` 单独调用。

## 分析策略

**核心原则：质量优先，层层递进，确保理解完整。**

1. **由浅入深** — 先扫描目录建立全局视图，再逐层深入读取关键文件，最后对疑点全量读取
2. **并行搜索** — 同一 Phase 内的多个 Grep/Glob 必须并行调用
3. **Grep 定位 + Read 确认** — Grep 快速定位，再 Read 命中文件的相关段落理解上下文
4. **排除无关目录** — node_modules/、dist/、build/、.git/、vendor/、__pycache__/
5. **不确定就多读** — 对某个模块/配置有疑问时，宁可多读几个文件也不要猜
6. **大文件分段** — 超过 300 行的文件分 2~3 段读取，避免单次输出过大
7. **全程串行** — 本分析不使用并行子 Agent，Phase 逐个执行

## 分析流程

### Phase 1: 项目结构扫描

1. 扫描项目根目录结构，识别：构建系统类型、语言及版本、多模块结构、现有 Docker 文件
2. 并行读取关键文件（README、构建配置文件、CI/CD 配置、现有 Docker 文件），构建配置和 Docker 文件必须全量读取
3. 写入 `.deploy-ops/deploy-analysis/01-structure.md`，包含：基本信息（项目名/语言/构建系统/模块划分）、关键目录树（每目录标注用途）、构建配置摘要表（配置文件/构建工具/关键配置）

### Phase 2: 依赖与调用链分析

1. **从 Phase 1 已全量读取的构建文件中直接提取依赖**：
   - package.json → dependencies/devDependencies
   - pom.xml → dependency 标签
   - requirements.txt / Pipfile / pyproject.toml → 依赖列表
   - go.mod → require 块
   - Gemfile / Cargo.toml / build.gradle(.kts) → 对应语法提取

2. **用 Grep 搜索源码中的额外依赖和外部服务**（不逐文件 Read）：
   - 外部服务关键词：redis|mysql|postgres|mongo|rabbitmq|kafka|elasticsearch|minio|nginx
   - 入口点：main(|app.run|listen|serve
   - 跨模块引用：项目内部模块的 import/require 路径

3. 对 Grep 命中的文件做针对性 Read，确保理解调用链上下文
4. 写入 `.deploy-ops/deploy-analysis/02-callchain.md`，包含：依赖关系表（依赖/版本/用途/是否必须）、核心调用链（ASCII 箭头图）、技术栈表（层/技术/版本要求）

### Phase 3: 硬编码值、环境变量、端口提取

**全部用 Grep 搜索，不要全量 Read 源码。**

1. **端口**: `\bport\s*[:=]\s*\d+|listen\(\s*\d+|\:\d{4,5}\/[a-zA-Z]|EXPOSE\s+\d+|0\.0\.0\.0:\d+`
2. **环境变量**: `process\.env|os\.environ|os\.Getenv|\$\{[A-Z_]+\}`
3. **硬编码 URL**: `https?://|ws://`
4. **硬编码 IP**: `\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}`
5. **密钥引用**: `API_KEY|SECRET|PASSWORD|TOKEN`
6. **配置文件**: Glob `**/*.{json,yaml,yml,toml,ini,conf,cfg,env}`

对 Grep 命中行，先记录文件:行号和内容。如需理解上下文再 Read 相关段落。

写入 `.deploy-ops/deploy-analysis/03-config.md`，包含 6 个子表格：端口（端口/服务/配置位置/是否可改）、环境变量（变量名/默认值/用途/文件位置）、硬编码 URL（URL/用途/文件:行号/部署时需改）、硬编码路径（路径/用途/文件:行号/Docker兼容性）、密钥引用（引用/类型/文件位置/处理建议）、关键配置文件（文件/用途/需修改项）

### Phase 4: 部署方案设计（构建分析 + Docker 方案）

1. **构建过程分析**：Read 构建脚本（Makefile / build.sh 等），提取构建命令链、构建依赖
2. **内网环境适配**：所有源替换为 nexus.yuwei.com
3. **容器铁律**：一个容器只跑一个服务，禁止 supervisord，多服务拆分为独立 Dockerfile + compose，服务间用 compose service name 通信（同 network 下直接用服务名访问）
4. **基础镜像选择**：**优先选择 Debian/Ubuntu 基础镜像**（如 python:3.11-slim、node:20-slim、maven:3.9-eclipse-temurin），避免 Alpine 镜像（apk 仓库不完善、glibc 兼容性问题多）。只有项目明确依赖 Alpine 时才使用
5. **多阶段构建**：能多阶段构建就多阶段构建（build 阶段 + runtime 阶段）
6. **Dockerfile 规范**：关键步骤加注释、内网源替换在最前、ARG 构建参数、ENV 运行时配置、非 root 用户。**HEALTHCHECK 只加在业务服务容器上，中间件容器（Redis/MySQL/Nginx 等）不加 HEALTHCHECK**。**nginx 配置中 upstream 直接用 compose service name，不使用 docker-entrypoint.d 脚本做环境变量替换**
6. **内网代理预写**：Dockerfile 中遇到包管理器时，直接写入以下代理配置，不要等构建失败再改：
   - **pip**:
     ```
     RUN pip config set global.index-url http://nexus.yuwei.com:8081/repository/pypi-proxy/simple && \
         pip config set global.trusted-host "nexus.yuwei.com"
     ```
   - **npm**: `RUN npm config set registry http://nexus.yuwei.com:8081/repository/npm-group/`
   - **Maven**: 在 Dockerfile 中写入 `settings.xml` 指向 `http://nexus.yuwei.com:8081/repository/maven-proxy/`
   - **Go**: `ENV GOPROXY=http://nexus.yuwei.com:8081/repository/go-proxy/,direct`
   - **Debian apt**（Suites 按基础镜像版本替换，如 bookworm/trixie）:
     ```
     RUN rm -f /etc/apt/sources.list.d/debian.sources && \
         cat > /etc/apt/sources.list.d/debian.sources <<'EOF'
     Types: deb
     URIs: http://nexus.yuwei.com:8081/repository/debian-proxy/
     Suites: trixie trixie-updates
     Components: main contrib non-free non-free-firmware
     Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg
     Enabled: true

     Types: deb
     URIs: http://nexus.yuwei.com:8081/repository/debian-security-proxy/
     Suites: trixie-security
     Components: main contrib non-free non-free-firmware
     Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg
     Enabled: true
     EOF
     ```
   - **Ubuntu apt**（Suites 按基础镜像版本替换，如 focal/jammy/noble）:
     ```
     RUN rm -f /etc/apt/sources.list.d/ubuntu.sources && \
         cat > /etc/apt/sources.list.d/ubuntu.sources <<'EOF'
     Types: deb
     URIs: http://nexus.yuwei.com:8081/repository/mirrors.aliyun.com.ubuntu/
     Suites: noble noble-updates noble-security noble-backports
     Components: main restricted universe multiverse
     Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
     EOF
     ```
   - **apk (Alpine)**: `RUN sed -i 's|http://dl-cdn.alpinelinux.org|http://nexus.yuwei.com:8081/repository/alpine-proxy|g' /etc/apk/repositories`
   - **基础镜像**: 从 `nexus.yuwei.com:8003/` 拉取，如 `FROM nexus.yuwei.com:8003/python:3.11-slim`
7. **docker build 和 compose 分离**：compose 只用 `image:` 指定镜像名（引用 .env 变量如 `${SERVER_IMAGE}`），不用 `build:` 指令。构建由手动 `docker build` 完成，compose 只负责启动服务

8. 写入 `.deploy-ops/deploy-analysis/04-deploy-plan.md`，包含：
   - 镜像选择表（服务/镜像/版本/来源，基础镜像优先 nexus.yuwei.com:8003）
   - ASCII 服务架构图（标注端口）
   - 端口映射表（容器端口/宿主机端口/服务/说明）
   - 环境变量清单（变量名/默认值/必须覆盖/说明）
   - 持久化卷表（容器路径/宿主机路径/用途）
   - 构建策略：多阶段构建说明 + 内网源替换具体命令（已写入 Dockerfile）
   - 健康检查设计表（业务服务/检查方式/命令/间隔/超时，中间件不加 HEALTHCHECK）
   - 构建命令表（服务/docker build 命令，逐条列出）

9. 基于方案编写部署文件到 `.deploy-ops/deploy/`：
   - `Dockerfile.<service>` — 多阶段构建，关键步骤有注释，内网代理已预写
   - `docker-compose.yml` — 服务编排，**只用 `image:` 指定镜像名（引用 .env 变量），不用 `build:`**，compose 负责启动服务，构建由手动 docker build 完成。必须定义自定义 network 并将所有服务加入，**所有可配置项（端口映射、镜像版本、卷路径等）必须用 `${VAR}` 引用 .env 变量，不在 compose 中写内联默认值（`${VAR:-default}`），默认值统一在 .env 中管理**，**持久化用 bind mount（宿主机目录映射），不用 named volume**，宿主机路径通过 .env 变量指定（如 `${DATA_DIR}/mysql:/var/lib/mysql`），业务服务加健康检查、中间件不加、卷配置
   - `.env.example` — 所有必需环境变量及默认值，和 compose 中的 `${VAR}` 一一对应

### Phase 5: 部署验证清单

逐项检查并写入 `.deploy-ops/deploy-analysis/05-checklist.md`，分四类：
- **配置完整性**：硬编码 URL 已替换、路径已适配 Docker、密钥已抽离为 env、端口无冲突
- **内网适配**：apt/yum 源已替换、npm/pip/go 源已替换、Docker 镜像已替换、无外网可构建
- **运行时保障**：每服务有健康检查、数据持久化已配置、日志到 stdout/stderr
- **文档完整性**：README.md 含架构/端口/env、.env.example 含所有必要变量

**P5 完成标志**：05-checklist.md 已生成，所有可检查项已标记

## 输出文件结构

```
.deploy-ops/deploy-analysis/
├── 01-structure.md
├── 02-callchain.md
├── 03-config.md
├── 04-deploy-plan.md
└── 05-checklist.md
```

## 内网环境配置

| 类型 | 代理地址 |
|------|---------|
| pip | http://nexus.yuwei.com:8081/repository/pypi-proxy/simple |
| npm | http://nexus.yuwei.com:8081/repository/npm-proxy/ |
| Maven | http://nexus.yuwei.com:8081/repository/maven-proxy/ |
| Debian apt | http://nexus.yuwei.com:8081/repository/debian-proxy/ (security: debian-security-proxy) |
| Ubuntu apt | http://nexus.yuwei.com:8081/repository/mirrors.aliyun.com.ubuntu/ |
| Docker 仓库 | nexus.yuwei.com:8003 |

## 注意事项

1. 不跳过任何 Phase — 每个 Phase 输出是下一个 Phase 的输入
2. 同一 Phase 内多个搜索必须并行执行
3. 所有硬编码值引用必须标注 `文件:行号`
4. 先分析后动手 — 完成全部 5 个 Phase 后再编写 Dockerfile
5. 内网优先 — 所有方案默认按无外网环境设计
6. 增量更新 — `.deploy-ops/deploy-analysis/` 已存在时先读取再决定更新