#!/usr/bin/env python3
"""Vault CLI - 知识库辅助工具
用法:
  python cli/cli_vault.py search "关键词"          搜索vault笔记(替代memory_search的嵌套读取链)
  python cli/cli_vault.py read   ref/ref-xxx.md     读取vault文件(直接输出内容,不嵌套存文件)
  python cli/cli_vault.py grep   ref/ref-xxx.md 关键词  定位行号
  python cli/cli_vault.py slice  ref/ref-xxx.md 起行 终行  精准提取行范围
  python cli/cli_vault.py deploy-check 服务名       一键采集部署参数
  python cli/cli_vault.py linkcheck                 扫描所有wikilink完整性(断链检测)
"""
import sys, os, json, subprocess, re

VAULT_DIR = os.environ.get("VAULT_DIR", "/root/.openocta/workspace/vault")

def search(keyword):
    """在vault目录中搜索关键词,输出匹配文件和行号"""
    results = []
    for root, dirs, files in os.walk(VAULT_DIR):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fn in files:
            if not fn.endswith(".md"): continue
            fpath = os.path.join(root, fn)
            relpath = os.path.relpath(fpath, VAULT_DIR)
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    lines = f.readlines()
            except: continue
            for i, line in enumerate(lines, 1):
                if keyword.lower() in line.lower():
                    results.append({"file": relpath, "line": i, "text": line.rstrip()})
    if not results:
        print(json.dumps({"hits": [], "note": f"未找到含{keyword}的内容"}, ensure_ascii=False))
        return
    hits = []
    for r in results[:30]:
        hits.append(r)
    out = {"hits": hits, "total": len(results), "showing": min(30, len(results))}
    print(json.dumps(out, ensure_ascii=False, indent=2))

def read(filepath):
    """读取vault文件,直接输出内容到stdout"""
    fullpath = os.path.join(VAULT_DIR, filepath)
    if not os.path.exists(fullpath):
        print(f"文件不存在: {fullpath}")
        sys.exit(1)
    with open(fullpath, "r", encoding="utf-8") as f:
        content = f.read()
    print(content)

def grep(filepath, keyword):
    """定位关键词在文件中的行号"""
    fullpath = os.path.join(VAULT_DIR, filepath)
    if not os.path.exists(fullpath):
        print(f"文件不存在: {fullpath}")
        sys.exit(1)
    with open(fullpath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    matches = []
    for i, line in enumerate(lines, 1):
        if keyword.lower() in line.lower():
            matches.append({"line": i, "text": line.rstrip()})
    print(json.dumps(matches, ensure_ascii=False, indent=2))

def slice(filepath, start, end):
    """精准提取文件行范围"""
    fullpath = os.path.join(VAULT_DIR, filepath)
    if not os.path.exists(fullpath):
        print(f"文件不存在: {fullpath}")
        sys.exit(1)
    with open(fullpath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    selected = lines[start-1:end]
    for line in selected:
        print(line, end="")

def deploy_check(service):
    """一键采集部署参数: 从注册表+yaml/集群 一次性输出"""
    reg_path = os.path.join(VAULT_DIR, "ref/ref-service-deploy-registry.md")
    with open(reg_path, "r", encoding="utf-8") as f:
        reg_content = f.read()
    info = {"service": service}
    # 从注册表提取服务行
    for line in reg_content.split("\n"):
        if service in line and "|" in line:
            parts = [p.strip().replace("**", "") for p in line.split("|")]
            if len(parts) >= 8:
                info["deploy_method"] = parts[3] if parts[4] else "unknown"
                info["yaml_or_values_path"] = parts[4] if parts[5] else "unknown"
                info["node"] = parts[5] if parts[6] else "unknown"
                info["current_tag"] = parts[7] if parts[7] else "unknown"
                break
    # 从yaml/values文件提取当前镜像
    if "yaml_or_values_path" in info and info["yaml_or_values_path"] != "unknown" and "→" not in info["yaml_or_values_path"]:
        fpath = info["yaml_or_values_path"]
        try:
            result = subprocess.run(["ssh", "172.17.3.180", f"grep image {fpath}"], capture_output=True, text=True, timeout=10)
            info["yaml_current_image"] = result.stdout.strip()
        except: info["yaml_current_image"] = "fetch_failed"
    else:
        info["yaml_current_image"] = "no_path"
    # 从集群提取当前镜像
    ns = "innies" if service != "deer-flow" else "deer-flow"
    if service in ["milvus","attu","vllm","xinference","infinity"]: ns = service
    try:
        result = subprocess.run(["kubectl", "get", "deploy", service, "-n", ns, "-o", "jsonpath={.spec.template.spec.containers[0].image}"], capture_output=True, text=True, timeout=10)
        info["cluster_current_image"] = result.stdout.strip()
    except: info["cluster_current_image"] = "fetch_failed"
    print(json.dumps(info, ensure_ascii=False, indent=2))

def linkcheck():
    """扫描所有.md文件中的[[wikilink]]，检查目标文件是否存在，输出JSON报告"""
    import re
    link_re = re.compile(r'\[\[([^\]|]+?)(?:\|[^\]]*)?\]\]')
    # 收集所有 .md 文件及其 basename -> relpath 映射
    all_files = []
    basename_map = {}  # filename -> relpath
    for root, dirs, files in os.walk(VAULT_DIR):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fn in files:
            if not fn.endswith(".md"): continue
            fpath = os.path.join(root, fn)
            relpath = os.path.relpath(fpath, VAULT_DIR)
            all_files.append(relpath)
            stem = fn[:-3]  # 去掉 .md
            if stem not in basename_map:
                basename_map[stem] = relpath
    # 逐文件扫描 wikilink
    broken = []
    total_links = 0
    total_files = 0
    for relpath in sorted(all_files):
        fpath = os.path.join(VAULT_DIR, relpath)
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except: continue
        file_has_links = False
        for i, line in enumerate(lines, 1):
            for m in link_re.finditer(line):
                target = m.group(1).strip()
                # 去掉 # 后面的锚点部分(Obsidian wikilink锚点语法)
                anchor = ""
                if "#" in target:
                    target, anchor = target.split("#", 1)
                    target = target.strip()
                # 跳过模板占位符(含 <xxx> 或 xxx-xxx-xxx 模式)
                if "<" in target or re.match(r'^[a-z]+-xxx', target):
                    continue
                total_links += 1
                file_has_links = True
                # 解析目标: 支持纯basename(无路径/无.md)和带路径的
                target_clean = target.replace(".md", "")
                found = False
                # 1. 精确匹配 basename (去.md)
                if target_clean in basename_map:
                    found = True
                # 2. 模糊匹配: basename 包含 target 或 target 包含 basename
                if not found:
                    for stem, rp in basename_map.items():
                        if target_clean == stem or target_clean == stem.replace("-quickref",""):
                            found = True
                            break
                # 3. 直接路径匹配
                if not found:
                    check_path = os.path.join(VAULT_DIR, target_clean + ".md")
                    if os.path.exists(check_path):
                        found = True
                    else:
                        check_path2 = os.path.join(VAULT_DIR, target_clean)
                        if os.path.exists(check_path2):
                            found = True
                if not found:
                    broken.append({
                        "source": relpath,
                        "line": i,
                        "target": target + ("#" + anchor if anchor else ""),
                        "text": line.rstrip()
                    })
        if file_has_links:
            total_files += 1
    report = {
        "summary": {
            "total_md_files": len(all_files),
            "files_with_links": total_files,
            "total_links": total_links,
            "broken_links": len(broken)
        },
        "broken": broken
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: cli_vault.py {search|read|grep|slice|deploy-check|linkcheck} 参数...")
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "search": search(sys.argv[2])
    elif cmd == "read": read(sys.argv[2])
    elif cmd == "grep":
        if len(sys.argv) < 4: print("需要文件路径和关键词"); sys.exit(1)
        grep(sys.argv[2], sys.argv[3])
    elif cmd == "slice":
        if len(sys.argv) < 5: print("需要文件路径、起行、终行"); sys.exit(1)
        slice(sys.argv[2], int(sys.argv[3]), int(sys.argv[4]))
    elif cmd == "deploy-check": deploy_check(sys.argv[2])
    elif cmd == "linkcheck": linkcheck()
    else: print(f"未知命令: {cmd}"); sys.exit(1)
