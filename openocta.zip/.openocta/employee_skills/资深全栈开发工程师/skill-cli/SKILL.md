---
displayName: skill-cli
name: skill-cli
description: Confluence 平台 Skill — Confluence 页面增删改查/搜索/评论/附件/版本/标签
---


# Confluence Skill

通过 CLI 工具调用 Confluence REST API。

## 硬性约束（违反必出错，每次执行前必检）

> 以下规则是过往踩坑的总结，违反会导致运行时错误或数据错误，**必须遵守**。

1. **`.docx` / `.pdf` 文件 → 必须用 `cli_document.py` 提取**，**禁止**在 Bash 中手写 `python -c` 或临时脚本调用 python-docx。`extract_docx` 一次调用同时返回文本结构 + 图片文件，无需额外步骤。详见核心原则第 6 条。
2. **AskUserQuestion 首次使用前必须预热**：`ToolSearch(query="select:AskUserQuestion")`，否则报 `questions is missing`。
3. **大段 HTML 禁止内联到命令行**：必须写 `./skill_temp.html` 再用 `@./skill_temp.html` 传入，shell 引号/换行问题无法修复。
4. **删除页面前必须二次确认**：执行 `delete` 命令前，必须用 AskUserQuestion 向用户确认（显示页面标题和 ID），用户明确同意后才可调用 delete。**禁止**未经确认直接删除页面。

## 核心原则

0. **AskUserQuestion 是 deferred tool，必须先预热再调用**：每次 skill 启动或新对话中首次使用前，先执行 `ToolSearch(query="select:AskUserQuestion")` 加载 schema，否则会报 `questions is missing`。
1. **收集参数必须用 AskUserQuestion**，每个 question 至少提供 **2 个 options**（SDK 强制要求），否则报 `too_small` 错误。
2. **Token 收集时** options 示例：`["输入 token", "我手动编辑配置文件"]`
3. **所有 HTML 内容（Confluence 创建/更新/评论）** 必须使用 Confluence Storage Format，`<p>` 包裹段落，宏必须放在 `<p>` 内。
4. **内容传参策略**：
   - **直接传参**：短文本（单行、<200字符、不含 `<table>`/`<ac:`/`<h1` 等 HTML 标签）直接用命令行参数传入：
     ```bash
     python cli/cli_confluence.py create DEV "标题" "<p>页面内容</p>"
     ```
   - **@文件模式**：**仅当**内容满足以下任一条件时，才先用 Write 写入 `./skill_temp.html`，再用 `@./skill_temp.html` 传入：
     - 多行文本或 >200 字符的段落
     - 包含 `<table>`、`<ac:structured-macro>`、`<h1>`~`<h6>` 等复杂 HTML 结构
     - 包含需要 `<![CDATA[...]]>` 的代码块宏
     - 来自 .docx/.pdf 提取后重新整理的大段内容
     
     CLI 读取后会自动清理 `skill_temp` 前缀的临时文件（P1-C），无需手动删除。
   
   **禁止**将大段 HTML 内联到 `bash -c` 或 `python -c` 中（shell 引号/换行问题会无法修复）。

5. **Windows 路径在 Bash 中必须用正斜杠**：`cli/cli_confluence.py`，不能写 `cli\cli_confluence.py`（反斜杠会被当作转义符）。
6. **.docx/.pdf 文件用 `cli_document.py` 提取文本**：`python cli/cli_document.py /path/to/file.docx`（首次使用自动安装 python-docx/PyPDF2 依赖）
   - **禁止手写 python-docx 代码**：不要在 Bash 中用 `python -c` 或临时脚本调用 python-docx，必须通过 `cli_document.py` 提取。`extract_docx` 已合并文本+图片提取，`structured[].images` 返回与磁盘文件一致的 hash 文件名，直接用于 `<ri:attachment ri:filename="...">`
   - **含图片的 .docx**：`extract_docx` 一次调用返回 `structured`（文本+图片文件名）+ `images_dir`（图片目录）+ `images`（图片列表），无需再单独调用 `confluence_docx_images`。流程：提取 → 按 `structured` 生成 HTML → `confluence_create` → 逐张 `confluence_upload` → 完成（图片引用已在 HTML 中内嵌，upload 后临时文件自动清理）
7. **临时文件统一写到当前工程目录**（如 `./skill_temp.html`），不要写 `/tmp/`，避免环境间路径映射不一致。
8. **编码问题已全局解决**：每个 CLI 脚本入口处强制设置 `sys.stdout/stderr` 为 utf-8（`io.TextIOWrapper` 重封装），不依赖外部环境变量，所有调用无需加 `-X utf8`。
9. **Confluence 创建/更新/查看操作完成后**，必须从返回的 `links` 字段中提取 `webui` 和 `tinyui`，向用户输出可点击的链接摘要：

```
文档标题：{title}
页面 ID：{id}
Web UI：{webui}
短链接：{tinyui}
```

## 首次使用 — Token 配置

首次调用时若 token 未配置，用 AskUserQuestion 收集。收到 token 后调用 `python cli/cli_confluence.py` 的 setup 函数保存。

## 操作选择

当用户没有明确指定操作时，用 AskUserQuestion 展示操作选项。

**Confluence 操作**：查看/搜索 / 创建 / 更新/删除/追加 / 评论/附件/版本/标签 / 连通测试/用户信息 / docx图片提取

## 调用方式

所有操作通过 **Bash** 调用 CLI 完成：

```bash
python cli/cli_confluence.py view 123456
python cli/cli_confluence.py append 123456 "<p>内容</p>" "h2:标题文本"
python cli/cli_confluence.py update 123456 _ "@./skill_temp.html"
python cli/cli_document.py /path/to/file.docx
```

## append 定位插入

`append` 命令支持 `after` 参数，可在指定 heading 后面插入内容而非末尾追加：
- 格式：`"h2:标题文本"` — 在指定级别的 h2 标题后插入
- 格式：`"heading:标题文本"` — 在任意级别（h1~h6）标题后插入
- 不传 after 时保持原有末尾追加行为
- heading 不存在时自动 fallback 到末尾追加（stderr 有提示）

```bash
# 在 h2 "Jumpserver部署文档" 后插入图片
python cli/cli_confluence.py append 123456 "<ac:image>...</ac:image>" "h2:Jumpserver部署文档"
```

## update title 默认值

`update` 命令的 `title` 参数默认为 `_`（不修改标题），只需传 page_id 和 body：
```bash
# 只更新正文，title 自动补 "_"
python cli/cli_confluence.py update 123456 "@./skill_temp.html"
# 仍可显式传 3 参数（不破坏旧用法）
python cli/cli_confluence.py update 123456 "新标题" "@./skill_temp.html"
```

## Reference 文件索引

详细的交互流程和 AskUserQuestion 模板见以下文件：

### Confluence references/
| 文件 | 说明 |
|------|------|
| [confluence-view.md](references/confluence-view.md) | 查看/搜索页面 |
| [confluence-create.md](references/confluence-create.md) | 创建页面 |
| [confluence-update.md](references/confluence-update.md) | 更新/删除页面 |
| [confluence-comments.md](references/confluence-comments.md) | 评论管理 |
| [confluence-attachments.md](references/confluence-attachments.md) | 附件/版本/标签/空间 |

## 文件结构

```
skill-cli/
├── SKILL.md              ← Skill 入口描述
├── skill_confluence.py   ← Confluence 函数层
├── cli/
│   ├── cli_confluence.py ← Confluence CLI 层（子进程）
│   ├── cli_document.py   ← 文档文本提取（docx/pdf）+ docx图片提取
│   └── token_store.py    ← Token 存储
└── references/           ← 详细交互模板（按需加载）
```