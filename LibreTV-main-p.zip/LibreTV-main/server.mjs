import path from 'path';
import express from 'express';
import axios from 'axios';
import cors from 'cors';
import { fileURLToPath } from 'url';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const config = {
  port: process.env.PORT || 8080,
  password: process.env.PASSWORD || '',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  timeout: parseInt(process.env.REQUEST_TIMEOUT || '5000'),
  maxRetries: parseInt(process.env.MAX_RETRIES || '2'),
  cacheMaxAge: process.env.CACHE_MAX_AGE || '1d',
  // API 缓存配置：内存缓存，默认10分钟过期，最大500条
  apiCacheTTL: parseInt(process.env.API_CACHE_TTL || '600000'),   // 毫秒，默认10分钟
  apiCacheMaxSize: parseInt(process.env.API_CACHE_MAX_SIZE || '500'),
  userAgent: process.env.USER_AGENT || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
  debug: process.env.DEBUG === 'true'
};

// ========== 内存缓存系统 ==========
const apiCache = new Map();

function setCache(key, data, statusCode) {
  // 如果缓存满了，删除最旧的1/4条目
  if (apiCache.size >= config.apiCacheMaxSize) {
    const keys = [...apiCache.keys()];
    const deleteCount = Math.ceil(keys.length / 4);
    for (let i = 0; i < deleteCount; i++) {
      apiCache.delete(keys[i]);
    }
  }
  apiCache.set(key, {
    data,
    statusCode,
    timestamp: Date.now(),
    ttl: config.apiCacheTTL,
  });
}

function getCache(key) {
  const entry = apiCache.get(key);
  if (!entry) return null;
  // 检查是否过期
  if (Date.now() - entry.timestamp > entry.ttl) {
    apiCache.delete(key);
    return null;
  }
  return entry;
}

function clearCache() {
  apiCache.clear();
}

function getCacheStats() {
  let expiredCount = 0;
  const now = Date.now();
  for (const [, entry] of apiCache) {
    if (now - entry.timestamp > entry.ttl) expiredCount++;
  }
  return {
    total: apiCache.size,
    active: apiCache.size - expiredCount,
    expired: expiredCount,
    maxSize: config.apiCacheMaxSize,
    ttlMs: config.apiCacheTTL,
    ttlDesc: `${config.apiCacheTTL / 1000}s`,
  };
}

const log = (...args) => {
  if (config.debug) {
    console.log('[DEBUG]', ...args);
  }
};

// ========== IP滑动窗口速率限制 ==========
const rateLimitWindowMs = 60 * 1000; // 1分钟窗口
const rateLimitMaxRequests = 60;      // 每窗口最大请求数
const rateLimitMap = new Map();        // IP -> { timestamps: [] }

function getClientIp(req) {
  // 优先从代理头获取真实IP
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
         req.headers['x-real-ip'] ||
         req.connection?.remoteAddress ||
         req.ip ||
         'unknown';
}

function rateLimiter(req, res, next) {
  const ip = getClientIp(req);
  const now = Date.now();

  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, { timestamps: [now] });
    return next();
  }

  const record = rateLimitMap.get(ip);
  // 清除窗口外的旧记录
  record.timestamps = record.timestamps.filter(t => now - t < rateLimitWindowMs);

  if (record.timestamps.length >= rateLimitMaxRequests) {
    res.setHeader('Retry-After', Math.ceil(rateLimitWindowMs / 1000));
    return res.status(429).json({
      success: false,
      error: '请求过于频繁，请稍后再试',
      retryAfter: Math.ceil(rateLimitWindowMs / 1000)
    });
  }

  record.timestamps.push(now);
  next();
}

// 定期清理过期的IP记录（每5分钟）
setInterval(() => {
  const now = Date.now();
  for (const [ip, record] of rateLimitMap) {
    record.timestamps = record.timestamps.filter(t => now - t < rateLimitWindowMs);
    if (record.timestamps.length === 0) {
      rateLimitMap.delete(ip);
    }
  }
}, 5 * 60 * 1000);

const app = express();

app.use(cors({
  origin: config.corsOrigin,
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

function sha256Hash(input) {
  return new Promise((resolve) => {
    const hash = crypto.createHash('sha256');
    hash.update(input);
    resolve(hash.digest('hex'));
  });
}

async function renderPage(filePath, password) {
  let content = fs.readFileSync(filePath, 'utf8');
  if (password !== '') {
    const sha256 = await sha256Hash(password);
    content = content.replace('{{PASSWORD}}', sha256);
  } else {
    content = content.replace('{{PASSWORD}}', '');
  }
  return content;
}

app.get(['/', '/index.html', '/player.html'], async (req, res) => {
  try {
    let filePath;
    switch (req.path) {
      case '/player.html':
        filePath = path.join(__dirname, 'player.html');
        break;
      default: // '/' 和 '/index.html'
        filePath = path.join(__dirname, 'index.html');
        break;
    }
    
    const content = await renderPage(filePath, config.password);
    res.send(content);
  } catch (error) {
    console.error('页面渲染错误:', error);
    res.status(500).send('读取静态页面失败');
  }
});

app.get('/s=:keyword', async (req, res) => {
  try {
    const filePath = path.join(__dirname, 'index.html');
    const content = await renderPage(filePath, config.password);
    res.send(content);
  } catch (error) {
    console.error('搜索页面渲染错误:', error);
    res.status(500).send('读取静态页面失败');
  }
});

function isValidUrl(urlString) {
  try {
    const parsed = new URL(urlString);
    const allowedProtocols = ['http:', 'https:'];
    
    // 从环境变量获取阻止的主机名列表
    const blockedHostnames = (process.env.BLOCKED_HOSTS || 'localhost,127.0.0.1,0.0.0.0,::1').split(',');
    
    // 从环境变量获取阻止的 IP 前缀
    const blockedPrefixes = (process.env.BLOCKED_IP_PREFIXES || '192.168.,10.,172.').split(',');
    
    if (!allowedProtocols.includes(parsed.protocol)) return false;
    if (blockedHostnames.includes(parsed.hostname)) return false;
    
    for (const prefix of blockedPrefixes) {
      if (parsed.hostname.startsWith(prefix)) return false;
    }
    
    return true;
  } catch {
    return false;
  }
}

// 验证代理请求的鉴权
function validateProxyAuth(req) {
  const authHash = req.query.auth;
  const timestamp = req.query.t;
  
  // 获取服务器端密码哈希
  const serverPassword = config.password;
  if (!serverPassword) {
    console.error('服务器未设置 PASSWORD 环境变量，代理访问被拒绝');
    return false;
  }
  
  // 使用 crypto 模块计算 SHA-256 哈希
  const serverPasswordHash = crypto.createHash('sha256').update(serverPassword).digest('hex');
  
  if (!authHash || authHash !== serverPasswordHash) {
    console.warn('代理请求鉴权失败：密码哈希不匹配');
    console.warn(`期望: ${serverPasswordHash}, 收到: ${authHash}`);
    return false;
  }
  
  // 验证时间戳（10分钟有效期）
  if (timestamp) {
    const now = Date.now();
    const maxAge = 10 * 60 * 1000; // 10分钟
    if (now - parseInt(timestamp) > maxAge) {
      console.warn('代理请求鉴权失败：时间戳过期');
      return false;
    }
  }
  
  return true;
}

app.get('/proxy/:encodedUrl', rateLimiter, async (req, res) => {
  try {
    // 验证鉴权
    if (!validateProxyAuth(req)) {
      return res.status(401).json({
        success: false,
        error: '代理访问未授权：请检查密码配置或鉴权参数'
      });
    }

    const encodedUrl = req.params.encodedUrl;
    const targetUrl = decodeURIComponent(encodedUrl);

    // 安全验证
    if (!isValidUrl(targetUrl)) {
      return res.status(400).send('无效的 URL');
    }

    // 检查内存缓存（仅缓存 API JSON 请求）
    const cacheKey = 'proxy:' + targetUrl;
    const cached = getCache(cacheKey);
    if (cached) {
      log(`缓存命中: ${targetUrl}`);
      res.setHeader('X-Cache', 'HIT');
      res.setHeader('Content-Type', 'application/json');
      return res.status(cached.statusCode).send(cached.data);
    }

    log(`代理请求: ${targetUrl}`);

    // 添加请求超时和重试逻辑
    const maxRetries = config.maxRetries;
    let retries = 0;

    const makeRequest = async () => {
      try {
        return await axios({
          method: 'get',
          url: targetUrl,
          responseType: 'stream',
          timeout: config.timeout,
          headers: {
            'User-Agent': config.userAgent
          }
        });
      } catch (error) {
        // 4xx 错误（客户端错误）不重试，直接抛出
        if (error.response && error.response.status >= 400 && error.response.status < 500) {
          log(`客户端错误 ${error.response.status}，不重试: ${targetUrl}`);
          throw error;
        }
        // 超时、5xx、网络错误等可重试
        if (retries < maxRetries) {
          retries++;
          const reason = error.code === 'ECONNABORTED' ? '超时' :
                         error.response ? `服务端错误 ${error.response.status}` : '网络错误';
          log(`${reason}，重试请求 (${retries}/${maxRetries}): ${targetUrl}`);
          return makeRequest();
        }
        throw error;
      }
    };

    const response = await makeRequest();

    // 判断是否为可缓存的 API 请求（JSON 响应，且来自采集站 API）
    const contentType = response.headers['content-type'] || '';
    const isApiRequest = contentType.includes('application/json') ||
                         targetUrl.includes('/api.php/provide/vod') ||
                         targetUrl.includes('/vod/detail/id/');

    if (isApiRequest) {
      // 收集完整响应数据以缓存
      const chunks = [];
      response.data.on('data', chunk => chunks.push(chunk));
      response.data.on('end', () => {
        const body = Buffer.concat(chunks).toString('utf-8');
        // 仅缓存包含实际数据的成功响应（空结果不缓存）
        if (response.status === 200) {
          try {
            const json = JSON.parse(body);
            const hasResults = (Array.isArray(json.list) && json.list.length > 0) ||
                               (Array.isArray(json.episodes) && json.episodes.length > 0);
            if (hasResults) {
              setCache(cacheKey, body, response.status);
              log(`已缓存: ${targetUrl} (${body.length} bytes)`);
            } else {
              log(`跳过缓存(空结果): ${targetUrl}`);
            }
          } catch {
            // JSON 解析失败也不缓存
            log(`跳过缓存(非JSON): ${targetUrl}`);
          }
        }
      });

      // 转发响应头（过滤敏感头）
      const headers = { ...response.headers };
      const sensitiveHeaders = (
        process.env.FILTERED_HEADERS ||
        'content-security-policy,cookie,set-cookie,x-frame-options,access-control-allow-origin'
      ).split(',');

      sensitiveHeaders.forEach(header => delete headers[header]);
      res.set(headers);
      res.setHeader('X-Cache', 'MISS');

      // 管道传输响应流
      response.data.pipe(res);
    } else {
      // 非 API 请求（HTML、图片等）不缓存，直接管道传输
      const headers = { ...response.headers };
      const sensitiveHeaders = (
        process.env.FILTERED_HEADERS ||
        'content-security-policy,cookie,set-cookie,x-frame-options,access-control-allow-origin'
      ).split(',');

      sensitiveHeaders.forEach(header => delete headers[header]);
      res.set(headers);

      response.data.pipe(res);
    }
  } catch (error) {
    console.error('代理请求错误:', error.message);
    if (error.response) {
      res.status(error.response.status || 500);
      error.response.data.pipe(res);
    } else {
      res.status(500).send(`请求失败: ${error.message}`);
    }
  }
});

app.use(express.static(path.join(__dirname), {
  maxAge: config.cacheMaxAge
}));

// ========== 缓存管理接口 ==========
// 查看缓存状态
app.get('/api/cache/stats', (req, res) => {
  res.json(getCacheStats());
});

// 清除缓存
app.delete('/api/cache/clear', (req, res) => {
  const stats = getCacheStats();
  clearCache();
  res.json({ success: true, cleared: stats.total, message: `已清除 ${stats.total} 条缓存` });
});

app.use((err, req, res, next) => {
  console.error('服务器错误:', err);
  res.status(500).send('服务器内部错误');
});

app.use((req, res) => {
  res.status(404).send('页面未找到');
});

// 启动服务器
app.listen(config.port, () => {
  console.log(`服务器运行在 http://localhost:${config.port}`);
  console.log(`API缓存: 最大${config.apiCacheMaxSize}条, TTL ${config.apiCacheTTL / 1000}秒`);
  if (config.password !== '') {
    console.log('用户登录密码已设置');
  } else {
    console.log('警告: 未设置 PASSWORD 环境变量，用户将被要求设置密码');
  }
  if (config.debug) {
    console.log('调试模式已启用');
    console.log('配置:', { ...config, password: config.password ? '******' : '' });
  }
});
