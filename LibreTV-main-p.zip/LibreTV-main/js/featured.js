// ========== 自建热门推荐功能（替代豆瓣） ==========

let featuredCurrentCategory = 'movie';

// 推荐数据（静态，无需外部API）
const FEATURED_DATA = {
    categories: [
        { id: 'movie', name: '电影', icon: '🎬' },
        { id: 'tv', name: '电视剧', icon: '📺' },
        { id: 'anime', name: '动漫', icon: '🎌' },
        { id: 'variety', name: '综艺', icon: '🎤' }
    ],
    items: {
        movie: [
            { title: '镖人：风起大漠', cover: 'image/featured/movie_1.jpg', rating: '8.5', tag: '动作', year: '2025' },
            { title: '低智商犯罪', cover: 'image/featured/movie_2.jpg', rating: '7.8', tag: '喜剧', year: '2025' },
            { title: '寒战1994', cover: 'image/featured/movie_3.jpg', rating: '8.3', tag: '犯罪', year: '2025' },
            { title: '惊蛰无声', cover: 'image/featured/movie_4.jpg', rating: '8.3', tag: '谍战', year: '2025' },
            { title: '疯狂动物城2', cover: 'image/featured/movie_5.jpg', rating: '7.8', tag: '动画', year: '2025' },
            { title: '消失的人', cover: 'image/featured/movie_6.jpg', rating: '7.4', tag: '悬疑', year: '2025' },
            { title: '哪吒之魔童闹海', cover: 'image/featured/movie_7.jpg', rating: '8.5', tag: '国产', year: '2025' },
            { title: '流浪地球2', cover: 'image/featured/movie_8.jpg', rating: '8.3', tag: '科幻', year: '2023' }
        ],
        tv: [
            { title: '狂飙', cover: 'image/featured/tv_1.jpg', rating: '9.0', tag: '犯罪', year: '2023' },
            { title: '漫长的季节', cover: 'image/featured/tv_2.jpg', rating: '9.4', tag: '悬疑', year: '2023' },
            { title: '繁花', cover: 'image/featured/tv_3.jpg', rating: '8.7', tag: '剧情', year: '2024' },
            { title: '三体', cover: 'image/featured/tv_4.jpg', rating: '8.0', tag: '科幻', year: '2023' },
            { title: '庆余年2', cover: 'image/featured/tv_5.jpg', rating: '7.5', tag: '古装', year: '2024' },
            { title: '我的阿勒泰', cover: 'image/featured/tv_6.jpg', rating: '8.9', tag: '文艺', year: '2024' },
            { title: '开端', cover: 'image/featured/tv_7.jpg', rating: '7.8', tag: '悬疑', year: '2022' },
            { title: '人世间', cover: 'image/featured/tv_8.jpg', rating: '8.1', tag: '剧情', year: '2022' }
        ],
        anime: [
            { title: '葬送的芙莉莲', cover: 'image/featured/anime_1.jpg', rating: '9.3', tag: '奇幻', year: '2024' },
            { title: '进击的巨人 完结篇', cover: 'image/featured/anime_2.jpg', rating: '8.9', tag: '热血', year: '2023' },
            { title: '间谍过家家', cover: 'image/featured/anime_3.jpg', rating: '8.5', tag: '喜剧', year: '2023' },
            { title: '我推的孩子', cover: 'image/featured/anime_4.jpg', rating: '8.4', tag: '悬疑', year: '2023' },
            { title: '药屋少女的呢喃', cover: 'image/featured/anime_5.jpg', rating: '8.3', tag: '悬疑', year: '2024' },
            { title: '国王排名', cover: 'image/featured/anime_6.jpg', rating: '8.6', tag: '冒险', year: '2022' },
            { title: '咒术回战', cover: 'image/featured/anime_7.jpg', rating: '8.1', tag: '热血', year: '2023' },
            { title: '鬼灭之刃 柱训练篇', cover: 'image/featured/anime_8.jpg', rating: '7.8', tag: '热血', year: '2024' }
        ],
        variety: [
            { title: '哈哈哈哈哈第一季', cover: 'image/featured/variety_1.jpg', rating: '7.5', tag: '真人秀', year: '2020' },
            { title: '哈哈哈哈哈第二季', cover: 'image/featured/variety_2.jpg', rating: '7.3', tag: '真人秀', year: '2021' },
            { title: '哈哈哈哈哈第三季', cover: 'image/featured/variety_3.jpg', rating: '7.6', tag: '真人秀', year: '2022' },
            { title: '哈哈哈哈哈第四季', cover: 'image/featured/variety_4.jpg', rating: '7.8', tag: '真人秀', year: '2023' },
            { title: '哈哈哈哈哈第五季', cover: 'image/featured/variety_5.jpg', rating: '7.9', tag: '真人秀', year: '2024' },
            { title: '哈哈哈哈哈第六季', cover: 'image/featured/variety_6.jpg', rating: '8.0', tag: '真人秀', year: '2025' },
            { title: '歌手2024', cover: 'image/featured/variety_7.jpg', rating: '8.2', tag: '音乐', year: '2024' },
            { title: '明星大侦探', cover: 'image/featured/variety_8.jpg', rating: '8.5', tag: '推理', year: '2023' }
        ]
    },
    filters: {
        type: [
            { value: '', label: '全部类型' },
            { value: '1', label: '电影' },
            { value: '2', label: '电视剧' },
            { value: '3', label: '动漫' },
            { value: '4', label: '综艺' }
        ],
        year: [
            { value: '', label: '全部年份' },
            { value: '2025', label: '2025' },
            { value: '2024', label: '2024' },
            { value: '2023', label: '2023' },
            { value: '2022', label: '2022' },
            { value: '2021', label: '2021' },
            { value: 'older', label: '更早' }
        ],
        area: [
            { value: '', label: '全部地区' },
            { value: '大陆', label: '大陆' },
            { value: '香港', label: '香港' },
            { value: '台湾', label: '台湾' },
            { value: '日本', label: '日本' },
            { value: '韩国', label: '韩国' },
            { value: '美国', label: '美国' },
            { value: '英国', label: '英国' }
        ]
    }
};

// 初始化推荐区域
function initFeatured() {
    populateFilterDropdowns();
    renderFeaturedTabs();
    renderFeaturedContent(featuredCurrentCategory);
}

// 渲染分类标签
function renderFeaturedTabs() {
    const tabContainer = document.getElementById('featured-tabs');
    if (!tabContainer) return;

    tabContainer.innerHTML = '';
    FEATURED_DATA.categories.forEach(cat => {
        const btn = document.createElement('button');
        let btnClass = 'px-3 py-1.5 text-sm rounded-full font-medium transition-all duration-300 border ';
        if (cat.id === featuredCurrentCategory) {
            btnClass += 'bg-pink-600 text-white border-pink-600 shadow-md';
        } else {
            btnClass += 'bg-[#1a1a1a] text-gray-300 border-[#333] hover:border-white hover:text-white';
        }
        btn.className = btnClass;
        btn.textContent = cat.icon + ' ' + cat.name;
        btn.onclick = function () {
            if (featuredCurrentCategory !== cat.id) {
                featuredCurrentCategory = cat.id;
                renderFeaturedTabs();
                renderFeaturedContent(cat.id);
            }
        };
        tabContainer.appendChild(btn);
    });
}

// 渲染推荐卡片
function renderFeaturedContent(categoryId) {
    const container = document.getElementById('featured-results');
    if (!container) return;

    const items = FEATURED_DATA.items[categoryId] || [];
    if (items.length === 0) {
        container.innerHTML = '<div class="col-span-full text-center py-8 text-gray-500">暂无推荐内容</div>';
        return;
    }

    const fragment = document.createDocumentFragment();

    items.forEach(item => {
        const safeTitle = item.title
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');

        const card = document.createElement('div');
        card.className = 'bg-[#111] hover:bg-[#222] transition-all duration-300 rounded-lg overflow-hidden flex flex-col transform hover:scale-105 shadow-md hover:shadow-lg cursor-pointer';
        card.onclick = function () {
            fillAndSearch(item.title);
        };

        card.innerHTML = `
            <div class="relative w-full aspect-[2/3] overflow-hidden">
                <img src="${item.cover}" alt="${safeTitle}"
                    class="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                    onerror="this.onerror=null; this.src='image/nomedia.png'; this.classList.add('object-contain');"
                    loading="lazy">
                <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                <div class="absolute bottom-2 left-2 flex items-center gap-2">
                    <span class="bg-black/70 text-yellow-400 text-xs px-1.5 py-0.5 rounded">
                        ★ ${item.rating}
                    </span>
                    ${item.tag ? `<span class="bg-black/70 text-pink-400 text-xs px-1.5 py-0.5 rounded">${item.tag}</span>` : ''}
                </div>
                ${item.year ? `<span class="absolute top-2 right-2 bg-black/70 text-gray-300 text-xs px-1.5 py-0.5 rounded">${item.year}</span>` : ''}
            </div>
            <div class="p-2 text-center bg-[#111]">
                <span class="text-sm font-medium text-white truncate block hover:text-pink-400 transition" title="${safeTitle}">
                    ${safeTitle}
                </span>
            </div>
        `;

        fragment.appendChild(card);
    });

    container.innerHTML = '';
    container.appendChild(fragment);
}

// 更新推荐区域显示状态
function updateFeaturedVisibility() {
    const featuredArea = document.getElementById('featuredArea');
    if (!featuredArea) return;

    const isSearching = document.getElementById('resultsArea') &&
        !document.getElementById('resultsArea').classList.contains('hidden');

    if (!isSearching) {
        featuredArea.classList.remove('hidden');
    } else {
        featuredArea.classList.add('hidden');
    }
}

// ========== 分类筛选功能 ==========

// 获取当前筛选状态
function getFilterState() {
    return {
        type: document.getElementById('filter-type')?.value || '',
        year: document.getElementById('filter-year')?.value || '',
        area: document.getElementById('filter-area')?.value || '',
    };
}

// 执行分类筛选搜索
function filterSearch() {
    const filters = getFilterState();
    const searchInput = document.getElementById('searchInput');
    const query = searchInput ? searchInput.value.trim() : '';

    // 构建筛选参数，需要通过采集站API的分类接口
    // 采集站支持 ?ac=detail&t=类型ID&year=年份&area=地区
    if (!query && !filters.type && !filters.year && !filters.area) {
        showToast('请至少选择一个筛选条件', 'info');
        return;
    }

    if (selectedAPIs.length === 0) {
        showToast('请至少选择一个API源', 'warning');
        return;
    }

    // 使用分类搜索：如果没有关键词则用分类参数搜索
    performFilterSearch(query, filters);
}

// 分类筛选搜索实现
async function performFilterSearch(query, filters) {
    // 密码保护校验
    try {
        if (window.ensurePasswordProtection) {
            window.ensurePasswordProtection();
        }
    } catch (error) {
        console.warn('Password protection check failed:', error.message);
        return;
    }

    showLoading();

    // 显示搜索结果区域
    document.getElementById('searchArea').classList.remove('flex-1');
    document.getElementById('searchArea').classList.add('mb-8');
    document.getElementById('resultsArea').classList.remove('hidden');

    // 隐藏推荐区域
    const featuredArea = document.getElementById('featuredArea');
    if (featuredArea) featuredArea.classList.add('hidden');

    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '';
    lastSearchAllResults = null;

    let allResults = [];
    let completedSources = 0;
    const totalSources = selectedAPIs.length;

    const searchProgress = document.getElementById('searchProgress');
    const searchProgressText = document.getElementById('searchProgressText');
    if (searchProgress) searchProgress.classList.remove('hidden');
    if (searchProgressText) searchProgressText.textContent = `筛选中 0/${totalSources} 源...`;

    // 更新结果计数
    function updateResultCount() {
        const countEl = document.getElementById('searchResultsCount');
        if (countEl) countEl.textContent = allResults.length;
    }

    // 黄色内容过滤
    function applyYellowFilter(results) {
        const yellowFilterEnabled = localStorage.getItem('yellowFilterEnabled') === 'true';
        if (yellowFilterEnabled) {
            const banned = ['伦理片', '福利', '里番动漫', '门事件', '萝莉少女', '制服诱惑', '国产传媒', 'cosplay', '黑丝诱惑', '无码', '日本无码', '有码', '日本有码', 'SWAG', '网红主播', '色情片', '同性片', '福利视频', '福利片'];
            return results.filter(item => {
                const typeName = item.type_name || '';
                return !banned.some(keyword => typeName.includes(keyword));
            });
        }
        return results;
    }

    try {
        // 对每个选中的源执行分类搜索
        const searchPromises = selectedAPIs.map(apiId =>
            searchByFilter(apiId, query, filters).then(results => {
                completedSources++;
                if (searchProgressText) {
                    searchProgressText.textContent = completedSources < totalSources
                        ? `筛选中 ${completedSources}/${totalSources} 源...`
                        : '筛选完成';
                }

                if (Array.isArray(results) && results.length > 0) {
                    const filteredResults = applyYellowFilter(results);
                    allResults = allResults.concat(filteredResults);
                    // 增量渲染：只追加新增卡片
                    const newCardsHtml = filteredResults.map(item => window.renderResultCard ? renderResultCard(item) : '').join('');
                    resultsDiv.insertAdjacentHTML('beforeend', newCardsHtml);
                    lastSearchAllResults = allResults;
                    updateResultCount();
                    hideLoading();
                }

                if (completedSources === totalSources) {
                    if (allResults.length === 0) {
                        resultsDiv.innerHTML = `
                            <div class="col-span-full text-center py-16">
                                <svg class="mx-auto h-12 w-12 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                          d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                <h3 class="mt-2 text-lg font-medium text-gray-400">没有找到匹配的结果</h3>
                                <p class="mt-1 text-sm text-gray-500">请尝试其他筛选条件</p>
                            </div>`;
                    }
                    hideLoading();
                    if (searchProgress) setTimeout(() => searchProgress.classList.add('hidden'), 1500);
                }

                return results;
            }).catch(error => {
                completedSources++;
                console.warn(`API ${apiId} 筛选失败:`, error);
                if (completedSources === totalSources) {
                    hideLoading();
                    if (searchProgress) setTimeout(() => searchProgress.classList.add('hidden'), 1500);
                }
                return [];
            })
        );

        await Promise.all(searchPromises);
    } catch (error) {
        console.error('筛选搜索错误:', error);
        showToast('筛选搜索失败，请稍后重试', 'error');
        hideLoading();
    }
}

// 通过分类筛选搜索单个源
async function searchByFilter(apiId, query, filters) {
    let apiBaseUrl, apiName;

    if (apiId.startsWith('custom_')) {
        const customIndex = apiId.replace('custom_', '');
        const customApi = getCustomApiInfo(customIndex);
        if (!customApi) return [];
        apiBaseUrl = customApi.url;
        apiName = customApi.name;
    } else {
        if (!API_SITES[apiId]) return [];
        apiBaseUrl = API_SITES[apiId].api;
        apiName = API_SITES[apiId].name;
    }

    // 构建分类筛选URL
    // 采集站API支持: ?ac=detail&t=类型&year=年份&area=地区&wd=关键词
    let apiUrl = apiBaseUrl + '?ac=detail';
    if (filters.type) apiUrl += '&t=' + filters.type;
    if (filters.year) {
        if (filters.year === 'older') {
            // 更早年份不做年份过滤
        } else {
            apiUrl += '&year=' + filters.year;
        }
    }
    if (filters.area) apiUrl += '&area=' + encodeURIComponent(filters.area);
    if (query) apiUrl += '&wd=' + encodeURIComponent(query);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    try {
        const proxiedUrl = await window.ProxyAuth?.addAuthToProxyUrl
            ? await window.ProxyAuth.addAuthToProxyUrl(PROXY_URL + encodeURIComponent(apiUrl))
            : PROXY_URL + encodeURIComponent(apiUrl);

        const response = await fetch(proxiedUrl, {
            headers: API_CONFIG.search.headers,
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) return [];

        const data = await response.json();
        if (!data || !data.list || !Array.isArray(data.list) || data.list.length === 0) return [];

        return data.list.map(item => ({
            ...item,
            source_name: apiName,
            source_code: apiId,
            api_url: apiId.startsWith('custom_') ? getCustomApiInfo(apiId.replace('custom_', ''))?.url : undefined
        }));
    } catch (error) {
        console.warn(`API ${apiId} 分类筛选失败:`, error);
        return [];
    }
}

// 重置筛选条件
function resetFilters() {
    const typeSelect = document.getElementById('filter-type');
    const yearSelect = document.getElementById('filter-year');
    const areaSelect = document.getElementById('filter-area');
    if (typeSelect) typeSelect.value = '';
    if (yearSelect) yearSelect.value = '';
    if (areaSelect) areaSelect.value = '';
}

// 填充筛选下拉框
function populateFilterDropdowns() {
    const typeSelect = document.getElementById('filter-type');
    const yearSelect = document.getElementById('filter-year');
    const areaSelect = document.getElementById('filter-area');

    if (typeSelect) {
        FEATURED_DATA.filters.type.forEach(item => {
            const opt = document.createElement('option');
            opt.value = item.value;
            opt.textContent = item.label;
            typeSelect.appendChild(opt);
        });
    }
    if (yearSelect) {
        FEATURED_DATA.filters.year.forEach(item => {
            const opt = document.createElement('option');
            opt.value = item.value;
            opt.textContent = item.label;
            yearSelect.appendChild(opt);
        });
    }
    if (areaSelect) {
        FEATURED_DATA.filters.area.forEach(item => {
            const opt = document.createElement('option');
            opt.value = item.value;
            opt.textContent = item.label;
            areaSelect.appendChild(opt);
        });
    }
}

// 填充搜索框并搜索（推荐卡片点击用）
function fillAndSearch(title) {
    if (!title) return;

    const safeTitle = title
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');

    const input = document.getElementById('searchInput');
    if (input) {
        input.value = title;
        search();

        try {
            const encodedQuery = encodeURIComponent(title);
            window.history.pushState(
                { search: title },
                `搜索: ${title} - 大白鲨TV - WDD ~ RJY`,
                `/s=${encodedQuery}`
            );
            document.title = `搜索: ${title} - 大白鲨TV - WDD ~ RJY`;
        } catch (e) {
            console.error('更新浏览器历史失败:', e);
        }
    }
}

// 返回首页
function resetToHome() {
    resetSearchArea();
    updateFeaturedVisibility();
}

// DOM加载后初始化
document.addEventListener('DOMContentLoaded', initFeatured);
