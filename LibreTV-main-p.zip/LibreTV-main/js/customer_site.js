const CUSTOMER_SITES = {
    qiqi: {
        api: 'https://www.qiqidys.com/api.php/provide/vod',
        name: '七七资源',
    },
    hongniu: {
        api: 'http://hongniuzy2.com/api.php/provide/vod/from/hnm3u8',
        name: '紅牛資源',
    },
    liangzi: {
        api: 'http://cj.lziapi.com/api.php/provide/vod/from/lzm3u8',
        name: '量子資源',
    },
    kaifang: {
        api: 'http://vod-demo.onrender.com/pubdovod.php',
        name: '開放電影',
    },
    youzhi: {
        api: 'http://api.1080zyku.com/inc/api.php/provide/vod',
        name: '优质资源库',
    },
    sanshijiu: {
        api: 'http://39kan.com/api.php/provide/vod',
        name: '39影視',
    },
    tiantang: {
        api: 'http://vipmv.cc/api.php/provide/vod',
        name: '天堂资源',
    },
    lehuo: {
        api: 'http://lehootv.com/api.php/provide/vod',
        name: '乐活影视',
    },
    tangrenjie1: {
        api: 'http://tangrenjie.tv/api.php/provide/vod',
        name: '唐人街',
    },
    kudian1: {
        api: 'http://api.kuapi.cc/api.php/provide/vod',
        name: '酷点资源',
    },
    wolong1: {
        api: 'http://collect.wolongzyw.com/api.php/provide/vod',
        name: '卧龙资源',
    },
    kudian2: {
        api: 'http://kudian10.com/api.php/provide/vod',
        name: '酷点资源',
    },
    tangrenjie2: {
        api: 'http://tangrenjie.tv/api.php/provide/vod/at/xm',
        name: '唐人街',
    },
    senlin: {
        api: 'http://slapibf.com/api.php/provide/vod',
        name: '森林资源',
        adult: true,
    },
    yingku: {
        api: 'http://api.ykapi.net/api.php/provide/vod',
        name: '影库资源网',
    },
    kuache1: {
        api: 'http://caiji.kczyapi.com/api.php/provide/vod/from/kcm3u8',
        name: '快车资源',
    },
    tantan: {
        api: 'http://apittzy.com/api.php/provide/vod',
        name: '探探资源',
    },
    shandian1: {
        api: 'http://sdzyapi.com/api.php/provide/vod/from/sdm3u8',
        name: '閃電資源',
    },
    jinying: {
        api: 'http://jyzyapi.com/provide/vod/from/jinyingm3u8',
        name: '金鹰资源',
    },
    guangsu: {
        api: 'http://api.guangsuapi.com/api.php/provide/vod/from/gsm3u8',
        name: '光速资源',
    },
    aosika: {
        api: 'http://aosikazy.com/api.php/provide/vod',
        name: '奥斯卡资源网',
    },
    laoya: {
        api: 'http://api.apilyzy.com/api.php/provide/vod',
        name: '老鸭资源采集',
    },
    uku1: {
        api: 'http://api.ukuapi.com/api.php/provide/vod',
        name: 'U酷资源',
    },
    beidouxing: {
        api: 'http://m3u8.bdxzyapi.com/api.php/provide/vod',
        name: '北斗星资源',
    },
    yinghua1: {
        api: 'http://m3u8.apiyhzy.com/api.php/provide/vod',
        name: '樱花资源网',
    },
    shandian2: {
        api: 'http://sdzyapi.com/api.php/provide/vod',
        name: '闪电资源',
    },
    feisu1: {
        api: 'http://feisuzy.com/api.php/provide/vod',
        name: '飞速资源',
    },
    kuaibo: {
        api: 'http://www.kuaibozy.com/api.php/provide/vod',
        name: '快播资源',
    },
    baidu1: {
        api: 'http://api.apibdzy.com/api.php/provide/vod',
        name: '百度资源',
    },
    aidan: {
        api: 'http://lovedan.net/api.php/provide/vod',
        name: '艾旦影视',
    },
    piaohua1: {
        api: 'http://www.zzrhgg.com/api.php/provide/vod',
        name: '飘花电影',
    },
    wangmin: {
        api: 'http://prinevillesda.org/api.php/provide/vod',
        name: '网民电影',
    },
    siwa: {
        api: 'http://siwazyw.cc/api.php/provide/vod',
        name: '丝袜资源',
        adult: true,
    },
    tiankong: {
        api: 'http://m3u8.tiankongapi.com/api.php/provide/vod/from/tkm3u8',
        name: '天空資源',
    },
    haiwaikan1: {
        api: 'http://haiwaikan.com/api.php/provide/vod',
        name: '海外看資源',
    },
    haiwaikan2: {
        api: 'https://haiwaikan.com/api.php/provide/vod/',
        name: '海外看|点播',
    },
    sanliuling: {
        api: 'https://360zy.com/api.php/provide/vod/',
        name: '360|点播',
    },
    heimuer: {
        api: 'https://www.heimuer.tv/api.php/provide/vod',
        name: '黑木耳|点播',
    },
    heimuer2: {
        api: 'https://json.heimuer.tv/api.php/provide/vod',
        name: '黑木耳|JSON',
    },
    citong: {
        api: 'http://ys9.cttv.vip/api.php/provide/vod/',
        name: '刺桐|点播',
    },
    guanwang: {
        api: 'http://gwcms.cttv.vip/api.php/provide/vod/',
        name: '官网|点播',
    },
    yeyu: {
        api: 'https://yyff.540734621.xyz/api.php/provide/vod/',
        name: '业余|点播',
    },
    huaweiba: {
        api: 'https://hw8.live/api.php/provide/vod/',
        name: '华为吧|点播',
    },
    xiaohuangren: {
        api: 'https://iqyi.xiaohuangrentv.com/api.php/provide/vod/',
        name: '小黄人|点播',
    },
    niuniu: {
        api: 'https://api.niuniuzy.me/api.php/provide/vod/',
        name: '牛牛|点播',
    },
    yaya: {
        api: 'https://cj.yayazy.net/api.php/provide/vod/',
        name: '丫丫|点播',
    },
    uku2: {
        api: 'https://api.ukuapi.com/api.php/provide/vod/',
        name: 'U酷|点播',
    },
    haohua1: {
        api: 'https://hhzyapi.com/api.php/provide/vod',
        name: '豪华|点播',
    },
    jisu: {
        api: 'https://jszyapi.com/api.php/provide/vod',
        name: '极速|点播',
    },
    jisu2: {
        api: 'https://jszyapi.com/api.php/provide/vod/at/json',
        name: '极速|JSON',
    },
    sijiu: {
        api: 'https://49zyw.com/api.php/provide/vod/',
        name: '四九|点播',
    },
    suoni: {
        api: 'https://suoniapi.com/api.php/provide/vod/',
        name: '索尼|点播',
    },
    ikun: {
        api: 'https://ikunzyapi.com/api.php/provide/vod/',
        name: 'ikun|点播',
    },
    feifan: {
        api: 'http://cj.ffzyapi.com/api.php/provide/vod/',
        name: '非凡|点播',
    },
    liangzi2: {
        api: 'https://cj.lziapi.com/api.php/provide/vod/',
        name: '量子|点播',
    },
    liangzi3: {
        api: 'https://cj.lziapi.com/api.php/provide/vod/at/xml/',
        name: '量子|XML',
    },
    baofeng: {
        api: 'https://bfzyapi.com/api.php/provide/vod/',
        name: '暴风|点播',
    },
    hongniu2: {
        api: 'https://www.hongniuzy2.com/api.php/provide/vod/',
        name: '红牛|点播',
    },
    feisu2: {
        api: 'https://www.feisuzyapi.com/api.php/provide/vod/',
        name: '飞速|点播',
    },
    kuaiikan: {
        api: 'https://www.kuaikan-api.com/api.php/provide/vod/',
        name: '快看|点播',
    },
    kuaiikan2: {
        api: 'https://kuaikan-api.com/api.php/provide/vod/from/kuaikanyun',
        name: '快看|云播',
    },
    xiongzhang: {
        api: 'https://xzcjz.com/api.php/provide/vod/',
        name: '熊掌|点播',
    },
    kuache2: {
        api: 'https://caiji.kczyapi.com/api.php/provide/vod/from/kcm3u8/',
        name: '快车|点播',
    },
    shandian3: {
        api: 'http://sdzyapi.com/api.php/provide/vod/',
        name: '闪电|点播',
    },
    yinghua2: {
        api: 'https://m3u8.apiyhzy.com/api.php/provide/vod/',
        name: '樱花|点播',
    },
    wolong2: {
        api: 'https://collect.wolongzyw.com/api.php/provide/vod/',
        name: '卧龙|点播',
    },
    piaohua2: {
        api: 'http://www.ahjiuman.com/api.php/provide/vod/at/json',
        name: '飘花|点播',
    },
    tianyi: {
        api: 'https://www.911ysw.top/tianyi.php/provide/vod/',
        name: '天翼|点播',
    },
    huya: {
        api: 'https://www.huyaapi.com/api.php/provide/vod/',
        name: '虎牙|点播',
    },
    baidu2: {
        api: 'https://api.apibdzy.com/api.php/provide/vod/',
        name: '百度|点播',
    },
    piaoling: {
        api: 'https://p2100.net/api.php/provide/vod/',
        name: '飘零|点播',
    },
    wujin: {
        api: 'https://api.wujinapi.com/api.php/provide/vod/',
        name: '无尽|点播',
    },
    wujin2: {
        api: 'https://api.wujinapi.me/api.php/provide/vod/',
        name: '无尽|ME',
    },
    subo: {
        api: 'https://subocaiji.com/api.php/provide/vod/',
        name: '速博|点播',
    },
    modu: {
        api: 'https://caiji.moduapi.cc/api.php/provide/vod/',
        name: '魔都|点播',
    },
    zuida: {
        api: 'http://zuidazy.me/api.php/provide/vod/',
        name: '最大|点播',
    },
    qihu: {
        api: 'https://caiji.qhzyapi.com/api.php/provide/vod/',
        name: '奇虎|点播',
    },
    xinlang: {
        api: 'https://api.xinlangapi.com/xinlangapi.php/provide/vod/',
        name: '新浪|点播',
    },
    kuaiyun: {
        api: 'https://www.kuaiyunzy.com/api.php/provide/vod/',
        name: '快云|点播',
    },
    mdzy: {
        api: 'https://www.mdzyapi.com/api.php/provide/vod',
        name: '麦豆|点播',
    },
    okzy: {
        api: 'https://vs.okcdn100.top/api.php/provide/vod',
        name: 'OK|点播',
    },
    // ===== 以下为新添加的源（去重后） =====
    ff9: {
        api: 'https://www.ff9.top/api.php/provide/vod/',
        name: 'FF9|云播',
    },
    wanaoyi: {
        api: 'http://1.ahailove.cn:23456/cj/api.php/provide/vod/',
        name: '玩偶姨妹',
        adult: true,
    },
    xingan0: {
        api: 'http://27.54.236.201/api.php/provide/vod/',
        name: '新感觉|TV4K',
    },
    leshi: {
        api: 'https://leshizyapi.com/api.php/provide/vod/',
        name: '乐视资源',
    },
    zhisheng: {
        api: 'http://82.156.40.118:1234/api.php/provide/vod/',
        name: '至圣云',
    },
    xiangkan: {
        api: 'https://xkanzy10.com/api.php/provide/vod/',
        name: '享看资源',
    },
    sishier: {
        api: 'https://www.42.la/api.php/provide/vod/',
        name: '42资源',
    },
    ckzy: {
        api: 'https://ckzy.me/api.php/provide/vod/',
        name: 'CK资源',
    },
    bajie: {
        api: 'http://cj.bajiecaiji.com/inc/apijson_vod.php',
        name: '八戒资源',
    },
    ziyuan1080: {
        api: 'https://api.1080zyku.com/inc/api_mac10.php',
        name: '1080资源库',
    },
    yutu: {
        api: 'https://apiyutu.com/api.php/provide/vod/',
        name: '玉兔资源',
        adult: true,
    },
    laobao: {
        api: 'http://laobaozy.com/api.php/provide/vod/',
        name: '老鸨资源',
        adult: true,
    },
    jikun: {
        api: 'https://jkunzyapi.com/api.php/provide/vod/',
        name: '鸡坤资源',
        adult: true,
    },
    jumaosz: {
        api: 'https://to.to-long.com/api.php/provide/vod/',
        name: '橘猫资源',
        adult: true,
    },
    semao: {
        api: 'https://caiji.semaozy.net/inc/apijson_vod.php',
        name: '色猫资源',
        adult: true,
    },
    doudou: {
        api: 'https://tmav.art/api.php/provide/vod/',
        name: '天美AV',
        adult: true,
    },
    youyi: {
        api: 'https://a.uezy.pw/api.php/provide/vod/',
        name: '优异资源',
        adult: true,
    },
    yese: {
        api: 'https://www.yszy02.com/api.php/provide/vod/',
        name: '夜色资源',
        adult: true,
    },
    huadu: {
        api: 'https://hdys2.com/api.php/provide/vod/',
        name: '花都影视',
        adult: true,
    },
    langyou: {
        api: 'https://api.lyhapi.com/api.php/provide/vod/',
        name: '狼友会资源',
        adult: true,
    },
    yikan: {
        api: 'https://api.yikanapi.com/api.php/provide/vod/',
        name: '易看资源',
        adult: true,
    },
    huangguan: {
        api: 'https://hghhh.com/api.php/provide/vod/',
        name: '皇冠资源',
        adult: true,
    },
    jiuyima: {
        api: 'https://91md.me/api.php/provide/vod',
        name: '91麻豆',
        adult: true,
    },
    jiuyima2: {
        api: 'https://91md.me/api.php/provide/vod/from/mdm3u8/',
        name: '91麻豆|M3U8',
        adult: true,
    },
    shayu: {
        api: 'https://shayuapi.com/api.php/provide/vod/',
        name: '鲨鱼资源',
        adult: true,
    },
    kkxz: {
        api: 'https://kkzy.me/api.php/provide/vod/',
        name: 'KK写真',
        adult: true,
    },
    aivin: {
        api: 'http://lbapiby.com/api.php/provide/vod/at/json',
        name: 'AIvin',
        adult: true,
    },
    haose: {
        api: 'https://haosezyw.com/api.php/provide/vod/',
        name: '好色资源',
        adult: true,
    },
    zuise: {
        api: 'https://zszyw.top/api.php/provide/vod/',
        name: '最色资源',
        adult: true,
    },
    sesehu: {
        api: 'https://apisesehuzy.com/api.php/provide/vod/',
        name: '色色虎资源',
        adult: true,
    },
    huanggua: {
        api: 'https://www.zy018.com/api.php/provide/vod/',
        name: '黄瓜资源',
        adult: true,
    },
    madou: {
        api: 'http://www.madouse.la/api.php/provide/vod/',
        name: '麻豆视频',
        adult: true,
    },
    lajiao: {
        api: 'https://apilj.com/api.php/provide/vod/',
        name: '辣椒资源',
        adult: true,
    },
    tianmi: {
        api: 'https://timizy10.cc/api.php/provide/vod/',
        name: '甜蜜资源',
        adult: true,
    },
    naixx: {
        api: 'https://naixxzy.com/api.php/provide/vod/',
        name: '奶香香',
        adult: true,
    },
    jingpin: {
        api: 'https://www.jingpinx.com/api.php/provide/vod/',
        name: '精品资源',
        adult: true,
    },
    caoliu: {
        api: 'https://www.caoliuzyw.com/api.php/prodao/vod/',
        name: '草榴资源',
        adult: true,
    },
    laosb: {
        api: 'https://apilsbzy1.com/api.php/provide/vod/',
        name: '老色逼资源',
        adult: true,
    },
    fhapi: {
        api: 'http://fhapi9.com/api.php/provide/vod/',
        name: '番号资源',
        adult: true,
    },
    sexnguon: {
        api: 'https://api.sexnguon.com/api.php/provide/vod/',
        name: '色南国资源',
        adult: true,
    },
    didi: {
        api: 'https://api.ddapi.cc/api.php/provide/vod/',
        name: '滴滴资源',
        adult: true,
    },
    jiuyiv: {
        api: 'https://91av.cyou/api.php/provide/vod/',
        name: '91视频',
        adult: true,
    },
    sezy: {
        api: 'https://sezy.website/api.php/provide/vod/',
        name: '色资源',
        adult: true,
    },
    shileyuan: {
        api: 'https://xxavs.com/api.php/provide/vod/',
        name: '湿乐园',
        adult: true,
    },
    sewo: {
        api: 'https://sewozyapi.com/api.php/provide/vod/',
        name: '色窝资源',
        adult: true,
    },
    tiankong2: {
        api: 'https://api.tiankongapi.com/api.php/provide/vod/',
        name: '天空|云播',
    },
    feisu3: {
        api: 'https://www.feisuzyapi.com/api.php/provide/vod/',
        name: '飞速|HTTPS',
    },
    guangsu2: {
        api: 'https://api.guangsuapi.com/api.php/provide/vod/from/gsm3u8/',
        name: '光速|M3U8',
    },
    xinlang2: {
        api: 'http://api.xinlangapi.com/xinlangapi.php/provide/vod/',
        name: '新浪|HTTP',
    },
    // ===== 第三批新增源（去重后） =====
    rycjapi: {
        api: 'https://cj.rycjapi.com/api.php/provide/vod/',
        name: '融创资源',
    },
    ipmogai: {
        api: 'http://38.47.213.61:41271/mogai_api.php/v1.vod',
        name: 'MOGAI|IP源',
    },
    yetu: {
        api: 'http://xh1.xn--yetu07f.icu/api.php/provide/vod/',
        name: '野兔资源',
    },
    adminqt: {
        api: 'https://video.adminqt.cn/api.php/provide/vod/',
        name: 'AdminQT',
    },
    guangsu3: {
        api: 'https://api.guangsuapi.com/api.php/provide/vod/',
        name: '光速|基础',
    },
    nntv: {
        api: 'https://www.nntv.in/api.php/v1.vod',
        name: 'NN电视',
    },
    dyttzy: {
        api: 'http://caiji.dyttzyapi.com/api.php/provide/vod',
        name: '电影天堂资源',
    },
    ffzy: {
        api: 'http://ffzy.tv/api.php/provide/vod/',
        name: '非凡|FFZY',
    },
    suoni2: {
        api: 'https://suoniapi.com/api.php/provide/vod/at/xml/',
        name: '索尼|XML',
    },
    wolong3: {
        api: 'https://wolongzyw.com/api.php/provide/vod/?ac=list',
        name: '卧龙|列表',
    },
    jacloud: {
        api: 'http://154.219.117.232:9981/jacloudapi.php/provide/vod',
        name: 'JA云',
    },
    jinchan: {
        api: 'https://zy.jinchancaiji.com/api.php/provide/vod',
        name: '金蝉采集',
    },
    // ===== 第四批：别人测试验证过的源（去重后补充） =====
    tyyszy: {
        api: 'https://tyyszy.com/api.php/provide/vod',
        name: '天涯资源',
    },
    ffzy_api: {
        api: 'https://api.ffzyapi.com/api.php/provide/vod',
        name: '非凡影视',
    },
    z360zy: {
        api: 'https://360zyzz.com/api.php/provide/vod',
        name: '360资源',
    },
    mtzy: {
        api: 'https://caiji.maotaizy.cc/api.php/provide/vod',
        name: '茅台资源',
    },
    dbzy: {
        api: 'https://dbzy.tv/api.php/provide/vod',
        name: '豆瓣资源',
    },
    dbcj: {
        api: 'https://caiji.dbzy5.com/api.php/provide/vod',
        name: '豆瓣点播',
    },
    mzzy: {
        api: 'https://mozhuazy.com/api.php/provide/vod',
        name: '魔爪资源',
    },
    zdzy: {
        api: 'https://api.zuidapi.com/api.php/provide/vod',
        name: '最大资源',
    },
    wwcj: {
        api: 'https://wwzy.tv/api.php/provide/vod',
        name: '旺旺短剧',
    },
    wwzy: {
        api: 'https://api.wwzy.tv/api.php/provide/vod',
        name: '旺旺资源',
    },
    lzcj: {
        api: 'https://cj.lzcaiji.com/api.php/provide/vod',
        name: '量子点播',
    },
    ukucj: {
        api: 'https://api.ukuapi88.com/api.php/provide/vod',
        name: 'U酷点播',
    },
    z1080zy: {
        api: 'https://api.1080zyku.com/inc/apijson.php',
        name: '1080资源',
    },
    iqiyizy: {
        api: 'https://iqiyizyapi.com/api.php/provide/vod',
        name: '爱奇艺资源',
    },
    yzzy: {
        api: 'https://api.yzzy-api.com/inc/apijson.php',
        name: '优质资源',
    },
    myzy: {
        api: 'https://api.maoyanapi.top/api.php/provide/vod',
        name: '猫眼资源',
    },
    jyzy: {
        api: 'https://jinyingzy.com/api.php/provide/vod',
        name: '金鹰|HTTPS',
    },
    shzy: {
        api: 'https://zy.sh0o.cn/api.php/provide/vod',
        name: '山海资源',
    },
    wsyzy: {
        api: 'https://api.wsyzy.net/api.php/provide/vod',
        name: '无水印资源',
    },
};

// 调用全局方法合并
if (window.extendAPISites) {
    window.extendAPISites(CUSTOMER_SITES);
} else {
    console.error("错误：请先加载 config.js！");
}