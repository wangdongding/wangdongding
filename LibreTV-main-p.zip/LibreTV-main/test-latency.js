/**
 * LibreTV API 源延迟测试脚本
 *
 * 用法:
 *   node test-latency.js              # 测试所有源
 *   node test-latency.js --timeout 5  # 设置超时为5秒（默认3秒）
 *   node test-latency.js --top 20     # 只显示延迟最低的20个源
 *   node test-latency.js --adult      # 也测试成人源（默认跳过）
 *   node test-latency.js --filter 3   # 过滤掉延迟超过3秒的源，生成新的配置文件
 *
 * 输出:
 *   - 控制台显示每个源的延迟和状态
 *   - 使用 --filter 时会生成 customer_site_filtered.js
 */

import http from 'http';
import https from 'https';
import { URL } from 'url';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 解析命令行参数
const args = process.argv.slice(2);
const TIMEOUT = parseInt(args[args.indexOf('--timeout') + 1]) || 3;
const TOP_N = args.includes('--top') ? parseInt(args[args.indexOf('--top') + 1]) : 0;
const INCLUDE_ADULT = args.includes('--adult');
const FILTER_THRESHOLD = args.includes('--filter') ? parseFloat(args[args.indexOf('--filter') + 1]) : 0;

// 从 customer_site.js 提取源配置
function parseCustomerSites() {
    const filePath = path.join(__dirname, 'js', 'customer_site.js');
    const content = fs.readFileSync(filePath, 'utf-8');

    // 提取 CUSTOMER_SITES 对象内容
    const match = content.match(/const CUSTOMER_SITES\s*=\s*(\{[\s\S]*\})\s*;/);
    if (!match) {
        console.error('无法解析 customer_site.js');
        process.exit(1);
    }

    // 使用 Function 构造器安全解析
    try {
        const fn = new Function('return ' + match[1]);
        return fn();
    } catch (e) {
        console.error('解析源配置失败:', e.message);
        process.exit(1);
    }
}

// 测试单个 URL 的延迟
function testLatency(urlStr, timeout) {
    return new Promise((resolve) => {
        const start = Date.now();
        let url;
        try {
            url = new URL(urlStr);
        } catch {
            resolve({ latency: -1, status: 'URL无效', size: 0 });
            return;
        }

        const isHttps = url.protocol === 'https:';
        const lib = isHttps ? https : http;

        const options = {
            hostname: url.hostname,
            port: url.port || (isHttps ? 443 : 80),
            path: url.pathname + url.search,
            method: 'GET',
            timeout: timeout * 1000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json, text/plain, */*',
            },
        };

        // 对 HTTPS 跳过证书验证（部分源证书有问题）
        if (isHttps) {
            options.rejectUnauthorized = false;
        }

        const req = lib.request(options, (res) => {
            let size = 0;
            // 只读前 1KB 即可判断连通性
            res.on('data', (chunk) => {
                size += chunk.length;
                if (size > 1024) {
                    res.destroy();
                }
            });
            res.on('end', () => {
                const latency = Date.now() - start;
                resolve({
                    latency,
                    status: res.statusCode === 200 ? 'OK' : `HTTP ${res.statusCode}`,
                    size,
                });
            });
        });

        req.on('timeout', () => {
            req.destroy();
            resolve({ latency: -1, status: '超时', size: 0 });
        });

        req.on('error', (e) => {
            resolve({ latency: -1, status: e.code || e.message, size: 0 });
        });

        req.end();
    });
}

// 格式化延迟输出
function formatLatency(ms) {
    if (ms < 0) return '   FAIL';
    if (ms < 1000) return `${ms}ms`.padStart(7);
    return `${(ms / 1000).toFixed(2)}s`.padStart(7);
}

// 状态颜色标记
function statusIcon(latency) {
    if (latency < 0) return '✗';
    if (latency < 500) return '●';   // 绿 - 优秀
    if (latency < 1000) return '◉';  // 黄 - 一般
    if (latency < 2000) return '○';  // 橙 - 较慢
    return '◎';                       // 红 - 很慢
}

async function main() {
    const sites = parseCustomerSites();
    const keys = Object.keys(sites);

    console.log(`\n${'='.repeat(70)}`);
    console.log(`  LibreTV API 源延迟测试`);
    console.log(`  共 ${keys.length} 个源 | 超时: ${TIMEOUT}s | 成人源: ${INCLUDE_ADULT ? '包含' : '跳过'}`);
    console.log(`${'='.repeat(70)}\n`);

    // 过滤成人源
    const testKeys = INCLUDE_ADULT ? keys : keys.filter(k => !sites[k].adult);
    if (!INCLUDE_ADULT) {
        const adultCount = keys.length - testKeys.length;
        if (adultCount > 0) {
            console.log(`  (跳过 ${adultCount} 个成人源，使用 --adult 参数包含)\n`);
        }
    }

    // 并发测试（每批10个，避免过多并发）
    const BATCH_SIZE = 10;
    const results = [];

    for (let i = 0; i < testKeys.length; i += BATCH_SIZE) {
        const batch = testKeys.slice(i, i + BATCH_SIZE);
        const promises = batch.map(async (key) => {
            const site = sites[key];
            const result = await testLatency(site.api, TIMEOUT);
            return { key, name: site.name, api: site.api, adult: site.adult || false, ...result };
        });

        const batchResults = await Promise.all(promises);
        results.push(...batchResults);

        // 实时输出批次结果
        for (const r of batchResults) {
            const icon = statusIcon(r.latency);
            const lat = formatLatency(r.latency);
            const adultTag = r.adult ? ' [成人]' : '';
            console.log(`  ${icon} ${lat}  ${r.key.padEnd(16)} ${r.name}${adultTag}  (${r.status})`);
        }
    }

    // 排序：按延迟升序（失败的排最后）
    results.sort((a, b) => {
        if (a.latency < 0 && b.latency < 0) return 0;
        if (a.latency < 0) return 1;
        if (b.latency < 0) return -1;
        return a.latency - b.latency;
    });

    // 统计
    const success = results.filter(r => r.latency >= 0);
    const failed = results.filter(r => r.latency < 0);

    console.log(`\n${'='.repeat(70)}`);
    console.log(`  测试结果汇总`);
    console.log(`${'='.repeat(70)}\n`);
    console.log(`  成功: ${success.length}  失败: ${failed.length}  总计: ${results.length}`);
    if (success.length > 0) {
        const avgLatency = Math.round(success.reduce((s, r) => s + r.latency, 0) / success.length);
        const minLatency = success[0].latency;
        const maxLatency = success[success.length - 1].latency;
        console.log(`  平均延迟: ${avgLatency}ms | 最低: ${minLatency}ms | 最高: ${maxLatency}ms`);
    }

    // TOP N
    if (TOP_N > 0) {
        console.log(`\n  延迟最低的 ${TOP_N} 个源:\n`);
        const topResults = results.filter(r => r.latency >= 0).slice(0, TOP_N);
        for (const r of topResults) {
            console.log(`  ${formatLatency(r.latency)}  ${r.key.padEnd(16)} ${r.name}`);
        }
    }

    // 显示失败列表
    if (failed.length > 0) {
        console.log(`\n  失败的源:\n`);
        for (const r of failed) {
            console.log(`  ✗ FAIL  ${r.key.padEnd(16)} ${r.name}  (${r.status})`);
        }
    }

    // 生成过滤后的配置文件
    if (FILTER_THRESHOLD > 0) {
        const filtered = results.filter(r => r.latency >= 0 && r.latency <= FILTER_THRESHOLD * 1000);
        const filteredSites = {};
        for (const r of filtered) {
            filteredSites[r.key] = { api: r.api, name: r.name };
            if (r.adult) filteredSites[r.key].adult = true;
        }

        const outputPath = path.join(__dirname, 'js', 'customer_site_filtered.js');
        const output = `// 自动生成的过滤配置 - 延迟 <= ${FILTER_THRESHOLD}s\n// 生成时间: ${new Date().toLocaleString('zh-CN')}\n// 原始源数: ${results.length} | 过滤后: ${Object.keys(filteredSites).length}\n\nconst CUSTOMER_SITES = ${JSON.stringify(filteredSites, null, 4)};\n\n// 调用全局方法合并\nif (window.extendAPISites) {\n    window.extendAPISites(CUSTOMER_SITES);\n} else {\n    console.error("错误：请先加载 config.js！");\n}\n`;

        fs.writeFileSync(outputPath, output, 'utf-8');
        console.log(`\n  已生成过滤配置: js/customer_site_filtered.js`);
        console.log(`  保留 ${Object.keys(filteredSites).length} 个源 (延迟 <= ${FILTER_THRESHOLD}s)`);
        console.log(`  使用方法: 将 customer_site_filtered.js 重命名为 customer_site.js 替换原文件`);
    }

    console.log(`\n${'='.repeat(70)}\n`);
}

main().catch(console.error);
