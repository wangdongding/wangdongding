-- V42__drop_reviewed_by_fkey.sql
-- Remove foreign key constraint on reviewed_by columns.
-- reviewed_by can be "SYSTEM" for auto-approved reviews, which is not a real user_account row.

ALTER TABLE review_task DROP CONSTRAINT IF EXISTS review_task_reviewed_by_fkey;
ALTER TABLE promotion_request DROP CONSTRAINT IF EXISTS promotion_request_reviewed_by_fkey;
