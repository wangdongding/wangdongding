package com.iflytek.skillhub.auth.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * LDAP authentication configuration properties.
 *
 * Bound to {@code skillhub.auth.ldap.*} in application YAML / environment variables.
 */
@Component
@ConfigurationProperties(prefix = "skillhub.auth.ldap")
public class LdapAuthProperties {

    private boolean enabled = false;

    /** LDAP server URL, e.g. ldap://ldap.example.com:389 */
    private String url;

    /** Base DN for user searches, e.g. dc=example,dc=com */
    private String baseDn;

    /**
     * LDAP user DN pattern for bind authentication.
     * Use {0} as the username placeholder, e.g. uid={0},ou=users,dc=example,dc=com
     */
    private String userDnPattern;

    /**
     * LDAP search filter for locating users (alternative to userDnPattern).
     * Use {0} as the username placeholder, e.g. (uid={0})
     */
    private String searchFilter;

    /** Manager/bind DN for searches when anonymous bind is not allowed. */
    private String bindDn;

    /** Manager/bind password. */
    private String bindPassword;

    /** LDAP attribute that holds the user's email address. */
    private String emailAttribute = "mail";

    /** LDAP attribute that holds the user's display name. */
    private String displayNameAttribute = "cn";

    /** Initial status for auto-created LDAP users. Defaults to ACTIVE. */
    private String initialUserStatus = "ACTIVE";

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getBaseDn() { return baseDn; }
    public void setBaseDn(String baseDn) { this.baseDn = baseDn; }

    public String getUserDnPattern() { return userDnPattern; }
    public void setUserDnPattern(String userDnPattern) { this.userDnPattern = userDnPattern; }

    public String getSearchFilter() { return searchFilter; }
    public void setSearchFilter(String searchFilter) { this.searchFilter = searchFilter; }

    public String getBindDn() { return bindDn; }
    public void setBindDn(String bindDn) { this.bindDn = bindDn; }

    public String getBindPassword() { return bindPassword; }
    public void setBindPassword(String bindPassword) { this.bindPassword = bindPassword; }

    public String getEmailAttribute() { return emailAttribute; }
    public void setEmailAttribute(String emailAttribute) { this.emailAttribute = emailAttribute; }

    public String getDisplayNameAttribute() { return displayNameAttribute; }
    public void setDisplayNameAttribute(String displayNameAttribute) { this.displayNameAttribute = displayNameAttribute; }

    public String getInitialUserStatus() { return initialUserStatus; }
    public void setInitialUserStatus(String initialUserStatus) { this.initialUserStatus = initialUserStatus; }
}