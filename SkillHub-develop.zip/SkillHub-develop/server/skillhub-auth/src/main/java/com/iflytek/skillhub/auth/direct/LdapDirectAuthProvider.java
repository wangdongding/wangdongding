package com.iflytek.skillhub.auth.direct;

import com.iflytek.skillhub.auth.identity.IdentityBindingService;
import com.iflytek.skillhub.auth.rbac.PlatformPrincipal;
import com.iflytek.skillhub.auth.config.LdapAuthProperties;
import com.iflytek.skillhub.domain.user.UserStatus;
import org.springframework.ldap.core.ContextMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.stereotype.Component;

import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.Attributes;
import javax.naming.directory.Attribute;

/**
 * Direct-auth provider that authenticates users against an LDAP directory.
 *
 * On successful bind, a local {@code UserAccount} + {@code IdentityBinding} is created
 * via {@link IdentityBindingService#bindOrCreateForDirect} so the user is tracked in the
 * platform with roles, permissions, and ownership — but the password is never stored locally.
 */
@Component
public class LdapDirectAuthProvider implements DirectAuthProvider {

    private final LdapAuthProperties properties;
    private final IdentityBindingService identityBindingService;

    public LdapDirectAuthProvider(LdapAuthProperties properties,
                                  IdentityBindingService identityBindingService) {
        this.properties = properties;
        this.identityBindingService = identityBindingService;
    }

    @Override
    public String providerCode() {
        return "ldap";
    }

    @Override
    public String displayName() {
        return "LDAP";
    }

    @Override
    public PlatformPrincipal authenticate(DirectAuthRequest request) {
        if (!properties.isEnabled()) {
            throw new IllegalStateException("LDAP authentication is not enabled");
        }

        String username = request.username();
        String password = request.password();

        // Build the user DN for bind authentication
        String userDn = buildUserDn(username);

        // Authenticate by binding with the user's own credentials
        LdapContextSource contextSource = buildContextSource();
        try {
            DirContext ctx = contextSource.getContext(userDn, password);
            // Bind succeeded — user is authenticated
            ctx.close();
        } catch (Exception e) {
            throw new com.iflytek.skillhub.auth.exception.AuthFlowException(
                org.springframework.http.HttpStatus.UNAUTHORIZED,
                "error.auth.ldap.invalidCredentials"
            );
        }

        // Lookup user attributes (email, display name) using a manager/service account
        String email = null;
        String displayName = username;
        String subject = username;

        if (properties.getSearchFilter() != null || properties.getBindDn() != null) {
            LdapTemplate ldapTemplate = new LdapTemplate(contextSource);
            try {
                String filter = properties.getSearchFilter() != null
                    ? properties.getSearchFilter().replace("{0}", username)
                    : "(uid=" + username + ")";

                var attrs = ldapTemplate.searchForObject(
                    properties.getBaseDn() != null ? properties.getBaseDn() : "",
                    filter,
                    (ContextMapper<java.util.HashMap<String, String>>) ctx1 -> {
                        var result = new java.util.HashMap<String, String>();
                        DirContextAdapter adapter = (DirContextAdapter) ctx1;
                        Attributes atts = adapter.getAttributes();
                        Attribute emailAttr = atts.get(properties.getEmailAttribute());
                        if (emailAttr != null) {
                            result.put("email", emailAttr.get().toString());
                        }
                        Attribute displayNameAttr = atts.get(properties.getDisplayNameAttribute());
                        if (displayNameAttr != null) {
                            result.put("displayName", displayNameAttr.get().toString());
                        }
                        Attribute dnAttr = atts.get("distinguishedName");
                        if (dnAttr != null) {
                            result.put("dn", dnAttr.get().toString());
                        }
                        return result;
                    }
                );

                if (attrs.get("email") != null) email = attrs.get("email");
                if (attrs.get("displayName") != null) displayName = attrs.get("displayName");
                if (attrs.get("dn") != null) subject = attrs.get("dn");
            } catch (Exception ignored) {
                // Attribute lookup is optional; fall back to username-based defaults
            }
        }

        UserStatus initialStatus = UserStatus.valueOf(properties.getInitialUserStatus());
        return identityBindingService.bindOrCreateForDirect(
            providerCode(), subject, username, email, displayName, initialStatus
        );
    }

    private String buildUserDn(String username) {
        if (properties.getUserDnPattern() != null) {
            return properties.getUserDnPattern().replace("{0}", username);
        }
        // Fallback: uid=username,baseDn
        return "uid=" + username + "," + properties.getBaseDn();
    }

    private LdapContextSource buildContextSource() {
        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(properties.getUrl());
        if (properties.getBindDn() != null) {
            contextSource.setUserDn(properties.getBindDn());
            contextSource.setPassword(properties.getBindPassword());
        }
        contextSource.afterPropertiesSet();
        return contextSource;
    }
}
