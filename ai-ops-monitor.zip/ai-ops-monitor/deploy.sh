#!/usr/bin/env bash
# =====================================================================
# AI-Ops 监控体系 - 一键部署脚本
#
# 架构: Netdata(主机实时采集+Web看板) + Prometheus(补充指标+告警)
#        + Alertmanager(告警路由) + Grafana(统一看板+日志)
#
# 前置: 镜像已上传到镜像仓库, 服务器可拉取
# =====================================================================
set -euo pipefail

# ---------- 变量 ----------
DEPLOY_DIR="/data/ai-ops-monitor"

# ---------- 颜色 ----------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err()  { echo -e "${RED}[ERR ]${NC}  $*"; exit 1; }

# ---------- 前置检查 ----------
[[ $EUID -ne 0 ]] && err "请使用 root 用户执行"
command -v docker >/dev/null 2>&1 || err "未安装 docker"
command -v docker compose >/dev/null 2>&1 || err "未安装 docker compose 插件"

# ---------- 创建目录 ----------
log "创建部署目录 ${DEPLOY_DIR}"
mkdir -p "${DEPLOY_DIR}"/{prometheus/alerts,alertmanager/templates,loki,promtail,grafana/provisioning/{datasources,dashboards},blackbox,postgres-exporter,netdata/health.d}

# ---------- 拷贝配置 ----------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
log "从 ${SCRIPT_DIR} 拷贝配置文件"
cp -r "${SCRIPT_DIR}"/* "${DEPLOY_DIR}/" 2>/dev/null || true
chmod -R 0644 "${DEPLOY_DIR}"

# ---------- 检查 .env ----------
if [[ ! -f "${DEPLOY_DIR}/.env" ]]; then
    err "未找到 .env 文件, 请先从 .env.example 复制并修改: cp .env.example .env"
fi

# 检查是否还是默认密码
if grep -q "Grafana_Admin_ChangeMe" "${DEPLOY_DIR}/.env" 2>/dev/null; then
    warn ".env 中仍使用默认密码, 请修改后再部署!"
    warn "运行: vi ${DEPLOY_DIR}/.env"
    exit 1
fi

# ---------- 拉取镜像 ----------
log "从镜像仓库拉取最新镜像"
cd "${DEPLOY_DIR}"
docker compose --env-file .env pull

# ---------- 启动服务 ----------
log "启动监控服务"
docker compose --env-file .env up -d

# ---------- 等待就绪 ----------
log "等待服务就绪..."
sleep 10

# ---------- 状态检查 ----------
log "服务状态:"
docker compose --env-file .env ps

# ---------- 输出访问信息 ----------
HOST_IP=$(hostname -I | awk '{print $1}')
source "${DEPLOY_DIR}/.env"
cat <<EOF

${GREEN}========================================${NC}
${GREEN} AI-Ops 监控体系部署完成${NC}
${GREEN}========================================${NC}

访问地址:
  Prometheus:    http://${HOST_IP}:9090
  Alertmanager: http://${HOST_IP}:9093
  Grafana:      http://${HOST_IP}:3000  (${GF_ADMIN_USER:-admin} / ***)
  Netdata:      http://${HOST_IP}:19999  (主机实时看板, 无需登录)
  Loki:         http://${HOST_IP}:3100
  Pushgateway:  http://${HOST_IP}:9091

架构说明:
  主机指标: Netdata 采集 (:19999 Web 看板 + Prometheus 拉取)
  补充指标: Blackbox(HTTP/TCP/ICMP 探测) + PostgreSQL + Pushgateway
  告警路由: Prometheus 评估 → Alertmanager 分发
  日志查看: Grafana + Loki/Promtail
  看板入口: Netdata(主机秒级) + Grafana(统一日志/PG/探测)

下一步:
  1. 在 Grafana 中导入 Dashboard JSON (推荐 ID: 11074/13639/15983)
  2. 修改 netdata/health_alarm_notify.conf 配置通知渠道 (Webhook/邮件/钉钉)
  3. 配置 alertmanager/alertmanager.yml 中的 webhook 接收端
  4. 调整 prometheus/prometheus.yml 中的 blackbox 探测目标

EOF
