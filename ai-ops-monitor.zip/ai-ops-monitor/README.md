# AI-Ops 监控告警体系

一套基于 **Netdata + Prometheus + Loki + Grafana** 的生产级监控告警体系，包含主机指标采集、日志收集、服务探测、数据库监控与告警分发。

## 架构

```
┌───────────────────────────────────────────────────────────────────┐
│                       可视化入口                                   │
│  ┌──────────────────┐    ┌─────────────────────────────────────┐  │
│  │  Netdata Web      │    │  Grafana                           │  │
│  │  :19999 (主机秒级) │    │  :3000 (统一看板/日志/PG/探测)     │  │
│  └────────┬──────────┘    └──────────────┬──────────────────────┘  │
└───────────┼──────────────────────────────┼─────────────────────────┘
            │                              │
┌───────────┼──────────────────────────────┼─────────────────────────┐
│           ▼                              ▼                         │
│  ┌─────────────────┐    ┌────────────────────────┐                 │
│  │  Netdata         │    │  Prometheus (告警评估) │                 │
│  │  主机指标主采集   │───▶│  补充拉取 Netdata 指标  │                 │
│  │  CPU/内存/磁盘/   │    │  + Blackbox/PG/Push    │                 │
│  │  网络/进程/容器   │    └───────────┬────────────┘                 │
│  └─────────────────┘                │                              │
│                                     ▼                              │
│                          ┌────────────────────┐                    │
│                          │  Alertmanager      │                    │
│                          │  告警路由与通知      │                    │
│                          └────────────────────┘                    │
│                                                                    │
│  ┌────────────┐  ┌──────────────┐  ┌──────────────┐               │
│  │ Blackbox   │  │ PG Exporter  │  │ Pushgateway  │               │
│  │ HTTP/TCP/  │  │ PostgreSQL   │  │ 临时任务指标  │               │
│  │ ICMP 探测   │  │ 指标采集     │  │              │               │
│  └────────────┘  └──────────────┘  └──────────────┘               │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  Loki (日志聚合) ← Promtail (宿主+容器日志采集)                │ │
│  └──────────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────┘
```

## 组件

| 服务 | 端口 | 说明 |
|------|------|------|
| **Netdata** | **19999** | **主机指标主采集 + Web 实时看板** |
| Prometheus | 9090 | 补充指标拉取 + 告警规则评估 |
| Alertmanager | 9093 | 告警路由与通知分发 |
| Grafana | 3000 | 统一看板 (日志/PG/探测) |
| Loki | 3100 | 日志聚合 |
| Promtail | 9080 | 日志采集 |
| Blackbox Exporter | 9115 | HTTP/TCP/ICMP 探测 |
| PostgreSQL Exporter | 9187 | PG 指标 |
| Pushgateway | 9091 | 临时指标推送 |
| ~~Node Exporter~~ | ~~9100~~ | **已由 Netdata 替代 (注释备用)** |

## 职责分工

| 职责 | 组件 | 说明 |
|------|------|------|
| 主机指标采集 | **Netdata** | CPU/内存/磁盘/网络/进程/容器, 秒级粒度 |
| 主机实时看板 | **Netdata Web (:19999)** | 无需登录, 实时秒级图表 |
| 补充指标 (探测/PG/临时) | **Prometheus** | 拉取 Netdata + Blackbox + PG + Pushgateway |
| 告警评估 | **Prometheus** | 基于 Netdata 指标的告警规则 |
| 告警路由与通知 | **Alertmanager** | 分组/抑制/多级路由/多通道通知 |
| 统一看板 | **Grafana (:3000)** | 日志/PG/探测/自定义 Dashboard |
| Netdata 自身告警 | Netdata health.d | 补充通道, 在 Netdata Web 可见告警状态 |

## 部署步骤

### 1. 导入离线镜像
```bash
docker load -i ai-ops-monitor-images.tar
```

### 2. 修改配置
- 编辑 `.env` 修改密码、外部地址
- 编辑 `netdata/health_alarm_notify.conf` 修改 Netdata 通知渠道 (Webhook/邮件/钉钉)
- 编辑 `prometheus/prometheus.yml` 修改 Blackbox 探测目标
- 编辑 `alertmanager/alertmanager.yml` 修改告警接收端

### 3. 一键部署
```bash
chmod +x deploy.sh
./deploy.sh ai-ops-monitor-images.tar
```

或手动启动：
```bash
cd /data/ai-ops-monitor
docker compose --env-file .env up -d
```

## 告警规则

### Prometheus 告警 (由 Alertmanager 分发)
- `host-resources.yml` - CPU/内存/磁盘/负载/inode (基于 Netdata 指标)
- `network.yml` - 主机宕机/HTTP 探测/SSL 证书/TCP 端口/ICMP/网卡错误
- `services.yml` - Netdata/Prometheus/Alertmanager/Grafana/Loki 等组件健康
- `postgres.yml` - 数据库连接数/慢查询/死锁/复制延迟

### Netdata 告警 (在 Netdata Web :19999 可见)
- `health.d/cpu.conf` - CPU 使用率/steal
- `health.d/memory.conf` - 内存/Swap/OOM Kill
- `health.d/disk.conf` - 磁盘空间/inode/IO
- `health.d/network.conf` - 网卡速率/错误包/丢包
- `health.d/system.conf` - 系统负载

## 运维操作

```bash
# 重载 Prometheus 配置（无需重启）
curl -X POST http://localhost:9090/-/reload

# 重载 Netdata 告警配置（无需重启）
docker exec ai-ops-netdata netdatacli reload-health

# 查看告警状态
curl http://localhost:9090/api/v1/alerts

# 查看服务日志
docker compose logs -f netdata
docker compose logs -f prometheus

# 停止所有服务
docker compose down

# 升级（拉新镜像后）
docker compose up -d
```

## 推荐 Grafana Dashboard

在 Grafana 中手动导入以下 Dashboard ID：
- **11074** - Netdata (官方推荐)
- **1860** - Node Exporter Full (如恢复 node-exporter)
- **9628** - PostgreSQL Database
- **13639** - Loki Logs
- **15983** - Blackbox Exporter

## 注意事项

1. **密码修改**: 部署前务必修改 `.env` 中的所有默认密码
2. **外部地址**: 替换 `prometheus.yml` 和 `alertmanager.yml` 中的占位地址
3. **PostgreSQL**: 在被监控的 PG 中创建 `postgres_exporter` 用户并赋权
4. **Netdata 配置**: 修改 `netdata/health_alarm_notify.conf` 配置通知渠道, 否则告警无法发出
5. **Netdata 权限**: 需要 `SYS_PTRACE` 和 `SYS_ADMIN` 权限
6. **Node Exporter**: 已注释, 如需恢复取消注释 docker-compose.yml + prometheus.yml 中对应部分
7. **日志保留**: Loki 默认 30 天, Prometheus 默认 90 天, Netdata dbengine 默认 512MB
