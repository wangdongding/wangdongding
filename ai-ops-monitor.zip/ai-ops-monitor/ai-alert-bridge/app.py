#!/usr/bin/env python3
"""
AI 告警分析桥接服务
Alertmanager → 本服务 → ① 原样转发 dingtalk-bridge（告警秒到）
                       → ② 调 OpenOcta 数字员工分析 → 通过 dingtalk-bridge 发第二条消息

注意: 纯内网环境无法直连 oapi.dingtalk.com，AI 分析消息也走 dingtalk-bridge 转发
"""
import asyncio
import hashlib
import hmac
import base64
import urllib.parse
import time
import json
import logging
import os

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import httpx

# ─────────── 日志 ───────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("ai-alert-bridge")

app = FastAPI(title="AI Alert Bridge")

# ─────────── 配置（优先读环境变量，缺省用硬编码） ───────────
OPENOCTA_URL = os.getenv("OPENOCTA_URL", "http://172.17.3.179:18900/openocta/open/v1/completion")
OPENOCTA_API_KEY = os.getenv("OPENOCTA_API_KEY", "octa_92e72a1f764b425824186b1b08985ecefd72b71e1a099628")
OPENOCTA_MODEL = os.getenv("OPENOCTA_MODEL", "vllm/glm-5.1")
OPENOCTA_TIMEOUT = int(os.getenv("OPENOCTA_TIMEOUT", "120"))

DINGTALK_BRIDGE_URL = os.getenv("DINGTALK_BRIDGE_URL", "http://172.17.47.137:8060/dingtalk/monitor/send")

LISTEN_PORT = int(os.getenv("LISTEN_PORT", "8070"))


# ═══════════════════════════════════════════════════
#  主入口
# ═══════════════════════════════════════════════════
@app.post("/alert")
async def handle_alert(request: Request):
    payload = await request.json()
    logger.info("收到 Alertmanager 告警, status=%s, alerts=%d",
                payload.get("status"), len(payload.get("alerts", [])))

    if payload.get("status") == "firing":
        # firing: 等 AI 分析后发合并消息（告警+分析），不单独转发原始告警
        asyncio.create_task(_analyze_and_notify(payload))
    else:
        # resolved: 直接转发原始恢复消息到 dingtalk-bridge，无需 AI 分析
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(DINGTALK_BRIDGE_URL, json=payload, timeout=10)
                logger.info("转发恢复消息 → dingtalk-bridge, status=%d", resp.status_code)
        except Exception as e:
            logger.error("转发恢复消息失败: %s", e)

    return JSONResponse({"status": "ok"}, status_code=200)


# ═══════════════════════════════════════════════════
#  AI 分析 + 发钉钉（合并分析，prompt 强约束分条格式）
# ═══════════════════════════════════════════════════
async def _analyze_and_notify(payload: dict):
    alerts = payload.get("alerts", [])
    if not alerts:
        logger.warning("告警列表为空，跳过")
        return

    alert_text = _format_alert(payload)
    try:
        analysis = await _call_openocta(alert_text, len(alerts))
        logger.info("AI 分析完成, 长度=%d", len(analysis))
    except Exception as e:
        analysis = f"AI 分析失败: {e}"
        logger.error("AI 分析异常: %s", e)

    # 标题汇总
    severity_order = {"critical": 3, "warning": 2, "info": 1}
    max_severity = "info"
    alert_names = []
    for a in alerts:
        lbl = a.get("labels", {})
        name = lbl.get("alertname", "Unknown")
        if name not in alert_names:
            alert_names.append(name)
        sev = lbl.get("severity", "info")
        if severity_order.get(sev, 0) > severity_order.get(max_severity, 0):
            max_severity = sev

    if len(alert_names) == 1:
        title_name = alert_names[0]
    elif len(alert_names) <= 3:
        title_name = "+".join(alert_names)
    else:
        title_name = f"{len(alert_names)}条告警"

    fake_payload = {
        "status": "firing",
        "alerts": [
            {
                "status": "firing",
                "labels": {
                    "alertname": f"AI分析-{title_name}",
                    "instance": "multi" if len(alerts) > 1 else (alerts[0].get("labels", {}).get("instance", "Unknown")),
                    "severity": max_severity,
                    "category": "ai-analysis",
                },
                "annotations": {
                    "summary": f"AI 告警分析: {title_name}",
                    "description": f"📋 原始告警\n{alert_text}\n\n🤖 AI 分析\n{analysis}",
                },
                "startsAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }
        ],
        "groupLabels": {"alertname": f"AI分析-{title_name}"},
        "commonLabels": {
            "alertname": f"AI分析-{title_name}",
            "severity": max_severity,
            "category": "ai-analysis",
        },
        "commonAnnotations": {
            "summary": f"AI 告警分析: {title_name}",
            "description": f"📋 原始告警\n{alert_text}\n\n🤖 AI 分析\n{analysis}",
        },
        "externalURL": "",
        "version": "4",
        "receiver": "ai-analysis",
    }

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(DINGTALK_BRIDGE_URL, json=fake_payload, timeout=10)
            resp.raise_for_status()
            logger.info("AI 分析消息发送完成, response=%s", resp.text[:200])
    except Exception as e:
        logger.error("发送 AI 分析到钉钉失败: %s", e)


def _format_alert(payload: dict) -> str:
    """把 Alertmanager webhook payload 格式化为可读文本"""
    status = payload.get("status", "unknown")
    alerts = payload.get("alerts", [])
    lines = []
    for i, alert in enumerate(alerts, 1):
        labels = alert.get("labels", {})
        annotations = alert.get("annotations", {})
        lines.append(f"[告警{i}] {labels.get('alertname', 'Unknown')} | {labels.get('instance', 'Unknown')} | {labels.get('severity', 'Unknown')}")
        lines.append(f"  描述: {annotations.get('description', 'N/A')}")
    lines.append(f"状态: {status}")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════
#  OpenOcta 数字员工调用
# ═══════════════════════════════════════════════════
MAX_RETRIES = 2

async def _call_openocta(alert_text: str, alert_count: int = 1) -> str:
    """调用 OpenOcta 数字员工进行 AI 分析（非流式 + 重试 + 详细日志）"""
    if alert_count == 1:
        prompt = (
            "你是运维告警分析助手。严格只分析以下告警，禁止编造或联想未提及的告警名称：\n\n"
            f"{alert_text}\n\n"
            "要求：\n"
            "- 只针对上面给出的告警分析，不得出现其他告警名称\n"
            "- 总字数控制在300字以内，精炼不啰嗦\n"
            "- 可用表格，但行数不超过5行\n"
            "- 排查命令用代码块，每个命令一行，不超过3条\n"
            "- 格式：\n"
            "🔍 可能原因（表格：优先级 | 原因 | 一句话依据）\n"
            "🔧 排查建议（代码块，仅关键命令）\n"
            "⚡ 紧急程度：高/中/低 + 一句话理由"
        )
    else:
        prompt = (
            f"你是运维告警分析助手。收到以下{alert_count}条监控告警，请逐条简洁分析。\n"
            "⚠️ 严格只分析下面列出的告警，禁止编造或联想未提及的告警名称：\n\n"
            f"{alert_text}\n\n"
            "严格按以下格式输出，每条告警一个区块，用编号分隔：\n"
            "━━━ 告警1：{上面给出的告警名称} ━━━\n"
            "🔍 可能原因（表格：优先级 | 原因 | 一句话依据，不超过3行）\n"
            "🔧 排查建议（代码块，仅关键命令，不超过2条）\n"
            "⚡ 紧急程度：高/中/低 + 一句话理由\n"
            "━━━ 告警2：{上面给出的告警名称} ━━━\n"
            "（同上格式）\n\n"
            "要求：\n"
            "- 每条告警控制在200字以内\n"
            "- 不要输出总览/总结，直接分条\n"
            "- 不要重复原始告警信息\n"
            "- 告警名称必须与上面给出的一致，不得自行编造"
        )

    headers = {
        "Authorization": f"Bearer {OPENOCTA_API_KEY}",
        "Content-Type": "application/json",
    }
    body = {
        "model": OPENOCTA_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
    }

    last_err = None
    for attempt in range(1, MAX_RETRIES + 1):
        logger.info("[OpenOcta] 第 %d/%d 次调用, url=%s, model=%s, timeout=%ds, prompt长度=%d",
                    attempt, MAX_RETRIES, OPENOCTA_URL, OPENOCTA_MODEL, OPENOCTA_TIMEOUT, len(prompt))
        t0 = time.time()
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(OPENOCTA_URL, headers=headers, json=body, timeout=OPENOCTA_TIMEOUT)
            elapsed = time.time() - t0
            logger.info("[OpenOcta] 响应状态=%d, 耗时=%.1fs, body长度=%d",
                        resp.status_code, elapsed, len(resp.text))
            if resp.status_code >= 400:
                logger.error("[OpenOcta] 错误响应: status=%d, body=%s", resp.status_code, resp.text[:500])
                resp.raise_for_status()
            data = resp.json()
            logger.info("[OpenOcta] 返回结构 keys=%s", list(data.keys()))
            # 兼容 OpenOcta 多种返回格式
            if "choices" in data:
                content = data["choices"][0].get("message", {}).get("content", "")
                if content:
                    logger.info("[OpenOcta] 解析成功(choices), 内容长度=%d", len(content))
                    return content
            if "output" in data:
                logger.info("[OpenOcta] 解析成功(output), 内容长度=%d", len(str(data["output"])))
                return data["output"]
            if "content" in data:
                logger.info("[OpenOcta] 解析成功(content), 内容长度=%d", len(str(data["content"])))
                return data["content"]
            logger.warning("[OpenOcta] 未识别的返回格式, 原始数据: %s", json.dumps(data, ensure_ascii=False)[:500])
            return json.dumps(data, ensure_ascii=False)[:500]
        except httpx.RemoteProtocolError as e:
            elapsed = time.time() - t0
            last_err = e
            logger.error("[OpenOcta] 连接断开(第%d次), 耗时=%.1fs, 错误: %s", attempt, elapsed, e)
        except httpx.ReadTimeout as e:
            elapsed = time.time() - t0
            last_err = e
            logger.error("[OpenOcta] 读取超时(第%d次), 耗时=%.1fs, timeout=%ds", attempt, elapsed, OPENOCTA_TIMEOUT)
        except httpx.HTTPStatusError as e:
            elapsed = time.time() - t0
            last_err = e
            logger.error("[OpenOcta] HTTP错误(第%d次), 耗时=%.1fs, status=%d", attempt, elapsed, e.response.status_code)
            # 4xx 错误不重试
            if 400 <= e.response.status_code < 500:
                raise
        except Exception as e:
            elapsed = time.time() - t0
            last_err = e
            logger.error("[OpenOcta] 未知异常(第%d次), 耗时=%.1fs, 类型=%s: %s", attempt, elapsed, type(e).__name__, e)

        if attempt < MAX_RETRIES:
            wait = 3 * attempt
            logger.info("[OpenOcta] 等待 %ds 后重试...", wait)
            await asyncio.sleep(wait)

    raise last_err or RuntimeError("OpenOcta 调用失败，未知原因")





# ═══════════════════════════════════════════════════
#  健康检查
# ═══════════════════════════════════════════════════
@app.get("/health")
async def health():
    return {"status": "ok"}


# ═══════════════════════════════════════════════════
#  启动
# ═══════════════════════════════════════════════════
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=LISTEN_PORT)
